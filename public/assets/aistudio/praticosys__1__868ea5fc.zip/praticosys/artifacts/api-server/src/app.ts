import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { sessionAuth } from "./middleware/session";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use('/api/backups', express.json({ limit: '8mb', inflate: false }));
app.use(express.json({ limit: '128kb', inflate: false }));
app.use(express.urlencoded({ extended: true }));

// Validação de sessão em todas as rotas (exceto as públicas)
app.use("/api", sessionAuth);
app.use("/api", router);

export default app;
