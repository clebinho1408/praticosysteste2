
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { User, UserRole, OperatorModule } from '../types';
import { Logo } from './Logo';
import { ForcePasswordChangeModal } from './ForcePasswordChangeModal';
import { 
  LayoutDashboard,
  FileText, 
  Users, 
  Settings, 
  LogOut, 
  CalendarCheck,
  Menu,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  ChevronDown,
  ChevronRight,
  Map,
  Car,
  Accessibility,
  BarChart3
} from 'lucide-react';

interface SubItem {
  label: string;
  path: string;
  icon?: React.ElementType;
}

interface NavItem {
  icon: React.ElementType;
  label: string;
  path?: string;
  subItems?: SubItem[];
  roles?: UserRole[];
}

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
}

const formatSidebarLabel = (value: string) => {
  const normalized = value.trim().toLocaleLowerCase('pt-BR');
  if (!normalized) return value;
  const [firstCharacter, ...remainingCharacters] = normalized;
  return firstCharacter.toLocaleUpperCase('pt-BR') + remainingCharacters.join('');
};

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({});
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    try {
      return window.localStorage.getItem('praticosys-sidebar-collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [showForcePassword, setShowForcePassword] = useState(!!user.forcePasswordChange);

  useEffect(() => {
    setShowForcePassword(!!user.forcePasswordChange);
  }, [user.forcePasswordChange]);

  const getRoleLabel = (role: string) => {
    switch(role) {
      case UserRole.ADMIN: return 'Administrador';
      case UserRole.SUPERVISOR: return 'Supervisor';
      case UserRole.OPERATOR: return 'Operador';
      case UserRole.CONSULTANT: return 'Consultor';
      case UserRole.SCHOOL: return 'Autoescola';
      case UserRole.EXAMINER: return 'Examinador';
      case UserRole.INSTRUCTOR: return 'Instrutor';
      default: return role;
    }
  };

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  const isActive = (path: string) => location.pathname === path;
  const isParentActive = (item: NavItem) => {
    if (item.path && isActive(item.path)) return true;
    return item.subItems?.some(sub => isActive(sub.path));
  };

  const toggleMenu = (label: string) => {
    setOpenMenus(prev => {
      const isCurrentlyOpen = !!prev[label];
      // Close all menus, then toggle the clicked one (auto-close others)
      return { [label]: !isCurrentlyOpen };
    });
  };

  const toggleSidebarCollapsed = () => {
    setIsSidebarCollapsed(current => {
      const next = !current;
      try {
        window.localStorage.setItem('praticosys-sidebar-collapsed', String(next));
      } catch {
        // Keep the toggle usable even when browser storage is unavailable.
      }
      return next;
    });
  };

  // Auto-expand menu if a sub-item is active on load
  useEffect(() => {
    const navItems = getNavItems();
    const newOpenMenus: Record<string, boolean> = {};
    navItems.forEach(item => {
      if (item.subItems?.some(sub => isActive(sub.path))) {
        newOpenMenus[item.label] = true;
      }
    });
    if (Object.keys(newOpenMenus).length > 0) {
      setOpenMenus(prev => ({ ...prev, ...newOpenMenus }));
    }
    // Close mobile menu on route change
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const getNavItems = (): NavItem[] => {
    const items: NavItem[] = [];

    if (user.role === UserRole.SCHOOL) {
       items.push({
         icon: Car,
         label: 'Exame Prático CFC',
         subItems: [
           { label: 'Dashboard',      path: '/admin/cfc/dashboard',    icon: LayoutDashboard },
           { label: 'Pedidos',   path: '/admin/cfc/agendamentos', icon: CalendarCheck }
         ]
       });
    } else if (user.role === UserRole.EXAMINER) {
       items.push({
         icon: CalendarCheck,
         label: 'Agendamentos',
         path: '/admin/cfc/agendamentos'
       });
    } else if (user.role === UserRole.INSTRUCTOR) {
       items.push({
         icon: FileText,
         label: 'Candidatos',
         path: '/admin/cnhdobrasil/candidatos'
       });
    } else {

       // Operador e Supervisor respeitam a seleção de módulos permitidos
       const isOperator = user.role === UserRole.OPERATOR;
       const hasModuleRestrictions = isOperator || user.role === UserRole.SUPERVISOR;
       const allowed: OperatorModule[] = (hasModuleRestrictions && user.allowedModules && user.allowedModules.length > 0)
         ? user.allowedModules
         : ['cnh', 'cfc', 'pcd'];

       // --- PAINEL DE CONTROLE GERAL (only for non-operator or operators with all 3 modules) ---
       if (!hasModuleRestrictions) {
         items.push({
           icon: LayoutDashboard,
           label: 'Painel de Controle',
           path: '/admin/dashboard'
         });
       }

       // --- GRUPO: CNH DO BRASIL ---
       if (!hasModuleRestrictions || allowed.includes('cnh')) {
         items.push({
           icon: Map,
           label: 'CNH do Brasil',
           subItems: [
             { label: 'Dashboard',    path: '/admin/cnhdobrasil/dashboard',   icon: LayoutDashboard },
             { label: 'Bancas',       path: '/admin/cnhdobrasil/bancas',      icon: CalendarCheck },
             { label: 'Candidatos',   path: '/admin/cnhdobrasil/candidatos',  icon: FileText },
             { label: 'Relatórios',   path: '/admin/cnhdobrasil/relatorios',  icon: BarChart3 }
           ]
         });
       }

       // --- GRUPO: PROVA PRÁTICA CFC ---
       if (!hasModuleRestrictions || allowed.includes('cfc')) {
         items.push({
           icon: Car,
           label: 'Exame Prático CFC',
           subItems: [
             { label: 'Dashboard',    path: '/admin/cfc/dashboard',    icon: LayoutDashboard },
             { label: 'Agendamentos', path: '/admin/cfc/agendamentos', icon: CalendarCheck },
             { label: 'Relatórios',   path: '/admin/cfc/relatorios',   icon: BarChart3 }
           ]
         });
       }

       // --- GRUPO: PROVA PRÁTICA PCD ---
       if (!hasModuleRestrictions || allowed.includes('pcd')) {
         items.push({
           icon: Accessibility,
           label: 'Exame Prático PCD',
           subItems: [
             { label: 'Dashboard',    path: '/admin/pcd/dashboard',    icon: LayoutDashboard },
             { label: 'Agendamentos', path: '/admin/pcd/agendamentos', icon: CalendarCheck },
             { label: 'Candidatos',   path: '/admin/pcd/candidatos',   icon: FileText },
             { label: 'Relatórios',   path: '/admin/pcd/relatorios',   icon: BarChart3 }
           ]
         });
       }
    }

    if (user.role === UserRole.ADMIN || user.role === UserRole.SUPERVISOR) {
      items.push({ icon: Users, label: 'Cadastros', path: '/admin/usuarios' });
    }
    if (user.role === UserRole.ADMIN) {
      items.push({ icon: Settings, label: 'Configurações', path: '/admin/configuracoes' });
    }

    return items;
  };

  const SidebarContent = ({ isMobile = false }: { isMobile?: boolean }) => {
    const isCollapsed = !isMobile && isSidebarCollapsed;

    return (
    <div className="flex flex-col h-full overflow-hidden bg-slate-900">
      <div className={`h-16 flex items-center gap-3 border-b border-slate-800 bg-slate-900 shrink-0 ${isCollapsed ? 'justify-center px-2' : 'px-6'}`}>
        <div className="bg-white/10 p-1.5 rounded-lg shrink-0">
          <Logo className="h-6 w-6" />
        </div>
        {!isCollapsed && <span className="text-lg font-bold text-white tracking-tight">PráticoSys</span>}
        {isMobile && (
        <button
          type="button"
          aria-label="Fechar menu"
          onClick={() => setIsMobileMenuOpen(false)}
          className="md:hidden ml-auto text-slate-400 p-2 hover:bg-slate-800 rounded-lg"
        >
           <X className="h-6 w-6" />
        </button>
        )}
      </div>

      <nav
        id={isMobile ? 'mobile-primary-navigation' : 'desktop-primary-navigation'}
        aria-label="Menu principal"
        className={`flex-1 space-y-2 overflow-y-auto custom-scrollbar ${isCollapsed ? 'p-2' : 'p-4'}`}
      >
        {getNavItems().map((item) => {
          const hasSubmenu = !!item.subItems;
          const isOpen = openMenus[item.label];
          const activeParent = isParentActive(item);

          return (
            <div key={item.label} className="space-y-1">
              {hasSubmenu ? (
                <button
                  type="button"
                  title={isCollapsed ? item.label : undefined}
                  aria-label={item.label}
                  aria-expanded={isCollapsed ? undefined : isOpen}
                  onClick={() => {
                    if (isCollapsed) {
                      setIsSidebarCollapsed(false);
                      try {
                        window.localStorage.setItem('praticosys-sidebar-collapsed', 'false');
                      } catch {
                        // Keep navigation usable when browser storage is unavailable.
                      }
                      setOpenMenus({ [item.label]: true });
                    } else {
                      toggleMenu(item.label);
                    }
                  }}
                  className={`w-full flex items-center rounded-xl text-sm font-bold transition-all duration-200 group ${
                    isCollapsed ? 'justify-center px-2 py-3' : 'justify-between px-4 py-3'
                  } ${
                    activeParent ? 'bg-slate-800/80 text-blue-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className={`flex items-center ${isCollapsed ? '' : 'gap-3'}`}>
                    <item.icon className={`h-5 w-5 transition-colors ${activeParent ? 'text-blue-400' : 'text-slate-500 group-hover:text-white'}`} />
                    {!isCollapsed && <span>{item.label}</span>}
                  </div>
                  {!isCollapsed && (isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />)}
                </button>
              ) : (
                <Link
                  to={item.path!}
                  title={isCollapsed ? item.label : undefined}
                  aria-label={isCollapsed ? item.label : undefined}
                  className={`flex items-center rounded-xl text-sm font-bold transition-all duration-200 group ${
                    isCollapsed ? 'justify-center px-2 py-3' : 'gap-3 px-4 py-3'
                  } ${
                    isActive(item.path!)
                      ? 'bg-blue-600 text-white shadow-xl shadow-blue-900/40'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <item.icon className={`h-5 w-5 transition-colors ${isActive(item.path!) ? 'text-white' : 'text-slate-500 group-hover:text-white'}`} />
                  {!isCollapsed && <span>{item.label}</span>}
                </Link>
              )}

              {!isCollapsed && hasSubmenu && isOpen && (
                <div className="ml-4 pl-4 border-l border-slate-800 space-y-1 animate-fadeIn">
                  {item.subItems!.map((sub) => (
                    <Link
                      key={sub.path}
                      to={sub.path}
                      className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-sm font-bold tracking-tight transition-all duration-200 ${
                        isActive(sub.path)
                          ? 'text-blue-400 bg-blue-400/10'
                          : 'text-slate-500 hover:text-slate-200 hover:bg-slate-800/40'
                      }`}
                    >
                      {sub.icon && <sub.icon className="h-4 w-4 opacity-70" />}
                      {sub.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>
      
      <div className={`${isCollapsed ? 'p-2' : 'p-4'} border-t border-slate-800 bg-slate-900/50 shrink-0`}>
        <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
          <div className="h-9 w-9 bg-slate-700 text-slate-200 rounded-xl flex items-center justify-center font-semibold text-sm border border-slate-600 shrink-0">
            {formatSidebarLabel(user.name).charAt(0)}
          </div>
          {!isCollapsed && <div className="min-w-0">
            <p className="text-sm font-semibold text-white leading-tight normal-case tracking-normal truncate">{formatSidebarLabel(user.name)}</p>
            <p className="text-[10px] text-blue-400 font-medium normal-case tracking-normal opacity-80">{formatSidebarLabel(getRoleLabel(user.role))}</p>
          </div>}
        </div>
      </div>
    </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row print:bg-white h-screen overflow-hidden print:h-auto print:overflow-visible">
      {showForcePassword && (
        <ForcePasswordChangeModal 
          user={user} 
          onSuccess={() => window.location.reload()}
        />
      )}
      
      {/* Sidebar Desktop */}
      <aside className={`hidden md:flex ${isSidebarCollapsed ? 'w-16' : 'w-64'} bg-slate-900 border-r border-slate-800 flex-col flex-shrink-0 print:hidden z-20 transition-[width] duration-200 ease-in-out`}>
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      <div className={`md:hidden fixed inset-0 z-[100] transition-all duration-300 ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setIsMobileMenuOpen(false)}></div>
          <aside className={`absolute top-0 left-0 h-full w-72 bg-slate-900 shadow-2xl transition-transform duration-300 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
              <SidebarContent isMobile />
          </aside>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-0 min-w-0 overflow-hidden bg-gray-50 print:h-auto print:overflow-visible">
        <header className="h-16 bg-white border-b border-gray-200 flex justify-between items-center px-4 md:px-8 print:hidden shadow-sm z-10 shrink-0">
            <div className="flex items-center gap-4">
                <button
                    type="button"
                    aria-label={isSidebarCollapsed ? 'Expandir menu lateral' : 'Recolher menu lateral'}
                    aria-controls="desktop-primary-navigation"
                    aria-expanded={!isSidebarCollapsed}
                    title={isSidebarCollapsed ? 'Expandir menu lateral' : 'Recolher menu lateral'}
                    onClick={toggleSidebarCollapsed}
                    className="hidden md:flex text-slate-500 p-2 hover:bg-slate-50 hover:text-blue-600 rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                >
                    {isSidebarCollapsed ? <PanelLeftOpen className="h-5 w-5" /> : <PanelLeftClose className="h-5 w-5" />}
                </button>
                <button onClick={() => setIsMobileMenuOpen(true)} className="md:hidden text-slate-500 p-2 hover:bg-slate-50 rounded-xl transition-colors">
                    <Menu className="h-6 w-6" />
                </button>
                <div className="hidden md:block">
                   <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">
                      {location.pathname.includes('cnhdobrasil/bancas') ? 'CNH do Brasil — Bancas' :
                       location.pathname.includes('cnhdobrasil/candidatos') ? 'CNH do Brasil — Candidatos' :
                       location.pathname.includes('cnhdobrasil/relatorios') ? 'CNH do Brasil — Relatórios' :
                       location.pathname.includes('cnhdobrasil/dashboard') ? 'CNH do Brasil — Dashboard' :
                       location.pathname.includes('cnhdobrasil') ? 'CNH do Brasil' :
                       location.pathname.includes('cfc/agendamentos') ? (user.role === UserRole.SCHOOL ? 'Exame Prático CFC — Pedidos' : 'Exame Prático CFC — Agendamentos') :
                       location.pathname.includes('cfc/relatorios') ? 'Exame Prático CFC — Relatórios' :
                       location.pathname.includes('cfc/dashboard') ? 'Exame Prático CFC — Dashboard' :
                       location.pathname.includes('pcd/agendamentos') ? 'Exame Prático PCD — Agendamentos' :
                       location.pathname.includes('pcd/candidatos') ? 'Exame Prático PCD — Candidatos' :
                       location.pathname.includes('pcd/relatorios') ? 'Exame Prático PCD — Relatórios' :
                       location.pathname.includes('pcd/dashboard') ? 'Exame Prático PCD — Dashboard' :
                       location.pathname.includes('usuarios') ? 'Administração' :
                       location.pathname.includes('configuracoes') ? 'Configurações' :
                       location.pathname === '/admin/dashboard' ? 'Painel de Controle' : 'Painel Principal'}
                   </h2>
                </div>
            </div>

            <div className="flex items-center gap-2">
                {/* Avatar — apenas mobile (desktop tem no sidebar) */}
                <div className="md:hidden h-9 w-9 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center font-black text-sm border border-slate-200 shadow-sm">
                    {user.name.charAt(0)}
                </div>
                {/* Botão Sair — visível em todos os tamanhos */}
                <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 text-slate-400 hover:text-red-600 hover:bg-red-50 p-2 md:px-3 md:py-2 rounded-xl transition-all text-xs font-black uppercase tracking-wider"
                >
                    <LogOut className="h-4 w-4" />
                    <span className="hidden md:inline">Sair</span>
                </button>
            </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-gray-50/50 p-4 md:p-8 print:p-0 print:bg-white relative custom-scrollbar print:overflow-visible print:h-auto">
          <div className="absolute top-0 left-0 w-full h-48 bg-gradient-to-b from-blue-100/20 to-transparent -z-10 pointer-events-none"></div>
          <div className="max-w-7xl mx-auto print:max-w-none">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
