var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to2, from, except2, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key) && key !== except2)
        __defProp(to2, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../node_modules/.pnpm/@neondatabase+serverless@0.10.4/node_modules/@neondatabase/serverless/index.mjs
function $e(r) {
  let e = 1779033703, t = 3144134277, n = 1013904242, i = 2773480762, s = 1359893119, o = 2600822924, u = 528734635, c = 1541459225, h = 0, l = 0, d = [
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ], b = a(
    (A, g) => A >>> g | A << 32 - g,
    "rrot"
  ), C = new Uint32Array(64), B = new Uint8Array(64), Q = a(() => {
    for (let R = 0, $ = 0; R < 16; R++, $ += 4) C[R] = B[$] << 24 | B[$ + 1] << 16 | B[$ + 2] << 8 | B[$ + 3];
    for (let R = 16; R < 64; R++) {
      let $ = b(C[R - 15], 7) ^ b(C[R - 15], 18) ^ C[R - 15] >>> 3, ce = b(C[R - 2], 17) ^ b(C[R - 2], 19) ^ C[R - 2] >>> 10;
      C[R] = C[R - 16] + $ + C[R - 7] + ce | 0;
    }
    let A = e, g = t, P = n, K = i, k = s, j = o, ee = u, oe = c;
    for (let R = 0; R < 64; R++) {
      let $ = b(
        k,
        6
      ) ^ b(k, 11) ^ b(k, 25), ce = k & j ^ ~k & ee, ye = oe + $ + ce + d[R] + C[R] | 0, Se = b(A, 2) ^ b(A, 13) ^ b(A, 22), je = A & g ^ A & P ^ g & P, he = Se + je | 0;
      oe = ee, ee = j, j = k, k = K + ye | 0, K = P, P = g, g = A, A = ye + he | 0;
    }
    e = e + A | 0, t = t + g | 0, n = n + P | 0, i = i + K | 0, s = s + k | 0, o = o + j | 0, u = u + ee | 0, c = c + oe | 0, l = 0;
  }, "process"), X = a((A) => {
    typeof A == "string" && (A = new TextEncoder().encode(A));
    for (let g = 0; g < A.length; g++) B[l++] = A[g], l === 64 && Q();
    h += A.length;
  }, "add"), de = a(() => {
    if (B[l++] = 128, l == 64 && Q(), l + 8 > 64) {
      for (; l < 64; ) B[l++] = 0;
      Q();
    }
    for (; l < 58; ) B[l++] = 0;
    let A = h * 8;
    B[l++] = A / 1099511627776 & 255, B[l++] = A / 4294967296 & 255, B[l++] = A >>> 24, B[l++] = A >>> 16 & 255, B[l++] = A >>> 8 & 255, B[l++] = A & 255, Q();
    let g = new Uint8Array(32);
    return g[0] = e >>> 24, g[1] = e >>> 16 & 255, g[2] = e >>> 8 & 255, g[3] = e & 255, g[4] = t >>> 24, g[5] = t >>> 16 & 255, g[6] = t >>> 8 & 255, g[7] = t & 255, g[8] = n >>> 24, g[9] = n >>> 16 & 255, g[10] = n >>> 8 & 255, g[11] = n & 255, g[12] = i >>> 24, g[13] = i >>> 16 & 255, g[14] = i >>> 8 & 255, g[15] = i & 255, g[16] = s >>> 24, g[17] = s >>> 16 & 255, g[18] = s >>> 8 & 255, g[19] = s & 255, g[20] = o >>> 24, g[21] = o >>> 16 & 255, g[22] = o >>> 8 & 255, g[23] = o & 255, g[24] = u >>> 24, g[25] = u >>> 16 & 255, g[26] = u >>> 8 & 255, g[27] = u & 255, g[28] = c >>> 24, g[29] = c >>> 16 & 255, g[30] = c >>> 8 & 255, g[31] = c & 255, g;
  }, "digest");
  return r === void 0 ? { add: X, digest: de } : (X(r), de());
}
function Yo(r) {
  return w.getRandomValues(y.alloc(r));
}
function Zo(r) {
  if (r === "sha256") return { update: a(
    function(e) {
      return { digest: a(function() {
        return y.from($e(e));
      }, "digest") };
    },
    "update"
  ) };
  if (r === "md5") return { update: a(function(e) {
    return { digest: a(function() {
      return typeof e == "string" ? Ve.hashStr(e) : Ve.hashByteArray(e);
    }, "digest") };
  }, "update") };
  throw new Error(
    `Hash type '${r}' not supported`
  );
}
function Jo(r, e) {
  if (r !== "sha256") throw new Error(
    `Only sha256 is supported (requested: '${r}')`
  );
  return { update: a(function(t) {
    return {
      digest: a(function() {
        typeof e == "string" && (e = new TextEncoder().encode(e)), typeof t == "string" && (t = new TextEncoder().encode(t));
        let n = e.length;
        if (n > 64) e = $e(e);
        else if (n < 64) {
          let c = new Uint8Array(64);
          c.set(e), e = c;
        }
        let i = new Uint8Array(64), s = new Uint8Array(
          64
        );
        for (let c = 0; c < 64; c++) i[c] = 54 ^ e[c], s[c] = 92 ^ e[c];
        let o = new Uint8Array(t.length + 64);
        o.set(i, 0), o.set(t, 64);
        let u = new Uint8Array(96);
        return u.set(s, 0), u.set(
          $e(o),
          64
        ), y.from($e(u));
      }, "digest")
    };
  }, "update") };
}
function cu(...r) {
  return r.join("/");
}
function hu(r, e) {
  e(new Error("No filesystem"));
}
function yr(r, e = false) {
  let { protocol: t } = new URL(r), n = "http:" + r.substring(t.length), {
    username: i,
    password: s,
    host: o,
    hostname: u,
    port: c,
    pathname: h,
    search: l,
    searchParams: d,
    hash: b
  } = new URL(n);
  s = decodeURIComponent(s), i = decodeURIComponent(
    i
  ), h = decodeURIComponent(h);
  let C = i + ":" + s, B = e ? Object.fromEntries(d.entries()) : l;
  return {
    href: r,
    protocol: t,
    auth: C,
    username: i,
    password: s,
    host: o,
    hostname: u,
    port: c,
    pathname: h,
    search: l,
    query: B,
    hash: b
  };
}
function ku(r) {
  return 0;
}
function pc({ socket: r, servername: e }) {
  return r.startTls(e), r;
}
function jc(r) {
  return r instanceof y ? "\\x" + r.toString("hex") : r;
}
function Xs(r, {
  arrayMode: e,
  fullResults: t,
  fetchOptions: n,
  isolationLevel: i,
  readOnly: s,
  deferrable: o,
  queryCallback: u,
  resultCallback: c,
  authToken: h
} = {}) {
  if (!r) throw new Error("No database connection string was provided to `neon()`. Perhaps an environment variable has not been set?");
  let l;
  try {
    l = yr(r);
  } catch {
    throw new Error("Database connection string provided to `neon()` is not a valid URL. Connection string: " + String(r));
  }
  let { protocol: d, username: b, hostname: C, port: B, pathname: Q } = l;
  if (d !== "postgres:" && d !== "postgresql:" || !b || !C || !Q) throw new Error("Database connection string format for `neon()` should be: postgresql://user:password@host.tld/dbname?option=value");
  function X(A, ...g) {
    let P, K;
    if (typeof A == "string") P = A, K = g[1], g = g[0] ?? [];
    else {
      P = "";
      for (let j = 0; j < A.length; j++)
        P += A[j], j < g.length && (P += "$" + (j + 1));
    }
    g = g.map((j) => jc((0, Zs.prepareValue)(j)));
    let k = {
      query: P,
      params: g
    };
    return u && u(k), Hc(de, k, K);
  }
  __name(X, "X");
  a(X, "resolve"), X.transaction = async (A, g) => {
    if (typeof A == "function" && (A = A(X)), !Array.isArray(A)) throw new Error(zs);
    A.forEach(
      (k) => {
        if (k[Symbol.toStringTag] !== "NeonQueryPromise") throw new Error(zs);
      }
    );
    let P = A.map((k) => k.parameterizedQuery), K = A.map((k) => k.opts ?? {});
    return de(P, K, g);
  };
  async function de(A, g, P) {
    let { fetchEndpoint: K, fetchFunction: k } = _e, j = Array.isArray(A) ? { queries: A } : A, ee = n ?? {}, oe = e ?? false, R = t ?? false, $ = i, ce = s, ye = o;
    P !== void 0 && (P.fetchOptions !== void 0 && (ee = {
      ...ee,
      ...P.fetchOptions
    }), P.arrayMode !== void 0 && (oe = P.arrayMode), P.fullResults !== void 0 && (R = P.fullResults), P.isolationLevel !== void 0 && ($ = P.isolationLevel), P.readOnly !== void 0 && (ce = P.readOnly), P.deferrable !== void 0 && (ye = P.deferrable)), g !== void 0 && !Array.isArray(
      g
    ) && g.fetchOptions !== void 0 && (ee = { ...ee, ...g.fetchOptions });
    let Se = h;
    !Array.isArray(
      g
    ) && g?.authToken !== void 0 && (Se = g.authToken);
    let je = typeof K == "function" ? K(C, B, { jwtAuth: Se !== void 0 }) : K, he = { "Neon-Connection-String": r, "Neon-Raw-Text-Output": "true", "Neon-Array-Mode": "true" }, it = await Gc(Se);
    it && (he.Authorization = `Bearer ${it}`), Array.isArray(
      A
    ) && ($ !== void 0 && (he["Neon-Batch-Isolation-Level"] = $), ce !== void 0 && (he["Neon-Batch-Read-Only"] = String(ce)), ye !== void 0 && (he["Neon-Batch-Deferrable"] = String(ye)));
    let te;
    try {
      te = await (k ?? fetch)(je, {
        method: "POST",
        body: JSON.stringify(j),
        headers: he,
        ...ee
      });
    } catch (W) {
      let H = new pe(`Error connecting to database: ${W.message}`);
      throw H.sourceError = W, H;
    }
    if (te.ok) {
      let W = await te.json();
      if (Array.isArray(A)) {
        let H = W.results;
        if (!Array.isArray(H)) throw new pe("Neon internal error: unexpected result format");
        return H.map((Ae, xe) => {
          let Lt = g[xe] ?? {}, ro = Lt.arrayMode ?? oe, no = Lt.fullResults ?? R;
          return Ys(Ae, {
            arrayMode: ro,
            fullResults: no,
            parameterizedQuery: A[xe],
            resultCallback: c,
            types: Lt.types
          });
        });
      } else {
        let H = g ?? {}, Ae = H.arrayMode ?? oe, xe = H.fullResults ?? R;
        return Ys(
          W,
          { arrayMode: Ae, fullResults: xe, parameterizedQuery: A, resultCallback: c, types: H.types }
        );
      }
    } else {
      let { status: W } = te;
      if (W === 400) {
        let H = await te.json(), Ae = new pe(H.message);
        for (let xe of Wc)
          Ae[xe] = H[xe] ?? void 0;
        throw Ae;
      } else {
        let H = await te.text();
        throw new pe(`Server error (HTTP status ${W}): ${H}`);
      }
    }
  }
  __name(de, "de");
  return a(de, "execute"), X;
}
function Hc(r, e, t) {
  return { [Symbol.toStringTag]: "NeonQueryPromise", parameterizedQuery: e, opts: t, then: a(
    (n, i) => r(e, t).then(n, i),
    "then"
  ), catch: a((n) => r(e, t).catch(n), "catch"), finally: a((n) => r(
    e,
    t
  ).finally(n), "finally") };
}
function Ys(r, {
  arrayMode: e,
  fullResults: t,
  parameterizedQuery: n,
  resultCallback: i,
  types: s
}) {
  let o = new Js.default(
    s
  ), u = r.fields.map((l) => l.name), c = r.fields.map((l) => o.getTypeParser(l.dataTypeID)), h = e === true ? r.rows.map((l) => l.map((d, b) => d === null ? null : c[b](d))) : r.rows.map((l) => Object.fromEntries(
    l.map((d, b) => [u[b], d === null ? null : c[b](d)])
  ));
  return i && i(n, r, h, { arrayMode: e, fullResults: t }), t ? (r.viaNeonFetch = true, r.rowAsArray = e, r.rows = h, r._parsers = c, r._types = o, r) : h;
}
async function Gc(r) {
  if (typeof r == "string") return r;
  if (typeof r == "function") try {
    return await Promise.resolve(r());
  } catch (e) {
    let t = new pe("Error getting auth token.");
    throw e instanceof Error && (t = new pe(`Error getting auth token: ${e.message}`)), t;
  }
}
function $c(r, e) {
  if (e) return {
    callback: e,
    result: void 0
  };
  let t, n, i = a(function(o, u) {
    o ? t(o) : n(u);
  }, "cb"), s = new r(function(o, u) {
    n = o, t = u;
  });
  return { callback: i, result: s };
}
var io, Ce, so, oo, ao, uo, co, a, z, I, se, Tn, Te, O, _, Bn, Ln, Kn, S, x, E, w, y, m, p, ge, He, zo, Ge, si, U, Ve, oi, Wt, Ht, $t, Vt, li, pi, mi, wi, Ai, Ti, Ri, Mi, Xe, et, tt, ji, ir, sr, or, ar, ur, lu, cr, Wi, lr, hr, Hi, Ki, Zi, Xi, wt, ts, Bu, rs, ns, mr, ss, bt, ls, ys, ws, gs, ms, v, _e, St, Xr, bs, xs, Es, As, hn, Cs, Ts, pn, Fs, Us, Os, Ic, Ns, qs, Ws, Vs, En, It, Bt, Zs, Js, Pt, pe, zs, Wc, to, Qe, An, _n, Cn, export_ClientBase, export_Connection, export_DatabaseError, export_Query, export_defaults, export_types;
var init_serverless = __esm({
  "../node_modules/.pnpm/@neondatabase+serverless@0.10.4/node_modules/@neondatabase/serverless/index.mjs"() {
    init_functionsRoutes_0_17677553668797852();
    io = Object.create;
    Ce = Object.defineProperty;
    so = Object.getOwnPropertyDescriptor;
    oo = Object.getOwnPropertyNames;
    ao = Object.getPrototypeOf;
    uo = Object.prototype.hasOwnProperty;
    co = /* @__PURE__ */ __name((r, e, t) => e in r ? Ce(r, e, { enumerable: true, configurable: true, writable: true, value: t }) : r[e] = t, "co");
    a = /* @__PURE__ */ __name((r, e) => Ce(r, "name", { value: e, configurable: true }), "a");
    z = /* @__PURE__ */ __name((r, e) => () => (r && (e = r(r = 0)), e), "z");
    I = /* @__PURE__ */ __name((r, e) => () => (e || r((e = { exports: {} }).exports, e), e.exports), "I");
    se = /* @__PURE__ */ __name((r, e) => {
      for (var t in e)
        Ce(r, t, { get: e[t], enumerable: true });
    }, "se");
    Tn = /* @__PURE__ */ __name((r, e, t, n) => {
      if (e && typeof e == "object" || typeof e == "function") for (let i of oo(e)) !uo.call(r, i) && i !== t && Ce(r, i, { get: /* @__PURE__ */ __name(() => e[i], "get"), enumerable: !(n = so(e, i)) || n.enumerable });
      return r;
    }, "Tn");
    Te = /* @__PURE__ */ __name((r, e, t) => (t = r != null ? io(ao(r)) : {}, Tn(e || !r || !r.__esModule ? Ce(t, "default", {
      value: r,
      enumerable: true
    }) : t, r)), "Te");
    O = /* @__PURE__ */ __name((r) => Tn(Ce({}, "__esModule", { value: true }), r), "O");
    _ = /* @__PURE__ */ __name((r, e, t) => co(r, typeof e != "symbol" ? e + "" : e, t), "_");
    Bn = I((st) => {
      "use strict";
      p();
      st.byteLength = lo;
      st.toByteArray = po;
      st.fromByteArray = go;
      var ae = [], re = [], ho = typeof Uint8Array < "u" ? Uint8Array : Array, Rt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for (Ee = 0, In = Rt.length; Ee < In; ++Ee)
        ae[Ee] = Rt[Ee], re[Rt.charCodeAt(Ee)] = Ee;
      var Ee, In;
      re[45] = 62;
      re[95] = 63;
      function Pn(r) {
        var e = r.length;
        if (e % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
        var t = r.indexOf("=");
        t === -1 && (t = e);
        var n = t === e ? 0 : 4 - t % 4;
        return [t, n];
      }
      __name(Pn, "Pn");
      a(
        Pn,
        "getLens"
      );
      function lo(r) {
        var e = Pn(r), t = e[0], n = e[1];
        return (t + n) * 3 / 4 - n;
      }
      __name(lo, "lo");
      a(lo, "byteLength");
      function fo(r, e, t) {
        return (e + t) * 3 / 4 - t;
      }
      __name(fo, "fo");
      a(fo, "_byteLength");
      function po(r) {
        var e, t = Pn(r), n = t[0], i = t[1], s = new ho(fo(r, n, i)), o = 0, u = i > 0 ? n - 4 : n, c;
        for (c = 0; c < u; c += 4) e = re[r.charCodeAt(c)] << 18 | re[r.charCodeAt(c + 1)] << 12 | re[r.charCodeAt(c + 2)] << 6 | re[r.charCodeAt(c + 3)], s[o++] = e >> 16 & 255, s[o++] = e >> 8 & 255, s[o++] = e & 255;
        return i === 2 && (e = re[r.charCodeAt(c)] << 2 | re[r.charCodeAt(c + 1)] >> 4, s[o++] = e & 255), i === 1 && (e = re[r.charCodeAt(
          c
        )] << 10 | re[r.charCodeAt(c + 1)] << 4 | re[r.charCodeAt(c + 2)] >> 2, s[o++] = e >> 8 & 255, s[o++] = e & 255), s;
      }
      __name(po, "po");
      a(po, "toByteArray");
      function yo(r) {
        return ae[r >> 18 & 63] + ae[r >> 12 & 63] + ae[r >> 6 & 63] + ae[r & 63];
      }
      __name(yo, "yo");
      a(yo, "tripletToBase64");
      function mo(r, e, t) {
        for (var n, i = [], s = e; s < t; s += 3) n = (r[s] << 16 & 16711680) + (r[s + 1] << 8 & 65280) + (r[s + 2] & 255), i.push(yo(n));
        return i.join(
          ""
        );
      }
      __name(mo, "mo");
      a(mo, "encodeChunk");
      function go(r) {
        for (var e, t = r.length, n = t % 3, i = [], s = 16383, o = 0, u = t - n; o < u; o += s) i.push(mo(r, o, o + s > u ? u : o + s));
        return n === 1 ? (e = r[t - 1], i.push(ae[e >> 2] + ae[e << 4 & 63] + "==")) : n === 2 && (e = (r[t - 2] << 8) + r[t - 1], i.push(ae[e >> 10] + ae[e >> 4 & 63] + ae[e << 2 & 63] + "=")), i.join("");
      }
      __name(go, "go");
      a(go, "fromByteArray");
    });
    Ln = I((Ft) => {
      p();
      Ft.read = function(r, e, t, n, i) {
        var s, o, u = i * 8 - n - 1, c = (1 << u) - 1, h = c >> 1, l = -7, d = t ? i - 1 : 0, b = t ? -1 : 1, C = r[e + d];
        for (d += b, s = C & (1 << -l) - 1, C >>= -l, l += u; l > 0; s = s * 256 + r[e + d], d += b, l -= 8) ;
        for (o = s & (1 << -l) - 1, s >>= -l, l += n; l > 0; o = o * 256 + r[e + d], d += b, l -= 8) ;
        if (s === 0) s = 1 - h;
        else {
          if (s === c) return o ? NaN : (C ? -1 : 1) * (1 / 0);
          o = o + Math.pow(2, n), s = s - h;
        }
        return (C ? -1 : 1) * o * Math.pow(2, s - n);
      };
      Ft.write = function(r, e, t, n, i, s) {
        var o, u, c, h = s * 8 - i - 1, l = (1 << h) - 1, d = l >> 1, b = i === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, C = n ? 0 : s - 1, B = n ? 1 : -1, Q = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
        for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (u = isNaN(e) ? 1 : 0, o = l) : (o = Math.floor(Math.log(e) / Math.LN2), e * (c = Math.pow(2, -o)) < 1 && (o--, c *= 2), o + d >= 1 ? e += b / c : e += b * Math.pow(2, 1 - d), e * c >= 2 && (o++, c /= 2), o + d >= l ? (u = 0, o = l) : o + d >= 1 ? (u = (e * c - 1) * Math.pow(
          2,
          i
        ), o = o + d) : (u = e * Math.pow(2, d - 1) * Math.pow(2, i), o = 0)); i >= 8; r[t + C] = u & 255, C += B, u /= 256, i -= 8) ;
        for (o = o << i | u, h += i; h > 0; r[t + C] = o & 255, C += B, o /= 256, h -= 8) ;
        r[t + C - B] |= Q * 128;
      };
    });
    Kn = I((Le) => {
      "use strict";
      p();
      var Mt = Bn(), Pe = Ln(), Rn = typeof Symbol == "function" && typeof Symbol.for == "function" ? /* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom") : null;
      Le.Buffer = f;
      Le.SlowBuffer = vo;
      Le.INSPECT_MAX_BYTES = 50;
      var ot = 2147483647;
      Le.kMaxLength = ot;
      f.TYPED_ARRAY_SUPPORT = wo();
      !f.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
      function wo() {
        try {
          let r = new Uint8Array(1), e = { foo: a(function() {
            return 42;
          }, "foo") };
          return Object.setPrototypeOf(e, Uint8Array.prototype), Object.setPrototypeOf(
            r,
            e
          ), r.foo() === 42;
        } catch {
          return false;
        }
      }
      __name(wo, "wo");
      a(wo, "typedArraySupport");
      Object.defineProperty(
        f.prototype,
        "parent",
        { enumerable: true, get: a(function() {
          if (f.isBuffer(this)) return this.buffer;
        }, "get") }
      );
      Object.defineProperty(f.prototype, "offset", { enumerable: true, get: a(
        function() {
          if (f.isBuffer(this)) return this.byteOffset;
        },
        "get"
      ) });
      function le(r) {
        if (r > ot) throw new RangeError('The value "' + r + '" is invalid for option "size"');
        let e = new Uint8Array(
          r
        );
        return Object.setPrototypeOf(e, f.prototype), e;
      }
      __name(le, "le");
      a(le, "createBuffer");
      function f(r, e, t) {
        if (typeof r == "number") {
          if (typeof e == "string") throw new TypeError('The "string" argument must be of type string. Received type number');
          return Ot(r);
        }
        return kn(
          r,
          e,
          t
        );
      }
      __name(f, "f");
      a(f, "Buffer");
      f.poolSize = 8192;
      function kn(r, e, t) {
        if (typeof r == "string") return So(
          r,
          e
        );
        if (ArrayBuffer.isView(r)) return xo(r);
        if (r == null) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof r);
        if (ue(r, ArrayBuffer) || r && ue(r.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (ue(r, SharedArrayBuffer) || r && ue(r.buffer, SharedArrayBuffer)))
          return kt(r, e, t);
        if (typeof r == "number") throw new TypeError('The "value" argument must not be of type number. Received type number');
        let n = r.valueOf && r.valueOf();
        if (n != null && n !== r) return f.from(n, e, t);
        let i = Eo(r);
        if (i) return i;
        if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof r[Symbol.toPrimitive] == "function") return f.from(r[Symbol.toPrimitive]("string"), e, t);
        throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof r);
      }
      __name(kn, "kn");
      a(kn, "from");
      f.from = function(r, e, t) {
        return kn(r, e, t);
      };
      Object.setPrototypeOf(f.prototype, Uint8Array.prototype);
      Object.setPrototypeOf(
        f,
        Uint8Array
      );
      function Un(r) {
        if (typeof r != "number") throw new TypeError('"size" argument must be of type number');
        if (r < 0) throw new RangeError('The value "' + r + '" is invalid for option "size"');
      }
      __name(Un, "Un");
      a(Un, "assertSize");
      function bo(r, e, t) {
        return Un(r), r <= 0 ? le(r) : e !== void 0 ? typeof t == "string" ? le(r).fill(e, t) : le(r).fill(e) : le(r);
      }
      __name(bo, "bo");
      a(
        bo,
        "alloc"
      );
      f.alloc = function(r, e, t) {
        return bo(r, e, t);
      };
      function Ot(r) {
        return Un(r), le(
          r < 0 ? 0 : Nt(r) | 0
        );
      }
      __name(Ot, "Ot");
      a(Ot, "allocUnsafe");
      f.allocUnsafe = function(r) {
        return Ot(r);
      };
      f.allocUnsafeSlow = function(r) {
        return Ot(r);
      };
      function So(r, e) {
        if ((typeof e != "string" || e === "") && (e = "utf8"), !f.isEncoding(e)) throw new TypeError("Unknown encoding: " + e);
        let t = On(r, e) | 0, n = le(t), i = n.write(r, e);
        return i !== t && (n = n.slice(0, i)), n;
      }
      __name(So, "So");
      a(So, "fromString");
      function Dt(r) {
        let e = r.length < 0 ? 0 : Nt(r.length) | 0, t = le(e);
        for (let n = 0; n < e; n += 1) t[n] = r[n] & 255;
        return t;
      }
      __name(Dt, "Dt");
      a(Dt, "fromArrayLike");
      function xo(r) {
        if (ue(r, Uint8Array)) {
          let e = new Uint8Array(r);
          return kt(e.buffer, e.byteOffset, e.byteLength);
        }
        return Dt(r);
      }
      __name(xo, "xo");
      a(xo, "fromArrayView");
      function kt(r, e, t) {
        if (e < 0 || r.byteLength < e) throw new RangeError('"offset" is outside of buffer bounds');
        if (r.byteLength < e + (t || 0)) throw new RangeError('"length" is outside of buffer bounds');
        let n;
        return e === void 0 && t === void 0 ? n = new Uint8Array(
          r
        ) : t === void 0 ? n = new Uint8Array(r, e) : n = new Uint8Array(r, e, t), Object.setPrototypeOf(
          n,
          f.prototype
        ), n;
      }
      __name(kt, "kt");
      a(kt, "fromArrayBuffer");
      function Eo(r) {
        if (f.isBuffer(r)) {
          let e = Nt(
            r.length
          ) | 0, t = le(e);
          return t.length === 0 || r.copy(t, 0, 0, e), t;
        }
        if (r.length !== void 0)
          return typeof r.length != "number" || Qt(r.length) ? le(0) : Dt(r);
        if (r.type === "Buffer" && Array.isArray(r.data)) return Dt(r.data);
      }
      __name(Eo, "Eo");
      a(Eo, "fromObject");
      function Nt(r) {
        if (r >= ot) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + ot.toString(16) + " bytes");
        return r | 0;
      }
      __name(Nt, "Nt");
      a(Nt, "checked");
      function vo(r) {
        return +r != r && (r = 0), f.alloc(+r);
      }
      __name(vo, "vo");
      a(vo, "SlowBuffer");
      f.isBuffer = a(function(e) {
        return e != null && e._isBuffer === true && e !== f.prototype;
      }, "isBuffer");
      f.compare = a(function(e, t) {
        if (ue(e, Uint8Array) && (e = f.from(e, e.offset, e.byteLength)), ue(t, Uint8Array) && (t = f.from(t, t.offset, t.byteLength)), !f.isBuffer(e) || !f.isBuffer(t)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
        if (e === t) return 0;
        let n = e.length, i = t.length;
        for (let s = 0, o = Math.min(n, i); s < o; ++s) if (e[s] !== t[s]) {
          n = e[s], i = t[s];
          break;
        }
        return n < i ? -1 : i < n ? 1 : 0;
      }, "compare");
      f.isEncoding = a(function(e) {
        switch (String(e).toLowerCase()) {
          case "hex":
          case "utf8":
          case "utf-8":
          case "ascii":
          case "latin1":
          case "binary":
          case "base64":
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return true;
          default:
            return false;
        }
      }, "isEncoding");
      f.concat = a(function(e, t) {
        if (!Array.isArray(e)) throw new TypeError('"list" argument must be an Array of Buffers');
        if (e.length === 0) return f.alloc(0);
        let n;
        if (t === void 0) for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
        let i = f.allocUnsafe(t), s = 0;
        for (n = 0; n < e.length; ++n) {
          let o = e[n];
          if (ue(o, Uint8Array)) s + o.length > i.length ? (f.isBuffer(
            o
          ) || (o = f.from(o)), o.copy(i, s)) : Uint8Array.prototype.set.call(i, o, s);
          else if (f.isBuffer(
            o
          )) o.copy(i, s);
          else throw new TypeError('"list" argument must be an Array of Buffers');
          s += o.length;
        }
        return i;
      }, "concat");
      function On(r, e) {
        if (f.isBuffer(r)) return r.length;
        if (ArrayBuffer.isView(r) || ue(r, ArrayBuffer)) return r.byteLength;
        if (typeof r != "string") throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof r);
        let t = r.length, n = arguments.length > 2 && arguments[2] === true;
        if (!n && t === 0) return 0;
        let i = false;
        for (; ; ) switch (e) {
          case "ascii":
          case "latin1":
          case "binary":
            return t;
          case "utf8":
          case "utf-8":
            return Ut(r).length;
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return t * 2;
          case "hex":
            return t >>> 1;
          case "base64":
            return Vn(r).length;
          default:
            if (i) return n ? -1 : Ut(r).length;
            e = ("" + e).toLowerCase(), i = true;
        }
      }
      __name(On, "On");
      a(On, "byteLength");
      f.byteLength = On;
      function _o(r, e, t) {
        let n = false;
        if ((e === void 0 || e < 0) && (e = 0), e > this.length || ((t === void 0 || t > this.length) && (t = this.length), t <= 0) || (t >>>= 0, e >>>= 0, t <= e)) return "";
        for (r || (r = "utf8"); ; ) switch (r) {
          case "hex":
            return Mo(
              this,
              e,
              t
            );
          case "utf8":
          case "utf-8":
            return qn(this, e, t);
          case "ascii":
            return Ro(
              this,
              e,
              t
            );
          case "latin1":
          case "binary":
            return Fo(this, e, t);
          case "base64":
            return Bo(
              this,
              e,
              t
            );
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return Do(this, e, t);
          default:
            if (n) throw new TypeError("Unknown encoding: " + r);
            r = (r + "").toLowerCase(), n = true;
        }
      }
      __name(_o, "_o");
      a(
        _o,
        "slowToString"
      );
      f.prototype._isBuffer = true;
      function ve(r, e, t) {
        let n = r[e];
        r[e] = r[t], r[t] = n;
      }
      __name(ve, "ve");
      a(ve, "swap");
      f.prototype.swap16 = a(function() {
        let e = this.length;
        if (e % 2 !== 0)
          throw new RangeError("Buffer size must be a multiple of 16-bits");
        for (let t = 0; t < e; t += 2) ve(this, t, t + 1);
        return this;
      }, "swap16");
      f.prototype.swap32 = a(function() {
        let e = this.length;
        if (e % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
        for (let t = 0; t < e; t += 4) ve(this, t, t + 3), ve(this, t + 1, t + 2);
        return this;
      }, "swap32");
      f.prototype.swap64 = a(function() {
        let e = this.length;
        if (e % 8 !== 0) throw new RangeError(
          "Buffer size must be a multiple of 64-bits"
        );
        for (let t = 0; t < e; t += 8) ve(this, t, t + 7), ve(this, t + 1, t + 6), ve(this, t + 2, t + 5), ve(this, t + 3, t + 4);
        return this;
      }, "swap64");
      f.prototype.toString = a(function() {
        let e = this.length;
        return e === 0 ? "" : arguments.length === 0 ? qn(
          this,
          0,
          e
        ) : _o.apply(this, arguments);
      }, "toString");
      f.prototype.toLocaleString = f.prototype.toString;
      f.prototype.equals = a(function(e) {
        if (!f.isBuffer(e)) throw new TypeError(
          "Argument must be a Buffer"
        );
        return this === e ? true : f.compare(this, e) === 0;
      }, "equals");
      f.prototype.inspect = a(function() {
        let e = "", t = Le.INSPECT_MAX_BYTES;
        return e = this.toString(
          "hex",
          0,
          t
        ).replace(/(.{2})/g, "$1 ").trim(), this.length > t && (e += " ... "), "<Buffer " + e + ">";
      }, "inspect");
      Rn && (f.prototype[Rn] = f.prototype.inspect);
      f.prototype.compare = a(function(e, t, n, i, s) {
        if (ue(e, Uint8Array) && (e = f.from(e, e.offset, e.byteLength)), !f.isBuffer(e)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e);
        if (t === void 0 && (t = 0), n === void 0 && (n = e ? e.length : 0), i === void 0 && (i = 0), s === void 0 && (s = this.length), t < 0 || n > e.length || i < 0 || s > this.length) throw new RangeError("out of range index");
        if (i >= s && t >= n) return 0;
        if (i >= s) return -1;
        if (t >= n) return 1;
        if (t >>>= 0, n >>>= 0, i >>>= 0, s >>>= 0, this === e) return 0;
        let o = s - i, u = n - t, c = Math.min(o, u), h = this.slice(i, s), l = e.slice(t, n);
        for (let d = 0; d < c; ++d)
          if (h[d] !== l[d]) {
            o = h[d], u = l[d];
            break;
          }
        return o < u ? -1 : u < o ? 1 : 0;
      }, "compare");
      function Nn(r, e, t, n, i) {
        if (r.length === 0) return -1;
        if (typeof t == "string" ? (n = t, t = 0) : t > 2147483647 ? t = 2147483647 : t < -2147483648 && (t = -2147483648), t = +t, Qt(t) && (t = i ? 0 : r.length - 1), t < 0 && (t = r.length + t), t >= r.length) {
          if (i) return -1;
          t = r.length - 1;
        } else if (t < 0) if (i) t = 0;
        else return -1;
        if (typeof e == "string" && (e = f.from(e, n)), f.isBuffer(e)) return e.length === 0 ? -1 : Fn(r, e, t, n, i);
        if (typeof e == "number") return e = e & 255, typeof Uint8Array.prototype.indexOf == "function" ? i ? Uint8Array.prototype.indexOf.call(r, e, t) : Uint8Array.prototype.lastIndexOf.call(r, e, t) : Fn(
          r,
          [e],
          t,
          n,
          i
        );
        throw new TypeError("val must be string, number or Buffer");
      }
      __name(Nn, "Nn");
      a(Nn, "bidirectionalIndexOf");
      function Fn(r, e, t, n, i) {
        let s = 1, o = r.length, u = e.length;
        if (n !== void 0 && (n = String(n).toLowerCase(), n === "ucs2" || n === "ucs-2" || n === "utf16le" || n === "utf-16le")) {
          if (r.length < 2 || e.length < 2) return -1;
          s = 2, o /= 2, u /= 2, t /= 2;
        }
        function c(l, d) {
          return s === 1 ? l[d] : l.readUInt16BE(d * s);
        }
        __name(c, "c");
        a(c, "read");
        let h;
        if (i) {
          let l = -1;
          for (h = t; h < o; h++) if (c(r, h) === c(e, l === -1 ? 0 : h - l)) {
            if (l === -1 && (l = h), h - l + 1 === u) return l * s;
          } else l !== -1 && (h -= h - l), l = -1;
        } else for (t + u > o && (t = o - u), h = t; h >= 0; h--) {
          let l = true;
          for (let d = 0; d < u; d++)
            if (c(r, h + d) !== c(e, d)) {
              l = false;
              break;
            }
          if (l) return h;
        }
        return -1;
      }
      __name(Fn, "Fn");
      a(Fn, "arrayIndexOf");
      f.prototype.includes = a(function(e, t, n) {
        return this.indexOf(e, t, n) !== -1;
      }, "includes");
      f.prototype.indexOf = a(function(e, t, n) {
        return Nn(this, e, t, n, true);
      }, "indexOf");
      f.prototype.lastIndexOf = a(function(e, t, n) {
        return Nn(this, e, t, n, false);
      }, "lastIndexOf");
      function Ao(r, e, t, n) {
        t = Number(t) || 0;
        let i = r.length - t;
        n ? (n = Number(n), n > i && (n = i)) : n = i;
        let s = e.length;
        n > s / 2 && (n = s / 2);
        let o;
        for (o = 0; o < n; ++o) {
          let u = parseInt(e.substr(o * 2, 2), 16);
          if (Qt(u))
            return o;
          r[t + o] = u;
        }
        return o;
      }
      __name(Ao, "Ao");
      a(Ao, "hexWrite");
      function Co(r, e, t, n) {
        return at(Ut(
          e,
          r.length - t
        ), r, t, n);
      }
      __name(Co, "Co");
      a(Co, "utf8Write");
      function To(r, e, t, n) {
        return at(No(e), r, t, n);
      }
      __name(To, "To");
      a(To, "asciiWrite");
      function Io(r, e, t, n) {
        return at(Vn(e), r, t, n);
      }
      __name(Io, "Io");
      a(Io, "base64Write");
      function Po(r, e, t, n) {
        return at(qo(e, r.length - t), r, t, n);
      }
      __name(Po, "Po");
      a(Po, "ucs2Write");
      f.prototype.write = a(function(e, t, n, i) {
        if (t === void 0) i = "utf8", n = this.length, t = 0;
        else if (n === void 0 && typeof t == "string") i = t, n = this.length, t = 0;
        else if (isFinite(t)) t = t >>> 0, isFinite(n) ? (n = n >>> 0, i === void 0 && (i = "utf8")) : (i = n, n = void 0);
        else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
        let s = this.length - t;
        if ((n === void 0 || n > s) && (n = s), e.length > 0 && (n < 0 || t < 0) || t > this.length) throw new RangeError(
          "Attempt to write outside buffer bounds"
        );
        i || (i = "utf8");
        let o = false;
        for (; ; ) switch (i) {
          case "hex":
            return Ao(this, e, t, n);
          case "utf8":
          case "utf-8":
            return Co(this, e, t, n);
          case "ascii":
          case "latin1":
          case "binary":
            return To(this, e, t, n);
          case "base64":
            return Io(
              this,
              e,
              t,
              n
            );
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return Po(this, e, t, n);
          default:
            if (o) throw new TypeError("Unknown encoding: " + i);
            i = ("" + i).toLowerCase(), o = true;
        }
      }, "write");
      f.prototype.toJSON = a(function() {
        return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
      }, "toJSON");
      function Bo(r, e, t) {
        return e === 0 && t === r.length ? Mt.fromByteArray(r) : Mt.fromByteArray(r.slice(e, t));
      }
      __name(Bo, "Bo");
      a(Bo, "base64Slice");
      function qn(r, e, t) {
        t = Math.min(r.length, t);
        let n = [], i = e;
        for (; i < t; ) {
          let s = r[i], o = null, u = s > 239 ? 4 : s > 223 ? 3 : s > 191 ? 2 : 1;
          if (i + u <= t) {
            let c, h, l, d;
            switch (u) {
              case 1:
                s < 128 && (o = s);
                break;
              case 2:
                c = r[i + 1], (c & 192) === 128 && (d = (s & 31) << 6 | c & 63, d > 127 && (o = d));
                break;
              case 3:
                c = r[i + 1], h = r[i + 2], (c & 192) === 128 && (h & 192) === 128 && (d = (s & 15) << 12 | (c & 63) << 6 | h & 63, d > 2047 && (d < 55296 || d > 57343) && (o = d));
                break;
              case 4:
                c = r[i + 1], h = r[i + 2], l = r[i + 3], (c & 192) === 128 && (h & 192) === 128 && (l & 192) === 128 && (d = (s & 15) << 18 | (c & 63) << 12 | (h & 63) << 6 | l & 63, d > 65535 && d < 1114112 && (o = d));
            }
          }
          o === null ? (o = 65533, u = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | o & 1023), n.push(o), i += u;
        }
        return Lo(n);
      }
      __name(qn, "qn");
      a(qn, "utf8Slice");
      var Mn = 4096;
      function Lo(r) {
        let e = r.length;
        if (e <= Mn) return String.fromCharCode.apply(String, r);
        let t = "", n = 0;
        for (; n < e; ) t += String.fromCharCode.apply(String, r.slice(n, n += Mn));
        return t;
      }
      __name(Lo, "Lo");
      a(Lo, "decodeCodePointsArray");
      function Ro(r, e, t) {
        let n = "";
        t = Math.min(r.length, t);
        for (let i = e; i < t; ++i) n += String.fromCharCode(r[i] & 127);
        return n;
      }
      __name(Ro, "Ro");
      a(Ro, "asciiSlice");
      function Fo(r, e, t) {
        let n = "";
        t = Math.min(r.length, t);
        for (let i = e; i < t; ++i) n += String.fromCharCode(r[i]);
        return n;
      }
      __name(Fo, "Fo");
      a(Fo, "latin1Slice");
      function Mo(r, e, t) {
        let n = r.length;
        (!e || e < 0) && (e = 0), (!t || t < 0 || t > n) && (t = n);
        let i = "";
        for (let s = e; s < t; ++s) i += Qo[r[s]];
        return i;
      }
      __name(Mo, "Mo");
      a(Mo, "hexSlice");
      function Do(r, e, t) {
        let n = r.slice(e, t), i = "";
        for (let s = 0; s < n.length - 1; s += 2) i += String.fromCharCode(n[s] + n[s + 1] * 256);
        return i;
      }
      __name(Do, "Do");
      a(Do, "utf16leSlice");
      f.prototype.slice = a(function(e, t) {
        let n = this.length;
        e = ~~e, t = t === void 0 ? n : ~~t, e < 0 ? (e += n, e < 0 && (e = 0)) : e > n && (e = n), t < 0 ? (t += n, t < 0 && (t = 0)) : t > n && (t = n), t < e && (t = e);
        let i = this.subarray(
          e,
          t
        );
        return Object.setPrototypeOf(i, f.prototype), i;
      }, "slice");
      function N(r, e, t) {
        if (r % 1 !== 0 || r < 0) throw new RangeError("offset is not uint");
        if (r + e > t) throw new RangeError(
          "Trying to access beyond buffer length"
        );
      }
      __name(N, "N");
      a(N, "checkOffset");
      f.prototype.readUintLE = f.prototype.readUIntLE = a(function(e, t, n) {
        e = e >>> 0, t = t >>> 0, n || N(e, t, this.length);
        let i = this[e], s = 1, o = 0;
        for (; ++o < t && (s *= 256); ) i += this[e + o] * s;
        return i;
      }, "readUIntLE");
      f.prototype.readUintBE = f.prototype.readUIntBE = a(function(e, t, n) {
        e = e >>> 0, t = t >>> 0, n || N(e, t, this.length);
        let i = this[e + --t], s = 1;
        for (; t > 0 && (s *= 256); ) i += this[e + --t] * s;
        return i;
      }, "readUIntBE");
      f.prototype.readUint8 = f.prototype.readUInt8 = a(function(e, t) {
        return e = e >>> 0, t || N(e, 1, this.length), this[e];
      }, "readUInt8");
      f.prototype.readUint16LE = f.prototype.readUInt16LE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 2, this.length), this[e] | this[e + 1] << 8;
      }, "readUInt16LE");
      f.prototype.readUint16BE = f.prototype.readUInt16BE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 2, this.length), this[e] << 8 | this[e + 1];
      }, "readUInt16BE");
      f.prototype.readUint32LE = f.prototype.readUInt32LE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + this[e + 3] * 16777216;
      }, "readUInt32LE");
      f.prototype.readUint32BE = f.prototype.readUInt32BE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), this[e] * 16777216 + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
      }, "readUInt32BE");
      f.prototype.readBigUInt64LE = me(a(function(e) {
        e = e >>> 0, Be(e, "offset");
        let t = this[e], n = this[e + 7];
        (t === void 0 || n === void 0) && We(e, this.length - 8);
        let i = t + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + this[++e] * 2 ** 24, s = this[++e] + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + n * 2 ** 24;
        return BigInt(i) + (BigInt(s) << BigInt(32));
      }, "readBigUInt64LE"));
      f.prototype.readBigUInt64BE = me(a(function(e) {
        e = e >>> 0, Be(e, "offset");
        let t = this[e], n = this[e + 7];
        (t === void 0 || n === void 0) && We(e, this.length - 8);
        let i = t * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + this[++e], s = this[++e] * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + n;
        return (BigInt(
          i
        ) << BigInt(32)) + BigInt(s);
      }, "readBigUInt64BE"));
      f.prototype.readIntLE = a(function(e, t, n) {
        e = e >>> 0, t = t >>> 0, n || N(e, t, this.length);
        let i = this[e], s = 1, o = 0;
        for (; ++o < t && (s *= 256); )
          i += this[e + o] * s;
        return s *= 128, i >= s && (i -= Math.pow(2, 8 * t)), i;
      }, "readIntLE");
      f.prototype.readIntBE = a(function(e, t, n) {
        e = e >>> 0, t = t >>> 0, n || N(e, t, this.length);
        let i = t, s = 1, o = this[e + --i];
        for (; i > 0 && (s *= 256); ) o += this[e + --i] * s;
        return s *= 128, o >= s && (o -= Math.pow(2, 8 * t)), o;
      }, "readIntBE");
      f.prototype.readInt8 = a(function(e, t) {
        return e = e >>> 0, t || N(e, 1, this.length), this[e] & 128 ? (255 - this[e] + 1) * -1 : this[e];
      }, "readInt8");
      f.prototype.readInt16LE = a(function(e, t) {
        e = e >>> 0, t || N(e, 2, this.length);
        let n = this[e] | this[e + 1] << 8;
        return n & 32768 ? n | 4294901760 : n;
      }, "readInt16LE");
      f.prototype.readInt16BE = a(
        function(e, t) {
          e = e >>> 0, t || N(e, 2, this.length);
          let n = this[e + 1] | this[e] << 8;
          return n & 32768 ? n | 4294901760 : n;
        },
        "readInt16BE"
      );
      f.prototype.readInt32LE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
      }, "readInt32LE");
      f.prototype.readInt32BE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
      }, "readInt32BE");
      f.prototype.readBigInt64LE = me(a(function(e) {
        e = e >>> 0, Be(e, "offset");
        let t = this[e], n = this[e + 7];
        (t === void 0 || n === void 0) && We(
          e,
          this.length - 8
        );
        let i = this[e + 4] + this[e + 5] * 2 ** 8 + this[e + 6] * 2 ** 16 + (n << 24);
        return (BigInt(
          i
        ) << BigInt(32)) + BigInt(t + this[++e] * 2 ** 8 + this[++e] * 2 ** 16 + this[++e] * 2 ** 24);
      }, "readBigInt64LE"));
      f.prototype.readBigInt64BE = me(a(function(e) {
        e = e >>> 0, Be(e, "offset");
        let t = this[e], n = this[e + 7];
        (t === void 0 || n === void 0) && We(e, this.length - 8);
        let i = (t << 24) + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + this[++e];
        return (BigInt(i) << BigInt(32)) + BigInt(
          this[++e] * 2 ** 24 + this[++e] * 2 ** 16 + this[++e] * 2 ** 8 + n
        );
      }, "readBigInt64BE"));
      f.prototype.readFloatLE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), Pe.read(
          this,
          e,
          true,
          23,
          4
        );
      }, "readFloatLE");
      f.prototype.readFloatBE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 4, this.length), Pe.read(this, e, false, 23, 4);
      }, "readFloatBE");
      f.prototype.readDoubleLE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 8, this.length), Pe.read(this, e, true, 52, 8);
      }, "readDoubleLE");
      f.prototype.readDoubleBE = a(function(e, t) {
        return e = e >>> 0, t || N(e, 8, this.length), Pe.read(this, e, false, 52, 8);
      }, "readDoubleBE");
      function Y(r, e, t, n, i, s) {
        if (!f.isBuffer(
          r
        )) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (e > i || e < s) throw new RangeError('"value" argument is out of bounds');
        if (t + n > r.length) throw new RangeError(
          "Index out of range"
        );
      }
      __name(Y, "Y");
      a(Y, "checkInt");
      f.prototype.writeUintLE = f.prototype.writeUIntLE = a(function(e, t, n, i) {
        if (e = +e, t = t >>> 0, n = n >>> 0, !i) {
          let u = Math.pow(2, 8 * n) - 1;
          Y(
            this,
            e,
            t,
            n,
            u,
            0
          );
        }
        let s = 1, o = 0;
        for (this[t] = e & 255; ++o < n && (s *= 256); ) this[t + o] = e / s & 255;
        return t + n;
      }, "writeUIntLE");
      f.prototype.writeUintBE = f.prototype.writeUIntBE = a(function(e, t, n, i) {
        if (e = +e, t = t >>> 0, n = n >>> 0, !i) {
          let u = Math.pow(2, 8 * n) - 1;
          Y(this, e, t, n, u, 0);
        }
        let s = n - 1, o = 1;
        for (this[t + s] = e & 255; --s >= 0 && (o *= 256); ) this[t + s] = e / o & 255;
        return t + n;
      }, "writeUIntBE");
      f.prototype.writeUint8 = f.prototype.writeUInt8 = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 1, 255, 0), this[t] = e & 255, t + 1;
      }, "writeUInt8");
      f.prototype.writeUint16LE = f.prototype.writeUInt16LE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(
          this,
          e,
          t,
          2,
          65535,
          0
        ), this[t] = e & 255, this[t + 1] = e >>> 8, t + 2;
      }, "writeUInt16LE");
      f.prototype.writeUint16BE = f.prototype.writeUInt16BE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(
          this,
          e,
          t,
          2,
          65535,
          0
        ), this[t] = e >>> 8, this[t + 1] = e & 255, t + 2;
      }, "writeUInt16BE");
      f.prototype.writeUint32LE = f.prototype.writeUInt32LE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(
          this,
          e,
          t,
          4,
          4294967295,
          0
        ), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = e & 255, t + 4;
      }, "writeUInt32LE");
      f.prototype.writeUint32BE = f.prototype.writeUInt32BE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 4, 4294967295, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = e & 255, t + 4;
      }, "writeUInt32BE");
      function Qn(r, e, t, n, i) {
        $n(
          e,
          n,
          i,
          r,
          t,
          7
        );
        let s = Number(e & BigInt(4294967295));
        r[t++] = s, s = s >> 8, r[t++] = s, s = s >> 8, r[t++] = s, s = s >> 8, r[t++] = s;
        let o = Number(e >> BigInt(32) & BigInt(4294967295));
        return r[t++] = o, o = o >> 8, r[t++] = o, o = o >> 8, r[t++] = o, o = o >> 8, r[t++] = o, t;
      }
      __name(Qn, "Qn");
      a(Qn, "wrtBigUInt64LE");
      function jn(r, e, t, n, i) {
        $n(e, n, i, r, t, 7);
        let s = Number(e & BigInt(4294967295));
        r[t + 7] = s, s = s >> 8, r[t + 6] = s, s = s >> 8, r[t + 5] = s, s = s >> 8, r[t + 4] = s;
        let o = Number(e >> BigInt(32) & BigInt(4294967295));
        return r[t + 3] = o, o = o >> 8, r[t + 2] = o, o = o >> 8, r[t + 1] = o, o = o >> 8, r[t] = o, t + 8;
      }
      __name(jn, "jn");
      a(jn, "wrtBigUInt64BE");
      f.prototype.writeBigUInt64LE = me(a(function(e, t = 0) {
        return Qn(this, e, t, BigInt(0), BigInt(
          "0xffffffffffffffff"
        ));
      }, "writeBigUInt64LE"));
      f.prototype.writeBigUInt64BE = me(a(function(e, t = 0) {
        return jn(this, e, t, BigInt(0), BigInt("0xffffffffffffffff"));
      }, "writeBigUInt64BE"));
      f.prototype.writeIntLE = a(function(e, t, n, i) {
        if (e = +e, t = t >>> 0, !i) {
          let c = Math.pow(
            2,
            8 * n - 1
          );
          Y(this, e, t, n, c - 1, -c);
        }
        let s = 0, o = 1, u = 0;
        for (this[t] = e & 255; ++s < n && (o *= 256); ) e < 0 && u === 0 && this[t + s - 1] !== 0 && (u = 1), this[t + s] = (e / o >> 0) - u & 255;
        return t + n;
      }, "writeIntLE");
      f.prototype.writeIntBE = a(function(e, t, n, i) {
        if (e = +e, t = t >>> 0, !i) {
          let c = Math.pow(
            2,
            8 * n - 1
          );
          Y(this, e, t, n, c - 1, -c);
        }
        let s = n - 1, o = 1, u = 0;
        for (this[t + s] = e & 255; --s >= 0 && (o *= 256); ) e < 0 && u === 0 && this[t + s + 1] !== 0 && (u = 1), this[t + s] = (e / o >> 0) - u & 255;
        return t + n;
      }, "writeIntBE");
      f.prototype.writeInt8 = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(
          this,
          e,
          t,
          1,
          127,
          -128
        ), e < 0 && (e = 255 + e + 1), this[t] = e & 255, t + 1;
      }, "writeInt8");
      f.prototype.writeInt16LE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 2, 32767, -32768), this[t] = e & 255, this[t + 1] = e >>> 8, t + 2;
      }, "writeInt16LE");
      f.prototype.writeInt16BE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = e & 255, t + 2;
      }, "writeInt16BE");
      f.prototype.writeInt32LE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 4, 2147483647, -2147483648), this[t] = e & 255, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24, t + 4;
      }, "writeInt32LE");
      f.prototype.writeInt32BE = a(function(e, t, n) {
        return e = +e, t = t >>> 0, n || Y(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = e & 255, t + 4;
      }, "writeInt32BE");
      f.prototype.writeBigInt64LE = me(a(function(e, t = 0) {
        return Qn(this, e, t, -BigInt(
          "0x8000000000000000"
        ), BigInt("0x7fffffffffffffff"));
      }, "writeBigInt64LE"));
      f.prototype.writeBigInt64BE = me(a(function(e, t = 0) {
        return jn(this, e, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
      }, "writeBigInt64BE"));
      function Wn(r, e, t, n, i, s) {
        if (t + n > r.length) throw new RangeError("Index out of range");
        if (t < 0) throw new RangeError(
          "Index out of range"
        );
      }
      __name(Wn, "Wn");
      a(Wn, "checkIEEE754");
      function Hn(r, e, t, n, i) {
        return e = +e, t = t >>> 0, i || Wn(r, e, t, 4, 34028234663852886e22, -34028234663852886e22), Pe.write(
          r,
          e,
          t,
          n,
          23,
          4
        ), t + 4;
      }
      __name(Hn, "Hn");
      a(Hn, "writeFloat");
      f.prototype.writeFloatLE = a(function(e, t, n) {
        return Hn(
          this,
          e,
          t,
          true,
          n
        );
      }, "writeFloatLE");
      f.prototype.writeFloatBE = a(function(e, t, n) {
        return Hn(
          this,
          e,
          t,
          false,
          n
        );
      }, "writeFloatBE");
      function Gn(r, e, t, n, i) {
        return e = +e, t = t >>> 0, i || Wn(
          r,
          e,
          t,
          8,
          17976931348623157e292,
          -17976931348623157e292
        ), Pe.write(r, e, t, n, 52, 8), t + 8;
      }
      __name(Gn, "Gn");
      a(Gn, "writeDouble");
      f.prototype.writeDoubleLE = a(function(e, t, n) {
        return Gn(
          this,
          e,
          t,
          true,
          n
        );
      }, "writeDoubleLE");
      f.prototype.writeDoubleBE = a(function(e, t, n) {
        return Gn(
          this,
          e,
          t,
          false,
          n
        );
      }, "writeDoubleBE");
      f.prototype.copy = a(function(e, t, n, i) {
        if (!f.isBuffer(
          e
        )) throw new TypeError("argument should be a Buffer");
        if (n || (n = 0), !i && i !== 0 && (i = this.length), t >= e.length && (t = e.length), t || (t = 0), i > 0 && i < n && (i = n), i === n || e.length === 0 || this.length === 0) return 0;
        if (t < 0) throw new RangeError("targetStart out of bounds");
        if (n < 0 || n >= this.length) throw new RangeError("Index out of range");
        if (i < 0) throw new RangeError(
          "sourceEnd out of bounds"
        );
        i > this.length && (i = this.length), e.length - t < i - n && (i = e.length - t + n);
        let s = i - n;
        return this === e && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(t, n, i) : Uint8Array.prototype.set.call(e, this.subarray(n, i), t), s;
      }, "copy");
      f.prototype.fill = a(function(e, t, n, i) {
        if (typeof e == "string") {
          if (typeof t == "string" ? (i = t, t = 0, n = this.length) : typeof n == "string" && (i = n, n = this.length), i !== void 0 && typeof i != "string") throw new TypeError("encoding must be a string");
          if (typeof i == "string" && !f.isEncoding(i)) throw new TypeError("Unknown encoding: " + i);
          if (e.length === 1) {
            let o = e.charCodeAt(0);
            (i === "utf8" && o < 128 || i === "latin1") && (e = o);
          }
        } else typeof e == "number" ? e = e & 255 : typeof e == "boolean" && (e = Number(e));
        if (t < 0 || this.length < t || this.length < n) throw new RangeError("Out of range index");
        if (n <= t) return this;
        t = t >>> 0, n = n === void 0 ? this.length : n >>> 0, e || (e = 0);
        let s;
        if (typeof e == "number") for (s = t; s < n; ++s)
          this[s] = e;
        else {
          let o = f.isBuffer(e) ? e : f.from(e, i), u = o.length;
          if (u === 0) throw new TypeError(
            'The value "' + e + '" is invalid for argument "value"'
          );
          for (s = 0; s < n - t; ++s) this[s + t] = o[s % u];
        }
        return this;
      }, "fill");
      var Ie = {};
      function qt(r, e, t) {
        var n;
        Ie[r] = (n = class extends t {
          static {
            __name(this, "n");
          }
          constructor() {
            super(), Object.defineProperty(this, "message", {
              value: e.apply(this, arguments),
              writable: true,
              configurable: true
            }), this.name = `${this.name} [${r}]`, this.stack, delete this.name;
          }
          get code() {
            return r;
          }
          set code(s) {
            Object.defineProperty(this, "code", {
              configurable: true,
              enumerable: true,
              value: s,
              writable: true
            });
          }
          toString() {
            return `${this.name} [${r}]: ${this.message}`;
          }
        }, a(n, "NodeError"), n);
      }
      __name(qt, "qt");
      a(qt, "E");
      qt("ERR_BUFFER_OUT_OF_BOUNDS", function(r) {
        return r ? `${r} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
      }, RangeError);
      qt("ERR_INVALID_ARG_TYPE", function(r, e) {
        return `The "${r}" argument must be of type number. Received type ${typeof e}`;
      }, TypeError);
      qt("ERR_OUT_OF_RANGE", function(r, e, t) {
        let n = `The value of "${r}" is out of range.`, i = t;
        return Number.isInteger(t) && Math.abs(t) > 2 ** 32 ? i = Dn(String(t)) : typeof t == "bigint" && (i = String(t), (t > BigInt(2) ** BigInt(32) || t < -(BigInt(2) ** BigInt(32))) && (i = Dn(i)), i += "n"), n += ` It must be ${e}. Received ${i}`, n;
      }, RangeError);
      function Dn(r) {
        let e = "", t = r.length, n = r[0] === "-" ? 1 : 0;
        for (; t >= n + 4; t -= 3) e = `_${r.slice(t - 3, t)}${e}`;
        return `${r.slice(
          0,
          t
        )}${e}`;
      }
      __name(Dn, "Dn");
      a(Dn, "addNumericalSeparator");
      function ko(r, e, t) {
        Be(e, "offset"), (r[e] === void 0 || r[e + t] === void 0) && We(e, r.length - (t + 1));
      }
      __name(ko, "ko");
      a(ko, "checkBounds");
      function $n(r, e, t, n, i, s) {
        if (r > t || r < e) {
          let o = typeof e == "bigint" ? "n" : "", u;
          throw s > 3 ? e === 0 || e === BigInt(0) ? u = `>= 0${o} and < 2${o} ** ${(s + 1) * 8}${o}` : u = `>= -(2${o} ** ${(s + 1) * 8 - 1}${o}) and < 2 ** ${(s + 1) * 8 - 1}${o}` : u = `>= ${e}${o} and <= ${t}${o}`, new Ie.ERR_OUT_OF_RANGE(
            "value",
            u,
            r
          );
        }
        ko(n, i, s);
      }
      __name($n, "$n");
      a($n, "checkIntBI");
      function Be(r, e) {
        if (typeof r != "number")
          throw new Ie.ERR_INVALID_ARG_TYPE(e, "number", r);
      }
      __name(Be, "Be");
      a(Be, "validateNumber");
      function We(r, e, t) {
        throw Math.floor(r) !== r ? (Be(r, t), new Ie.ERR_OUT_OF_RANGE(
          t || "offset",
          "an integer",
          r
        )) : e < 0 ? new Ie.ERR_BUFFER_OUT_OF_BOUNDS() : new Ie.ERR_OUT_OF_RANGE(t || "offset", `>= ${t ? 1 : 0} and <= ${e}`, r);
      }
      __name(We, "We");
      a(We, "boundsError");
      var Uo = /[^+/0-9A-Za-z-_]/g;
      function Oo(r) {
        if (r = r.split("=")[0], r = r.trim().replace(Uo, ""), r.length < 2) return "";
        for (; r.length % 4 !== 0; ) r = r + "=";
        return r;
      }
      __name(Oo, "Oo");
      a(Oo, "base64clean");
      function Ut(r, e) {
        e = e || 1 / 0;
        let t, n = r.length, i = null, s = [];
        for (let o = 0; o < n; ++o) {
          if (t = r.charCodeAt(o), t > 55295 && t < 57344) {
            if (!i) {
              if (t > 56319) {
                (e -= 3) > -1 && s.push(239, 191, 189);
                continue;
              } else if (o + 1 === n) {
                (e -= 3) > -1 && s.push(239, 191, 189);
                continue;
              }
              i = t;
              continue;
            }
            if (t < 56320) {
              (e -= 3) > -1 && s.push(
                239,
                191,
                189
              ), i = t;
              continue;
            }
            t = (i - 55296 << 10 | t - 56320) + 65536;
          } else i && (e -= 3) > -1 && s.push(
            239,
            191,
            189
          );
          if (i = null, t < 128) {
            if ((e -= 1) < 0) break;
            s.push(t);
          } else if (t < 2048) {
            if ((e -= 2) < 0) break;
            s.push(t >> 6 | 192, t & 63 | 128);
          } else if (t < 65536) {
            if ((e -= 3) < 0) break;
            s.push(t >> 12 | 224, t >> 6 & 63 | 128, t & 63 | 128);
          } else if (t < 1114112) {
            if ((e -= 4) < 0) break;
            s.push(t >> 18 | 240, t >> 12 & 63 | 128, t >> 6 & 63 | 128, t & 63 | 128);
          } else throw new Error("Invalid code point");
        }
        return s;
      }
      __name(Ut, "Ut");
      a(
        Ut,
        "utf8ToBytes"
      );
      function No(r) {
        let e = [];
        for (let t = 0; t < r.length; ++t) e.push(r.charCodeAt(
          t
        ) & 255);
        return e;
      }
      __name(No, "No");
      a(No, "asciiToBytes");
      function qo(r, e) {
        let t, n, i, s = [];
        for (let o = 0; o < r.length && !((e -= 2) < 0); ++o) t = r.charCodeAt(o), n = t >> 8, i = t % 256, s.push(i), s.push(n);
        return s;
      }
      __name(qo, "qo");
      a(qo, "utf16leToBytes");
      function Vn(r) {
        return Mt.toByteArray(Oo(r));
      }
      __name(Vn, "Vn");
      a(Vn, "base64ToBytes");
      function at(r, e, t, n) {
        let i;
        for (i = 0; i < n && !(i + t >= e.length || i >= r.length); ++i)
          e[i + t] = r[i];
        return i;
      }
      __name(at, "at");
      a(at, "blitBuffer");
      function ue(r, e) {
        return r instanceof e || r != null && r.constructor != null && r.constructor.name != null && r.constructor.name === e.name;
      }
      __name(ue, "ue");
      a(ue, "isInstance");
      function Qt(r) {
        return r !== r;
      }
      __name(Qt, "Qt");
      a(Qt, "numberIsNaN");
      var Qo = (function() {
        let r = "0123456789abcdef", e = new Array(256);
        for (let t = 0; t < 16; ++t) {
          let n = t * 16;
          for (let i = 0; i < 16; ++i) e[n + i] = r[t] + r[i];
        }
        return e;
      })();
      function me(r) {
        return typeof BigInt > "u" ? jo : r;
      }
      __name(me, "me");
      a(me, "defineBigIntMethod");
      function jo() {
        throw new Error("BigInt not supported");
      }
      __name(jo, "jo");
      a(jo, "BufferBigIntNotDefined");
    });
    p = z(() => {
      "use strict";
      S = globalThis, x = globalThis.setImmediate ?? ((r) => setTimeout(
        r,
        0
      )), E = globalThis.clearImmediate ?? ((r) => clearTimeout(r)), w = globalThis.crypto ?? {};
      w.subtle ?? (w.subtle = {});
      y = typeof globalThis.Buffer == "function" && typeof globalThis.Buffer.allocUnsafe == "function" ? globalThis.Buffer : Kn().Buffer, m = globalThis.process ?? {};
      m.env ?? (m.env = {});
      try {
        m.nextTick(() => {
        });
      } catch {
        let e = Promise.resolve();
        m.nextTick = e.then.bind(e);
      }
    });
    ge = I((nh, jt) => {
      "use strict";
      p();
      var Re = typeof Reflect == "object" ? Reflect : null, zn = Re && typeof Re.apply == "function" ? Re.apply : a(function(e, t, n) {
        return Function.prototype.apply.call(e, t, n);
      }, "ReflectApply"), ut;
      Re && typeof Re.ownKeys == "function" ? ut = Re.ownKeys : Object.getOwnPropertySymbols ? ut = a(function(e) {
        return Object.getOwnPropertyNames(
          e
        ).concat(Object.getOwnPropertySymbols(e));
      }, "ReflectOwnKeys") : ut = a(function(e) {
        return Object.getOwnPropertyNames(e);
      }, "ReflectOwnKeys");
      function Wo(r) {
        console && console.warn && console.warn(r);
      }
      __name(Wo, "Wo");
      a(Wo, "ProcessEmitWarning");
      var Zn = Number.isNaN || a(function(e) {
        return e !== e;
      }, "NumberIsNaN");
      function L() {
        L.init.call(this);
      }
      __name(L, "L");
      a(L, "EventEmitter");
      jt.exports = L;
      jt.exports.once = Vo;
      L.EventEmitter = L;
      L.prototype._events = void 0;
      L.prototype._eventsCount = 0;
      L.prototype._maxListeners = void 0;
      var Yn = 10;
      function ct(r) {
        if (typeof r != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof r);
      }
      __name(ct, "ct");
      a(ct, "checkListener");
      Object.defineProperty(L, "defaultMaxListeners", { enumerable: true, get: a(function() {
        return Yn;
      }, "get"), set: a(function(r) {
        if (typeof r != "number" || r < 0 || Zn(r)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + r + ".");
        Yn = r;
      }, "set") });
      L.init = function() {
        (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
      };
      L.prototype.setMaxListeners = a(
        function(e) {
          if (typeof e != "number" || e < 0 || Zn(e)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
          return this._maxListeners = e, this;
        },
        "setMaxListeners"
      );
      function Jn(r) {
        return r._maxListeners === void 0 ? L.defaultMaxListeners : r._maxListeners;
      }
      __name(Jn, "Jn");
      a(Jn, "_getMaxListeners");
      L.prototype.getMaxListeners = a(function() {
        return Jn(this);
      }, "getMaxListeners");
      L.prototype.emit = a(function(e) {
        for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
        var i = e === "error", s = this._events;
        if (s !== void 0) i = i && s.error === void 0;
        else if (!i) return false;
        if (i) {
          var o;
          if (t.length > 0 && (o = t[0]), o instanceof Error) throw o;
          var u = new Error("Unhandled error." + (o ? " (" + o.message + ")" : ""));
          throw u.context = o, u;
        }
        var c = s[e];
        if (c === void 0) return false;
        if (typeof c == "function") zn(c, this, t);
        else for (var h = c.length, l = ni(c, h), n = 0; n < h; ++n) zn(
          l[n],
          this,
          t
        );
        return true;
      }, "emit");
      function Xn(r, e, t, n) {
        var i, s, o;
        if (ct(t), s = r._events, s === void 0 ? (s = r._events = /* @__PURE__ */ Object.create(null), r._eventsCount = 0) : (s.newListener !== void 0 && (r.emit(
          "newListener",
          e,
          t.listener ? t.listener : t
        ), s = r._events), o = s[e]), o === void 0) o = s[e] = t, ++r._eventsCount;
        else if (typeof o == "function" ? o = s[e] = n ? [t, o] : [o, t] : n ? o.unshift(
          t
        ) : o.push(t), i = Jn(r), i > 0 && o.length > i && !o.warned) {
          o.warned = true;
          var u = new Error("Possible EventEmitter memory leak detected. " + o.length + " " + String(e) + " listeners added. Use emitter.setMaxListeners() to increase limit");
          u.name = "MaxListenersExceededWarning", u.emitter = r, u.type = e, u.count = o.length, Wo(u);
        }
        return r;
      }
      __name(Xn, "Xn");
      a(Xn, "_addListener");
      L.prototype.addListener = a(function(e, t) {
        return Xn(this, e, t, false);
      }, "addListener");
      L.prototype.on = L.prototype.addListener;
      L.prototype.prependListener = a(function(e, t) {
        return Xn(this, e, t, true);
      }, "prependListener");
      function Ho() {
        if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = true, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
      }
      __name(Ho, "Ho");
      a(
        Ho,
        "onceWrapper"
      );
      function ei(r, e, t) {
        var n = {
          fired: false,
          wrapFn: void 0,
          target: r,
          type: e,
          listener: t
        }, i = Ho.bind(n);
        return i.listener = t, n.wrapFn = i, i;
      }
      __name(ei, "ei");
      a(ei, "_onceWrap");
      L.prototype.once = a(function(e, t) {
        return ct(t), this.on(e, ei(this, e, t)), this;
      }, "once");
      L.prototype.prependOnceListener = a(function(e, t) {
        return ct(t), this.prependListener(e, ei(
          this,
          e,
          t
        )), this;
      }, "prependOnceListener");
      L.prototype.removeListener = a(
        function(e, t) {
          var n, i, s, o, u;
          if (ct(t), i = this._events, i === void 0) return this;
          if (n = i[e], n === void 0) return this;
          if (n === t || n.listener === t) --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete i[e], i.removeListener && this.emit("removeListener", e, n.listener || t));
          else if (typeof n != "function") {
            for (s = -1, o = n.length - 1; o >= 0; o--) if (n[o] === t || n[o].listener === t) {
              u = n[o].listener, s = o;
              break;
            }
            if (s < 0) return this;
            s === 0 ? n.shift() : Go(n, s), n.length === 1 && (i[e] = n[0]), i.removeListener !== void 0 && this.emit("removeListener", e, u || t);
          }
          return this;
        },
        "removeListener"
      );
      L.prototype.off = L.prototype.removeListener;
      L.prototype.removeAllListeners = a(function(e) {
        var t, n, i;
        if (n = this._events, n === void 0) return this;
        if (n.removeListener === void 0) return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : n[e] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete n[e]), this;
        if (arguments.length === 0) {
          var s = Object.keys(n), o;
          for (i = 0; i < s.length; ++i) o = s[i], o !== "removeListener" && this.removeAllListeners(o);
          return this.removeAllListeners(
            "removeListener"
          ), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
        }
        if (t = n[e], typeof t == "function") this.removeListener(e, t);
        else if (t !== void 0) for (i = t.length - 1; i >= 0; i--) this.removeListener(e, t[i]);
        return this;
      }, "removeAllListeners");
      function ti(r, e, t) {
        var n = r._events;
        if (n === void 0) return [];
        var i = n[e];
        return i === void 0 ? [] : typeof i == "function" ? t ? [i.listener || i] : [i] : t ? $o(i) : ni(i, i.length);
      }
      __name(ti, "ti");
      a(ti, "_listeners");
      L.prototype.listeners = a(function(e) {
        return ti(this, e, true);
      }, "listeners");
      L.prototype.rawListeners = a(function(e) {
        return ti(this, e, false);
      }, "rawListeners");
      L.listenerCount = function(r, e) {
        return typeof r.listenerCount == "function" ? r.listenerCount(e) : ri.call(r, e);
      };
      L.prototype.listenerCount = ri;
      function ri(r) {
        var e = this._events;
        if (e !== void 0) {
          var t = e[r];
          if (typeof t == "function") return 1;
          if (t !== void 0) return t.length;
        }
        return 0;
      }
      __name(ri, "ri");
      a(ri, "listenerCount");
      L.prototype.eventNames = a(function() {
        return this._eventsCount > 0 ? ut(this._events) : [];
      }, "eventNames");
      function ni(r, e) {
        for (var t = new Array(e), n = 0; n < e; ++n) t[n] = r[n];
        return t;
      }
      __name(ni, "ni");
      a(ni, "arrayClone");
      function Go(r, e) {
        for (; e + 1 < r.length; e++) r[e] = r[e + 1];
        r.pop();
      }
      __name(Go, "Go");
      a(Go, "spliceOne");
      function $o(r) {
        for (var e = new Array(r.length), t = 0; t < e.length; ++t)
          e[t] = r[t].listener || r[t];
        return e;
      }
      __name($o, "$o");
      a($o, "unwrapListeners");
      function Vo(r, e) {
        return new Promise(
          function(t, n) {
            function i(o) {
              r.removeListener(e, s), n(o);
            }
            __name(i, "i");
            a(i, "errorListener");
            function s() {
              typeof r.removeListener == "function" && r.removeListener("error", i), t([].slice.call(
                arguments
              ));
            }
            __name(s, "s");
            a(s, "resolver"), ii(r, e, s, { once: true }), e !== "error" && Ko(r, i, { once: true });
          }
        );
      }
      __name(Vo, "Vo");
      a(Vo, "once");
      function Ko(r, e, t) {
        typeof r.on == "function" && ii(r, "error", e, t);
      }
      __name(Ko, "Ko");
      a(
        Ko,
        "addErrorHandlerIfEventEmitter"
      );
      function ii(r, e, t, n) {
        if (typeof r.on == "function")
          n.once ? r.once(e, t) : r.on(e, t);
        else if (typeof r.addEventListener == "function") r.addEventListener(
          e,
          a(/* @__PURE__ */ __name(function i(s) {
            n.once && r.removeEventListener(e, i), t(s);
          }, "i"), "wrapListener")
        );
        else
          throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof r);
      }
      __name(ii, "ii");
      a(ii, "eventTargetAgnosticAddListener");
    });
    He = {};
    se(He, { default: /* @__PURE__ */ __name(() => zo, "default") });
    Ge = z(() => {
      "use strict";
      p();
      zo = {};
    });
    __name($e, "$e");
    si = z(
      () => {
        "use strict";
        p();
        a($e, "sha256");
      }
    );
    oi = z(() => {
      "use strict";
      p();
      U = class U2 {
        static {
          __name(this, "U");
        }
        constructor() {
          _(
            this,
            "_dataLength",
            0
          );
          _(this, "_bufferLength", 0);
          _(this, "_state", new Int32Array(4));
          _(
            this,
            "_buffer",
            new ArrayBuffer(68)
          );
          _(this, "_buffer8");
          _(this, "_buffer32");
          this._buffer8 = new Uint8Array(
            this._buffer,
            0,
            68
          ), this._buffer32 = new Uint32Array(this._buffer, 0, 17), this.start();
        }
        static hashByteArray(e, t = false) {
          return this.onePassHasher.start().appendByteArray(e).end(t);
        }
        static hashStr(e, t = false) {
          return this.onePassHasher.start().appendStr(e).end(t);
        }
        static hashAsciiStr(e, t = false) {
          return this.onePassHasher.start().appendAsciiStr(e).end(t);
        }
        static _hex(e) {
          let t = U2.hexChars, n = U2.hexOut, i, s, o, u;
          for (u = 0; u < 4; u += 1) for (s = u * 8, i = e[u], o = 0; o < 8; o += 2) n[s + 1 + o] = t.charAt(i & 15), i >>>= 4, n[s + 0 + o] = t.charAt(i & 15), i >>>= 4;
          return n.join("");
        }
        static _md5cycle(e, t) {
          let n = e[0], i = e[1], s = e[2], o = e[3];
          n += (i & s | ~i & o) + t[0] - 680876936 | 0, n = (n << 7 | n >>> 25) + i | 0, o += (n & i | ~n & s) + t[1] - 389564586 | 0, o = (o << 12 | o >>> 20) + n | 0, s += (o & n | ~o & i) + t[2] + 606105819 | 0, s = (s << 17 | s >>> 15) + o | 0, i += (s & o | ~s & n) + t[3] - 1044525330 | 0, i = (i << 22 | i >>> 10) + s | 0, n += (i & s | ~i & o) + t[4] - 176418897 | 0, n = (n << 7 | n >>> 25) + i | 0, o += (n & i | ~n & s) + t[5] + 1200080426 | 0, o = (o << 12 | o >>> 20) + n | 0, s += (o & n | ~o & i) + t[6] - 1473231341 | 0, s = (s << 17 | s >>> 15) + o | 0, i += (s & o | ~s & n) + t[7] - 45705983 | 0, i = (i << 22 | i >>> 10) + s | 0, n += (i & s | ~i & o) + t[8] + 1770035416 | 0, n = (n << 7 | n >>> 25) + i | 0, o += (n & i | ~n & s) + t[9] - 1958414417 | 0, o = (o << 12 | o >>> 20) + n | 0, s += (o & n | ~o & i) + t[10] - 42063 | 0, s = (s << 17 | s >>> 15) + o | 0, i += (s & o | ~s & n) + t[11] - 1990404162 | 0, i = (i << 22 | i >>> 10) + s | 0, n += (i & s | ~i & o) + t[12] + 1804603682 | 0, n = (n << 7 | n >>> 25) + i | 0, o += (n & i | ~n & s) + t[13] - 40341101 | 0, o = (o << 12 | o >>> 20) + n | 0, s += (o & n | ~o & i) + t[14] - 1502002290 | 0, s = (s << 17 | s >>> 15) + o | 0, i += (s & o | ~s & n) + t[15] + 1236535329 | 0, i = (i << 22 | i >>> 10) + s | 0, n += (i & o | s & ~o) + t[1] - 165796510 | 0, n = (n << 5 | n >>> 27) + i | 0, o += (n & s | i & ~s) + t[6] - 1069501632 | 0, o = (o << 9 | o >>> 23) + n | 0, s += (o & i | n & ~i) + t[11] + 643717713 | 0, s = (s << 14 | s >>> 18) + o | 0, i += (s & n | o & ~n) + t[0] - 373897302 | 0, i = (i << 20 | i >>> 12) + s | 0, n += (i & o | s & ~o) + t[5] - 701558691 | 0, n = (n << 5 | n >>> 27) + i | 0, o += (n & s | i & ~s) + t[10] + 38016083 | 0, o = (o << 9 | o >>> 23) + n | 0, s += (o & i | n & ~i) + t[15] - 660478335 | 0, s = (s << 14 | s >>> 18) + o | 0, i += (s & n | o & ~n) + t[4] - 405537848 | 0, i = (i << 20 | i >>> 12) + s | 0, n += (i & o | s & ~o) + t[9] + 568446438 | 0, n = (n << 5 | n >>> 27) + i | 0, o += (n & s | i & ~s) + t[14] - 1019803690 | 0, o = (o << 9 | o >>> 23) + n | 0, s += (o & i | n & ~i) + t[3] - 187363961 | 0, s = (s << 14 | s >>> 18) + o | 0, i += (s & n | o & ~n) + t[8] + 1163531501 | 0, i = (i << 20 | i >>> 12) + s | 0, n += (i & o | s & ~o) + t[13] - 1444681467 | 0, n = (n << 5 | n >>> 27) + i | 0, o += (n & s | i & ~s) + t[2] - 51403784 | 0, o = (o << 9 | o >>> 23) + n | 0, s += (o & i | n & ~i) + t[7] + 1735328473 | 0, s = (s << 14 | s >>> 18) + o | 0, i += (s & n | o & ~n) + t[12] - 1926607734 | 0, i = (i << 20 | i >>> 12) + s | 0, n += (i ^ s ^ o) + t[5] - 378558 | 0, n = (n << 4 | n >>> 28) + i | 0, o += (n ^ i ^ s) + t[8] - 2022574463 | 0, o = (o << 11 | o >>> 21) + n | 0, s += (o ^ n ^ i) + t[11] + 1839030562 | 0, s = (s << 16 | s >>> 16) + o | 0, i += (s ^ o ^ n) + t[14] - 35309556 | 0, i = (i << 23 | i >>> 9) + s | 0, n += (i ^ s ^ o) + t[1] - 1530992060 | 0, n = (n << 4 | n >>> 28) + i | 0, o += (n ^ i ^ s) + t[4] + 1272893353 | 0, o = (o << 11 | o >>> 21) + n | 0, s += (o ^ n ^ i) + t[7] - 155497632 | 0, s = (s << 16 | s >>> 16) + o | 0, i += (s ^ o ^ n) + t[10] - 1094730640 | 0, i = (i << 23 | i >>> 9) + s | 0, n += (i ^ s ^ o) + t[13] + 681279174 | 0, n = (n << 4 | n >>> 28) + i | 0, o += (n ^ i ^ s) + t[0] - 358537222 | 0, o = (o << 11 | o >>> 21) + n | 0, s += (o ^ n ^ i) + t[3] - 722521979 | 0, s = (s << 16 | s >>> 16) + o | 0, i += (s ^ o ^ n) + t[6] + 76029189 | 0, i = (i << 23 | i >>> 9) + s | 0, n += (i ^ s ^ o) + t[9] - 640364487 | 0, n = (n << 4 | n >>> 28) + i | 0, o += (n ^ i ^ s) + t[12] - 421815835 | 0, o = (o << 11 | o >>> 21) + n | 0, s += (o ^ n ^ i) + t[15] + 530742520 | 0, s = (s << 16 | s >>> 16) + o | 0, i += (s ^ o ^ n) + t[2] - 995338651 | 0, i = (i << 23 | i >>> 9) + s | 0, n += (s ^ (i | ~o)) + t[0] - 198630844 | 0, n = (n << 6 | n >>> 26) + i | 0, o += (i ^ (n | ~s)) + t[7] + 1126891415 | 0, o = (o << 10 | o >>> 22) + n | 0, s += (n ^ (o | ~i)) + t[14] - 1416354905 | 0, s = (s << 15 | s >>> 17) + o | 0, i += (o ^ (s | ~n)) + t[5] - 57434055 | 0, i = (i << 21 | i >>> 11) + s | 0, n += (s ^ (i | ~o)) + t[12] + 1700485571 | 0, n = (n << 6 | n >>> 26) + i | 0, o += (i ^ (n | ~s)) + t[3] - 1894986606 | 0, o = (o << 10 | o >>> 22) + n | 0, s += (n ^ (o | ~i)) + t[10] - 1051523 | 0, s = (s << 15 | s >>> 17) + o | 0, i += (o ^ (s | ~n)) + t[1] - 2054922799 | 0, i = (i << 21 | i >>> 11) + s | 0, n += (s ^ (i | ~o)) + t[8] + 1873313359 | 0, n = (n << 6 | n >>> 26) + i | 0, o += (i ^ (n | ~s)) + t[15] - 30611744 | 0, o = (o << 10 | o >>> 22) + n | 0, s += (n ^ (o | ~i)) + t[6] - 1560198380 | 0, s = (s << 15 | s >>> 17) + o | 0, i += (o ^ (s | ~n)) + t[13] + 1309151649 | 0, i = (i << 21 | i >>> 11) + s | 0, n += (s ^ (i | ~o)) + t[4] - 145523070 | 0, n = (n << 6 | n >>> 26) + i | 0, o += (i ^ (n | ~s)) + t[11] - 1120210379 | 0, o = (o << 10 | o >>> 22) + n | 0, s += (n ^ (o | ~i)) + t[2] + 718787259 | 0, s = (s << 15 | s >>> 17) + o | 0, i += (o ^ (s | ~n)) + t[9] - 343485551 | 0, i = (i << 21 | i >>> 11) + s | 0, e[0] = n + e[0] | 0, e[1] = i + e[1] | 0, e[2] = s + e[2] | 0, e[3] = o + e[3] | 0;
        }
        start() {
          return this._dataLength = 0, this._bufferLength = 0, this._state.set(U2.stateIdentity), this;
        }
        appendStr(e) {
          let t = this._buffer8, n = this._buffer32, i = this._bufferLength, s, o;
          for (o = 0; o < e.length; o += 1) {
            if (s = e.charCodeAt(o), s < 128) t[i++] = s;
            else if (s < 2048) t[i++] = (s >>> 6) + 192, t[i++] = s & 63 | 128;
            else if (s < 55296 || s > 56319) t[i++] = (s >>> 12) + 224, t[i++] = s >>> 6 & 63 | 128, t[i++] = s & 63 | 128;
            else {
              if (s = (s - 55296) * 1024 + (e.charCodeAt(++o) - 56320) + 65536, s > 1114111) throw new Error("Unicode standard supports code points up to U+10FFFF");
              t[i++] = (s >>> 18) + 240, t[i++] = s >>> 12 & 63 | 128, t[i++] = s >>> 6 & 63 | 128, t[i++] = s & 63 | 128;
            }
            i >= 64 && (this._dataLength += 64, U2._md5cycle(this._state, n), i -= 64, n[0] = n[16]);
          }
          return this._bufferLength = i, this;
        }
        appendAsciiStr(e) {
          let t = this._buffer8, n = this._buffer32, i = this._bufferLength, s, o = 0;
          for (; ; ) {
            for (s = Math.min(e.length - o, 64 - i); s--; ) t[i++] = e.charCodeAt(o++);
            if (i < 64) break;
            this._dataLength += 64, U2._md5cycle(
              this._state,
              n
            ), i = 0;
          }
          return this._bufferLength = i, this;
        }
        appendByteArray(e) {
          let t = this._buffer8, n = this._buffer32, i = this._bufferLength, s, o = 0;
          for (; ; ) {
            for (s = Math.min(e.length - o, 64 - i); s--; ) t[i++] = e[o++];
            if (i < 64) break;
            this._dataLength += 64, U2._md5cycle(
              this._state,
              n
            ), i = 0;
          }
          return this._bufferLength = i, this;
        }
        getState() {
          let e = this._state;
          return { buffer: String.fromCharCode.apply(null, Array.from(this._buffer8)), buflen: this._bufferLength, length: this._dataLength, state: [e[0], e[1], e[2], e[3]] };
        }
        setState(e) {
          let t = e.buffer, n = e.state, i = this._state, s;
          for (this._dataLength = e.length, this._bufferLength = e.buflen, i[0] = n[0], i[1] = n[1], i[2] = n[2], i[3] = n[3], s = 0; s < t.length; s += 1) this._buffer8[s] = t.charCodeAt(s);
        }
        end(e = false) {
          let t = this._bufferLength, n = this._buffer8, i = this._buffer32, s = (t >> 2) + 1;
          this._dataLength += t;
          let o = this._dataLength * 8;
          if (n[t] = 128, n[t + 1] = n[t + 2] = n[t + 3] = 0, i.set(U2.buffer32Identity.subarray(s), s), t > 55 && (U2._md5cycle(this._state, i), i.set(U2.buffer32Identity)), o <= 4294967295)
            i[14] = o;
          else {
            let u = o.toString(16).match(/(.*?)(.{0,8})$/);
            if (u === null) return;
            let c = parseInt(
              u[2],
              16
            ), h = parseInt(u[1], 16) || 0;
            i[14] = c, i[15] = h;
          }
          return U2._md5cycle(this._state, i), e ? this._state : U2._hex(this._state);
        }
      };
      a(U, "Md5"), _(U, "stateIdentity", new Int32Array(
        [1732584193, -271733879, -1732584194, 271733878]
      )), _(U, "buffer32Identity", new Int32Array(
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      )), _(U, "hexChars", "0123456789abcdef"), _(U, "hexOut", []), _(U, "onePassHasher", new U());
      Ve = U;
    });
    Wt = {};
    se(Wt, { createHash: /* @__PURE__ */ __name(() => Zo, "createHash"), createHmac: /* @__PURE__ */ __name(() => Jo, "createHmac"), randomBytes: /* @__PURE__ */ __name(() => Yo, "randomBytes") });
    __name(Yo, "Yo");
    __name(Zo, "Zo");
    __name(Jo, "Jo");
    Ht = z(() => {
      "use strict";
      p();
      si();
      oi();
      a(Yo, "randomBytes");
      a(Zo, "createHash");
      a(Jo, "createHmac");
    });
    $t = I((ai) => {
      "use strict";
      p();
      ai.parse = function(r, e) {
        return new Gt(r, e).parse();
      };
      var ht = class ht2 {
        static {
          __name(this, "ht");
        }
        constructor(e, t) {
          this.source = e, this.transform = t || Xo, this.position = 0, this.entries = [], this.recorded = [], this.dimension = 0;
        }
        isEof() {
          return this.position >= this.source.length;
        }
        nextCharacter() {
          var e = this.source[this.position++];
          return e === "\\" ? { value: this.source[this.position++], escaped: true } : { value: e, escaped: false };
        }
        record(e) {
          this.recorded.push(e);
        }
        newEntry(e) {
          var t;
          (this.recorded.length > 0 || e) && (t = this.recorded.join(""), t === "NULL" && !e && (t = null), t !== null && (t = this.transform(t)), this.entries.push(
            t
          ), this.recorded = []);
        }
        consumeDimensions() {
          if (this.source[0] === "[") for (; !this.isEof(); ) {
            var e = this.nextCharacter();
            if (e.value === "=") break;
          }
        }
        parse(e) {
          var t, n, i;
          for (this.consumeDimensions(); !this.isEof(); ) if (t = this.nextCharacter(), t.value === "{" && !i) this.dimension++, this.dimension > 1 && (n = new ht2(this.source.substr(this.position - 1), this.transform), this.entries.push(
            n.parse(true)
          ), this.position += n.position - 2);
          else if (t.value === "}" && !i) {
            if (this.dimension--, !this.dimension && (this.newEntry(), e)) return this.entries;
          } else t.value === '"' && !t.escaped ? (i && this.newEntry(true), i = !i) : t.value === "," && !i ? this.newEntry() : this.record(
            t.value
          );
          if (this.dimension !== 0) throw new Error("array dimension not balanced");
          return this.entries;
        }
      };
      a(ht, "ArrayParser");
      var Gt = ht;
      function Xo(r) {
        return r;
      }
      __name(Xo, "Xo");
      a(Xo, "identity");
    });
    Vt = I((Sh, ui) => {
      p();
      var ea = $t();
      ui.exports = { create: a(function(r, e) {
        return { parse: a(
          function() {
            return ea.parse(r, e);
          },
          "parse"
        ) };
      }, "create") };
    });
    li = I((vh, hi) => {
      "use strict";
      p();
      var ta = /(\d{1,})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d{1,})?.*?( BC)?$/, ra = /^(\d{1,})-(\d{2})-(\d{2})( BC)?$/, na = /([Z+-])(\d{2})?:?(\d{2})?:?(\d{2})?/, ia = /^-?infinity$/;
      hi.exports = a(function(e) {
        if (ia.test(e)) return Number(e.replace("i", "I"));
        var t = ta.exec(e);
        if (!t) return sa(e) || null;
        var n = !!t[8], i = parseInt(t[1], 10);
        n && (i = ci(i));
        var s = parseInt(
          t[2],
          10
        ) - 1, o = t[3], u = parseInt(t[4], 10), c = parseInt(t[5], 10), h = parseInt(t[6], 10), l = t[7];
        l = l ? 1e3 * parseFloat(l) : 0;
        var d, b = oa(e);
        return b != null ? (d = new Date(Date.UTC(
          i,
          s,
          o,
          u,
          c,
          h,
          l
        )), Kt(i) && d.setUTCFullYear(i), b !== 0 && d.setTime(d.getTime() - b)) : (d = new Date(
          i,
          s,
          o,
          u,
          c,
          h,
          l
        ), Kt(i) && d.setFullYear(i)), d;
      }, "parseDate");
      function sa(r) {
        var e = ra.exec(r);
        if (e) {
          var t = parseInt(e[1], 10), n = !!e[4];
          n && (t = ci(t));
          var i = parseInt(
            e[2],
            10
          ) - 1, s = e[3], o = new Date(t, i, s);
          return Kt(t) && o.setFullYear(t), o;
        }
      }
      __name(sa, "sa");
      a(sa, "getDate");
      function oa(r) {
        if (r.endsWith("+00")) return 0;
        var e = na.exec(r.split(" ")[1]);
        if (e) {
          var t = e[1];
          if (t === "Z") return 0;
          var n = t === "-" ? -1 : 1, i = parseInt(e[2], 10) * 3600 + parseInt(
            e[3] || 0,
            10
          ) * 60 + parseInt(e[4] || 0, 10);
          return i * n * 1e3;
        }
      }
      __name(oa, "oa");
      a(oa, "timeZoneOffset");
      function ci(r) {
        return -(r - 1);
      }
      __name(ci, "ci");
      a(ci, "bcYearToNegativeYear");
      function Kt(r) {
        return r >= 0 && r < 100;
      }
      __name(Kt, "Kt");
      a(
        Kt,
        "is0To99"
      );
    });
    pi = I((Ch, fi) => {
      p();
      fi.exports = ua;
      var aa = Object.prototype.hasOwnProperty;
      function ua(r) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];
          for (var n in t) aa.call(
            t,
            n
          ) && (r[n] = t[n]);
        }
        return r;
      }
      __name(ua, "ua");
      a(ua, "extend");
    });
    mi = I((Ph, yi) => {
      "use strict";
      p();
      var ca = pi();
      yi.exports = Fe;
      function Fe(r) {
        if (!(this instanceof Fe)) return new Fe(r);
        ca(this, xa(r));
      }
      __name(Fe, "Fe");
      a(Fe, "PostgresInterval");
      var ha = ["seconds", "minutes", "hours", "days", "months", "years"];
      Fe.prototype.toPostgres = function() {
        var r = ha.filter(this.hasOwnProperty, this);
        return this.milliseconds && r.indexOf("seconds") < 0 && r.push("seconds"), r.length === 0 ? "0" : r.map(function(e) {
          var t = this[e] || 0;
          return e === "seconds" && this.milliseconds && (t = (t + this.milliseconds / 1e3).toFixed(6).replace(
            /\.?0+$/,
            ""
          )), t + " " + e;
        }, this).join(" ");
      };
      var la = { years: "Y", months: "M", days: "D", hours: "H", minutes: "M", seconds: "S" }, fa = ["years", "months", "days"], pa = ["hours", "minutes", "seconds"];
      Fe.prototype.toISOString = Fe.prototype.toISO = function() {
        var r = fa.map(t, this).join(""), e = pa.map(t, this).join("");
        return "P" + r + "T" + e;
        function t(n) {
          var i = this[n] || 0;
          return n === "seconds" && this.milliseconds && (i = (i + this.milliseconds / 1e3).toFixed(6).replace(
            /0+$/,
            ""
          )), i + la[n];
        }
        __name(t, "t");
      };
      var zt = "([+-]?\\d+)", da = zt + "\\s+years?", ya = zt + "\\s+mons?", ma = zt + "\\s+days?", ga = "([+-])?([\\d]*):(\\d\\d):(\\d\\d)\\.?(\\d{1,6})?", wa = new RegExp([
        da,
        ya,
        ma,
        ga
      ].map(function(r) {
        return "(" + r + ")?";
      }).join("\\s*")), di = {
        years: 2,
        months: 4,
        days: 6,
        hours: 9,
        minutes: 10,
        seconds: 11,
        milliseconds: 12
      }, ba = ["hours", "minutes", "seconds", "milliseconds"];
      function Sa(r) {
        var e = r + "000000".slice(r.length);
        return parseInt(
          e,
          10
        ) / 1e3;
      }
      __name(Sa, "Sa");
      a(Sa, "parseMilliseconds");
      function xa(r) {
        if (!r) return {};
        var e = wa.exec(
          r
        ), t = e[8] === "-";
        return Object.keys(di).reduce(function(n, i) {
          var s = di[i], o = e[s];
          return !o || (o = i === "milliseconds" ? Sa(o) : parseInt(o, 10), !o) || (t && ~ba.indexOf(i) && (o *= -1), n[i] = o), n;
        }, {});
      }
      __name(xa, "xa");
      a(xa, "parse");
    });
    wi = I((Rh, gi) => {
      "use strict";
      p();
      gi.exports = a(function(e) {
        if (/^\\x/.test(e)) return new y(
          e.substr(2),
          "hex"
        );
        for (var t = "", n = 0; n < e.length; ) if (e[n] !== "\\") t += e[n], ++n;
        else if (/[0-7]{3}/.test(e.substr(n + 1, 3))) t += String.fromCharCode(parseInt(e.substr(n + 1, 3), 8)), n += 4;
        else {
          for (var i = 1; n + i < e.length && e[n + i] === "\\"; ) i++;
          for (var s = 0; s < Math.floor(i / 2); ++s) t += "\\";
          n += Math.floor(i / 2) * 2;
        }
        return new y(t, "binary");
      }, "parseBytea");
    });
    Ai = I((Dh, _i) => {
      p();
      var Ke = $t(), ze = Vt(), lt2 = li(), Si = mi(), xi = wi();
      function ft(r) {
        return a(function(t) {
          return t === null ? t : r(t);
        }, "nullAllowed");
      }
      __name(ft, "ft");
      a(ft, "allowNull");
      function Ei(r) {
        return r === null ? r : r === "TRUE" || r === "t" || r === "true" || r === "y" || r === "yes" || r === "on" || r === "1";
      }
      __name(Ei, "Ei");
      a(Ei, "parseBool");
      function Ea(r) {
        return r ? Ke.parse(r, Ei) : null;
      }
      __name(Ea, "Ea");
      a(Ea, "parseBoolArray");
      function va(r) {
        return parseInt(r, 10);
      }
      __name(va, "va");
      a(va, "parseBaseTenInt");
      function Yt(r) {
        return r ? Ke.parse(r, ft(va)) : null;
      }
      __name(Yt, "Yt");
      a(Yt, "parseIntegerArray");
      function _a(r) {
        return r ? Ke.parse(r, ft(function(e) {
          return vi(e).trim();
        })) : null;
      }
      __name(_a, "_a");
      a(_a, "parseBigIntegerArray");
      var Aa = a(function(r) {
        if (!r) return null;
        var e = ze.create(r, function(t) {
          return t !== null && (t = er(t)), t;
        });
        return e.parse();
      }, "parsePointArray"), Zt = a(function(r) {
        if (!r)
          return null;
        var e = ze.create(r, function(t) {
          return t !== null && (t = parseFloat(t)), t;
        });
        return e.parse();
      }, "parseFloatArray"), ne2 = a(function(r) {
        if (!r) return null;
        var e = ze.create(r);
        return e.parse();
      }, "parseStringArray"), Jt = a(function(r) {
        if (!r) return null;
        var e = ze.create(r, function(t) {
          return t !== null && (t = lt2(t)), t;
        });
        return e.parse();
      }, "parseDateArray"), Ca = a(function(r) {
        if (!r) return null;
        var e = ze.create(r, function(t) {
          return t !== null && (t = Si(t)), t;
        });
        return e.parse();
      }, "parseIntervalArray"), Ta = a(function(r) {
        return r ? Ke.parse(r, ft(xi)) : null;
      }, "parseByteAArray"), Xt = a(function(r) {
        return parseInt(
          r,
          10
        );
      }, "parseInteger"), vi = a(function(r) {
        var e = String(r);
        return /^\d+$/.test(e) ? e : r;
      }, "parseBigInteger"), bi = a(
        function(r) {
          return r ? Ke.parse(r, ft(JSON.parse)) : null;
        },
        "parseJsonArray"
      ), er = a(function(r) {
        return r[0] !== "(" ? null : (r = r.substring(1, r.length - 1).split(","), { x: parseFloat(r[0]), y: parseFloat(r[1]) });
      }, "parsePoint"), Ia = a(function(r) {
        if (r[0] !== "<" && r[1] !== "(") return null;
        for (var e = "(", t = "", n = false, i = 2; i < r.length - 1; i++) {
          if (n || (e += r[i]), r[i] === ")") {
            n = true;
            continue;
          } else if (!n) continue;
          r[i] !== "," && (t += r[i]);
        }
        var s = er(e);
        return s.radius = parseFloat(t), s;
      }, "parseCircle"), Pa = a(function(r) {
        r(
          20,
          vi
        ), r(21, Xt), r(23, Xt), r(26, Xt), r(700, parseFloat), r(701, parseFloat), r(16, Ei), r(
          1082,
          lt2
        ), r(1114, lt2), r(1184, lt2), r(600, er), r(651, ne2), r(718, Ia), r(1e3, Ea), r(1001, Ta), r(
          1005,
          Yt
        ), r(1007, Yt), r(1028, Yt), r(1016, _a), r(1017, Aa), r(1021, Zt), r(1022, Zt), r(1231, Zt), r(1014, ne2), r(1015, ne2), r(1008, ne2), r(1009, ne2), r(1040, ne2), r(1041, ne2), r(1115, Jt), r(
          1182,
          Jt
        ), r(1185, Jt), r(1186, Si), r(1187, Ca), r(17, xi), r(114, JSON.parse.bind(JSON)), r(
          3802,
          JSON.parse.bind(JSON)
        ), r(199, bi), r(3807, bi), r(3907, ne2), r(2951, ne2), r(791, ne2), r(
          1183,
          ne2
        ), r(1270, ne2);
      }, "init");
      _i.exports = { init: Pa };
    });
    Ti = I((Oh, Ci) => {
      "use strict";
      p();
      var Z = 1e6;
      function Ba(r) {
        var e = r.readInt32BE(
          0
        ), t = r.readUInt32BE(4), n = "";
        e < 0 && (e = ~e + (t === 0), t = ~t + 1 >>> 0, n = "-");
        var i = "", s, o, u, c, h, l;
        {
          if (s = e % Z, e = e / Z >>> 0, o = 4294967296 * s + t, t = o / Z >>> 0, u = "" + (o - Z * t), t === 0 && e === 0) return n + u + i;
          for (c = "", h = 6 - u.length, l = 0; l < h; l++) c += "0";
          i = c + u + i;
        }
        {
          if (s = e % Z, e = e / Z >>> 0, o = 4294967296 * s + t, t = o / Z >>> 0, u = "" + (o - Z * t), t === 0 && e === 0) return n + u + i;
          for (c = "", h = 6 - u.length, l = 0; l < h; l++) c += "0";
          i = c + u + i;
        }
        {
          if (s = e % Z, e = e / Z >>> 0, o = 4294967296 * s + t, t = o / Z >>> 0, u = "" + (o - Z * t), t === 0 && e === 0) return n + u + i;
          for (c = "", h = 6 - u.length, l = 0; l < h; l++) c += "0";
          i = c + u + i;
        }
        return s = e % Z, o = 4294967296 * s + t, u = "" + o % Z, n + u + i;
      }
      __name(Ba, "Ba");
      a(Ba, "readInt8");
      Ci.exports = Ba;
    });
    Ri = I((Qh, Li) => {
      p();
      var La = Ti(), F = a(function(r, e, t, n, i) {
        t = t || 0, n = n || false, i = i || function(C, B, Q) {
          return C * Math.pow(2, Q) + B;
        };
        var s = t >> 3, o = a(function(C) {
          return n ? ~C & 255 : C;
        }, "inv"), u = 255, c = 8 - t % 8;
        e < c && (u = 255 << 8 - e & 255, c = e), t && (u = u >> t % 8);
        var h = 0;
        t % 8 + e >= 8 && (h = i(0, o(r[s]) & u, c));
        for (var l = e + t >> 3, d = s + 1; d < l; d++) h = i(h, o(r[d]), 8);
        var b = (e + t) % 8;
        return b > 0 && (h = i(h, o(r[l]) >> 8 - b, b)), h;
      }, "parseBits"), Bi = a(function(r, e, t) {
        var n = Math.pow(2, t - 1) - 1, i = F(r, 1), s = F(r, t, 1);
        if (s === 0) return 0;
        var o = 1, u = a(function(h, l, d) {
          h === 0 && (h = 1);
          for (var b = 1; b <= d; b++) o /= 2, (l & 1 << d - b) > 0 && (h += o);
          return h;
        }, "parsePrecisionBits"), c = F(r, e, t + 1, false, u);
        return s == Math.pow(2, t + 1) - 1 ? c === 0 ? i === 0 ? 1 / 0 : -1 / 0 : NaN : (i === 0 ? 1 : -1) * Math.pow(2, s - n) * c;
      }, "parseFloatFromBits"), Ra = a(function(r) {
        return F(r, 1) == 1 ? -1 * (F(r, 15, 1, true) + 1) : F(r, 15, 1);
      }, "parseInt16"), Ii = a(function(r) {
        return F(r, 1) == 1 ? -1 * (F(
          r,
          31,
          1,
          true
        ) + 1) : F(r, 31, 1);
      }, "parseInt32"), Fa = a(function(r) {
        return Bi(r, 23, 8);
      }, "parseFloat32"), Ma = a(function(r) {
        return Bi(r, 52, 11);
      }, "parseFloat64"), Da = a(function(r) {
        var e = F(r, 16, 32);
        if (e == 49152) return NaN;
        for (var t = Math.pow(1e4, F(r, 16, 16)), n = 0, i = [], s = F(r, 16), o = 0; o < s; o++) n += F(r, 16, 64 + 16 * o) * t, t /= 1e4;
        var u = Math.pow(10, F(r, 16, 48));
        return (e === 0 ? 1 : -1) * Math.round(n * u) / u;
      }, "parseNumeric"), Pi = a(function(r, e) {
        var t = F(
          e,
          1
        ), n = F(e, 63, 1), i = new Date((t === 0 ? 1 : -1) * n / 1e3 + 9466848e5);
        return r || i.setTime(i.getTime() + i.getTimezoneOffset() * 6e4), i.usec = n % 1e3, i.getMicroSeconds = function() {
          return this.usec;
        }, i.setMicroSeconds = function(s) {
          this.usec = s;
        }, i.getUTCMicroSeconds = function() {
          return this.usec;
        }, i;
      }, "parseDate"), Ye = a(function(r) {
        for (var e = F(r, 32), t = F(r, 32, 32), n = F(r, 32, 64), i = 96, s = [], o = 0; o < e; o++) s[o] = F(r, 32, i), i += 32, i += 32;
        var u = a(function(h) {
          var l = F(r, 32, i);
          if (i += 32, l == 4294967295) return null;
          var d;
          if (h == 23 || h == 20) return d = F(r, l * 8, i), i += l * 8, d;
          if (h == 25) return d = r.toString(this.encoding, i >> 3, (i += l << 3) >> 3), d;
          console.log("ERROR: ElementType not implemented: " + h);
        }, "parseElement"), c = a(function(h, l) {
          var d = [], b;
          if (h.length > 1) {
            var C = h.shift();
            for (b = 0; b < C; b++) d[b] = c(h, l);
            h.unshift(
              C
            );
          } else for (b = 0; b < h[0]; b++) d[b] = u(l);
          return d;
        }, "parse");
        return c(s, n);
      }, "parseArray"), ka = a(function(r) {
        return r.toString("utf8");
      }, "parseText"), Ua = a(function(r) {
        return r === null ? null : F(r, 8) > 0;
      }, "parseBool"), Oa = a(function(r) {
        r(20, La), r(21, Ra), r(23, Ii), r(
          26,
          Ii
        ), r(1700, Da), r(700, Fa), r(701, Ma), r(16, Ua), r(1114, Pi.bind(null, false)), r(1184, Pi.bind(
          null,
          true
        )), r(1e3, Ye), r(1007, Ye), r(1016, Ye), r(1008, Ye), r(1009, Ye), r(25, ka);
      }, "init");
      Li.exports = { init: Oa };
    });
    Mi = I((Hh, Fi) => {
      p();
      Fi.exports = {
        BOOL: 16,
        BYTEA: 17,
        CHAR: 18,
        INT8: 20,
        INT2: 21,
        INT4: 23,
        REGPROC: 24,
        TEXT: 25,
        OID: 26,
        TID: 27,
        XID: 28,
        CID: 29,
        JSON: 114,
        XML: 142,
        PG_NODE_TREE: 194,
        SMGR: 210,
        PATH: 602,
        POLYGON: 604,
        CIDR: 650,
        FLOAT4: 700,
        FLOAT8: 701,
        ABSTIME: 702,
        RELTIME: 703,
        TINTERVAL: 704,
        CIRCLE: 718,
        MACADDR8: 774,
        MONEY: 790,
        MACADDR: 829,
        INET: 869,
        ACLITEM: 1033,
        BPCHAR: 1042,
        VARCHAR: 1043,
        DATE: 1082,
        TIME: 1083,
        TIMESTAMP: 1114,
        TIMESTAMPTZ: 1184,
        INTERVAL: 1186,
        TIMETZ: 1266,
        BIT: 1560,
        VARBIT: 1562,
        NUMERIC: 1700,
        REFCURSOR: 1790,
        REGPROCEDURE: 2202,
        REGOPER: 2203,
        REGOPERATOR: 2204,
        REGCLASS: 2205,
        REGTYPE: 2206,
        UUID: 2950,
        TXID_SNAPSHOT: 2970,
        PG_LSN: 3220,
        PG_NDISTINCT: 3361,
        PG_DEPENDENCIES: 3402,
        TSVECTOR: 3614,
        TSQUERY: 3615,
        GTSVECTOR: 3642,
        REGCONFIG: 3734,
        REGDICTIONARY: 3769,
        JSONB: 3802,
        REGNAMESPACE: 4089,
        REGROLE: 4096
      };
    });
    Xe = I((Je) => {
      p();
      var Na = Ai(), qa = Ri(), Qa = Vt(), ja = Mi();
      Je.getTypeParser = Wa;
      Je.setTypeParser = Ha;
      Je.arrayParser = Qa;
      Je.builtins = ja;
      var Ze = { text: {}, binary: {} };
      function Di(r) {
        return String(
          r
        );
      }
      __name(Di, "Di");
      a(Di, "noParse");
      function Wa(r, e) {
        return e = e || "text", Ze[e] && Ze[e][r] || Di;
      }
      __name(Wa, "Wa");
      a(
        Wa,
        "getTypeParser"
      );
      function Ha(r, e, t) {
        typeof e == "function" && (t = e, e = "text"), Ze[e][r] = t;
      }
      __name(Ha, "Ha");
      a(Ha, "setTypeParser");
      Na.init(function(r, e) {
        Ze.text[r] = e;
      });
      qa.init(function(r, e) {
        Ze.binary[r] = e;
      });
    });
    et = I((zh, tr) => {
      "use strict";
      p();
      tr.exports = {
        host: "localhost",
        user: m.platform === "win32" ? m.env.USERNAME : m.env.USER,
        database: void 0,
        password: null,
        connectionString: void 0,
        port: 5432,
        rows: 0,
        binary: false,
        max: 10,
        idleTimeoutMillis: 3e4,
        client_encoding: "",
        ssl: false,
        application_name: void 0,
        fallback_application_name: void 0,
        options: void 0,
        parseInputDatesAsUTC: false,
        statement_timeout: false,
        lock_timeout: false,
        idle_in_transaction_session_timeout: false,
        query_timeout: false,
        connect_timeout: 0,
        keepalives: 1,
        keepalives_idle: 0
      };
      var Me = Xe(), Ga = Me.getTypeParser(
        20,
        "text"
      ), $a = Me.getTypeParser(1016, "text");
      tr.exports.__defineSetter__("parseInt8", function(r) {
        Me.setTypeParser(20, "text", r ? Me.getTypeParser(23, "text") : Ga), Me.setTypeParser(1016, "text", r ? Me.getTypeParser(1007, "text") : $a);
      });
    });
    tt = I((Zh, Ui) => {
      "use strict";
      p();
      var Va = (Ht(), O(Wt)), Ka = et();
      function za(r) {
        var e = r.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
        return '"' + e + '"';
      }
      __name(za, "za");
      a(za, "escapeElement");
      function ki(r) {
        for (var e = "{", t = 0; t < r.length; t++) t > 0 && (e = e + ","), r[t] === null || typeof r[t] > "u" ? e = e + "NULL" : Array.isArray(r[t]) ? e = e + ki(r[t]) : r[t] instanceof y ? e += "\\\\x" + r[t].toString("hex") : e += za(pt(r[t]));
        return e = e + "}", e;
      }
      __name(ki, "ki");
      a(ki, "arrayString");
      var pt = a(function(r, e) {
        if (r == null) return null;
        if (r instanceof y) return r;
        if (ArrayBuffer.isView(r)) {
          var t = y.from(r.buffer, r.byteOffset, r.byteLength);
          return t.length === r.byteLength ? t : t.slice(
            r.byteOffset,
            r.byteOffset + r.byteLength
          );
        }
        return r instanceof Date ? Ka.parseInputDatesAsUTC ? Ja(r) : Za(r) : Array.isArray(r) ? ki(r) : typeof r == "object" ? Ya(r, e) : r.toString();
      }, "prepareValue");
      function Ya(r, e) {
        if (r && typeof r.toPostgres == "function") {
          if (e = e || [], e.indexOf(r) !== -1) throw new Error('circular reference detected while preparing "' + r + '" for query');
          return e.push(r), pt(r.toPostgres(pt), e);
        }
        return JSON.stringify(r);
      }
      __name(Ya, "Ya");
      a(Ya, "prepareObject");
      function G(r, e) {
        for (r = "" + r; r.length < e; ) r = "0" + r;
        return r;
      }
      __name(G, "G");
      a(
        G,
        "pad"
      );
      function Za(r) {
        var e = -r.getTimezoneOffset(), t = r.getFullYear(), n = t < 1;
        n && (t = Math.abs(t) + 1);
        var i = G(t, 4) + "-" + G(r.getMonth() + 1, 2) + "-" + G(r.getDate(), 2) + "T" + G(r.getHours(), 2) + ":" + G(r.getMinutes(), 2) + ":" + G(r.getSeconds(), 2) + "." + G(
          r.getMilliseconds(),
          3
        );
        return e < 0 ? (i += "-", e *= -1) : i += "+", i += G(Math.floor(e / 60), 2) + ":" + G(e % 60, 2), n && (i += " BC"), i;
      }
      __name(Za, "Za");
      a(Za, "dateToString");
      function Ja(r) {
        var e = r.getUTCFullYear(), t = e < 1;
        t && (e = Math.abs(e) + 1);
        var n = G(e, 4) + "-" + G(r.getUTCMonth() + 1, 2) + "-" + G(r.getUTCDate(), 2) + "T" + G(r.getUTCHours(), 2) + ":" + G(r.getUTCMinutes(), 2) + ":" + G(r.getUTCSeconds(), 2) + "." + G(r.getUTCMilliseconds(), 3);
        return n += "+00:00", t && (n += " BC"), n;
      }
      __name(Ja, "Ja");
      a(Ja, "dateToStringUTC");
      function Xa(r, e, t) {
        return r = typeof r == "string" ? { text: r } : r, e && (typeof e == "function" ? r.callback = e : r.values = e), t && (r.callback = t), r;
      }
      __name(Xa, "Xa");
      a(Xa, "normalizeQueryConfig");
      var rr = a(function(r) {
        return Va.createHash("md5").update(r, "utf-8").digest("hex");
      }, "md5"), eu = a(function(r, e, t) {
        var n = rr(e + r), i = rr(y.concat([y.from(n), t]));
        return "md5" + i;
      }, "postgresMd5PasswordHash");
      Ui.exports = { prepareValue: a(function(e) {
        return pt(
          e
        );
      }, "prepareValueWrapper"), normalizeQueryConfig: Xa, postgresMd5PasswordHash: eu, md5: rr };
    });
    ji = I((el, Qi) => {
      "use strict";
      p();
      var nr = (Ht(), O(Wt));
      function tu(r) {
        if (r.indexOf(
          "SCRAM-SHA-256"
        ) === -1) throw new Error("SASL: Only mechanism SCRAM-SHA-256 is currently supported");
        let e = nr.randomBytes(18).toString("base64");
        return { mechanism: "SCRAM-SHA-256", clientNonce: e, response: "n,,n=*,r=" + e, message: "SASLInitialResponse" };
      }
      __name(tu, "tu");
      a(tu, "startSession");
      function ru(r, e, t) {
        if (r.message !== "SASLInitialResponse") throw new Error(
          "SASL: Last message was not SASLInitialResponse"
        );
        if (typeof e != "string") throw new Error(
          "SASL: SCRAM-SERVER-FIRST-MESSAGE: client password must be a string"
        );
        if (typeof t != "string") throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: serverData must be a string");
        let n = su(t);
        if (n.nonce.startsWith(r.clientNonce)) {
          if (n.nonce.length === r.clientNonce.length) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short");
        } else throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce");
        var i = y.from(n.salt, "base64"), s = uu(
          e,
          i,
          n.iteration
        ), o = De(s, "Client Key"), u = au(o), c = "n=*,r=" + r.clientNonce, h = "r=" + n.nonce + ",s=" + n.salt + ",i=" + n.iteration, l = "c=biws,r=" + n.nonce, d = c + "," + h + "," + l, b = De(u, d), C = qi(
          o,
          b
        ), B = C.toString("base64"), Q = De(s, "Server Key"), X = De(Q, d);
        r.message = "SASLResponse", r.serverSignature = X.toString("base64"), r.response = l + ",p=" + B;
      }
      __name(ru, "ru");
      a(ru, "continueSession");
      function nu(r, e) {
        if (r.message !== "SASLResponse") throw new Error("SASL: Last message was not SASLResponse");
        if (typeof e != "string") throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: serverData must be a string");
        let { serverSignature: t } = ou(
          e
        );
        if (t !== r.serverSignature) throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature does not match");
      }
      __name(nu, "nu");
      a(nu, "finalizeSession");
      function iu(r) {
        if (typeof r != "string") throw new TypeError("SASL: text must be a string");
        return r.split("").map(
          (e, t) => r.charCodeAt(t)
        ).every((e) => e >= 33 && e <= 43 || e >= 45 && e <= 126);
      }
      __name(iu, "iu");
      a(iu, "isPrintableChars");
      function Oi(r) {
        return /^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(r);
      }
      __name(Oi, "Oi");
      a(Oi, "isBase64");
      function Ni(r) {
        if (typeof r != "string") throw new TypeError(
          "SASL: attribute pairs text must be a string"
        );
        return new Map(r.split(",").map((e) => {
          if (!/^.=/.test(e)) throw new Error("SASL: Invalid attribute pair entry");
          let t = e[0], n = e.substring(2);
          return [t, n];
        }));
      }
      __name(Ni, "Ni");
      a(Ni, "parseAttributePairs");
      function su(r) {
        let e = Ni(
          r
        ), t = e.get("r");
        if (t) {
          if (!iu(t)) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce must only contain printable characters");
        } else throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing");
        let n = e.get("s");
        if (n) {
          if (!Oi(n)) throw new Error(
            "SASL: SCRAM-SERVER-FIRST-MESSAGE: salt must be base64"
          );
        } else throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing");
        let i = e.get("i");
        if (i) {
          if (!/^[1-9][0-9]*$/.test(i)) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: invalid iteration count");
        } else throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: iteration missing");
        let s = parseInt(i, 10);
        return { nonce: t, salt: n, iteration: s };
      }
      __name(su, "su");
      a(su, "parseServerFirstMessage");
      function ou(r) {
        let t = Ni(r).get("v");
        if (t) {
          if (!Oi(t)) throw new Error("SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature must be base64");
        } else throw new Error(
          "SASL: SCRAM-SERVER-FINAL-MESSAGE: server signature is missing"
        );
        return { serverSignature: t };
      }
      __name(ou, "ou");
      a(ou, "parseServerFinalMessage");
      function qi(r, e) {
        if (!y.isBuffer(r)) throw new TypeError(
          "first argument must be a Buffer"
        );
        if (!y.isBuffer(e)) throw new TypeError("second argument must be a Buffer");
        if (r.length !== e.length) throw new Error("Buffer lengths must match");
        if (r.length === 0) throw new Error("Buffers cannot be empty");
        return y.from(r.map((t, n) => r[n] ^ e[n]));
      }
      __name(qi, "qi");
      a(qi, "xorBuffers");
      function au(r) {
        return nr.createHash(
          "sha256"
        ).update(r).digest();
      }
      __name(au, "au");
      a(au, "sha256");
      function De(r, e) {
        return nr.createHmac(
          "sha256",
          r
        ).update(e).digest();
      }
      __name(De, "De");
      a(De, "hmacSha256");
      function uu(r, e, t) {
        for (var n = De(
          r,
          y.concat([e, y.from([0, 0, 0, 1])])
        ), i = n, s = 0; s < t - 1; s++) n = De(r, n), i = qi(i, n);
        return i;
      }
      __name(uu, "uu");
      a(uu, "Hi");
      Qi.exports = { startSession: tu, continueSession: ru, finalizeSession: nu };
    });
    ir = {};
    se(ir, { join: /* @__PURE__ */ __name(() => cu, "join") });
    __name(cu, "cu");
    sr = z(() => {
      "use strict";
      p();
      a(cu, "join");
    });
    or = {};
    se(or, { stat: /* @__PURE__ */ __name(() => hu, "stat") });
    __name(hu, "hu");
    ar = z(
      () => {
        "use strict";
        p();
        a(hu, "stat");
      }
    );
    ur = {};
    se(ur, { default: /* @__PURE__ */ __name(() => lu, "default") });
    cr = z(() => {
      "use strict";
      p();
      lu = {};
    });
    Wi = {};
    se(Wi, { StringDecoder: /* @__PURE__ */ __name(() => hr, "StringDecoder") });
    Hi = z(() => {
      "use strict";
      p();
      lr = class lr {
        static {
          __name(this, "lr");
        }
        constructor(e) {
          _(this, "td");
          this.td = new TextDecoder(e);
        }
        write(e) {
          return this.td.decode(e, { stream: true });
        }
        end(e) {
          return this.td.decode(e);
        }
      };
      a(lr, "StringDecoder");
      hr = lr;
    });
    Ki = I((hl, Vi) => {
      "use strict";
      p();
      var { Transform: fu } = (cr(), O(ur)), { StringDecoder: pu } = (Hi(), O(Wi)), we = /* @__PURE__ */ Symbol("last"), dt = /* @__PURE__ */ Symbol("decoder");
      function du(r, e, t) {
        let n;
        if (this.overflow) {
          if (n = this[dt].write(r).split(this.matcher), n.length === 1) return t();
          n.shift(), this.overflow = false;
        } else this[we] += this[dt].write(r), n = this[we].split(this.matcher);
        this[we] = n.pop();
        for (let i = 0; i < n.length; i++) try {
          $i(this, this.mapper(n[i]));
        } catch (s) {
          return t(
            s
          );
        }
        if (this.overflow = this[we].length > this.maxLength, this.overflow && !this.skipOverflow) {
          t(new Error("maximum buffer reached"));
          return;
        }
        t();
      }
      __name(du, "du");
      a(du, "transform");
      function yu(r) {
        if (this[we] += this[dt].end(), this[we]) try {
          $i(this, this.mapper(this[we]));
        } catch (e) {
          return r(e);
        }
        r();
      }
      __name(yu, "yu");
      a(yu, "flush");
      function $i(r, e) {
        e !== void 0 && r.push(e);
      }
      __name($i, "$i");
      a($i, "push");
      function Gi(r) {
        return r;
      }
      __name(Gi, "Gi");
      a(Gi, "noop");
      function mu(r, e, t) {
        switch (r = r || /\r?\n/, e = e || Gi, t = t || {}, arguments.length) {
          case 1:
            typeof r == "function" ? (e = r, r = /\r?\n/) : typeof r == "object" && !(r instanceof RegExp) && !r[Symbol.split] && (t = r, r = /\r?\n/);
            break;
          case 2:
            typeof r == "function" ? (t = e, e = r, r = /\r?\n/) : typeof e == "object" && (t = e, e = Gi);
        }
        t = Object.assign({}, t), t.autoDestroy = true, t.transform = du, t.flush = yu, t.readableObjectMode = true;
        let n = new fu(t);
        return n[we] = "", n[dt] = new pu("utf8"), n.matcher = r, n.mapper = e, n.maxLength = t.maxLength, n.skipOverflow = t.skipOverflow || false, n.overflow = false, n._destroy = function(i, s) {
          this._writableState.errorEmitted = false, s(i);
        }, n;
      }
      __name(mu, "mu");
      a(mu, "split");
      Vi.exports = mu;
    });
    Zi = I((pl, fe) => {
      "use strict";
      p();
      var zi = (sr(), O(ir)), gu = (cr(), O(ur)).Stream, wu = Ki(), Yi = (Ge(), O(He)), bu = 5432, yt = m.platform === "win32", rt = m.stderr, Su = 56, xu = 7, Eu = 61440, vu = 32768;
      function _u(r) {
        return (r & Eu) == vu;
      }
      __name(_u, "_u");
      a(_u, "isRegFile");
      var ke = [
        "host",
        "port",
        "database",
        "user",
        "password"
      ], fr = ke.length, Au = ke[fr - 1];
      function pr() {
        var r = rt instanceof gu && rt.writable === true;
        if (r) {
          var e = Array.prototype.slice.call(arguments).concat(`
`);
          rt.write(Yi.format.apply(Yi, e));
        }
      }
      __name(pr, "pr");
      a(pr, "warn");
      Object.defineProperty(
        fe.exports,
        "isWin",
        { get: a(function() {
          return yt;
        }, "get"), set: a(function(r) {
          yt = r;
        }, "set") }
      );
      fe.exports.warnTo = function(r) {
        var e = rt;
        return rt = r, e;
      };
      fe.exports.getFileName = function(r) {
        var e = r || m.env, t = e.PGPASSFILE || (yt ? zi.join(e.APPDATA || "./", "postgresql", "pgpass.conf") : zi.join(e.HOME || "./", ".pgpass"));
        return t;
      };
      fe.exports.usePgPass = function(r, e) {
        return Object.prototype.hasOwnProperty.call(m.env, "PGPASSWORD") ? false : yt ? true : (e = e || "<unkn>", _u(r.mode) ? r.mode & (Su | xu) ? (pr('WARNING: password file "%s" has group or world access; permissions should be u=rw (0600) or less', e), false) : true : (pr('WARNING: password file "%s" is not a plain file', e), false));
      };
      var Cu = fe.exports.match = function(r, e) {
        return ke.slice(0, -1).reduce(function(t, n, i) {
          return i == 1 && Number(r[n] || bu) === Number(
            e[n]
          ) ? t && true : t && (e[n] === "*" || e[n] === r[n]);
        }, true);
      };
      fe.exports.getPassword = function(r, e, t) {
        var n, i = e.pipe(wu());
        function s(c) {
          var h = Tu(c);
          h && Iu(h) && Cu(r, h) && (n = h[Au], i.end());
        }
        __name(s, "s");
        a(s, "onLine");
        var o = a(function() {
          e.destroy(), t(n);
        }, "onEnd"), u = a(function(c) {
          e.destroy(), pr("WARNING: error on reading file: %s", c), t(void 0);
        }, "onErr");
        e.on("error", u), i.on("data", s).on("end", o).on("error", u);
      };
      var Tu = fe.exports.parseLine = function(r) {
        if (r.length < 11 || r.match(/^\s+#/)) return null;
        for (var e = "", t = "", n = 0, i = 0, s = 0, o = {}, u = false, c = a(function(l, d, b) {
          var C = r.substring(d, b);
          Object.hasOwnProperty.call(
            m.env,
            "PGPASS_NO_DEESCAPE"
          ) || (C = C.replace(/\\([:\\])/g, "$1")), o[ke[l]] = C;
        }, "addToObj"), h = 0; h < r.length - 1; h += 1) {
          if (e = r.charAt(h + 1), t = r.charAt(h), u = n == fr - 1, u) {
            c(n, i);
            break;
          }
          h >= 0 && e == ":" && t !== "\\" && (c(n, i, h + 1), i = h + 2, n += 1);
        }
        return o = Object.keys(o).length === fr ? o : null, o;
      }, Iu = fe.exports.isValidEntry = function(r) {
        for (var e = { 0: function(o) {
          return o.length > 0;
        }, 1: function(o) {
          return o === "*" ? true : (o = Number(o), isFinite(o) && o > 0 && o < 9007199254740992 && Math.floor(o) === o);
        }, 2: function(o) {
          return o.length > 0;
        }, 3: function(o) {
          return o.length > 0;
        }, 4: function(o) {
          return o.length > 0;
        } }, t = 0; t < ke.length; t += 1) {
          var n = e[t], i = r[ke[t]] || "", s = n(i);
          if (!s) return false;
        }
        return true;
      };
    });
    Xi = I((gl, dr) => {
      "use strict";
      p();
      var ml = (sr(), O(ir)), Ji = (ar(), O(or)), mt = Zi();
      dr.exports = function(r, e) {
        var t = mt.getFileName();
        Ji.stat(t, function(n, i) {
          if (n || !mt.usePgPass(i, t)) return e(void 0);
          var s = Ji.createReadStream(t);
          mt.getPassword(
            r,
            s,
            e
          );
        });
      };
      dr.exports.warnTo = mt.warnTo;
    });
    wt = I((bl, es) => {
      "use strict";
      p();
      var Pu = Xe();
      function gt2(r) {
        this._types = r || Pu, this.text = {}, this.binary = {};
      }
      __name(gt2, "gt");
      a(gt2, "TypeOverrides");
      gt2.prototype.getOverrides = function(r) {
        switch (r) {
          case "text":
            return this.text;
          case "binary":
            return this.binary;
          default:
            return {};
        }
      };
      gt2.prototype.setTypeParser = function(r, e, t) {
        typeof e == "function" && (t = e, e = "text"), this.getOverrides(e)[r] = t;
      };
      gt2.prototype.getTypeParser = function(r, e) {
        return e = e || "text", this.getOverrides(e)[r] || this._types.getTypeParser(r, e);
      };
      es.exports = gt2;
    });
    ts = {};
    se(ts, { default: /* @__PURE__ */ __name(() => Bu, "default") });
    rs = z(() => {
      "use strict";
      p();
      Bu = {};
    });
    ns = {};
    se(ns, { parse: /* @__PURE__ */ __name(() => yr, "parse") });
    __name(yr, "yr");
    mr = z(() => {
      "use strict";
      p();
      a(yr, "parse");
    });
    ss = I((Al, is2) => {
      "use strict";
      p();
      var Lu = (mr(), O(ns)), gr = (ar(), O(or));
      function wr(r) {
        if (r.charAt(0) === "/") {
          var t = r.split(" ");
          return { host: t[0], database: t[1] };
        }
        var e = Lu.parse(/ |%[^a-f0-9]|%[a-f0-9][^a-f0-9]/i.test(r) ? encodeURI(r).replace(
          /\%25(\d\d)/g,
          "%$1"
        ) : r, true), t = e.query;
        for (var n in t) Array.isArray(t[n]) && (t[n] = t[n][t[n].length - 1]);
        var i = (e.auth || ":").split(":");
        if (t.user = i[0], t.password = i.splice(1).join(":"), t.port = e.port, e.protocol == "socket:") return t.host = decodeURI(e.pathname), t.database = e.query.db, t.client_encoding = e.query.encoding, t;
        t.host || (t.host = e.hostname);
        var s = e.pathname;
        if (!t.host && s && /^%2f/i.test(s)) {
          var o = s.split("/");
          t.host = decodeURIComponent(
            o[0]
          ), s = o.splice(1).join("/");
        }
        switch (s && s.charAt(0) === "/" && (s = s.slice(1) || null), t.database = s && decodeURI(s), (t.ssl === "true" || t.ssl === "1") && (t.ssl = true), t.ssl === "0" && (t.ssl = false), (t.sslcert || t.sslkey || t.sslrootcert || t.sslmode) && (t.ssl = {}), t.sslcert && (t.ssl.cert = gr.readFileSync(t.sslcert).toString()), t.sslkey && (t.ssl.key = gr.readFileSync(
          t.sslkey
        ).toString()), t.sslrootcert && (t.ssl.ca = gr.readFileSync(t.sslrootcert).toString()), t.sslmode) {
          case "disable": {
            t.ssl = false;
            break;
          }
          case "prefer":
          case "require":
          case "verify-ca":
          case "verify-full":
            break;
          case "no-verify": {
            t.ssl.rejectUnauthorized = false;
            break;
          }
        }
        return t;
      }
      __name(wr, "wr");
      a(wr, "parse");
      is2.exports = wr;
      wr.parse = wr;
    });
    bt = I((Il, us) => {
      "use strict";
      p();
      var Ru = (rs(), O(ts)), as = et(), os = ss().parse, V = a(
        function(r, e, t) {
          return t === void 0 ? t = m.env["PG" + r.toUpperCase()] : t === false || (t = m.env[t]), e[r] || t || as[r];
        },
        "val"
      ), Fu = a(function() {
        switch (m.env.PGSSLMODE) {
          case "disable":
            return false;
          case "prefer":
          case "require":
          case "verify-ca":
          case "verify-full":
            return true;
          case "no-verify":
            return { rejectUnauthorized: false };
        }
        return as.ssl;
      }, "readSSLConfigFromEnvironment"), Ue = a(
        function(r) {
          return "'" + ("" + r).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
        },
        "quoteParamValue"
      ), ie = a(function(r, e, t) {
        var n = e[t];
        n != null && r.push(t + "=" + Ue(n));
      }, "add"), Sr = class Sr {
        static {
          __name(this, "Sr");
        }
        constructor(e) {
          e = typeof e == "string" ? os(e) : e || {}, e.connectionString && (e = Object.assign({}, e, os(e.connectionString))), this.user = V("user", e), this.database = V("database", e), this.database === void 0 && (this.database = this.user), this.port = parseInt(
            V("port", e),
            10
          ), this.host = V("host", e), Object.defineProperty(this, "password", {
            configurable: true,
            enumerable: false,
            writable: true,
            value: V("password", e)
          }), this.binary = V("binary", e), this.options = V("options", e), this.ssl = typeof e.ssl > "u" ? Fu() : e.ssl, typeof this.ssl == "string" && this.ssl === "true" && (this.ssl = true), this.ssl === "no-verify" && (this.ssl = { rejectUnauthorized: false }), this.ssl && this.ssl.key && Object.defineProperty(this.ssl, "key", { enumerable: false }), this.client_encoding = V("client_encoding", e), this.replication = V("replication", e), this.isDomainSocket = !(this.host || "").indexOf("/"), this.application_name = V("application_name", e, "PGAPPNAME"), this.fallback_application_name = V("fallback_application_name", e, false), this.statement_timeout = V("statement_timeout", e, false), this.lock_timeout = V(
            "lock_timeout",
            e,
            false
          ), this.idle_in_transaction_session_timeout = V("idle_in_transaction_session_timeout", e, false), this.query_timeout = V("query_timeout", e, false), e.connectionTimeoutMillis === void 0 ? this.connect_timeout = m.env.PGCONNECT_TIMEOUT || 0 : this.connect_timeout = Math.floor(e.connectionTimeoutMillis / 1e3), e.keepAlive === false ? this.keepalives = 0 : e.keepAlive === true && (this.keepalives = 1), typeof e.keepAliveInitialDelayMillis == "number" && (this.keepalives_idle = Math.floor(e.keepAliveInitialDelayMillis / 1e3));
        }
        getLibpqConnectionString(e) {
          var t = [];
          ie(t, this, "user"), ie(t, this, "password"), ie(t, this, "port"), ie(t, this, "application_name"), ie(t, this, "fallback_application_name"), ie(t, this, "connect_timeout"), ie(
            t,
            this,
            "options"
          );
          var n = typeof this.ssl == "object" ? this.ssl : this.ssl ? { sslmode: this.ssl } : {};
          if (ie(t, n, "sslmode"), ie(t, n, "sslca"), ie(t, n, "sslkey"), ie(t, n, "sslcert"), ie(t, n, "sslrootcert"), this.database && t.push("dbname=" + Ue(this.database)), this.replication && t.push("replication=" + Ue(this.replication)), this.host && t.push("host=" + Ue(this.host)), this.isDomainSocket) return e(null, t.join(" "));
          this.client_encoding && t.push("client_encoding=" + Ue(this.client_encoding)), Ru.lookup(this.host, function(i, s) {
            return i ? e(i, null) : (t.push("hostaddr=" + Ue(s)), e(null, t.join(" ")));
          });
        }
      };
      a(Sr, "ConnectionParameters");
      var br = Sr;
      us.exports = br;
    });
    ls = I((Ll, hs) => {
      "use strict";
      p();
      var Mu = Xe(), cs = /^([A-Za-z]+)(?: (\d+))?(?: (\d+))?/, Er = class Er {
        static {
          __name(this, "Er");
        }
        constructor(e, t) {
          this.command = null, this.rowCount = null, this.oid = null, this.rows = [], this.fields = [], this._parsers = void 0, this._types = t, this.RowCtor = null, this.rowAsArray = e === "array", this.rowAsArray && (this.parseRow = this._parseRowAsArray);
        }
        addCommandComplete(e) {
          var t;
          e.text ? t = cs.exec(e.text) : t = cs.exec(e.command), t && (this.command = t[1], t[3] ? (this.oid = parseInt(t[2], 10), this.rowCount = parseInt(t[3], 10)) : t[2] && (this.rowCount = parseInt(
            t[2],
            10
          )));
        }
        _parseRowAsArray(e) {
          for (var t = new Array(e.length), n = 0, i = e.length; n < i; n++) {
            var s = e[n];
            s !== null ? t[n] = this._parsers[n](s) : t[n] = null;
          }
          return t;
        }
        parseRow(e) {
          for (var t = {}, n = 0, i = e.length; n < i; n++) {
            var s = e[n], o = this.fields[n].name;
            s !== null ? t[o] = this._parsers[n](
              s
            ) : t[o] = null;
          }
          return t;
        }
        addRow(e) {
          this.rows.push(e);
        }
        addFields(e) {
          this.fields = e, this.fields.length && (this._parsers = new Array(e.length));
          for (var t = 0; t < e.length; t++) {
            var n = e[t];
            this._types ? this._parsers[t] = this._types.getTypeParser(n.dataTypeID, n.format || "text") : this._parsers[t] = Mu.getTypeParser(n.dataTypeID, n.format || "text");
          }
        }
      };
      a(Er, "Result");
      var xr = Er;
      hs.exports = xr;
    });
    ys = I((Ml, ds) => {
      "use strict";
      p();
      var { EventEmitter: Du } = ge(), fs = ls(), ps = tt(), _r = class _r extends Du {
        static {
          __name(this, "_r");
        }
        constructor(e, t, n) {
          super(), e = ps.normalizeQueryConfig(e, t, n), this.text = e.text, this.values = e.values, this.rows = e.rows, this.types = e.types, this.name = e.name, this.binary = e.binary, this.portal = e.portal || "", this.callback = e.callback, this._rowMode = e.rowMode, m.domain && e.callback && (this.callback = m.domain.bind(e.callback)), this._result = new fs(this._rowMode, this.types), this._results = this._result, this.isPreparedStatement = false, this._canceledDueToError = false, this._promise = null;
        }
        requiresPreparation() {
          return this.name || this.rows ? true : !this.text || !this.values ? false : this.values.length > 0;
        }
        _checkForMultirow() {
          this._result.command && (Array.isArray(this._results) || (this._results = [this._result]), this._result = new fs(
            this._rowMode,
            this.types
          ), this._results.push(this._result));
        }
        handleRowDescription(e) {
          this._checkForMultirow(), this._result.addFields(e.fields), this._accumulateRows = this.callback || !this.listeners("row").length;
        }
        handleDataRow(e) {
          let t;
          if (!this._canceledDueToError) {
            try {
              t = this._result.parseRow(e.fields);
            } catch (n) {
              this._canceledDueToError = n;
              return;
            }
            this.emit("row", t, this._result), this._accumulateRows && this._result.addRow(t);
          }
        }
        handleCommandComplete(e, t) {
          this._checkForMultirow(), this._result.addCommandComplete(e), this.rows && t.sync();
        }
        handleEmptyQuery(e) {
          this.rows && e.sync();
        }
        handleError(e, t) {
          if (this._canceledDueToError && (e = this._canceledDueToError, this._canceledDueToError = false), this.callback) return this.callback(e);
          this.emit("error", e);
        }
        handleReadyForQuery(e) {
          if (this._canceledDueToError) return this.handleError(
            this._canceledDueToError,
            e
          );
          if (this.callback) try {
            this.callback(null, this._results);
          } catch (t) {
            m.nextTick(() => {
              throw t;
            });
          }
          this.emit("end", this._results);
        }
        submit(e) {
          if (typeof this.text != "string" && typeof this.name != "string") return new Error("A query must have either text or a name. Supplying neither is unsupported.");
          let t = e.parsedStatements[this.name];
          return this.text && t && this.text !== t ? new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`) : this.values && !Array.isArray(this.values) ? new Error("Query values must be an array") : (this.requiresPreparation() ? this.prepare(e) : e.query(this.text), null);
        }
        hasBeenParsed(e) {
          return this.name && e.parsedStatements[this.name];
        }
        handlePortalSuspended(e) {
          this._getRows(e, this.rows);
        }
        _getRows(e, t) {
          e.execute(
            { portal: this.portal, rows: t }
          ), t ? e.flush() : e.sync();
        }
        prepare(e) {
          this.isPreparedStatement = true, this.hasBeenParsed(e) || e.parse({ text: this.text, name: this.name, types: this.types });
          try {
            e.bind({ portal: this.portal, statement: this.name, values: this.values, binary: this.binary, valueMapper: ps.prepareValue });
          } catch (t) {
            this.handleError(t, e);
            return;
          }
          e.describe(
            { type: "P", name: this.portal || "" }
          ), this._getRows(e, this.rows);
        }
        handleCopyInResponse(e) {
          e.sendCopyFail("No source stream defined");
        }
        handleCopyData(e, t) {
        }
      };
      a(_r, "Query");
      var vr = _r;
      ds.exports = vr;
    });
    ws = {};
    se(ws, { Socket: /* @__PURE__ */ __name(() => _e, "Socket"), isIP: /* @__PURE__ */ __name(() => ku, "isIP") });
    __name(ku, "ku");
    St = z(() => {
      "use strict";
      p();
      gs = Te(ge(), 1);
      a(ku, "isIP");
      ms = /^[^.]+\./, v = class v2 extends gs.EventEmitter {
        static {
          __name(this, "v");
        }
        constructor() {
          super(...arguments);
          _(this, "opts", {});
          _(this, "connecting", false);
          _(this, "pending", true);
          _(this, "writable", true);
          _(this, "encrypted", false);
          _(this, "authorized", false);
          _(this, "destroyed", false);
          _(this, "ws", null);
          _(this, "writeBuffer");
          _(this, "tlsState", 0);
          _(
            this,
            "tlsRead"
          );
          _(this, "tlsWrite");
        }
        static get poolQueryViaFetch() {
          return v2.opts.poolQueryViaFetch ?? v2.defaults.poolQueryViaFetch;
        }
        static set poolQueryViaFetch(t) {
          v2.opts.poolQueryViaFetch = t;
        }
        static get fetchEndpoint() {
          return v2.opts.fetchEndpoint ?? v2.defaults.fetchEndpoint;
        }
        static set fetchEndpoint(t) {
          v2.opts.fetchEndpoint = t;
        }
        static get fetchConnectionCache() {
          return true;
        }
        static set fetchConnectionCache(t) {
          console.warn("The `fetchConnectionCache` option is deprecated (now always `true`)");
        }
        static get fetchFunction() {
          return v2.opts.fetchFunction ?? v2.defaults.fetchFunction;
        }
        static set fetchFunction(t) {
          v2.opts.fetchFunction = t;
        }
        static get webSocketConstructor() {
          return v2.opts.webSocketConstructor ?? v2.defaults.webSocketConstructor;
        }
        static set webSocketConstructor(t) {
          v2.opts.webSocketConstructor = t;
        }
        get webSocketConstructor() {
          return this.opts.webSocketConstructor ?? v2.webSocketConstructor;
        }
        set webSocketConstructor(t) {
          this.opts.webSocketConstructor = t;
        }
        static get wsProxy() {
          return v2.opts.wsProxy ?? v2.defaults.wsProxy;
        }
        static set wsProxy(t) {
          v2.opts.wsProxy = t;
        }
        get wsProxy() {
          return this.opts.wsProxy ?? v2.wsProxy;
        }
        set wsProxy(t) {
          this.opts.wsProxy = t;
        }
        static get coalesceWrites() {
          return v2.opts.coalesceWrites ?? v2.defaults.coalesceWrites;
        }
        static set coalesceWrites(t) {
          v2.opts.coalesceWrites = t;
        }
        get coalesceWrites() {
          return this.opts.coalesceWrites ?? v2.coalesceWrites;
        }
        set coalesceWrites(t) {
          this.opts.coalesceWrites = t;
        }
        static get useSecureWebSocket() {
          return v2.opts.useSecureWebSocket ?? v2.defaults.useSecureWebSocket;
        }
        static set useSecureWebSocket(t) {
          v2.opts.useSecureWebSocket = t;
        }
        get useSecureWebSocket() {
          return this.opts.useSecureWebSocket ?? v2.useSecureWebSocket;
        }
        set useSecureWebSocket(t) {
          this.opts.useSecureWebSocket = t;
        }
        static get forceDisablePgSSL() {
          return v2.opts.forceDisablePgSSL ?? v2.defaults.forceDisablePgSSL;
        }
        static set forceDisablePgSSL(t) {
          v2.opts.forceDisablePgSSL = t;
        }
        get forceDisablePgSSL() {
          return this.opts.forceDisablePgSSL ?? v2.forceDisablePgSSL;
        }
        set forceDisablePgSSL(t) {
          this.opts.forceDisablePgSSL = t;
        }
        static get disableSNI() {
          return v2.opts.disableSNI ?? v2.defaults.disableSNI;
        }
        static set disableSNI(t) {
          v2.opts.disableSNI = t;
        }
        get disableSNI() {
          return this.opts.disableSNI ?? v2.disableSNI;
        }
        set disableSNI(t) {
          this.opts.disableSNI = t;
        }
        static get pipelineConnect() {
          return v2.opts.pipelineConnect ?? v2.defaults.pipelineConnect;
        }
        static set pipelineConnect(t) {
          v2.opts.pipelineConnect = t;
        }
        get pipelineConnect() {
          return this.opts.pipelineConnect ?? v2.pipelineConnect;
        }
        set pipelineConnect(t) {
          this.opts.pipelineConnect = t;
        }
        static get subtls() {
          return v2.opts.subtls ?? v2.defaults.subtls;
        }
        static set subtls(t) {
          v2.opts.subtls = t;
        }
        get subtls() {
          return this.opts.subtls ?? v2.subtls;
        }
        set subtls(t) {
          this.opts.subtls = t;
        }
        static get pipelineTLS() {
          return v2.opts.pipelineTLS ?? v2.defaults.pipelineTLS;
        }
        static set pipelineTLS(t) {
          v2.opts.pipelineTLS = t;
        }
        get pipelineTLS() {
          return this.opts.pipelineTLS ?? v2.pipelineTLS;
        }
        set pipelineTLS(t) {
          this.opts.pipelineTLS = t;
        }
        static get rootCerts() {
          return v2.opts.rootCerts ?? v2.defaults.rootCerts;
        }
        static set rootCerts(t) {
          v2.opts.rootCerts = t;
        }
        get rootCerts() {
          return this.opts.rootCerts ?? v2.rootCerts;
        }
        set rootCerts(t) {
          this.opts.rootCerts = t;
        }
        wsProxyAddrForHost(t, n) {
          let i = this.wsProxy;
          if (i === void 0) throw new Error("No WebSocket proxy is configured. Please see https://github.com/neondatabase/serverless/blob/main/CONFIG.md#wsproxy-string--host-string-port-number--string--string");
          return typeof i == "function" ? i(t, n) : `${i}?address=${t}:${n}`;
        }
        setNoDelay() {
          return this;
        }
        setKeepAlive() {
          return this;
        }
        ref() {
          return this;
        }
        unref() {
          return this;
        }
        connect(t, n, i) {
          this.connecting = true, i && this.once("connect", i);
          let s = a(() => {
            this.connecting = false, this.pending = false, this.emit("connect"), this.emit("ready");
          }, "handleWebSocketOpen"), o = a((c, h = false) => {
            c.binaryType = "arraybuffer", c.addEventListener("error", (l) => {
              this.emit("error", l), this.emit("close");
            }), c.addEventListener("message", (l) => {
              if (this.tlsState === 0) {
                let d = y.from(l.data);
                this.emit(
                  "data",
                  d
                );
              }
            }), c.addEventListener("close", () => {
              this.emit("close");
            }), h ? s() : c.addEventListener(
              "open",
              s
            );
          }, "configureWebSocket"), u;
          try {
            u = this.wsProxyAddrForHost(n, typeof t == "string" ? parseInt(t, 10) : t);
          } catch (c) {
            this.emit("error", c), this.emit("close");
            return;
          }
          try {
            let h = (this.useSecureWebSocket ? "wss:" : "ws:") + "//" + u;
            if (this.webSocketConstructor !== void 0) this.ws = new this.webSocketConstructor(h), o(this.ws);
            else try {
              this.ws = new WebSocket(
                h
              ), o(this.ws);
            } catch {
              this.ws = new __unstable_WebSocket(h), o(this.ws);
            }
          } catch (c) {
            let l = (this.useSecureWebSocket ? "https:" : "http:") + "//" + u;
            fetch(l, { headers: { Upgrade: "websocket" } }).then((d) => {
              if (this.ws = d.webSocket, this.ws == null) throw c;
              this.ws.accept(), o(
                this.ws,
                true
              );
            }).catch((d) => {
              this.emit("error", new Error(`All attempts to open a WebSocket to connect to the database failed. Please refer to https://github.com/neondatabase/serverless/blob/main/CONFIG.md#websocketconstructor-typeof-websocket--undefined. Details: ${d.message}`)), this.emit("close");
            });
          }
        }
        async startTls(t) {
          if (this.subtls === void 0) throw new Error("For Postgres SSL connections, you must set `neonConfig.subtls` to the subtls library. See https://github.com/neondatabase/serverless/blob/main/CONFIG.md for more information.");
          this.tlsState = 1;
          let n = this.subtls.TrustedCert.fromPEM(this.rootCerts), i = new this.subtls.WebSocketReadQueue(this.ws), s = i.read.bind(
            i
          ), o = this.rawWrite.bind(this), [u, c] = await this.subtls.startTls(t, n, s, o, { useSNI: !this.disableSNI, expectPreData: this.pipelineTLS ? new Uint8Array([83]) : void 0 });
          this.tlsRead = u, this.tlsWrite = c, this.tlsState = 2, this.encrypted = true, this.authorized = true, this.emit(
            "secureConnection",
            this
          ), this.tlsReadLoop();
        }
        async tlsReadLoop() {
          for (; ; ) {
            let t = await this.tlsRead();
            if (t === void 0) break;
            {
              let n = y.from(t);
              this.emit("data", n);
            }
          }
        }
        rawWrite(t) {
          if (!this.coalesceWrites) {
            this.ws.send(t);
            return;
          }
          if (this.writeBuffer === void 0) this.writeBuffer = t, setTimeout(
            () => {
              this.ws.send(this.writeBuffer), this.writeBuffer = void 0;
            },
            0
          );
          else {
            let n = new Uint8Array(this.writeBuffer.length + t.length);
            n.set(this.writeBuffer), n.set(t, this.writeBuffer.length), this.writeBuffer = n;
          }
        }
        write(t, n = "utf8", i = (s) => {
        }) {
          return t.length === 0 ? (i(), true) : (typeof t == "string" && (t = y.from(t, n)), this.tlsState === 0 ? (this.rawWrite(t), i()) : this.tlsState === 1 ? this.once("secureConnection", () => {
            this.write(
              t,
              n,
              i
            );
          }) : (this.tlsWrite(t), i()), true);
        }
        end(t = y.alloc(0), n = "utf8", i = () => {
        }) {
          return this.write(t, n, () => {
            this.ws.close(), i();
          }), this;
        }
        destroy() {
          return this.destroyed = true, this.end();
        }
      };
      a(v, "Socket"), _(v, "defaults", {
        poolQueryViaFetch: false,
        fetchEndpoint: a((t, n, i) => {
          let s;
          return i?.jwtAuth ? s = t.replace(ms, "apiauth.") : s = t.replace(ms, "api."), "https://" + s + "/sql";
        }, "fetchEndpoint"),
        fetchConnectionCache: true,
        fetchFunction: void 0,
        webSocketConstructor: void 0,
        wsProxy: a((t) => t + "/v2", "wsProxy"),
        useSecureWebSocket: true,
        forceDisablePgSSL: true,
        coalesceWrites: true,
        pipelineConnect: "password",
        subtls: void 0,
        rootCerts: "",
        pipelineTLS: false,
        disableSNI: false
      }), _(v, "opts", {});
      _e = v;
    });
    Xr = I((T) => {
      "use strict";
      p();
      Object.defineProperty(T, "__esModule", { value: true });
      T.NoticeMessage = T.DataRowMessage = T.CommandCompleteMessage = T.ReadyForQueryMessage = T.NotificationResponseMessage = T.BackendKeyDataMessage = T.AuthenticationMD5Password = T.ParameterStatusMessage = T.ParameterDescriptionMessage = T.RowDescriptionMessage = T.Field = T.CopyResponse = T.CopyDataMessage = T.DatabaseError = T.copyDone = T.emptyQuery = T.replicationStart = T.portalSuspended = T.noData = T.closeComplete = T.bindComplete = T.parseComplete = void 0;
      T.parseComplete = { name: "parseComplete", length: 5 };
      T.bindComplete = { name: "bindComplete", length: 5 };
      T.closeComplete = { name: "closeComplete", length: 5 };
      T.noData = { name: "noData", length: 5 };
      T.portalSuspended = { name: "portalSuspended", length: 5 };
      T.replicationStart = { name: "replicationStart", length: 4 };
      T.emptyQuery = { name: "emptyQuery", length: 4 };
      T.copyDone = { name: "copyDone", length: 4 };
      var Nr = class Nr extends Error {
        static {
          __name(this, "Nr");
        }
        constructor(e, t, n) {
          super(
            e
          ), this.length = t, this.name = n;
        }
      };
      a(Nr, "DatabaseError");
      var Ar = Nr;
      T.DatabaseError = Ar;
      var qr = class qr {
        static {
          __name(this, "qr");
        }
        constructor(e, t) {
          this.length = e, this.chunk = t, this.name = "copyData";
        }
      };
      a(qr, "CopyDataMessage");
      var Cr = qr;
      T.CopyDataMessage = Cr;
      var Qr = class Qr {
        static {
          __name(this, "Qr");
        }
        constructor(e, t, n, i) {
          this.length = e, this.name = t, this.binary = n, this.columnTypes = new Array(i);
        }
      };
      a(Qr, "CopyResponse");
      var Tr = Qr;
      T.CopyResponse = Tr;
      var jr = class jr {
        static {
          __name(this, "jr");
        }
        constructor(e, t, n, i, s, o, u) {
          this.name = e, this.tableID = t, this.columnID = n, this.dataTypeID = i, this.dataTypeSize = s, this.dataTypeModifier = o, this.format = u;
        }
      };
      a(jr, "Field");
      var Ir = jr;
      T.Field = Ir;
      var Wr = class Wr {
        static {
          __name(this, "Wr");
        }
        constructor(e, t) {
          this.length = e, this.fieldCount = t, this.name = "rowDescription", this.fields = new Array(
            this.fieldCount
          );
        }
      };
      a(Wr, "RowDescriptionMessage");
      var Pr = Wr;
      T.RowDescriptionMessage = Pr;
      var Hr = class Hr {
        static {
          __name(this, "Hr");
        }
        constructor(e, t) {
          this.length = e, this.parameterCount = t, this.name = "parameterDescription", this.dataTypeIDs = new Array(this.parameterCount);
        }
      };
      a(Hr, "ParameterDescriptionMessage");
      var Br = Hr;
      T.ParameterDescriptionMessage = Br;
      var Gr = class Gr {
        static {
          __name(this, "Gr");
        }
        constructor(e, t, n) {
          this.length = e, this.parameterName = t, this.parameterValue = n, this.name = "parameterStatus";
        }
      };
      a(Gr, "ParameterStatusMessage");
      var Lr = Gr;
      T.ParameterStatusMessage = Lr;
      var $r = class $r {
        static {
          __name(this, "$r");
        }
        constructor(e, t) {
          this.length = e, this.salt = t, this.name = "authenticationMD5Password";
        }
      };
      a($r, "AuthenticationMD5Password");
      var Rr = $r;
      T.AuthenticationMD5Password = Rr;
      var Vr = class Vr {
        static {
          __name(this, "Vr");
        }
        constructor(e, t, n) {
          this.length = e, this.processID = t, this.secretKey = n, this.name = "backendKeyData";
        }
      };
      a(
        Vr,
        "BackendKeyDataMessage"
      );
      var Fr = Vr;
      T.BackendKeyDataMessage = Fr;
      var Kr = class Kr {
        static {
          __name(this, "Kr");
        }
        constructor(e, t, n, i) {
          this.length = e, this.processId = t, this.channel = n, this.payload = i, this.name = "notification";
        }
      };
      a(Kr, "NotificationResponseMessage");
      var Mr = Kr;
      T.NotificationResponseMessage = Mr;
      var zr = class zr {
        static {
          __name(this, "zr");
        }
        constructor(e, t) {
          this.length = e, this.status = t, this.name = "readyForQuery";
        }
      };
      a(zr, "ReadyForQueryMessage");
      var Dr = zr;
      T.ReadyForQueryMessage = Dr;
      var Yr = class Yr {
        static {
          __name(this, "Yr");
        }
        constructor(e, t) {
          this.length = e, this.text = t, this.name = "commandComplete";
        }
      };
      a(Yr, "CommandCompleteMessage");
      var kr = Yr;
      T.CommandCompleteMessage = kr;
      var Zr = class Zr {
        static {
          __name(this, "Zr");
        }
        constructor(e, t) {
          this.length = e, this.fields = t, this.name = "dataRow", this.fieldCount = t.length;
        }
      };
      a(Zr, "DataRowMessage");
      var Ur = Zr;
      T.DataRowMessage = Ur;
      var Jr = class Jr {
        static {
          __name(this, "Jr");
        }
        constructor(e, t) {
          this.length = e, this.message = t, this.name = "notice";
        }
      };
      a(Jr, "NoticeMessage");
      var Or = Jr;
      T.NoticeMessage = Or;
    });
    bs = I((xt) => {
      "use strict";
      p();
      Object.defineProperty(xt, "__esModule", { value: true });
      xt.Writer = void 0;
      var tn = class tn {
        static {
          __name(this, "tn");
        }
        constructor(e = 256) {
          this.size = e, this.offset = 5, this.headerPosition = 0, this.buffer = y.allocUnsafe(e);
        }
        ensure(e) {
          var t = this.buffer.length - this.offset;
          if (t < e) {
            var n = this.buffer, i = n.length + (n.length >> 1) + e;
            this.buffer = y.allocUnsafe(
              i
            ), n.copy(this.buffer);
          }
        }
        addInt32(e) {
          return this.ensure(4), this.buffer[this.offset++] = e >>> 24 & 255, this.buffer[this.offset++] = e >>> 16 & 255, this.buffer[this.offset++] = e >>> 8 & 255, this.buffer[this.offset++] = e >>> 0 & 255, this;
        }
        addInt16(e) {
          return this.ensure(2), this.buffer[this.offset++] = e >>> 8 & 255, this.buffer[this.offset++] = e >>> 0 & 255, this;
        }
        addCString(e) {
          if (!e) this.ensure(1);
          else {
            var t = y.byteLength(e);
            this.ensure(t + 1), this.buffer.write(
              e,
              this.offset,
              "utf-8"
            ), this.offset += t;
          }
          return this.buffer[this.offset++] = 0, this;
        }
        addString(e = "") {
          var t = y.byteLength(e);
          return this.ensure(t), this.buffer.write(e, this.offset), this.offset += t, this;
        }
        add(e) {
          return this.ensure(e.length), e.copy(this.buffer, this.offset), this.offset += e.length, this;
        }
        join(e) {
          if (e) {
            this.buffer[this.headerPosition] = e;
            let t = this.offset - (this.headerPosition + 1);
            this.buffer.writeInt32BE(t, this.headerPosition + 1);
          }
          return this.buffer.slice(e ? 0 : 5, this.offset);
        }
        flush(e) {
          var t = this.join(e);
          return this.offset = 5, this.headerPosition = 0, this.buffer = y.allocUnsafe(this.size), t;
        }
      };
      a(tn, "Writer");
      var en = tn;
      xt.Writer = en;
    });
    xs = I((vt) => {
      "use strict";
      p();
      Object.defineProperty(vt, "__esModule", { value: true });
      vt.serialize = void 0;
      var rn = bs(), M = new rn.Writer(), Uu = a((r) => {
        M.addInt16(3).addInt16(
          0
        );
        for (let n of Object.keys(r)) M.addCString(n).addCString(r[n]);
        M.addCString("client_encoding").addCString("UTF8");
        var e = M.addCString("").flush(), t = e.length + 4;
        return new rn.Writer().addInt32(t).add(e).flush();
      }, "startup"), Ou = a(() => {
        let r = y.allocUnsafe(8);
        return r.writeInt32BE(8, 0), r.writeInt32BE(80877103, 4), r;
      }, "requestSsl"), Nu = a((r) => M.addCString(r).flush(112), "password"), qu = a(function(r, e) {
        return M.addCString(r).addInt32(
          y.byteLength(e)
        ).addString(e), M.flush(112);
      }, "sendSASLInitialResponseMessage"), Qu = a(
        function(r) {
          return M.addString(r).flush(112);
        },
        "sendSCRAMClientFinalMessage"
      ), ju = a(
        (r) => M.addCString(r).flush(81),
        "query"
      ), Ss = [], Wu = a((r) => {
        let e = r.name || "";
        e.length > 63 && (console.error("Warning! Postgres only supports 63 characters for query names."), console.error("You supplied %s (%s)", e, e.length), console.error("This can cause conflicts and silent errors executing queries"));
        let t = r.types || Ss;
        for (var n = t.length, i = M.addCString(e).addCString(r.text).addInt16(n), s = 0; s < n; s++) i.addInt32(t[s]);
        return M.flush(80);
      }, "parse"), Oe = new rn.Writer(), Hu = a(function(r, e) {
        for (let t = 0; t < r.length; t++) {
          let n = e ? e(r[t], t) : r[t];
          n == null ? (M.addInt16(0), Oe.addInt32(-1)) : n instanceof y ? (M.addInt16(1), Oe.addInt32(n.length), Oe.add(n)) : (M.addInt16(0), Oe.addInt32(y.byteLength(
            n
          )), Oe.addString(n));
        }
      }, "writeValues"), Gu = a((r = {}) => {
        let e = r.portal || "", t = r.statement || "", n = r.binary || false, i = r.values || Ss, s = i.length;
        return M.addCString(e).addCString(t), M.addInt16(s), Hu(i, r.valueMapper), M.addInt16(s), M.add(Oe.flush()), M.addInt16(n ? 1 : 0), M.flush(66);
      }, "bind"), $u = y.from([69, 0, 0, 0, 9, 0, 0, 0, 0, 0]), Vu = a((r) => {
        if (!r || !r.portal && !r.rows) return $u;
        let e = r.portal || "", t = r.rows || 0, n = y.byteLength(e), i = 4 + n + 1 + 4, s = y.allocUnsafe(1 + i);
        return s[0] = 69, s.writeInt32BE(i, 1), s.write(e, 5, "utf-8"), s[n + 5] = 0, s.writeUInt32BE(t, s.length - 4), s;
      }, "execute"), Ku = a((r, e) => {
        let t = y.allocUnsafe(16);
        return t.writeInt32BE(16, 0), t.writeInt16BE(1234, 4), t.writeInt16BE(5678, 6), t.writeInt32BE(
          r,
          8
        ), t.writeInt32BE(e, 12), t;
      }, "cancel"), nn = a(
        (r, e) => {
          let n = 4 + y.byteLength(e) + 1, i = y.allocUnsafe(1 + n);
          return i[0] = r, i.writeInt32BE(n, 1), i.write(e, 5, "utf-8"), i[n] = 0, i;
        },
        "cstringMessage"
      ), zu = M.addCString("P").flush(68), Yu = M.addCString("S").flush(68), Zu = a((r) => r.name ? nn(68, `${r.type}${r.name || ""}`) : r.type === "P" ? zu : Yu, "describe"), Ju = a(
        (r) => {
          let e = `${r.type}${r.name || ""}`;
          return nn(67, e);
        },
        "close"
      ), Xu = a((r) => M.add(r).flush(
        100
      ), "copyData"), ec = a((r) => nn(102, r), "copyFail"), Et = a((r) => y.from([r, 0, 0, 0, 4]), "codeOnlyBuffer"), tc = Et(72), rc = Et(83), nc = Et(88), ic = Et(99), sc = {
        startup: Uu,
        password: Nu,
        requestSsl: Ou,
        sendSASLInitialResponseMessage: qu,
        sendSCRAMClientFinalMessage: Qu,
        query: ju,
        parse: Wu,
        bind: Gu,
        execute: Vu,
        describe: Zu,
        close: Ju,
        flush: a(() => tc, "flush"),
        sync: a(
          () => rc,
          "sync"
        ),
        end: a(() => nc, "end"),
        copyData: Xu,
        copyDone: a(() => ic, "copyDone"),
        copyFail: ec,
        cancel: Ku
      };
      vt.serialize = sc;
    });
    Es = I((_t) => {
      "use strict";
      p();
      Object.defineProperty(_t, "__esModule", { value: true });
      _t.BufferReader = void 0;
      var oc = y.allocUnsafe(0), on = class on {
        static {
          __name(this, "on");
        }
        constructor(e = 0) {
          this.offset = e, this.buffer = oc, this.encoding = "utf-8";
        }
        setBuffer(e, t) {
          this.offset = e, this.buffer = t;
        }
        int16() {
          let e = this.buffer.readInt16BE(this.offset);
          return this.offset += 2, e;
        }
        byte() {
          let e = this.buffer[this.offset];
          return this.offset++, e;
        }
        int32() {
          let e = this.buffer.readInt32BE(this.offset);
          return this.offset += 4, e;
        }
        string(e) {
          let t = this.buffer.toString(this.encoding, this.offset, this.offset + e);
          return this.offset += e, t;
        }
        cstring() {
          let e = this.offset, t = e;
          for (; this.buffer[t++] !== 0; ) ;
          return this.offset = t, this.buffer.toString(this.encoding, e, t - 1);
        }
        bytes(e) {
          let t = this.buffer.slice(this.offset, this.offset + e);
          return this.offset += e, t;
        }
      };
      a(on, "BufferReader");
      var sn = on;
      _t.BufferReader = sn;
    });
    As = I((At) => {
      "use strict";
      p();
      Object.defineProperty(At, "__esModule", { value: true });
      At.Parser = void 0;
      var D = Xr(), ac = Es(), an = 1, uc = 4, vs = an + uc, _s = y.allocUnsafe(0), cn = class cn {
        static {
          __name(this, "cn");
        }
        constructor(e) {
          if (this.buffer = _s, this.bufferLength = 0, this.bufferOffset = 0, this.reader = new ac.BufferReader(), e?.mode === "binary") throw new Error("Binary mode not supported yet");
          this.mode = e?.mode || "text";
        }
        parse(e, t) {
          this.mergeBuffer(e);
          let n = this.bufferOffset + this.bufferLength, i = this.bufferOffset;
          for (; i + vs <= n; ) {
            let s = this.buffer[i], o = this.buffer.readUInt32BE(
              i + an
            ), u = an + o;
            if (u + i <= n) {
              let c = this.handlePacket(i + vs, s, o, this.buffer);
              t(c), i += u;
            } else
              break;
          }
          i === n ? (this.buffer = _s, this.bufferLength = 0, this.bufferOffset = 0) : (this.bufferLength = n - i, this.bufferOffset = i);
        }
        mergeBuffer(e) {
          if (this.bufferLength > 0) {
            let t = this.bufferLength + e.byteLength;
            if (t + this.bufferOffset > this.buffer.byteLength) {
              let i;
              if (t <= this.buffer.byteLength && this.bufferOffset >= this.bufferLength) i = this.buffer;
              else {
                let s = this.buffer.byteLength * 2;
                for (; t >= s; ) s *= 2;
                i = y.allocUnsafe(s);
              }
              this.buffer.copy(
                i,
                0,
                this.bufferOffset,
                this.bufferOffset + this.bufferLength
              ), this.buffer = i, this.bufferOffset = 0;
            }
            e.copy(this.buffer, this.bufferOffset + this.bufferLength), this.bufferLength = t;
          } else this.buffer = e, this.bufferOffset = 0, this.bufferLength = e.byteLength;
        }
        handlePacket(e, t, n, i) {
          switch (t) {
            case 50:
              return D.bindComplete;
            case 49:
              return D.parseComplete;
            case 51:
              return D.closeComplete;
            case 110:
              return D.noData;
            case 115:
              return D.portalSuspended;
            case 99:
              return D.copyDone;
            case 87:
              return D.replicationStart;
            case 73:
              return D.emptyQuery;
            case 68:
              return this.parseDataRowMessage(
                e,
                n,
                i
              );
            case 67:
              return this.parseCommandCompleteMessage(e, n, i);
            case 90:
              return this.parseReadyForQueryMessage(e, n, i);
            case 65:
              return this.parseNotificationMessage(
                e,
                n,
                i
              );
            case 82:
              return this.parseAuthenticationResponse(e, n, i);
            case 83:
              return this.parseParameterStatusMessage(e, n, i);
            case 75:
              return this.parseBackendKeyData(e, n, i);
            case 69:
              return this.parseErrorMessage(e, n, i, "error");
            case 78:
              return this.parseErrorMessage(
                e,
                n,
                i,
                "notice"
              );
            case 84:
              return this.parseRowDescriptionMessage(e, n, i);
            case 116:
              return this.parseParameterDescriptionMessage(e, n, i);
            case 71:
              return this.parseCopyInMessage(
                e,
                n,
                i
              );
            case 72:
              return this.parseCopyOutMessage(e, n, i);
            case 100:
              return this.parseCopyData(
                e,
                n,
                i
              );
            default:
              return new D.DatabaseError("received invalid response: " + t.toString(
                16
              ), n, "error");
          }
        }
        parseReadyForQueryMessage(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.string(1);
          return new D.ReadyForQueryMessage(t, i);
        }
        parseCommandCompleteMessage(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.cstring();
          return new D.CommandCompleteMessage(
            t,
            i
          );
        }
        parseCopyData(e, t, n) {
          let i = n.slice(e, e + (t - 4));
          return new D.CopyDataMessage(
            t,
            i
          );
        }
        parseCopyInMessage(e, t, n) {
          return this.parseCopyMessage(e, t, n, "copyInResponse");
        }
        parseCopyOutMessage(e, t, n) {
          return this.parseCopyMessage(e, t, n, "copyOutResponse");
        }
        parseCopyMessage(e, t, n, i) {
          this.reader.setBuffer(e, n);
          let s = this.reader.byte() !== 0, o = this.reader.int16(), u = new D.CopyResponse(t, i, s, o);
          for (let c = 0; c < o; c++) u.columnTypes[c] = this.reader.int16();
          return u;
        }
        parseNotificationMessage(e, t, n) {
          this.reader.setBuffer(
            e,
            n
          );
          let i = this.reader.int32(), s = this.reader.cstring(), o = this.reader.cstring();
          return new D.NotificationResponseMessage(t, i, s, o);
        }
        parseRowDescriptionMessage(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.int16(), s = new D.RowDescriptionMessage(t, i);
          for (let o = 0; o < i; o++) s.fields[o] = this.parseField();
          return s;
        }
        parseField() {
          let e = this.reader.cstring(), t = this.reader.int32(), n = this.reader.int16(), i = this.reader.int32(), s = this.reader.int16(), o = this.reader.int32(), u = this.reader.int16() === 0 ? "text" : "binary";
          return new D.Field(e, t, n, i, s, o, u);
        }
        parseParameterDescriptionMessage(e, t, n) {
          this.reader.setBuffer(
            e,
            n
          );
          let i = this.reader.int16(), s = new D.ParameterDescriptionMessage(t, i);
          for (let o = 0; o < i; o++) s.dataTypeIDs[o] = this.reader.int32();
          return s;
        }
        parseDataRowMessage(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.int16(), s = new Array(i);
          for (let o = 0; o < i; o++) {
            let u = this.reader.int32();
            s[o] = u === -1 ? null : this.reader.string(u);
          }
          return new D.DataRowMessage(
            t,
            s
          );
        }
        parseParameterStatusMessage(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.cstring(), s = this.reader.cstring();
          return new D.ParameterStatusMessage(t, i, s);
        }
        parseBackendKeyData(e, t, n) {
          this.reader.setBuffer(e, n);
          let i = this.reader.int32(), s = this.reader.int32();
          return new D.BackendKeyDataMessage(t, i, s);
        }
        parseAuthenticationResponse(e, t, n) {
          this.reader.setBuffer(
            e,
            n
          );
          let i = this.reader.int32(), s = { name: "authenticationOk", length: t };
          switch (i) {
            case 0:
              break;
            case 3:
              s.length === 8 && (s.name = "authenticationCleartextPassword");
              break;
            case 5:
              if (s.length === 12) {
                s.name = "authenticationMD5Password";
                let u = this.reader.bytes(4);
                return new D.AuthenticationMD5Password(t, u);
              }
              break;
            case 10:
              s.name = "authenticationSASL", s.mechanisms = [];
              let o;
              do
                o = this.reader.cstring(), o && s.mechanisms.push(o);
              while (o);
              break;
            case 11:
              s.name = "authenticationSASLContinue", s.data = this.reader.string(t - 8);
              break;
            case 12:
              s.name = "authenticationSASLFinal", s.data = this.reader.string(t - 8);
              break;
            default:
              throw new Error("Unknown authenticationOk message type " + i);
          }
          return s;
        }
        parseErrorMessage(e, t, n, i) {
          this.reader.setBuffer(e, n);
          let s = {}, o = this.reader.string(1);
          for (; o !== "\0"; ) s[o] = this.reader.cstring(), o = this.reader.string(1);
          let u = s.M, c = i === "notice" ? new D.NoticeMessage(
            t,
            u
          ) : new D.DatabaseError(u, t, i);
          return c.severity = s.S, c.code = s.C, c.detail = s.D, c.hint = s.H, c.position = s.P, c.internalPosition = s.p, c.internalQuery = s.q, c.where = s.W, c.schema = s.s, c.table = s.t, c.column = s.c, c.dataType = s.d, c.constraint = s.n, c.file = s.F, c.line = s.L, c.routine = s.R, c;
        }
      };
      a(cn, "Parser");
      var un = cn;
      At.Parser = un;
    });
    hn = I((be) => {
      "use strict";
      p();
      Object.defineProperty(be, "__esModule", { value: true });
      be.DatabaseError = be.serialize = be.parse = void 0;
      var cc = Xr();
      Object.defineProperty(
        be,
        "DatabaseError",
        { enumerable: true, get: a(function() {
          return cc.DatabaseError;
        }, "get") }
      );
      var hc = xs();
      Object.defineProperty(be, "serialize", { enumerable: true, get: a(function() {
        return hc.serialize;
      }, "get") });
      var lc = As();
      function fc(r, e) {
        let t = new lc.Parser();
        return r.on("data", (n) => t.parse(n, e)), new Promise((n) => r.on("end", () => n()));
      }
      __name(fc, "fc");
      a(fc, "parse");
      be.parse = fc;
    });
    Cs = {};
    se(Cs, { connect: /* @__PURE__ */ __name(() => pc, "connect") });
    __name(pc, "pc");
    Ts = z(() => {
      "use strict";
      p();
      a(pc, "connect");
    });
    pn = I((of, Bs) => {
      "use strict";
      p();
      var Is = (St(), O(ws)), dc = ge().EventEmitter, {
        parse: yc,
        serialize: q
      } = hn(), Ps = q.flush(), mc = q.sync(), gc = q.end(), fn = class fn extends dc {
        static {
          __name(this, "fn");
        }
        constructor(e) {
          super(), e = e || {}, this.stream = e.stream || new Is.Socket(), this._keepAlive = e.keepAlive, this._keepAliveInitialDelayMillis = e.keepAliveInitialDelayMillis, this.lastBuffer = false, this.parsedStatements = {}, this.ssl = e.ssl || false, this._ending = false, this._emitMessage = false;
          var t = this;
          this.on("newListener", function(n) {
            n === "message" && (t._emitMessage = true);
          });
        }
        connect(e, t) {
          var n = this;
          this._connecting = true, this.stream.setNoDelay(true), this.stream.connect(
            e,
            t
          ), this.stream.once("connect", function() {
            n._keepAlive && n.stream.setKeepAlive(
              true,
              n._keepAliveInitialDelayMillis
            ), n.emit("connect");
          });
          let i = a(function(s) {
            n._ending && (s.code === "ECONNRESET" || s.code === "EPIPE") || n.emit("error", s);
          }, "reportStreamError");
          if (this.stream.on("error", i), this.stream.on("close", function() {
            n.emit("end");
          }), !this.ssl) return this.attachListeners(this.stream);
          this.stream.once("data", function(s) {
            var o = s.toString("utf8");
            switch (o) {
              case "S":
                break;
              case "N":
                return n.stream.end(), n.emit("error", new Error("The server does not support SSL connections"));
              default:
                return n.stream.end(), n.emit("error", new Error("There was an error establishing an SSL connection"));
            }
            var u = (Ts(), O(Cs));
            let c = { socket: n.stream };
            n.ssl !== true && (Object.assign(
              c,
              n.ssl
            ), "key" in n.ssl && (c.key = n.ssl.key)), Is.isIP(t) === 0 && (c.servername = t);
            try {
              n.stream = u.connect(c);
            } catch (h) {
              return n.emit("error", h);
            }
            n.attachListeners(n.stream), n.stream.on("error", i), n.emit("sslconnect");
          });
        }
        attachListeners(e) {
          e.on("end", () => {
            this.emit("end");
          }), yc(e, (t) => {
            var n = t.name === "error" ? "errorMessage" : t.name;
            this._emitMessage && this.emit("message", t), this.emit(n, t);
          });
        }
        requestSsl() {
          this.stream.write(q.requestSsl());
        }
        startup(e) {
          this.stream.write(q.startup(e));
        }
        cancel(e, t) {
          this._send(q.cancel(e, t));
        }
        password(e) {
          this._send(q.password(e));
        }
        sendSASLInitialResponseMessage(e, t) {
          this._send(q.sendSASLInitialResponseMessage(
            e,
            t
          ));
        }
        sendSCRAMClientFinalMessage(e) {
          this._send(q.sendSCRAMClientFinalMessage(e));
        }
        _send(e) {
          return this.stream.writable ? this.stream.write(e) : false;
        }
        query(e) {
          this._send(q.query(
            e
          ));
        }
        parse(e) {
          this._send(q.parse(e));
        }
        bind(e) {
          this._send(q.bind(e));
        }
        execute(e) {
          this._send(q.execute(e));
        }
        flush() {
          this.stream.writable && this.stream.write(Ps);
        }
        sync() {
          this._ending = true, this._send(Ps), this._send(mc);
        }
        ref() {
          this.stream.ref();
        }
        unref() {
          this.stream.unref();
        }
        end() {
          if (this._ending = true, !this._connecting || !this.stream.writable) {
            this.stream.end();
            return;
          }
          return this.stream.write(gc, () => {
            this.stream.end();
          });
        }
        close(e) {
          this._send(q.close(e));
        }
        describe(e) {
          this._send(q.describe(e));
        }
        sendCopyFromChunk(e) {
          this._send(q.copyData(e));
        }
        endCopyFrom() {
          this._send(q.copyDone());
        }
        sendCopyFail(e) {
          this._send(q.copyFail(e));
        }
      };
      a(fn, "Connection");
      var ln = fn;
      Bs.exports = ln;
    });
    Fs = I((hf, Rs) => {
      "use strict";
      p();
      var wc = ge().EventEmitter, cf = (Ge(), O(He)), bc = tt(), dn = ji(), Sc = Xi(), xc = wt(), Ec = bt(), Ls = ys(), vc = et(), _c = pn(), yn = class yn extends wc {
        static {
          __name(this, "yn");
        }
        constructor(e) {
          super(), this.connectionParameters = new Ec(e), this.user = this.connectionParameters.user, this.database = this.connectionParameters.database, this.port = this.connectionParameters.port, this.host = this.connectionParameters.host, Object.defineProperty(this, "password", { configurable: true, enumerable: false, writable: true, value: this.connectionParameters.password }), this.replication = this.connectionParameters.replication;
          var t = e || {};
          this._Promise = t.Promise || S.Promise, this._types = new xc(t.types), this._ending = false, this._connecting = false, this._connected = false, this._connectionError = false, this._queryable = true, this.connection = t.connection || new _c({ stream: t.stream, ssl: this.connectionParameters.ssl, keepAlive: t.keepAlive || false, keepAliveInitialDelayMillis: t.keepAliveInitialDelayMillis || 0, encoding: this.connectionParameters.client_encoding || "utf8" }), this.queryQueue = [], this.binary = t.binary || vc.binary, this.processID = null, this.secretKey = null, this.ssl = this.connectionParameters.ssl || false, this.ssl && this.ssl.key && Object.defineProperty(this.ssl, "key", { enumerable: false }), this._connectionTimeoutMillis = t.connectionTimeoutMillis || 0;
        }
        _errorAllQueries(e) {
          let t = a(
            (n) => {
              m.nextTick(() => {
                n.handleError(e, this.connection);
              });
            },
            "enqueueError"
          );
          this.activeQuery && (t(this.activeQuery), this.activeQuery = null), this.queryQueue.forEach(t), this.queryQueue.length = 0;
        }
        _connect(e) {
          var t = this, n = this.connection;
          if (this._connectionCallback = e, this._connecting || this._connected) {
            let i = new Error("Client has already been connected. You cannot reuse a client.");
            m.nextTick(() => {
              e(i);
            });
            return;
          }
          this._connecting = true, this.connectionTimeoutHandle, this._connectionTimeoutMillis > 0 && (this.connectionTimeoutHandle = setTimeout(() => {
            n._ending = true, n.stream.destroy(new Error("timeout expired"));
          }, this._connectionTimeoutMillis)), this.host && this.host.indexOf("/") === 0 ? n.connect(this.host + "/.s.PGSQL." + this.port) : n.connect(this.port, this.host), n.on("connect", function() {
            t.ssl ? n.requestSsl() : n.startup(t.getStartupConf());
          }), n.on("sslconnect", function() {
            n.startup(t.getStartupConf());
          }), this._attachListeners(n), n.once("end", () => {
            let i = this._ending ? new Error("Connection terminated") : new Error("Connection terminated unexpectedly");
            clearTimeout(this.connectionTimeoutHandle), this._errorAllQueries(i), this._ending || (this._connecting && !this._connectionError ? this._connectionCallback ? this._connectionCallback(i) : this._handleErrorEvent(i) : this._connectionError || this._handleErrorEvent(
              i
            )), m.nextTick(() => {
              this.emit("end");
            });
          });
        }
        connect(e) {
          if (e) {
            this._connect(e);
            return;
          }
          return new this._Promise((t, n) => {
            this._connect((i) => {
              i ? n(i) : t();
            });
          });
        }
        _attachListeners(e) {
          e.on("authenticationCleartextPassword", this._handleAuthCleartextPassword.bind(this)), e.on("authenticationMD5Password", this._handleAuthMD5Password.bind(this)), e.on("authenticationSASL", this._handleAuthSASL.bind(this)), e.on("authenticationSASLContinue", this._handleAuthSASLContinue.bind(this)), e.on("authenticationSASLFinal", this._handleAuthSASLFinal.bind(this)), e.on("backendKeyData", this._handleBackendKeyData.bind(this)), e.on("error", this._handleErrorEvent.bind(this)), e.on(
            "errorMessage",
            this._handleErrorMessage.bind(this)
          ), e.on("readyForQuery", this._handleReadyForQuery.bind(this)), e.on("notice", this._handleNotice.bind(this)), e.on("rowDescription", this._handleRowDescription.bind(this)), e.on("dataRow", this._handleDataRow.bind(this)), e.on("portalSuspended", this._handlePortalSuspended.bind(this)), e.on(
            "emptyQuery",
            this._handleEmptyQuery.bind(this)
          ), e.on("commandComplete", this._handleCommandComplete.bind(this)), e.on("parseComplete", this._handleParseComplete.bind(this)), e.on("copyInResponse", this._handleCopyInResponse.bind(this)), e.on("copyData", this._handleCopyData.bind(this)), e.on("notification", this._handleNotification.bind(this));
        }
        _checkPgPass(e) {
          let t = this.connection;
          typeof this.password == "function" ? this._Promise.resolve().then(
            () => this.password()
          ).then((n) => {
            if (n !== void 0) {
              if (typeof n != "string") {
                t.emit("error", new TypeError("Password must be a string"));
                return;
              }
              this.connectionParameters.password = this.password = n;
            } else this.connectionParameters.password = this.password = null;
            e();
          }).catch((n) => {
            t.emit("error", n);
          }) : this.password !== null ? e() : Sc(
            this.connectionParameters,
            (n) => {
              n !== void 0 && (this.connectionParameters.password = this.password = n), e();
            }
          );
        }
        _handleAuthCleartextPassword(e) {
          this._checkPgPass(() => {
            this.connection.password(this.password);
          });
        }
        _handleAuthMD5Password(e) {
          this._checkPgPass(() => {
            let t = bc.postgresMd5PasswordHash(
              this.user,
              this.password,
              e.salt
            );
            this.connection.password(t);
          });
        }
        _handleAuthSASL(e) {
          this._checkPgPass(() => {
            this.saslSession = dn.startSession(e.mechanisms), this.connection.sendSASLInitialResponseMessage(
              this.saslSession.mechanism,
              this.saslSession.response
            );
          });
        }
        _handleAuthSASLContinue(e) {
          dn.continueSession(this.saslSession, this.password, e.data), this.connection.sendSCRAMClientFinalMessage(
            this.saslSession.response
          );
        }
        _handleAuthSASLFinal(e) {
          dn.finalizeSession(
            this.saslSession,
            e.data
          ), this.saslSession = null;
        }
        _handleBackendKeyData(e) {
          this.processID = e.processID, this.secretKey = e.secretKey;
        }
        _handleReadyForQuery(e) {
          this._connecting && (this._connecting = false, this._connected = true, clearTimeout(this.connectionTimeoutHandle), this._connectionCallback && (this._connectionCallback(null, this), this._connectionCallback = null), this.emit("connect"));
          let { activeQuery: t } = this;
          this.activeQuery = null, this.readyForQuery = true, t && t.handleReadyForQuery(this.connection), this._pulseQueryQueue();
        }
        _handleErrorWhileConnecting(e) {
          if (!this._connectionError) {
            if (this._connectionError = true, clearTimeout(this.connectionTimeoutHandle), this._connectionCallback) return this._connectionCallback(e);
            this.emit("error", e);
          }
        }
        _handleErrorEvent(e) {
          if (this._connecting) return this._handleErrorWhileConnecting(e);
          this._queryable = false, this._errorAllQueries(e), this.emit("error", e);
        }
        _handleErrorMessage(e) {
          if (this._connecting)
            return this._handleErrorWhileConnecting(e);
          let t = this.activeQuery;
          if (!t) {
            this._handleErrorEvent(
              e
            );
            return;
          }
          this.activeQuery = null, t.handleError(e, this.connection);
        }
        _handleRowDescription(e) {
          this.activeQuery.handleRowDescription(e);
        }
        _handleDataRow(e) {
          this.activeQuery.handleDataRow(
            e
          );
        }
        _handlePortalSuspended(e) {
          this.activeQuery.handlePortalSuspended(this.connection);
        }
        _handleEmptyQuery(e) {
          this.activeQuery.handleEmptyQuery(this.connection);
        }
        _handleCommandComplete(e) {
          this.activeQuery.handleCommandComplete(e, this.connection);
        }
        _handleParseComplete(e) {
          this.activeQuery.name && (this.connection.parsedStatements[this.activeQuery.name] = this.activeQuery.text);
        }
        _handleCopyInResponse(e) {
          this.activeQuery.handleCopyInResponse(
            this.connection
          );
        }
        _handleCopyData(e) {
          this.activeQuery.handleCopyData(e, this.connection);
        }
        _handleNotification(e) {
          this.emit("notification", e);
        }
        _handleNotice(e) {
          this.emit("notice", e);
        }
        getStartupConf() {
          var e = this.connectionParameters, t = { user: e.user, database: e.database }, n = e.application_name || e.fallback_application_name;
          return n && (t.application_name = n), e.replication && (t.replication = "" + e.replication), e.statement_timeout && (t.statement_timeout = String(parseInt(
            e.statement_timeout,
            10
          ))), e.lock_timeout && (t.lock_timeout = String(parseInt(e.lock_timeout, 10))), e.idle_in_transaction_session_timeout && (t.idle_in_transaction_session_timeout = String(parseInt(
            e.idle_in_transaction_session_timeout,
            10
          ))), e.options && (t.options = e.options), t;
        }
        cancel(e, t) {
          if (e.activeQuery === t) {
            var n = this.connection;
            this.host && this.host.indexOf("/") === 0 ? n.connect(this.host + "/.s.PGSQL." + this.port) : n.connect(this.port, this.host), n.on("connect", function() {
              n.cancel(
                e.processID,
                e.secretKey
              );
            });
          } else e.queryQueue.indexOf(t) !== -1 && e.queryQueue.splice(e.queryQueue.indexOf(t), 1);
        }
        setTypeParser(e, t, n) {
          return this._types.setTypeParser(e, t, n);
        }
        getTypeParser(e, t) {
          return this._types.getTypeParser(e, t);
        }
        escapeIdentifier(e) {
          return '"' + e.replace(
            /"/g,
            '""'
          ) + '"';
        }
        escapeLiteral(e) {
          for (var t = false, n = "'", i = 0; i < e.length; i++) {
            var s = e[i];
            s === "'" ? n += s + s : s === "\\" ? (n += s + s, t = true) : n += s;
          }
          return n += "'", t === true && (n = " E" + n), n;
        }
        _pulseQueryQueue() {
          if (this.readyForQuery === true) if (this.activeQuery = this.queryQueue.shift(), this.activeQuery) {
            this.readyForQuery = false, this.hasExecuted = true;
            let e = this.activeQuery.submit(this.connection);
            e && m.nextTick(() => {
              this.activeQuery.handleError(e, this.connection), this.readyForQuery = true, this._pulseQueryQueue();
            });
          } else this.hasExecuted && (this.activeQuery = null, this.emit("drain"));
        }
        query(e, t, n) {
          var i, s, o, u, c;
          if (e == null) throw new TypeError("Client was passed a null or undefined query");
          return typeof e.submit == "function" ? (o = e.query_timeout || this.connectionParameters.query_timeout, s = i = e, typeof t == "function" && (i.callback = i.callback || t)) : (o = this.connectionParameters.query_timeout, i = new Ls(
            e,
            t,
            n
          ), i.callback || (s = new this._Promise((h, l) => {
            i.callback = (d, b) => d ? l(d) : h(b);
          }))), o && (c = i.callback, u = setTimeout(() => {
            var h = new Error("Query read timeout");
            m.nextTick(
              () => {
                i.handleError(h, this.connection);
              }
            ), c(h), i.callback = () => {
            };
            var l = this.queryQueue.indexOf(i);
            l > -1 && this.queryQueue.splice(l, 1), this._pulseQueryQueue();
          }, o), i.callback = (h, l) => {
            clearTimeout(u), c(h, l);
          }), this.binary && !i.binary && (i.binary = true), i._result && !i._result._types && (i._result._types = this._types), this._queryable ? this._ending ? (m.nextTick(() => {
            i.handleError(
              new Error("Client was closed and is not queryable"),
              this.connection
            );
          }), s) : (this.queryQueue.push(i), this._pulseQueryQueue(), s) : (m.nextTick(
            () => {
              i.handleError(new Error("Client has encountered a connection error and is not queryable"), this.connection);
            }
          ), s);
        }
        ref() {
          this.connection.ref();
        }
        unref() {
          this.connection.unref();
        }
        end(e) {
          if (this._ending = true, !this.connection._connecting) if (e) e();
          else return this._Promise.resolve();
          if (this.activeQuery || !this._queryable ? this.connection.stream.destroy() : this.connection.end(), e) this.connection.once("end", e);
          else return new this._Promise((t) => {
            this.connection.once("end", t);
          });
        }
      };
      a(yn, "Client");
      var Ct = yn;
      Ct.Query = Ls;
      Rs.exports = Ct;
    });
    Us = I((pf, ks) => {
      "use strict";
      p();
      var Ac = ge().EventEmitter, Ms = a(function() {
      }, "NOOP"), Ds = a(
        (r, e) => {
          let t = r.findIndex(e);
          return t === -1 ? void 0 : r.splice(t, 1)[0];
        },
        "removeWhere"
      ), wn = class wn {
        static {
          __name(this, "wn");
        }
        constructor(e, t, n) {
          this.client = e, this.idleListener = t, this.timeoutId = n;
        }
      };
      a(wn, "IdleItem");
      var mn = wn, bn = class bn {
        static {
          __name(this, "bn");
        }
        constructor(e) {
          this.callback = e;
        }
      };
      a(bn, "PendingItem");
      var Ne = bn;
      function Cc() {
        throw new Error("Release called on client which has already been released to the pool.");
      }
      __name(Cc, "Cc");
      a(Cc, "throwOnDoubleRelease");
      function Tt(r, e) {
        if (e) return { callback: e, result: void 0 };
        let t, n, i = a(function(o, u) {
          o ? t(o) : n(u);
        }, "cb"), s = new r(function(o, u) {
          n = o, t = u;
        }).catch((o) => {
          throw Error.captureStackTrace(
            o
          ), o;
        });
        return { callback: i, result: s };
      }
      __name(Tt, "Tt");
      a(Tt, "promisify");
      function Tc(r, e) {
        return a(
          /* @__PURE__ */ __name(function t(n) {
            n.client = e, e.removeListener("error", t), e.on("error", () => {
              r.log("additional client error after disconnection due to error", n);
            }), r._remove(e), r.emit("error", n, e);
          }, "t"),
          "idleListener"
        );
      }
      __name(Tc, "Tc");
      a(Tc, "makeIdleListener");
      var Sn = class Sn extends Ac {
        static {
          __name(this, "Sn");
        }
        constructor(e, t) {
          super(), this.options = Object.assign({}, e), e != null && "password" in e && Object.defineProperty(
            this.options,
            "password",
            { configurable: true, enumerable: false, writable: true, value: e.password }
          ), e != null && e.ssl && e.ssl.key && Object.defineProperty(this.options.ssl, "key", { enumerable: false }), this.options.max = this.options.max || this.options.poolSize || 10, this.options.maxUses = this.options.maxUses || 1 / 0, this.options.allowExitOnIdle = this.options.allowExitOnIdle || false, this.options.maxLifetimeSeconds = this.options.maxLifetimeSeconds || 0, this.log = this.options.log || function() {
          }, this.Client = this.options.Client || t || It().Client, this.Promise = this.options.Promise || S.Promise, typeof this.options.idleTimeoutMillis > "u" && (this.options.idleTimeoutMillis = 1e4), this._clients = [], this._idle = [], this._expired = /* @__PURE__ */ new WeakSet(), this._pendingQueue = [], this._endCallback = void 0, this.ending = false, this.ended = false;
        }
        _isFull() {
          return this._clients.length >= this.options.max;
        }
        _pulseQueue() {
          if (this.log("pulse queue"), this.ended) {
            this.log("pulse queue ended");
            return;
          }
          if (this.ending) {
            this.log(
              "pulse queue on ending"
            ), this._idle.length && this._idle.slice().map((t) => {
              this._remove(
                t.client
              );
            }), this._clients.length || (this.ended = true, this._endCallback());
            return;
          }
          if (!this._pendingQueue.length) {
            this.log("no queued requests");
            return;
          }
          if (!this._idle.length && this._isFull()) return;
          let e = this._pendingQueue.shift();
          if (this._idle.length) {
            let t = this._idle.pop();
            clearTimeout(t.timeoutId);
            let n = t.client;
            n.ref && n.ref();
            let i = t.idleListener;
            return this._acquireClient(n, e, i, false);
          }
          if (!this._isFull()) return this.newClient(e);
          throw new Error("unexpected condition");
        }
        _remove(e) {
          let t = Ds(this._idle, (n) => n.client === e);
          t !== void 0 && clearTimeout(t.timeoutId), this._clients = this._clients.filter((n) => n !== e), e.end(), this.emit("remove", e);
        }
        connect(e) {
          if (this.ending) {
            let i = new Error("Cannot use a pool after calling end on the pool");
            return e ? e(i) : this.Promise.reject(
              i
            );
          }
          let t = Tt(this.Promise, e), n = t.result;
          if (this._isFull() || this._idle.length) {
            if (this._idle.length && m.nextTick(() => this._pulseQueue()), !this.options.connectionTimeoutMillis)
              return this._pendingQueue.push(new Ne(t.callback)), n;
            let i = a((u, c, h) => {
              clearTimeout(
                o
              ), t.callback(u, c, h);
            }, "queueCallback"), s = new Ne(i), o = setTimeout(() => {
              Ds(
                this._pendingQueue,
                (u) => u.callback === i
              ), s.timedOut = true, t.callback(new Error("timeout exceeded when trying to connect"));
            }, this.options.connectionTimeoutMillis);
            return this._pendingQueue.push(s), n;
          }
          return this.newClient(new Ne(t.callback)), n;
        }
        newClient(e) {
          let t = new this.Client(this.options);
          this._clients.push(t);
          let n = Tc(this, t);
          this.log("checking client timeout");
          let i, s = false;
          this.options.connectionTimeoutMillis && (i = setTimeout(() => {
            this.log("ending client due to timeout"), s = true, t.connection ? t.connection.stream.destroy() : t.end();
          }, this.options.connectionTimeoutMillis)), this.log("connecting new client"), t.connect((o) => {
            if (i && clearTimeout(i), t.on("error", n), o) this.log("client failed to connect", o), this._clients = this._clients.filter((u) => u !== t), s && (o.message = "Connection terminated due to connection timeout"), this._pulseQueue(), e.timedOut || e.callback(
              o,
              void 0,
              Ms
            );
            else {
              if (this.log("new client connected"), this.options.maxLifetimeSeconds !== 0) {
                let u = setTimeout(() => {
                  this.log("ending client due to expired lifetime"), this._expired.add(t), this._idle.findIndex((h) => h.client === t) !== -1 && this._acquireClient(
                    t,
                    new Ne((h, l, d) => d()),
                    n,
                    false
                  );
                }, this.options.maxLifetimeSeconds * 1e3);
                u.unref(), t.once(
                  "end",
                  () => clearTimeout(u)
                );
              }
              return this._acquireClient(t, e, n, true);
            }
          });
        }
        _acquireClient(e, t, n, i) {
          i && this.emit("connect", e), this.emit("acquire", e), e.release = this._releaseOnce(e, n), e.removeListener("error", n), t.timedOut ? i && this.options.verify ? this.options.verify(
            e,
            e.release
          ) : e.release() : i && this.options.verify ? this.options.verify(e, (s) => {
            if (s) return e.release(s), t.callback(s, void 0, Ms);
            t.callback(void 0, e, e.release);
          }) : t.callback(
            void 0,
            e,
            e.release
          );
        }
        _releaseOnce(e, t) {
          let n = false;
          return (i) => {
            n && Cc(), n = true, this._release(
              e,
              t,
              i
            );
          };
        }
        _release(e, t, n) {
          if (e.on("error", t), e._poolUseCount = (e._poolUseCount || 0) + 1, this.emit("release", n, e), n || this.ending || !e._queryable || e._ending || e._poolUseCount >= this.options.maxUses) {
            e._poolUseCount >= this.options.maxUses && this.log("remove expended client"), this._remove(e), this._pulseQueue();
            return;
          }
          if (this._expired.has(e)) {
            this.log("remove expired client"), this._expired.delete(e), this._remove(e), this._pulseQueue();
            return;
          }
          let s;
          this.options.idleTimeoutMillis && (s = setTimeout(() => {
            this.log("remove idle client"), this._remove(e);
          }, this.options.idleTimeoutMillis), this.options.allowExitOnIdle && s.unref()), this.options.allowExitOnIdle && e.unref(), this._idle.push(new mn(e, t, s)), this._pulseQueue();
        }
        query(e, t, n) {
          if (typeof e == "function") {
            let s = Tt(this.Promise, e);
            return x(function() {
              return s.callback(new Error("Passing a function as the first parameter to pool.query is not supported"));
            }), s.result;
          }
          typeof t == "function" && (n = t, t = void 0);
          let i = Tt(this.Promise, n);
          return n = i.callback, this.connect((s, o) => {
            if (s)
              return n(s);
            let u = false, c = a((h) => {
              u || (u = true, o.release(h), n(h));
            }, "onError");
            o.once("error", c), this.log("dispatching query");
            try {
              o.query(e, t, (h, l) => {
                if (this.log("query dispatched"), o.removeListener("error", c), !u) return u = true, o.release(h), h ? n(h) : n(
                  void 0,
                  l
                );
              });
            } catch (h) {
              return o.release(h), n(h);
            }
          }), i.result;
        }
        end(e) {
          if (this.log("ending"), this.ending) {
            let n = new Error("Called end on pool more than once");
            return e ? e(n) : this.Promise.reject(n);
          }
          this.ending = true;
          let t = Tt(this.Promise, e);
          return this._endCallback = t.callback, this._pulseQueue(), t.result;
        }
        get waitingCount() {
          return this._pendingQueue.length;
        }
        get idleCount() {
          return this._idle.length;
        }
        get expiredCount() {
          return this._clients.reduce((e, t) => e + (this._expired.has(t) ? 1 : 0), 0);
        }
        get totalCount() {
          return this._clients.length;
        }
      };
      a(Sn, "Pool");
      var gn = Sn;
      ks.exports = gn;
    });
    Os = {};
    se(Os, { default: /* @__PURE__ */ __name(() => Ic, "default") });
    Ns = z(() => {
      "use strict";
      p();
      Ic = {};
    });
    qs = I((gf, Pc) => {
      Pc.exports = { name: "pg", version: "8.8.0", description: "PostgreSQL client - pure javascript & libpq with the same API", keywords: [
        "database",
        "libpq",
        "pg",
        "postgre",
        "postgres",
        "postgresql",
        "rdbms"
      ], homepage: "https://github.com/brianc/node-postgres", repository: { type: "git", url: "git://github.com/brianc/node-postgres.git", directory: "packages/pg" }, author: "Brian Carlson <brian.m.carlson@gmail.com>", main: "./lib", dependencies: {
        "buffer-writer": "2.0.0",
        "packet-reader": "1.0.0",
        "pg-connection-string": "^2.5.0",
        "pg-pool": "^3.5.2",
        "pg-protocol": "^1.5.0",
        "pg-types": "^2.1.0",
        pgpass: "1.x"
      }, devDependencies: { async: "2.6.4", bluebird: "3.5.2", co: "4.6.0", "pg-copy-streams": "0.3.0" }, peerDependencies: { "pg-native": ">=3.0.1" }, peerDependenciesMeta: {
        "pg-native": { optional: true }
      }, scripts: { test: "make test-all" }, files: ["lib", "SPONSORS.md"], license: "MIT", engines: { node: ">= 8.0.0" }, gitHead: "c99fb2c127ddf8d712500db2c7b9a5491a178655" };
    });
    Ws = I((wf, js) => {
      "use strict";
      p();
      var Qs = ge().EventEmitter, Bc = (Ge(), O(He)), xn = tt(), qe = js.exports = function(r, e, t) {
        Qs.call(this), r = xn.normalizeQueryConfig(r, e, t), this.text = r.text, this.values = r.values, this.name = r.name, this.callback = r.callback, this.state = "new", this._arrayMode = r.rowMode === "array", this._emitRowEvents = false, this.on("newListener", function(n) {
          n === "row" && (this._emitRowEvents = true);
        }.bind(this));
      };
      Bc.inherits(
        qe,
        Qs
      );
      var Lc = { sqlState: "code", statementPosition: "position", messagePrimary: "message", context: "where", schemaName: "schema", tableName: "table", columnName: "column", dataTypeName: "dataType", constraintName: "constraint", sourceFile: "file", sourceLine: "line", sourceFunction: "routine" };
      qe.prototype.handleError = function(r) {
        var e = this.native.pq.resultErrorFields();
        if (e) for (var t in e) {
          var n = Lc[t] || t;
          r[n] = e[t];
        }
        this.callback ? this.callback(r) : this.emit("error", r), this.state = "error";
      };
      qe.prototype.then = function(r, e) {
        return this._getPromise().then(r, e);
      };
      qe.prototype.catch = function(r) {
        return this._getPromise().catch(r);
      };
      qe.prototype._getPromise = function() {
        return this._promise ? this._promise : (this._promise = new Promise(function(r, e) {
          this._once("end", r), this._once(
            "error",
            e
          );
        }.bind(this)), this._promise);
      };
      qe.prototype.submit = function(r) {
        this.state = "running";
        var e = this;
        this.native = r.native, r.native.arrayMode = this._arrayMode;
        var t = a(
          function(s, o, u) {
            if (r.native.arrayMode = false, x(function() {
              e.emit("_done");
            }), s) return e.handleError(s);
            e._emitRowEvents && (u.length > 1 ? o.forEach((c, h) => {
              c.forEach((l) => {
                e.emit(
                  "row",
                  l,
                  u[h]
                );
              });
            }) : o.forEach(function(c) {
              e.emit("row", c, u);
            })), e.state = "end", e.emit(
              "end",
              u
            ), e.callback && e.callback(null, u);
          },
          "after"
        );
        if (m.domain && (t = m.domain.bind(
          t
        )), this.name) {
          this.name.length > 63 && (console.error("Warning! Postgres only supports 63 characters for query names."), console.error(
            "You supplied %s (%s)",
            this.name,
            this.name.length
          ), console.error("This can cause conflicts and silent errors executing queries"));
          var n = (this.values || []).map(xn.prepareValue);
          if (r.namedQueries[this.name]) {
            if (this.text && r.namedQueries[this.name] !== this.text) {
              let s = new Error(`Prepared statements must be unique - '${this.name}' was used for a different statement`);
              return t(s);
            }
            return r.native.execute(this.name, n, t);
          }
          return r.native.prepare(
            this.name,
            this.text,
            n.length,
            function(s) {
              return s ? t(s) : (r.namedQueries[e.name] = e.text, e.native.execute(e.name, n, t));
            }
          );
        } else if (this.values) {
          if (!Array.isArray(this.values)) {
            let s = new Error("Query values must be an array");
            return t(s);
          }
          var i = this.values.map(xn.prepareValue);
          r.native.query(this.text, i, t);
        } else r.native.query(this.text, t);
      };
    });
    Vs = I((Ef, $s) => {
      "use strict";
      p();
      var Rc = (Ns(), O(Os)), Fc = wt(), xf = qs(), Hs = ge().EventEmitter, Mc = (Ge(), O(He)), Dc = bt(), Gs = Ws(), J = $s.exports = function(r) {
        Hs.call(this), r = r || {}, this._Promise = r.Promise || S.Promise, this._types = new Fc(r.types), this.native = new Rc({ types: this._types }), this._queryQueue = [], this._ending = false, this._connecting = false, this._connected = false, this._queryable = true;
        var e = this.connectionParameters = new Dc(
          r
        );
        this.user = e.user, Object.defineProperty(this, "password", {
          configurable: true,
          enumerable: false,
          writable: true,
          value: e.password
        }), this.database = e.database, this.host = e.host, this.port = e.port, this.namedQueries = {};
      };
      J.Query = Gs;
      Mc.inherits(J, Hs);
      J.prototype._errorAllQueries = function(r) {
        let e = a(
          (t) => {
            m.nextTick(() => {
              t.native = this.native, t.handleError(r);
            });
          },
          "enqueueError"
        );
        this._hasActiveQuery() && (e(this._activeQuery), this._activeQuery = null), this._queryQueue.forEach(e), this._queryQueue.length = 0;
      };
      J.prototype._connect = function(r) {
        var e = this;
        if (this._connecting) {
          m.nextTick(() => r(new Error("Client has already been connected. You cannot reuse a client.")));
          return;
        }
        this._connecting = true, this.connectionParameters.getLibpqConnectionString(function(t, n) {
          if (t) return r(
            t
          );
          e.native.connect(n, function(i) {
            if (i) return e.native.end(), r(i);
            e._connected = true, e.native.on("error", function(s) {
              e._queryable = false, e._errorAllQueries(s), e.emit("error", s);
            }), e.native.on("notification", function(s) {
              e.emit("notification", { channel: s.relname, payload: s.extra });
            }), e.emit("connect"), e._pulseQueryQueue(true), r();
          });
        });
      };
      J.prototype.connect = function(r) {
        if (r) {
          this._connect(r);
          return;
        }
        return new this._Promise(
          (e, t) => {
            this._connect((n) => {
              n ? t(n) : e();
            });
          }
        );
      };
      J.prototype.query = function(r, e, t) {
        var n, i, s, o, u;
        if (r == null) throw new TypeError("Client was passed a null or undefined query");
        if (typeof r.submit == "function") s = r.query_timeout || this.connectionParameters.query_timeout, i = n = r, typeof e == "function" && (r.callback = e);
        else if (s = this.connectionParameters.query_timeout, n = new Gs(r, e, t), !n.callback) {
          let c, h;
          i = new this._Promise((l, d) => {
            c = l, h = d;
          }), n.callback = (l, d) => l ? h(l) : c(d);
        }
        return s && (u = n.callback, o = setTimeout(() => {
          var c = new Error("Query read timeout");
          m.nextTick(() => {
            n.handleError(c, this.connection);
          }), u(c), n.callback = () => {
          };
          var h = this._queryQueue.indexOf(n);
          h > -1 && this._queryQueue.splice(h, 1), this._pulseQueryQueue();
        }, s), n.callback = (c, h) => {
          clearTimeout(o), u(c, h);
        }), this._queryable ? this._ending ? (n.native = this.native, m.nextTick(() => {
          n.handleError(
            new Error("Client was closed and is not queryable")
          );
        }), i) : (this._queryQueue.push(
          n
        ), this._pulseQueryQueue(), i) : (n.native = this.native, m.nextTick(() => {
          n.handleError(
            new Error("Client has encountered a connection error and is not queryable")
          );
        }), i);
      };
      J.prototype.end = function(r) {
        var e = this;
        this._ending = true, this._connected || this.once(
          "connect",
          this.end.bind(this, r)
        );
        var t;
        return r || (t = new this._Promise(function(n, i) {
          r = a((s) => s ? i(s) : n(), "cb");
        })), this.native.end(function() {
          e._errorAllQueries(new Error(
            "Connection terminated"
          )), m.nextTick(() => {
            e.emit("end"), r && r();
          });
        }), t;
      };
      J.prototype._hasActiveQuery = function() {
        return this._activeQuery && this._activeQuery.state !== "error" && this._activeQuery.state !== "end";
      };
      J.prototype._pulseQueryQueue = function(r) {
        if (this._connected && !this._hasActiveQuery()) {
          var e = this._queryQueue.shift();
          if (!e) {
            r || this.emit("drain");
            return;
          }
          this._activeQuery = e, e.submit(this);
          var t = this;
          e.once(
            "_done",
            function() {
              t._pulseQueryQueue();
            }
          );
        }
      };
      J.prototype.cancel = function(r) {
        this._activeQuery === r ? this.native.cancel(function() {
        }) : this._queryQueue.indexOf(r) !== -1 && this._queryQueue.splice(this._queryQueue.indexOf(r), 1);
      };
      J.prototype.ref = function() {
      };
      J.prototype.unref = function() {
      };
      J.prototype.setTypeParser = function(r, e, t) {
        return this._types.setTypeParser(r, e, t);
      };
      J.prototype.getTypeParser = function(r, e) {
        return this._types.getTypeParser(r, e);
      };
    });
    En = I((Af, Ks) => {
      "use strict";
      p();
      Ks.exports = Vs();
    });
    It = I((Tf, nt) => {
      "use strict";
      p();
      var kc = Fs(), Uc = et(), Oc = pn(), Nc = Us(), { DatabaseError: qc } = hn(), Qc = a((r) => {
        var e;
        return e = class extends Nc {
          static {
            __name(this, "e");
          }
          constructor(n) {
            super(n, r);
          }
        }, a(e, "BoundPool"), e;
      }, "poolFactory"), vn = a(function(r) {
        this.defaults = Uc, this.Client = r, this.Query = this.Client.Query, this.Pool = Qc(this.Client), this._pools = [], this.Connection = Oc, this.types = Xe(), this.DatabaseError = qc;
      }, "PG");
      typeof m.env.NODE_PG_FORCE_NATIVE < "u" ? nt.exports = new vn(En()) : (nt.exports = new vn(kc), Object.defineProperty(nt.exports, "native", { configurable: true, enumerable: false, get() {
        var r = null;
        try {
          r = new vn(En());
        } catch (e) {
          if (e.code !== "MODULE_NOT_FOUND") throw e;
        }
        return Object.defineProperty(nt.exports, "native", { value: r }), r;
      } }));
    });
    p();
    Bt = Te(It());
    St();
    p();
    St();
    mr();
    Zs = Te(tt());
    Js = Te(wt());
    __name(jc, "jc");
    a(jc, "encodeBuffersAsBytea");
    Pt = class Pt2 extends Error {
      static {
        __name(this, "Pt");
      }
      constructor(t) {
        super(t);
        _(
          this,
          "name",
          "NeonDbError"
        );
        _(this, "severity");
        _(this, "code");
        _(this, "detail");
        _(this, "hint");
        _(this, "position");
        _(this, "internalPosition");
        _(this, "internalQuery");
        _(this, "where");
        _(this, "schema");
        _(this, "table");
        _(this, "column");
        _(this, "dataType");
        _(
          this,
          "constraint"
        );
        _(this, "file");
        _(this, "line");
        _(this, "routine");
        _(this, "sourceError");
        "captureStackTrace" in Error && typeof Error.captureStackTrace == "function" && Error.captureStackTrace(this, Pt2);
      }
    };
    a(Pt, "NeonDbError");
    pe = Pt;
    zs = "transaction() expects an array of queries, or a function returning an array of queries";
    Wc = ["severity", "code", "detail", "hint", "position", "internalPosition", "internalQuery", "where", "schema", "table", "column", "dataType", "constraint", "file", "line", "routine"];
    __name(Xs, "Xs");
    a(Xs, "neon");
    __name(Hc, "Hc");
    a(Hc, "createNeonQueryPromise");
    __name(Ys, "Ys");
    a(Ys, "processQueryResult");
    __name(Gc, "Gc");
    a(Gc, "getAuthToken");
    to = Te(bt());
    Qe = Te(It());
    An = class An2 extends Bt.Client {
      static {
        __name(this, "An");
      }
      constructor(t) {
        super(t);
        this.config = t;
      }
      get neonConfig() {
        return this.connection.stream;
      }
      connect(t) {
        let { neonConfig: n } = this;
        n.forceDisablePgSSL && (this.ssl = this.connection.ssl = false), this.ssl && n.useSecureWebSocket && console.warn("SSL is enabled for both Postgres (e.g. ?sslmode=require in the connection string + forceDisablePgSSL = false) and the WebSocket tunnel (useSecureWebSocket = true). Double encryption will increase latency and CPU usage. It may be appropriate to disable SSL in the Postgres connection parameters or set forceDisablePgSSL = true.");
        let i = this.config?.host !== void 0 || this.config?.connectionString !== void 0 || m.env.PGHOST !== void 0, s = m.env.USER ?? m.env.USERNAME;
        if (!i && this.host === "localhost" && this.user === s && this.database === s && this.password === null) throw new Error(`No database host or connection string was set, and key parameters have default values (host: localhost, user: ${s}, db: ${s}, password: null). Is an environment variable missing? Alternatively, if you intended to connect with these parameters, please set the host to 'localhost' explicitly.`);
        let o = super.connect(t), u = n.pipelineTLS && this.ssl, c = n.pipelineConnect === "password";
        if (!u && !n.pipelineConnect) return o;
        let h = this.connection;
        if (u && h.on("connect", () => h.stream.emit("data", "S")), c) {
          h.removeAllListeners(
            "authenticationCleartextPassword"
          ), h.removeAllListeners("readyForQuery"), h.once(
            "readyForQuery",
            () => h.on("readyForQuery", this._handleReadyForQuery.bind(this))
          );
          let l = this.ssl ? "sslconnect" : "connect";
          h.on(l, () => {
            this._handleAuthCleartextPassword(), this._handleReadyForQuery();
          });
        }
        return o;
      }
      async _handleAuthSASLContinue(t) {
        let n = this.saslSession, i = this.password, s = t.data;
        if (n.message !== "SASLInitialResponse" || typeof i != "string" || typeof s != "string") throw new Error("SASL: protocol error");
        let o = Object.fromEntries(s.split(",").map((te) => {
          if (!/^.=/.test(te)) throw new Error("SASL: Invalid attribute pair entry");
          let W = te[0], H = te.substring(2);
          return [W, H];
        })), u = o.r, c = o.s, h = o.i;
        if (!u || !/^[!-+--~]+$/.test(u)) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: nonce missing/unprintable");
        if (!c || !/^(?:[a-zA-Z0-9+/]{4})*(?:[a-zA-Z0-9+/]{2}==|[a-zA-Z0-9+/]{3}=)?$/.test(c)) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: salt missing/not base64");
        if (!h || !/^[1-9][0-9]*$/.test(h)) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: missing/invalid iteration count");
        if (!u.startsWith(n.clientNonce)) throw new Error(
          "SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce does not start with client nonce"
        );
        if (u.length === n.clientNonce.length) throw new Error("SASL: SCRAM-SERVER-FIRST-MESSAGE: server nonce is too short");
        let l = parseInt(h, 10), d = y.from(c, "base64"), b = new TextEncoder(), C = b.encode(i), B = await w.subtle.importKey("raw", C, { name: "HMAC", hash: { name: "SHA-256" } }, false, ["sign"]), Q = new Uint8Array(await w.subtle.sign("HMAC", B, y.concat([d, y.from(
          [0, 0, 0, 1]
        )]))), X = Q;
        for (var de = 0; de < l - 1; de++) Q = new Uint8Array(await w.subtle.sign(
          "HMAC",
          B,
          Q
        )), X = y.from(X.map((te, W) => X[W] ^ Q[W]));
        let A = X, g = await w.subtle.importKey(
          "raw",
          A,
          { name: "HMAC", hash: { name: "SHA-256" } },
          false,
          ["sign"]
        ), P = new Uint8Array(await w.subtle.sign("HMAC", g, b.encode("Client Key"))), K = await w.subtle.digest(
          "SHA-256",
          P
        ), k = "n=*,r=" + n.clientNonce, j = "r=" + u + ",s=" + c + ",i=" + l, ee = "c=biws,r=" + u, oe = k + "," + j + "," + ee, R = await w.subtle.importKey(
          "raw",
          K,
          { name: "HMAC", hash: { name: "SHA-256" } },
          false,
          ["sign"]
        );
        var $ = new Uint8Array(await w.subtle.sign("HMAC", R, b.encode(oe))), ce = y.from(P.map((te, W) => P[W] ^ $[W])), ye = ce.toString("base64");
        let Se = await w.subtle.importKey(
          "raw",
          A,
          { name: "HMAC", hash: { name: "SHA-256" } },
          false,
          ["sign"]
        ), je = await w.subtle.sign(
          "HMAC",
          Se,
          b.encode("Server Key")
        ), he = await w.subtle.importKey("raw", je, { name: "HMAC", hash: { name: "SHA-256" } }, false, ["sign"]);
        var it = y.from(await w.subtle.sign(
          "HMAC",
          he,
          b.encode(oe)
        ));
        n.message = "SASLResponse", n.serverSignature = it.toString("base64"), n.response = ee + ",p=" + ye, this.connection.sendSCRAMClientFinalMessage(this.saslSession.response);
      }
    };
    a(An, "NeonClient");
    _n = An;
    __name($c, "$c");
    a($c, "promisify");
    Cn = class Cn2 extends Bt.Pool {
      static {
        __name(this, "Cn");
      }
      constructor() {
        super(...arguments);
        _(this, "Client", _n);
        _(this, "hasFetchUnsupportedListeners", false);
      }
      on(t, n) {
        return t !== "error" && (this.hasFetchUnsupportedListeners = true), super.on(t, n);
      }
      query(t, n, i) {
        if (!_e.poolQueryViaFetch || this.hasFetchUnsupportedListeners || typeof t == "function")
          return super.query(t, n, i);
        typeof n == "function" && (i = n, n = void 0);
        let s = $c(
          this.Promise,
          i
        );
        i = s.callback;
        try {
          let o = new to.default(this.options), u = encodeURIComponent, c = encodeURI, h = `postgresql://${u(o.user)}:${u(o.password)}@${u(o.host)}/${c(o.database)}`, l = typeof t == "string" ? t : t.text, d = n ?? t.values ?? [];
          Xs(h, { fullResults: true, arrayMode: t.rowMode === "array" })(l, d, { types: t.types ?? this.options?.types }).then((C) => i(void 0, C)).catch((C) => i(
            C
          ));
        } catch (o) {
          i(o);
        }
        return s.result;
      }
    };
    a(Cn, "NeonPool");
    export_ClientBase = Qe.ClientBase;
    export_Connection = Qe.Connection;
    export_DatabaseError = Qe.DatabaseError;
    export_Query = Qe.Query;
    export_defaults = Qe.defaults;
    export_types = Qe.types;
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/entity.js
function is(value, type) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (value instanceof type) {
    return true;
  }
  if (!Object.prototype.hasOwnProperty.call(type, entityKind)) {
    throw new Error(
      `Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`
    );
  }
  let cls = Object.getPrototypeOf(value).constructor;
  if (cls) {
    while (cls) {
      if (entityKind in cls && cls[entityKind] === type[entityKind]) {
        return true;
      }
      cls = Object.getPrototypeOf(cls);
    }
  }
  return false;
}
var entityKind;
var init_entity = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/entity.js"() {
    init_functionsRoutes_0_17677553668797852();
    entityKind = /* @__PURE__ */ Symbol.for("drizzle:entityKind");
    __name(is, "is");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/logger.js
var ConsoleLogWriter, DefaultLogger, NoopLogger;
var init_logger = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/logger.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    ConsoleLogWriter = class {
      static {
        __name(this, "ConsoleLogWriter");
      }
      static [entityKind] = "ConsoleLogWriter";
      write(message) {
        console.log(message);
      }
    };
    DefaultLogger = class {
      static {
        __name(this, "DefaultLogger");
      }
      static [entityKind] = "DefaultLogger";
      writer;
      constructor(config) {
        this.writer = config?.writer ?? new ConsoleLogWriter();
      }
      logQuery(query, params) {
        const stringifiedParams = params.map((p2) => {
          try {
            return JSON.stringify(p2);
          } catch {
            return String(p2);
          }
        });
        const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
        this.writer.write(`Query: ${query}${paramsStr}`);
      }
    };
    NoopLogger = class {
      static {
        __name(this, "NoopLogger");
      }
      static [entityKind] = "NoopLogger";
      logQuery() {
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/query-promise.js
var QueryPromise;
var init_query_promise = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/query-promise.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    QueryPromise = class {
      static {
        __name(this, "QueryPromise");
      }
      static [entityKind] = "QueryPromise";
      [Symbol.toStringTag] = "QueryPromise";
      catch(onRejected) {
        return this.then(void 0, onRejected);
      }
      finally(onFinally) {
        return this.then(
          (value) => {
            onFinally?.();
            return value;
          },
          (reason) => {
            onFinally?.();
            throw reason;
          }
        );
      }
      then(onFulfilled, onRejected) {
        return this.execute().then(onFulfilled, onRejected);
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/column.js
var Column;
var init_column = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/column.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    Column = class {
      static {
        __name(this, "Column");
      }
      constructor(table, config) {
        this.table = table;
        this.config = config;
        this.name = config.name;
        this.keyAsName = config.keyAsName;
        this.notNull = config.notNull;
        this.default = config.default;
        this.defaultFn = config.defaultFn;
        this.onUpdateFn = config.onUpdateFn;
        this.hasDefault = config.hasDefault;
        this.primary = config.primaryKey;
        this.isUnique = config.isUnique;
        this.uniqueName = config.uniqueName;
        this.uniqueType = config.uniqueType;
        this.dataType = config.dataType;
        this.columnType = config.columnType;
        this.generated = config.generated;
        this.generatedIdentity = config.generatedIdentity;
      }
      static [entityKind] = "Column";
      name;
      keyAsName;
      primary;
      notNull;
      default;
      defaultFn;
      onUpdateFn;
      hasDefault;
      isUnique;
      uniqueName;
      uniqueType;
      dataType;
      columnType;
      enumValues = void 0;
      generated = void 0;
      generatedIdentity = void 0;
      config;
      mapFromDriverValue(value) {
        return value;
      }
      mapToDriverValue(value) {
        return value;
      }
      // ** @internal */
      shouldDisableInsert() {
        return this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/column-builder.js
var ColumnBuilder;
var init_column_builder = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/column-builder.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    ColumnBuilder = class {
      static {
        __name(this, "ColumnBuilder");
      }
      static [entityKind] = "ColumnBuilder";
      config;
      constructor(name, dataType, columnType) {
        this.config = {
          name,
          keyAsName: name === "",
          notNull: false,
          default: void 0,
          hasDefault: false,
          primaryKey: false,
          isUnique: false,
          uniqueName: void 0,
          uniqueType: void 0,
          dataType,
          columnType,
          generated: void 0
        };
      }
      /**
       * Changes the data type of the column. Commonly used with `json` columns. Also, useful for branded types.
       *
       * @example
       * ```ts
       * const users = pgTable('users', {
       * 	id: integer('id').$type<UserId>().primaryKey(),
       * 	details: json('details').$type<UserDetails>().notNull(),
       * });
       * ```
       */
      $type() {
        return this;
      }
      /**
       * Adds a `not null` clause to the column definition.
       *
       * Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
       */
      notNull() {
        this.config.notNull = true;
        return this;
      }
      /**
       * Adds a `default <value>` clause to the column definition.
       *
       * Affects the `insert` model of the table - columns *with* `default` are optional on insert.
       *
       * If you need to set a dynamic default value, use {@link $defaultFn} instead.
       */
      default(value) {
        this.config.default = value;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Adds a dynamic default value to the column.
       * The function will be called when the row is inserted, and the returned value will be used as the column value.
       *
       * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
       */
      $defaultFn(fn) {
        this.config.defaultFn = fn;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Alias for {@link $defaultFn}.
       */
      $default = this.$defaultFn;
      /**
       * Adds a dynamic update value to the column.
       * The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
       * If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
       *
       * **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
       */
      $onUpdateFn(fn) {
        this.config.onUpdateFn = fn;
        this.config.hasDefault = true;
        return this;
      }
      /**
       * Alias for {@link $onUpdateFn}.
       */
      $onUpdate = this.$onUpdateFn;
      /**
       * Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
       *
       * In SQLite, `integer primary key` implicitly makes the column auto-incrementing.
       */
      primaryKey() {
        this.config.primaryKey = true;
        this.config.notNull = true;
        return this;
      }
      /** @internal Sets the name of the column to the key within the table definition if a name was not given. */
      setName(name) {
        if (this.config.name !== "")
          return;
        this.config.name = name;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/table.utils.js
var TableName;
var init_table_utils = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/table.utils.js"() {
    init_functionsRoutes_0_17677553668797852();
    TableName = /* @__PURE__ */ Symbol.for("drizzle:Name");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/foreign-keys.js
var ForeignKeyBuilder, ForeignKey;
var init_foreign_keys = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/foreign-keys.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table_utils();
    ForeignKeyBuilder = class {
      static {
        __name(this, "ForeignKeyBuilder");
      }
      static [entityKind] = "PgForeignKeyBuilder";
      /** @internal */
      reference;
      /** @internal */
      _onUpdate = "no action";
      /** @internal */
      _onDelete = "no action";
      constructor(config, actions) {
        this.reference = () => {
          const { name, columns, foreignColumns } = config();
          return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
        };
        if (actions) {
          this._onUpdate = actions.onUpdate;
          this._onDelete = actions.onDelete;
        }
      }
      onUpdate(action) {
        this._onUpdate = action === void 0 ? "no action" : action;
        return this;
      }
      onDelete(action) {
        this._onDelete = action === void 0 ? "no action" : action;
        return this;
      }
      /** @internal */
      build(table) {
        return new ForeignKey(table, this);
      }
    };
    ForeignKey = class {
      static {
        __name(this, "ForeignKey");
      }
      constructor(table, builder) {
        this.table = table;
        this.reference = builder.reference;
        this.onUpdate = builder._onUpdate;
        this.onDelete = builder._onDelete;
      }
      static [entityKind] = "PgForeignKey";
      reference;
      onUpdate;
      onDelete;
      getName() {
        const { name, columns, foreignColumns } = this.reference();
        const columnNames = columns.map((column) => column.name);
        const foreignColumnNames = foreignColumns.map((column) => column.name);
        const chunks = [
          this.table[TableName],
          ...columnNames,
          foreignColumns[0].table[TableName],
          ...foreignColumnNames
        ];
        return name ?? `${chunks.join("_")}_fk`;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/tracing-utils.js
function iife(fn, ...args) {
  return fn(...args);
}
var init_tracing_utils = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/tracing-utils.js"() {
    init_functionsRoutes_0_17677553668797852();
    __name(iife, "iife");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/unique-constraint.js
function uniqueKeyName(table, columns) {
  return `${table[TableName]}_${columns.join("_")}_unique`;
}
var UniqueConstraintBuilder, UniqueOnConstraintBuilder, UniqueConstraint;
var init_unique_constraint = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/unique-constraint.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table_utils();
    __name(uniqueKeyName, "uniqueKeyName");
    UniqueConstraintBuilder = class {
      static {
        __name(this, "UniqueConstraintBuilder");
      }
      constructor(columns, name) {
        this.name = name;
        this.columns = columns;
      }
      static [entityKind] = "PgUniqueConstraintBuilder";
      /** @internal */
      columns;
      /** @internal */
      nullsNotDistinctConfig = false;
      nullsNotDistinct() {
        this.nullsNotDistinctConfig = true;
        return this;
      }
      /** @internal */
      build(table) {
        return new UniqueConstraint(table, this.columns, this.nullsNotDistinctConfig, this.name);
      }
    };
    UniqueOnConstraintBuilder = class {
      static {
        __name(this, "UniqueOnConstraintBuilder");
      }
      static [entityKind] = "PgUniqueOnConstraintBuilder";
      /** @internal */
      name;
      constructor(name) {
        this.name = name;
      }
      on(...columns) {
        return new UniqueConstraintBuilder(columns, this.name);
      }
    };
    UniqueConstraint = class {
      static {
        __name(this, "UniqueConstraint");
      }
      constructor(table, columns, nullsNotDistinct, name) {
        this.table = table;
        this.columns = columns;
        this.name = name ?? uniqueKeyName(this.table, this.columns.map((column) => column.name));
        this.nullsNotDistinct = nullsNotDistinct;
      }
      static [entityKind] = "PgUniqueConstraint";
      columns;
      name;
      nullsNotDistinct = false;
      getName() {
        return this.name;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils/array.js
function parsePgArrayValue(arrayString, startFrom, inQuotes) {
  for (let i = startFrom; i < arrayString.length; i++) {
    const char2 = arrayString[i];
    if (char2 === "\\") {
      i++;
      continue;
    }
    if (char2 === '"') {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i + 1];
    }
    if (inQuotes) {
      continue;
    }
    if (char2 === "," || char2 === "}") {
      return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i];
    }
  }
  return [arrayString.slice(startFrom).replace(/\\/g, ""), arrayString.length];
}
function parsePgNestedArray(arrayString, startFrom = 0) {
  const result = [];
  let i = startFrom;
  let lastCharIsComma = false;
  while (i < arrayString.length) {
    const char2 = arrayString[i];
    if (char2 === ",") {
      if (lastCharIsComma || i === startFrom) {
        result.push("");
      }
      lastCharIsComma = true;
      i++;
      continue;
    }
    lastCharIsComma = false;
    if (char2 === "\\") {
      i += 2;
      continue;
    }
    if (char2 === '"') {
      const [value2, startFrom2] = parsePgArrayValue(arrayString, i + 1, true);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    if (char2 === "}") {
      return [result, i + 1];
    }
    if (char2 === "{") {
      const [value2, startFrom2] = parsePgNestedArray(arrayString, i + 1);
      result.push(value2);
      i = startFrom2;
      continue;
    }
    const [value, newStartFrom] = parsePgArrayValue(arrayString, i, false);
    result.push(value);
    i = newStartFrom;
  }
  return [result, i];
}
function parsePgArray(arrayString) {
  const [result] = parsePgNestedArray(arrayString, 1);
  return result;
}
function makePgArray(array) {
  return `{${array.map((item) => {
    if (Array.isArray(item)) {
      return makePgArray(item);
    }
    if (typeof item === "string") {
      return `"${item.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
    }
    return `${item}`;
  }).join(",")}}`;
}
var init_array = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils/array.js"() {
    init_functionsRoutes_0_17677553668797852();
    __name(parsePgArrayValue, "parsePgArrayValue");
    __name(parsePgNestedArray, "parsePgNestedArray");
    __name(parsePgArray, "parsePgArray");
    __name(makePgArray, "makePgArray");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/common.js
var PgColumnBuilder, PgColumn, ExtraConfigColumn, IndexedColumn, PgArrayBuilder, PgArray;
var init_common = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/common.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_column_builder();
    init_column();
    init_entity();
    init_foreign_keys();
    init_tracing_utils();
    init_unique_constraint();
    init_array();
    PgColumnBuilder = class extends ColumnBuilder {
      static {
        __name(this, "PgColumnBuilder");
      }
      foreignKeyConfigs = [];
      static [entityKind] = "PgColumnBuilder";
      array(size) {
        return new PgArrayBuilder(this.config.name, this, size);
      }
      references(ref, actions = {}) {
        this.foreignKeyConfigs.push({ ref, actions });
        return this;
      }
      unique(name, config) {
        this.config.isUnique = true;
        this.config.uniqueName = name;
        this.config.uniqueType = config?.nulls;
        return this;
      }
      generatedAlwaysAs(as) {
        this.config.generated = {
          as,
          type: "always",
          mode: "stored"
        };
        return this;
      }
      /** @internal */
      buildForeignKeys(column, table) {
        return this.foreignKeyConfigs.map(({ ref, actions }) => {
          return iife(
            (ref2, actions2) => {
              const builder = new ForeignKeyBuilder(() => {
                const foreignColumn = ref2();
                return { columns: [column], foreignColumns: [foreignColumn] };
              });
              if (actions2.onUpdate) {
                builder.onUpdate(actions2.onUpdate);
              }
              if (actions2.onDelete) {
                builder.onDelete(actions2.onDelete);
              }
              return builder.build(table);
            },
            ref,
            actions
          );
        });
      }
      /** @internal */
      buildExtraConfigColumn(table) {
        return new ExtraConfigColumn(table, this.config);
      }
    };
    PgColumn = class extends Column {
      static {
        __name(this, "PgColumn");
      }
      constructor(table, config) {
        if (!config.uniqueName) {
          config.uniqueName = uniqueKeyName(table, [config.name]);
        }
        super(table, config);
        this.table = table;
      }
      static [entityKind] = "PgColumn";
    };
    ExtraConfigColumn = class extends PgColumn {
      static {
        __name(this, "ExtraConfigColumn");
      }
      static [entityKind] = "ExtraConfigColumn";
      getSQLType() {
        return this.getSQLType();
      }
      indexConfig = {
        order: this.config.order ?? "asc",
        nulls: this.config.nulls ?? "last",
        opClass: this.config.opClass
      };
      defaultConfig = {
        order: "asc",
        nulls: "last",
        opClass: void 0
      };
      asc() {
        this.indexConfig.order = "asc";
        return this;
      }
      desc() {
        this.indexConfig.order = "desc";
        return this;
      }
      nullsFirst() {
        this.indexConfig.nulls = "first";
        return this;
      }
      nullsLast() {
        this.indexConfig.nulls = "last";
        return this;
      }
      /**
       * ### PostgreSQL documentation quote
       *
       * > An operator class with optional parameters can be specified for each column of an index.
       * The operator class identifies the operators to be used by the index for that column.
       * For example, a B-tree index on four-byte integers would use the int4_ops class;
       * this operator class includes comparison functions for four-byte integers.
       * In practice the default operator class for the column's data type is usually sufficient.
       * The main point of having operator classes is that for some data types, there could be more than one meaningful ordering.
       * For example, we might want to sort a complex-number data type either by absolute value or by real part.
       * We could do this by defining two operator classes for the data type and then selecting the proper class when creating an index.
       * More information about operator classes check:
       *
       * ### Useful links
       * https://www.postgresql.org/docs/current/sql-createindex.html
       *
       * https://www.postgresql.org/docs/current/indexes-opclass.html
       *
       * https://www.postgresql.org/docs/current/xindex.html
       *
       * ### Additional types
       * If you have the `pg_vector` extension installed in your database, you can use the
       * `vector_l2_ops`, `vector_ip_ops`, `vector_cosine_ops`, `vector_l1_ops`, `bit_hamming_ops`, `bit_jaccard_ops`, `halfvec_l2_ops`, `sparsevec_l2_ops` options, which are predefined types.
       *
       * **You can always specify any string you want in the operator class, in case Drizzle doesn't have it natively in its types**
       *
       * @param opClass
       * @returns
       */
      op(opClass) {
        this.indexConfig.opClass = opClass;
        return this;
      }
    };
    IndexedColumn = class {
      static {
        __name(this, "IndexedColumn");
      }
      static [entityKind] = "IndexedColumn";
      constructor(name, keyAsName, type, indexConfig) {
        this.name = name;
        this.keyAsName = keyAsName;
        this.type = type;
        this.indexConfig = indexConfig;
      }
      name;
      keyAsName;
      type;
      indexConfig;
    };
    PgArrayBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgArrayBuilder");
      }
      static [entityKind] = "PgArrayBuilder";
      constructor(name, baseBuilder, size) {
        super(name, "array", "PgArray");
        this.config.baseBuilder = baseBuilder;
        this.config.size = size;
      }
      /** @internal */
      build(table) {
        const baseColumn = this.config.baseBuilder.build(table);
        return new PgArray(
          table,
          this.config,
          baseColumn
        );
      }
    };
    PgArray = class _PgArray extends PgColumn {
      static {
        __name(this, "PgArray");
      }
      constructor(table, config, baseColumn, range) {
        super(table, config);
        this.baseColumn = baseColumn;
        this.range = range;
        this.size = config.size;
      }
      size;
      static [entityKind] = "PgArray";
      getSQLType() {
        return `${this.baseColumn.getSQLType()}[${typeof this.size === "number" ? this.size : ""}]`;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          value = parsePgArray(value);
        }
        return value.map((v2) => this.baseColumn.mapFromDriverValue(v2));
      }
      mapToDriverValue(value, isNestedArray = false) {
        const a2 = value.map(
          (v2) => v2 === null ? null : is(this.baseColumn, _PgArray) ? this.baseColumn.mapToDriverValue(v2, true) : this.baseColumn.mapToDriverValue(v2)
        );
        if (isNestedArray)
          return a2;
        return makePgArray(a2);
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/enum.js
function isPgEnum(obj) {
  return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
}
function pgEnumWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: values,
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
function pgEnumObjectWithSchema(enumName, values, schema) {
  const enumInstance = Object.assign(
    (name) => new PgEnumObjectColumnBuilder(name ?? "", enumInstance),
    {
      enumName,
      enumValues: Object.values(values),
      schema,
      [isPgEnumSym]: true
    }
  );
  return enumInstance;
}
var PgEnumObjectColumnBuilder, PgEnumObjectColumn, isPgEnumSym, PgEnumColumnBuilder, PgEnumColumn;
var init_enum = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/enum.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgEnumObjectColumnBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgEnumObjectColumnBuilder");
      }
      static [entityKind] = "PgEnumObjectColumnBuilder";
      constructor(name, enumInstance) {
        super(name, "string", "PgEnumObjectColumn");
        this.config.enum = enumInstance;
      }
      /** @internal */
      build(table) {
        return new PgEnumObjectColumn(
          table,
          this.config
        );
      }
    };
    PgEnumObjectColumn = class extends PgColumn {
      static {
        __name(this, "PgEnumObjectColumn");
      }
      static [entityKind] = "PgEnumObjectColumn";
      enum;
      enumValues = this.config.enum.enumValues;
      constructor(table, config) {
        super(table, config);
        this.enum = config.enum;
      }
      getSQLType() {
        return this.enum.enumName;
      }
    };
    isPgEnumSym = /* @__PURE__ */ Symbol.for("drizzle:isPgEnum");
    __name(isPgEnum, "isPgEnum");
    PgEnumColumnBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgEnumColumnBuilder");
      }
      static [entityKind] = "PgEnumColumnBuilder";
      constructor(name, enumInstance) {
        super(name, "string", "PgEnumColumn");
        this.config.enum = enumInstance;
      }
      /** @internal */
      build(table) {
        return new PgEnumColumn(
          table,
          this.config
        );
      }
    };
    PgEnumColumn = class extends PgColumn {
      static {
        __name(this, "PgEnumColumn");
      }
      static [entityKind] = "PgEnumColumn";
      enum = this.config.enum;
      enumValues = this.config.enum.enumValues;
      constructor(table, config) {
        super(table, config);
        this.enum = config.enum;
      }
      getSQLType() {
        return this.enum.enumName;
      }
    };
    __name(pgEnumWithSchema, "pgEnumWithSchema");
    __name(pgEnumObjectWithSchema, "pgEnumObjectWithSchema");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/subquery.js
var Subquery, WithSubquery;
var init_subquery = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/subquery.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    Subquery = class {
      static {
        __name(this, "Subquery");
      }
      static [entityKind] = "Subquery";
      constructor(sql4, selection, alias, isWith = false) {
        this._ = {
          brand: "Subquery",
          sql: sql4,
          selectedFields: selection,
          alias,
          isWith
        };
      }
      // getSQL(): SQL<unknown> {
      // 	return new SQL([this]);
      // }
    };
    WithSubquery = class extends Subquery {
      static {
        __name(this, "WithSubquery");
      }
      static [entityKind] = "WithSubquery";
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/version.js
var version;
var init_version = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/version.js"() {
    init_functionsRoutes_0_17677553668797852();
    version = "0.43.1";
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/tracing.js
var otel, rawTracer, tracer;
var init_tracing = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/tracing.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_tracing_utils();
    init_version();
    tracer = {
      startActiveSpan(name, fn) {
        if (!otel) {
          return fn();
        }
        if (!rawTracer) {
          rawTracer = otel.trace.getTracer("drizzle-orm", version);
        }
        return iife(
          (otel2, rawTracer2) => rawTracer2.startActiveSpan(
            name,
            (span) => {
              try {
                return fn(span);
              } catch (e) {
                span.setStatus({
                  code: otel2.SpanStatusCode.ERROR,
                  message: e instanceof Error ? e.message : "Unknown error"
                  // eslint-disable-line no-instanceof/no-instanceof
                });
                throw e;
              } finally {
                span.end();
              }
            }
          ),
          otel,
          rawTracer
        );
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/view-common.js
var ViewBaseConfig;
var init_view_common = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/view-common.js"() {
    init_functionsRoutes_0_17677553668797852();
    ViewBaseConfig = /* @__PURE__ */ Symbol.for("drizzle:ViewBaseConfig");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/table.js
function getTableName(table) {
  return table[TableName];
}
function getTableUniqueName(table) {
  return `${table[Schema] ?? "public"}.${table[TableName]}`;
}
var Schema, Columns, ExtraConfigColumns, OriginalName, BaseName, IsAlias, ExtraConfigBuilder, IsDrizzleTable, Table;
var init_table = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/table.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table_utils();
    Schema = /* @__PURE__ */ Symbol.for("drizzle:Schema");
    Columns = /* @__PURE__ */ Symbol.for("drizzle:Columns");
    ExtraConfigColumns = /* @__PURE__ */ Symbol.for("drizzle:ExtraConfigColumns");
    OriginalName = /* @__PURE__ */ Symbol.for("drizzle:OriginalName");
    BaseName = /* @__PURE__ */ Symbol.for("drizzle:BaseName");
    IsAlias = /* @__PURE__ */ Symbol.for("drizzle:IsAlias");
    ExtraConfigBuilder = /* @__PURE__ */ Symbol.for("drizzle:ExtraConfigBuilder");
    IsDrizzleTable = /* @__PURE__ */ Symbol.for("drizzle:IsDrizzleTable");
    Table = class {
      static {
        __name(this, "Table");
      }
      static [entityKind] = "Table";
      /** @internal */
      static Symbol = {
        Name: TableName,
        Schema,
        OriginalName,
        Columns,
        ExtraConfigColumns,
        BaseName,
        IsAlias,
        ExtraConfigBuilder
      };
      /**
       * @internal
       * Can be changed if the table is aliased.
       */
      [TableName];
      /**
       * @internal
       * Used to store the original name of the table, before any aliasing.
       */
      [OriginalName];
      /** @internal */
      [Schema];
      /** @internal */
      [Columns];
      /** @internal */
      [ExtraConfigColumns];
      /**
       *  @internal
       * Used to store the table name before the transformation via the `tableCreator` functions.
       */
      [BaseName];
      /** @internal */
      [IsAlias] = false;
      /** @internal */
      [IsDrizzleTable] = true;
      /** @internal */
      [ExtraConfigBuilder] = void 0;
      constructor(name, schema, baseName) {
        this[TableName] = this[OriginalName] = name;
        this[Schema] = schema;
        this[BaseName] = baseName;
      }
    };
    __name(getTableName, "getTableName");
    __name(getTableUniqueName, "getTableUniqueName");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/sql.js
function isSQLWrapper(value) {
  return value !== null && value !== void 0 && typeof value.getSQL === "function";
}
function mergeQueries(queries) {
  const result = { sql: "", params: [] };
  for (const query of queries) {
    result.sql += query.sql;
    result.params.push(...query.params);
    if (query.typings?.length) {
      if (!result.typings) {
        result.typings = [];
      }
      result.typings.push(...query.typings);
    }
  }
  return result;
}
function isDriverValueEncoder(value) {
  return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
}
function sql(strings, ...params) {
  const queryChunks = [];
  if (params.length > 0 || strings.length > 0 && strings[0] !== "") {
    queryChunks.push(new StringChunk(strings[0]));
  }
  for (const [paramIndex, param2] of params.entries()) {
    queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
  }
  return new SQL(queryChunks);
}
function fillPlaceholders(params, values) {
  return params.map((p2) => {
    if (is(p2, Placeholder)) {
      if (!(p2.name in values)) {
        throw new Error(`No value for placeholder "${p2.name}" was provided`);
      }
      return values[p2.name];
    }
    if (is(p2, Param) && is(p2.value, Placeholder)) {
      if (!(p2.value.name in values)) {
        throw new Error(`No value for placeholder "${p2.value.name}" was provided`);
      }
      return p2.encoder.mapToDriverValue(values[p2.value.name]);
    }
    return p2;
  });
}
var FakePrimitiveParam, StringChunk, SQL, Name, noopDecoder, noopEncoder, noopMapper, Param, Placeholder, IsDrizzleView, View;
var init_sql = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/sql.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_enum();
    init_subquery();
    init_tracing();
    init_view_common();
    init_column();
    init_table();
    FakePrimitiveParam = class {
      static {
        __name(this, "FakePrimitiveParam");
      }
      static [entityKind] = "FakePrimitiveParam";
    };
    __name(isSQLWrapper, "isSQLWrapper");
    __name(mergeQueries, "mergeQueries");
    StringChunk = class {
      static {
        __name(this, "StringChunk");
      }
      static [entityKind] = "StringChunk";
      value;
      constructor(value) {
        this.value = Array.isArray(value) ? value : [value];
      }
      getSQL() {
        return new SQL([this]);
      }
    };
    SQL = class _SQL {
      static {
        __name(this, "SQL");
      }
      constructor(queryChunks) {
        this.queryChunks = queryChunks;
      }
      static [entityKind] = "SQL";
      /** @internal */
      decoder = noopDecoder;
      shouldInlineParams = false;
      append(query) {
        this.queryChunks.push(...query.queryChunks);
        return this;
      }
      toQuery(config) {
        return tracer.startActiveSpan("drizzle.buildSQL", (span) => {
          const query = this.buildQueryFromSourceParams(this.queryChunks, config);
          span?.setAttributes({
            "drizzle.query.text": query.sql,
            "drizzle.query.params": JSON.stringify(query.params)
          });
          return query;
        });
      }
      buildQueryFromSourceParams(chunks, _config) {
        const config = Object.assign({}, _config, {
          inlineParams: _config.inlineParams || this.shouldInlineParams,
          paramStartIndex: _config.paramStartIndex || { value: 0 }
        });
        const {
          casing,
          escapeName,
          escapeParam,
          prepareTyping,
          inlineParams,
          paramStartIndex
        } = config;
        return mergeQueries(chunks.map((chunk) => {
          if (is(chunk, StringChunk)) {
            return { sql: chunk.value.join(""), params: [] };
          }
          if (is(chunk, Name)) {
            return { sql: escapeName(chunk.value), params: [] };
          }
          if (chunk === void 0) {
            return { sql: "", params: [] };
          }
          if (Array.isArray(chunk)) {
            const result = [new StringChunk("(")];
            for (const [i, p2] of chunk.entries()) {
              result.push(p2);
              if (i < chunk.length - 1) {
                result.push(new StringChunk(", "));
              }
            }
            result.push(new StringChunk(")"));
            return this.buildQueryFromSourceParams(result, config);
          }
          if (is(chunk, _SQL)) {
            return this.buildQueryFromSourceParams(chunk.queryChunks, {
              ...config,
              inlineParams: inlineParams || chunk.shouldInlineParams
            });
          }
          if (is(chunk, Table)) {
            const schemaName = chunk[Table.Symbol.Schema];
            const tableName = chunk[Table.Symbol.Name];
            return {
              sql: schemaName === void 0 || chunk[IsAlias] ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
              params: []
            };
          }
          if (is(chunk, Column)) {
            const columnName = casing.getColumnCasing(chunk);
            if (_config.invokeSource === "indexes") {
              return { sql: escapeName(columnName), params: [] };
            }
            const schemaName = chunk.table[Table.Symbol.Schema];
            return {
              sql: chunk.table[IsAlias] || schemaName === void 0 ? escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName) : escapeName(schemaName) + "." + escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName),
              params: []
            };
          }
          if (is(chunk, View)) {
            const schemaName = chunk[ViewBaseConfig].schema;
            const viewName = chunk[ViewBaseConfig].name;
            return {
              sql: schemaName === void 0 || chunk[ViewBaseConfig].isAlias ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
              params: []
            };
          }
          if (is(chunk, Param)) {
            if (is(chunk.value, Placeholder)) {
              return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
            }
            const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
            if (is(mappedValue, _SQL)) {
              return this.buildQueryFromSourceParams([mappedValue], config);
            }
            if (inlineParams) {
              return { sql: this.mapInlineParam(mappedValue, config), params: [] };
            }
            let typings = ["none"];
            if (prepareTyping) {
              typings = [prepareTyping(chunk.encoder)];
            }
            return { sql: escapeParam(paramStartIndex.value++, mappedValue), params: [mappedValue], typings };
          }
          if (is(chunk, Placeholder)) {
            return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
          }
          if (is(chunk, _SQL.Aliased) && chunk.fieldAlias !== void 0) {
            return { sql: escapeName(chunk.fieldAlias), params: [] };
          }
          if (is(chunk, Subquery)) {
            if (chunk._.isWith) {
              return { sql: escapeName(chunk._.alias), params: [] };
            }
            return this.buildQueryFromSourceParams([
              new StringChunk("("),
              chunk._.sql,
              new StringChunk(") "),
              new Name(chunk._.alias)
            ], config);
          }
          if (isPgEnum(chunk)) {
            if (chunk.schema) {
              return { sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName), params: [] };
            }
            return { sql: escapeName(chunk.enumName), params: [] };
          }
          if (isSQLWrapper(chunk)) {
            if (chunk.shouldOmitSQLParens?.()) {
              return this.buildQueryFromSourceParams([chunk.getSQL()], config);
            }
            return this.buildQueryFromSourceParams([
              new StringChunk("("),
              chunk.getSQL(),
              new StringChunk(")")
            ], config);
          }
          if (inlineParams) {
            return { sql: this.mapInlineParam(chunk, config), params: [] };
          }
          return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
        }));
      }
      mapInlineParam(chunk, { escapeString: escapeString2 }) {
        if (chunk === null) {
          return "null";
        }
        if (typeof chunk === "number" || typeof chunk === "boolean") {
          return chunk.toString();
        }
        if (typeof chunk === "string") {
          return escapeString2(chunk);
        }
        if (typeof chunk === "object") {
          const mappedValueAsString = chunk.toString();
          if (mappedValueAsString === "[object Object]") {
            return escapeString2(JSON.stringify(chunk));
          }
          return escapeString2(mappedValueAsString);
        }
        throw new Error("Unexpected param value: " + chunk);
      }
      getSQL() {
        return this;
      }
      as(alias) {
        if (alias === void 0) {
          return this;
        }
        return new _SQL.Aliased(this, alias);
      }
      mapWith(decoder) {
        this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
        return this;
      }
      inlineParams() {
        this.shouldInlineParams = true;
        return this;
      }
      /**
       * This method is used to conditionally include a part of the query.
       *
       * @param condition - Condition to check
       * @returns itself if the condition is `true`, otherwise `undefined`
       */
      if(condition) {
        return condition ? this : void 0;
      }
    };
    Name = class {
      static {
        __name(this, "Name");
      }
      constructor(value) {
        this.value = value;
      }
      static [entityKind] = "Name";
      brand;
      getSQL() {
        return new SQL([this]);
      }
    };
    __name(isDriverValueEncoder, "isDriverValueEncoder");
    noopDecoder = {
      mapFromDriverValue: /* @__PURE__ */ __name((value) => value, "mapFromDriverValue")
    };
    noopEncoder = {
      mapToDriverValue: /* @__PURE__ */ __name((value) => value, "mapToDriverValue")
    };
    noopMapper = {
      ...noopDecoder,
      ...noopEncoder
    };
    Param = class {
      static {
        __name(this, "Param");
      }
      /**
       * @param value - Parameter value
       * @param encoder - Encoder to convert the value to a driver parameter
       */
      constructor(value, encoder = noopEncoder) {
        this.value = value;
        this.encoder = encoder;
      }
      static [entityKind] = "Param";
      brand;
      getSQL() {
        return new SQL([this]);
      }
    };
    __name(sql, "sql");
    ((sql22) => {
      function empty() {
        return new SQL([]);
      }
      __name(empty, "empty");
      sql22.empty = empty;
      function fromList(list) {
        return new SQL(list);
      }
      __name(fromList, "fromList");
      sql22.fromList = fromList;
      function raw(str) {
        return new SQL([new StringChunk(str)]);
      }
      __name(raw, "raw");
      sql22.raw = raw;
      function join(chunks, separator) {
        const result = [];
        for (const [i, chunk] of chunks.entries()) {
          if (i > 0 && separator !== void 0) {
            result.push(separator);
          }
          result.push(chunk);
        }
        return new SQL(result);
      }
      __name(join, "join");
      sql22.join = join;
      function identifier(value) {
        return new Name(value);
      }
      __name(identifier, "identifier");
      sql22.identifier = identifier;
      function placeholder2(name2) {
        return new Placeholder(name2);
      }
      __name(placeholder2, "placeholder2");
      sql22.placeholder = placeholder2;
      function param2(value, encoder) {
        return new Param(value, encoder);
      }
      __name(param2, "param2");
      sql22.param = param2;
    })(sql || (sql = {}));
    ((SQL2) => {
      class Aliased {
        static {
          __name(this, "Aliased");
        }
        constructor(sql22, fieldAlias) {
          this.sql = sql22;
          this.fieldAlias = fieldAlias;
        }
        static [entityKind] = "SQL.Aliased";
        /** @internal */
        isSelectionField = false;
        getSQL() {
          return this.sql;
        }
        /** @internal */
        clone() {
          return new Aliased(this.sql, this.fieldAlias);
        }
      }
      SQL2.Aliased = Aliased;
    })(SQL || (SQL = {}));
    Placeholder = class {
      static {
        __name(this, "Placeholder");
      }
      constructor(name2) {
        this.name = name2;
      }
      static [entityKind] = "Placeholder";
      getSQL() {
        return new SQL([this]);
      }
    };
    __name(fillPlaceholders, "fillPlaceholders");
    IsDrizzleView = /* @__PURE__ */ Symbol.for("drizzle:IsDrizzleView");
    View = class {
      static {
        __name(this, "View");
      }
      static [entityKind] = "View";
      /** @internal */
      [ViewBaseConfig];
      /** @internal */
      [IsDrizzleView] = true;
      constructor({ name: name2, schema, selectedFields, query }) {
        this[ViewBaseConfig] = {
          name: name2,
          originalName: name2,
          schema,
          selectedFields,
          query,
          isExisting: !query,
          isAlias: false
        };
      }
      getSQL() {
        return new SQL([this]);
      }
    };
    Column.prototype.getSQL = function() {
      return new SQL([this]);
    };
    Table.prototype.getSQL = function() {
      return new SQL([this]);
    };
    Subquery.prototype.getSQL = function() {
      return new SQL([this]);
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/alias.js
function aliasedTable(table, tableAlias) {
  return new Proxy(table, new TableAliasProxyHandler(tableAlias, false));
}
function aliasedTableColumn(column, tableAlias) {
  return new Proxy(
    column,
    new ColumnAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false)))
  );
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
  return new SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
  return sql.join(query.queryChunks.map((c) => {
    if (is(c, Column)) {
      return aliasedTableColumn(c, alias);
    }
    if (is(c, SQL)) {
      return mapColumnsInSQLToAlias(c, alias);
    }
    if (is(c, SQL.Aliased)) {
      return mapColumnsInAliasedSQLToAlias(c, alias);
    }
    return c;
  }));
}
var ColumnAliasProxyHandler, TableAliasProxyHandler, RelationTableAliasProxyHandler;
var init_alias = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/alias.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_column();
    init_entity();
    init_sql();
    init_table();
    init_view_common();
    ColumnAliasProxyHandler = class {
      static {
        __name(this, "ColumnAliasProxyHandler");
      }
      constructor(table) {
        this.table = table;
      }
      static [entityKind] = "ColumnAliasProxyHandler";
      get(columnObj, prop) {
        if (prop === "table") {
          return this.table;
        }
        return columnObj[prop];
      }
    };
    TableAliasProxyHandler = class {
      static {
        __name(this, "TableAliasProxyHandler");
      }
      constructor(alias, replaceOriginalName) {
        this.alias = alias;
        this.replaceOriginalName = replaceOriginalName;
      }
      static [entityKind] = "TableAliasProxyHandler";
      get(target, prop) {
        if (prop === Table.Symbol.IsAlias) {
          return true;
        }
        if (prop === Table.Symbol.Name) {
          return this.alias;
        }
        if (this.replaceOriginalName && prop === Table.Symbol.OriginalName) {
          return this.alias;
        }
        if (prop === ViewBaseConfig) {
          return {
            ...target[ViewBaseConfig],
            name: this.alias,
            isAlias: true
          };
        }
        if (prop === Table.Symbol.Columns) {
          const columns = target[Table.Symbol.Columns];
          if (!columns) {
            return columns;
          }
          const proxiedColumns = {};
          Object.keys(columns).map((key) => {
            proxiedColumns[key] = new Proxy(
              columns[key],
              new ColumnAliasProxyHandler(new Proxy(target, this))
            );
          });
          return proxiedColumns;
        }
        const value = target[prop];
        if (is(value, Column)) {
          return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
        }
        return value;
      }
    };
    RelationTableAliasProxyHandler = class {
      static {
        __name(this, "RelationTableAliasProxyHandler");
      }
      constructor(alias) {
        this.alias = alias;
      }
      static [entityKind] = "RelationTableAliasProxyHandler";
      get(target, prop) {
        if (prop === "sourceTable") {
          return aliasedTable(target.sourceTable, this.alias);
        }
        return target[prop];
      }
    };
    __name(aliasedTable, "aliasedTable");
    __name(aliasedTableColumn, "aliasedTableColumn");
    __name(mapColumnsInAliasedSQLToAlias, "mapColumnsInAliasedSQLToAlias");
    __name(mapColumnsInSQLToAlias, "mapColumnsInSQLToAlias");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/selection-proxy.js
var SelectionProxyHandler;
var init_selection_proxy = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/selection-proxy.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_alias();
    init_column();
    init_entity();
    init_sql();
    init_subquery();
    init_view_common();
    SelectionProxyHandler = class _SelectionProxyHandler {
      static {
        __name(this, "SelectionProxyHandler");
      }
      static [entityKind] = "SelectionProxyHandler";
      config;
      constructor(config) {
        this.config = { ...config };
      }
      get(subquery, prop) {
        if (prop === "_") {
          return {
            ...subquery["_"],
            selectedFields: new Proxy(
              subquery._.selectedFields,
              this
            )
          };
        }
        if (prop === ViewBaseConfig) {
          return {
            ...subquery[ViewBaseConfig],
            selectedFields: new Proxy(
              subquery[ViewBaseConfig].selectedFields,
              this
            )
          };
        }
        if (typeof prop === "symbol") {
          return subquery[prop];
        }
        const columns = is(subquery, Subquery) ? subquery._.selectedFields : is(subquery, View) ? subquery[ViewBaseConfig].selectedFields : subquery;
        const value = columns[prop];
        if (is(value, SQL.Aliased)) {
          if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) {
            return value.sql;
          }
          const newValue = value.clone();
          newValue.isSelectionField = true;
          return newValue;
        }
        if (is(value, SQL)) {
          if (this.config.sqlBehavior === "sql") {
            return value;
          }
          throw new Error(
            `You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`
          );
        }
        if (is(value, Column)) {
          if (this.config.alias) {
            return new Proxy(
              value,
              new ColumnAliasProxyHandler(
                new Proxy(
                  value.table,
                  new TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false)
                )
              )
            );
          }
          return value;
        }
        if (typeof value !== "object" || value === null) {
          return value;
        }
        return new Proxy(value, new _SelectionProxyHandler(this.config));
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/utils.js
function mapResultRow(columns, row, joinsNotNullableMap) {
  const nullifyMap = {};
  const result = columns.reduce(
    (result2, { path, field }, columnIndex) => {
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      let node = result2;
      for (const [pathChunkIndex, pathChunk] of path.entries()) {
        if (pathChunkIndex < path.length - 1) {
          if (!(pathChunk in node)) {
            node[pathChunk] = {};
          }
          node = node[pathChunk];
        } else {
          const rawValue = row[columnIndex];
          const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
          if (joinsNotNullableMap && is(field, Column) && path.length === 2) {
            const objectName = path[0];
            if (!(objectName in nullifyMap)) {
              nullifyMap[objectName] = value === null ? getTableName(field.table) : false;
            } else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== getTableName(field.table)) {
              nullifyMap[objectName] = false;
            }
          }
        }
      }
      return result2;
    },
    {}
  );
  if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
    for (const [objectName, tableName] of Object.entries(nullifyMap)) {
      if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) {
        result[objectName] = null;
      }
    }
  }
  return result;
}
function orderSelectedFields(fields, pathPrefix) {
  return Object.entries(fields).reduce((result, [name, field]) => {
    if (typeof name !== "string") {
      return result;
    }
    const newPath = pathPrefix ? [...pathPrefix, name] : [name];
    if (is(field, Column) || is(field, SQL) || is(field, SQL.Aliased)) {
      result.push({ path: newPath, field });
    } else if (is(field, Table)) {
      result.push(...orderSelectedFields(field[Table.Symbol.Columns], newPath));
    } else {
      result.push(...orderSelectedFields(field, newPath));
    }
    return result;
  }, []);
}
function haveSameKeys(left, right) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) {
    return false;
  }
  for (const [index, key] of leftKeys.entries()) {
    if (key !== rightKeys[index]) {
      return false;
    }
  }
  return true;
}
function mapUpdateSet(table, values) {
  const entries = Object.entries(values).filter(([, value]) => value !== void 0).map(([key, value]) => {
    if (is(value, SQL) || is(value, Column)) {
      return [key, value];
    } else {
      return [key, new Param(value, table[Table.Symbol.Columns][key])];
    }
  });
  if (entries.length === 0) {
    throw new Error("No values to set");
  }
  return Object.fromEntries(entries);
}
function applyMixins(baseClass, extendedClasses) {
  for (const extendedClass of extendedClasses) {
    for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
      if (name === "constructor")
        continue;
      Object.defineProperty(
        baseClass.prototype,
        name,
        Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || /* @__PURE__ */ Object.create(null)
      );
    }
  }
}
function getTableColumns(table) {
  return table[Table.Symbol.Columns];
}
function getTableLikeName(table) {
  return is(table, Subquery) ? table._.alias : is(table, View) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : table[Table.Symbol.IsAlias] ? table[Table.Symbol.Name] : table[Table.Symbol.BaseName];
}
function getColumnNameAndConfig(a2, b) {
  return {
    name: typeof a2 === "string" && a2.length > 0 ? a2 : "",
    config: typeof a2 === "object" ? a2 : b
  };
}
function isConfig(data) {
  if (typeof data !== "object" || data === null)
    return false;
  if (data.constructor.name !== "Object")
    return false;
  if ("logger" in data) {
    const type = typeof data["logger"];
    if (type !== "boolean" && (type !== "object" || typeof data["logger"]["logQuery"] !== "function") && type !== "undefined")
      return false;
    return true;
  }
  if ("schema" in data) {
    const type = typeof data["schema"];
    if (type !== "object" && type !== "undefined")
      return false;
    return true;
  }
  if ("casing" in data) {
    const type = typeof data["casing"];
    if (type !== "string" && type !== "undefined")
      return false;
    return true;
  }
  if ("mode" in data) {
    if (data["mode"] !== "default" || data["mode"] !== "planetscale" || data["mode"] !== void 0)
      return false;
    return true;
  }
  if ("connection" in data) {
    const type = typeof data["connection"];
    if (type !== "string" && type !== "object" && type !== "undefined")
      return false;
    return true;
  }
  if ("client" in data) {
    const type = typeof data["client"];
    if (type !== "object" && type !== "function" && type !== "undefined")
      return false;
    return true;
  }
  if (Object.keys(data).length === 0)
    return true;
  return false;
}
var init_utils = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/utils.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_column();
    init_entity();
    init_sql();
    init_subquery();
    init_table();
    init_view_common();
    __name(mapResultRow, "mapResultRow");
    __name(orderSelectedFields, "orderSelectedFields");
    __name(haveSameKeys, "haveSameKeys");
    __name(mapUpdateSet, "mapUpdateSet");
    __name(applyMixins, "applyMixins");
    __name(getTableColumns, "getTableColumns");
    __name(getTableLikeName, "getTableLikeName");
    __name(getColumnNameAndConfig, "getColumnNameAndConfig");
    __name(isConfig, "isConfig");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/delete.js
var PgDeleteBase;
var init_delete = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/delete.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_table();
    init_tracing();
    init_utils();
    PgDeleteBase = class extends QueryPromise {
      static {
        __name(this, "PgDeleteBase");
      }
      constructor(table, session, dialect2, withList) {
        super();
        this.session = session;
        this.dialect = dialect2;
        this.config = { table, withList };
      }
      static [entityKind] = "PgDelete";
      config;
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will delete only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be deleted.
       *
       * ```ts
       * // Delete all cars with green color
       * await db.delete(cars).where(eq(cars.color, 'green'));
       * // or
       * await db.delete(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Delete all BMW cars with a green color
       * await db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Delete all cars with the green or blue color
       * await db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      returning(fields = this.config.table[Table.Symbol.Columns]) {
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildDeleteQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = /* @__PURE__ */ __name((placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      }, "execute");
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/casing.js
function toSnakeCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.reduce((acc, word, i) => {
    const formattedWord = i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`;
    return acc + formattedWord;
  }, "");
}
function noopCase(input) {
  return input;
}
var CasingCache;
var init_casing = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/casing.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table();
    __name(toSnakeCase, "toSnakeCase");
    __name(toCamelCase, "toCamelCase");
    __name(noopCase, "noopCase");
    CasingCache = class {
      static {
        __name(this, "CasingCache");
      }
      static [entityKind] = "CasingCache";
      /** @internal */
      cache = {};
      cachedTables = {};
      convert;
      constructor(casing) {
        this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
      }
      getColumnCasing(column) {
        if (!column.keyAsName)
          return column.name;
        const schema = column.table[Table.Symbol.Schema] ?? "public";
        const tableName = column.table[Table.Symbol.OriginalName];
        const key = `${schema}.${tableName}.${column.name}`;
        if (!this.cache[key]) {
          this.cacheTable(column.table);
        }
        return this.cache[key];
      }
      cacheTable(table) {
        const schema = table[Table.Symbol.Schema] ?? "public";
        const tableName = table[Table.Symbol.OriginalName];
        const tableKey = `${schema}.${tableName}`;
        if (!this.cachedTables[tableKey]) {
          for (const column of Object.values(table[Table.Symbol.Columns])) {
            const columnKey = `${tableKey}.${column.name}`;
            this.cache[columnKey] = this.convert(column.name);
          }
          this.cachedTables[tableKey] = true;
        }
      }
      clearCache() {
        this.cache = {};
        this.cachedTables = {};
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/errors.js
var DrizzleError, TransactionRollbackError;
var init_errors = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/errors.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    DrizzleError = class extends Error {
      static {
        __name(this, "DrizzleError");
      }
      static [entityKind] = "DrizzleError";
      constructor({ message, cause }) {
        super(message);
        this.name = "DrizzleError";
        this.cause = cause;
      }
    };
    TransactionRollbackError = class extends DrizzleError {
      static {
        __name(this, "TransactionRollbackError");
      }
      static [entityKind] = "TransactionRollbackError";
      constructor() {
        super({ message: "Rollback" });
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/int.common.js
var PgIntColumnBaseBuilder;
var init_int_common = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/int.common.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgIntColumnBaseBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgIntColumnBaseBuilder");
      }
      static [entityKind] = "PgIntColumnBaseBuilder";
      generatedAlwaysAsIdentity(sequence) {
        if (sequence) {
          const { name, ...options } = sequence;
          this.config.generatedIdentity = {
            type: "always",
            sequenceName: name,
            sequenceOptions: options
          };
        } else {
          this.config.generatedIdentity = {
            type: "always"
          };
        }
        this.config.hasDefault = true;
        this.config.notNull = true;
        return this;
      }
      generatedByDefaultAsIdentity(sequence) {
        if (sequence) {
          const { name, ...options } = sequence;
          this.config.generatedIdentity = {
            type: "byDefault",
            sequenceName: name,
            sequenceOptions: options
          };
        } else {
          this.config.generatedIdentity = {
            type: "byDefault"
          };
        }
        this.config.hasDefault = true;
        this.config.notNull = true;
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/bigint.js
function bigint(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (config.mode === "number") {
    return new PgBigInt53Builder(name);
  }
  return new PgBigInt64Builder(name);
}
var PgBigInt53Builder, PgBigInt53, PgBigInt64Builder, PgBigInt64;
var init_bigint = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/bigint.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    init_int_common();
    PgBigInt53Builder = class extends PgIntColumnBaseBuilder {
      static {
        __name(this, "PgBigInt53Builder");
      }
      static [entityKind] = "PgBigInt53Builder";
      constructor(name) {
        super(name, "number", "PgBigInt53");
      }
      /** @internal */
      build(table) {
        return new PgBigInt53(table, this.config);
      }
    };
    PgBigInt53 = class extends PgColumn {
      static {
        __name(this, "PgBigInt53");
      }
      static [entityKind] = "PgBigInt53";
      getSQLType() {
        return "bigint";
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") {
          return value;
        }
        return Number(value);
      }
    };
    PgBigInt64Builder = class extends PgIntColumnBaseBuilder {
      static {
        __name(this, "PgBigInt64Builder");
      }
      static [entityKind] = "PgBigInt64Builder";
      constructor(name) {
        super(name, "bigint", "PgBigInt64");
      }
      /** @internal */
      build(table) {
        return new PgBigInt64(
          table,
          this.config
        );
      }
    };
    PgBigInt64 = class extends PgColumn {
      static {
        __name(this, "PgBigInt64");
      }
      static [entityKind] = "PgBigInt64";
      getSQLType() {
        return "bigint";
      }
      // eslint-disable-next-line unicorn/prefer-native-coercion-functions
      mapFromDriverValue(value) {
        return BigInt(value);
      }
    };
    __name(bigint, "bigint");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/bigserial.js
function bigserial(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (config.mode === "number") {
    return new PgBigSerial53Builder(name);
  }
  return new PgBigSerial64Builder(name);
}
var PgBigSerial53Builder, PgBigSerial53, PgBigSerial64Builder, PgBigSerial64;
var init_bigserial = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/bigserial.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgBigSerial53Builder = class extends PgColumnBuilder {
      static {
        __name(this, "PgBigSerial53Builder");
      }
      static [entityKind] = "PgBigSerial53Builder";
      constructor(name) {
        super(name, "number", "PgBigSerial53");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgBigSerial53(
          table,
          this.config
        );
      }
    };
    PgBigSerial53 = class extends PgColumn {
      static {
        __name(this, "PgBigSerial53");
      }
      static [entityKind] = "PgBigSerial53";
      getSQLType() {
        return "bigserial";
      }
      mapFromDriverValue(value) {
        if (typeof value === "number") {
          return value;
        }
        return Number(value);
      }
    };
    PgBigSerial64Builder = class extends PgColumnBuilder {
      static {
        __name(this, "PgBigSerial64Builder");
      }
      static [entityKind] = "PgBigSerial64Builder";
      constructor(name) {
        super(name, "bigint", "PgBigSerial64");
        this.config.hasDefault = true;
      }
      /** @internal */
      build(table) {
        return new PgBigSerial64(
          table,
          this.config
        );
      }
    };
    PgBigSerial64 = class extends PgColumn {
      static {
        __name(this, "PgBigSerial64");
      }
      static [entityKind] = "PgBigSerial64";
      getSQLType() {
        return "bigserial";
      }
      // eslint-disable-next-line unicorn/prefer-native-coercion-functions
      mapFromDriverValue(value) {
        return BigInt(value);
      }
    };
    __name(bigserial, "bigserial");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/boolean.js
function boolean(name) {
  return new PgBooleanBuilder(name ?? "");
}
var PgBooleanBuilder, PgBoolean;
var init_boolean = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/boolean.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgBooleanBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgBooleanBuilder");
      }
      static [entityKind] = "PgBooleanBuilder";
      constructor(name) {
        super(name, "boolean", "PgBoolean");
      }
      /** @internal */
      build(table) {
        return new PgBoolean(table, this.config);
      }
    };
    PgBoolean = class extends PgColumn {
      static {
        __name(this, "PgBoolean");
      }
      static [entityKind] = "PgBoolean";
      getSQLType() {
        return "boolean";
      }
    };
    __name(boolean, "boolean");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/char.js
function char(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgCharBuilder(name, config);
}
var PgCharBuilder, PgChar;
var init_char = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/char.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgCharBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgCharBuilder");
      }
      static [entityKind] = "PgCharBuilder";
      constructor(name, config) {
        super(name, "string", "PgChar");
        this.config.length = config.length;
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgChar(
          table,
          this.config
        );
      }
    };
    PgChar = class extends PgColumn {
      static {
        __name(this, "PgChar");
      }
      static [entityKind] = "PgChar";
      length = this.config.length;
      enumValues = this.config.enumValues;
      getSQLType() {
        return this.length === void 0 ? `char` : `char(${this.length})`;
      }
    };
    __name(char, "char");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/cidr.js
function cidr(name) {
  return new PgCidrBuilder(name ?? "");
}
var PgCidrBuilder, PgCidr;
var init_cidr = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/cidr.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgCidrBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgCidrBuilder");
      }
      static [entityKind] = "PgCidrBuilder";
      constructor(name) {
        super(name, "string", "PgCidr");
      }
      /** @internal */
      build(table) {
        return new PgCidr(table, this.config);
      }
    };
    PgCidr = class extends PgColumn {
      static {
        __name(this, "PgCidr");
      }
      static [entityKind] = "PgCidr";
      getSQLType() {
        return "cidr";
      }
    };
    __name(cidr, "cidr");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/custom.js
function customType(customTypeParams) {
  return (a2, b) => {
    const { name, config } = getColumnNameAndConfig(a2, b);
    return new PgCustomColumnBuilder(name, config, customTypeParams);
  };
}
var PgCustomColumnBuilder, PgCustomColumn;
var init_custom = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/custom.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgCustomColumnBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgCustomColumnBuilder");
      }
      static [entityKind] = "PgCustomColumnBuilder";
      constructor(name, fieldConfig, customTypeParams) {
        super(name, "custom", "PgCustomColumn");
        this.config.fieldConfig = fieldConfig;
        this.config.customTypeParams = customTypeParams;
      }
      /** @internal */
      build(table) {
        return new PgCustomColumn(
          table,
          this.config
        );
      }
    };
    PgCustomColumn = class extends PgColumn {
      static {
        __name(this, "PgCustomColumn");
      }
      static [entityKind] = "PgCustomColumn";
      sqlName;
      mapTo;
      mapFrom;
      constructor(table, config) {
        super(table, config);
        this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
        this.mapTo = config.customTypeParams.toDriver;
        this.mapFrom = config.customTypeParams.fromDriver;
      }
      getSQLType() {
        return this.sqlName;
      }
      mapFromDriverValue(value) {
        return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
      }
      mapToDriverValue(value) {
        return typeof this.mapTo === "function" ? this.mapTo(value) : value;
      }
    };
    __name(customType, "customType");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/date.common.js
var PgDateColumnBaseBuilder;
var init_date_common = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/date.common.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_sql();
    init_common();
    PgDateColumnBaseBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgDateColumnBaseBuilder");
      }
      static [entityKind] = "PgDateColumnBaseBuilder";
      defaultNow() {
        return this.default(sql`now()`);
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/date.js
function date(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (config?.mode === "date") {
    return new PgDateBuilder(name);
  }
  return new PgDateStringBuilder(name);
}
var PgDateBuilder, PgDate, PgDateStringBuilder, PgDateString;
var init_date = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/date.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgDateBuilder = class extends PgDateColumnBaseBuilder {
      static {
        __name(this, "PgDateBuilder");
      }
      static [entityKind] = "PgDateBuilder";
      constructor(name) {
        super(name, "date", "PgDate");
      }
      /** @internal */
      build(table) {
        return new PgDate(table, this.config);
      }
    };
    PgDate = class extends PgColumn {
      static {
        __name(this, "PgDate");
      }
      static [entityKind] = "PgDate";
      getSQLType() {
        return "date";
      }
      mapFromDriverValue(value) {
        return new Date(value);
      }
      mapToDriverValue(value) {
        return value.toISOString();
      }
    };
    PgDateStringBuilder = class extends PgDateColumnBaseBuilder {
      static {
        __name(this, "PgDateStringBuilder");
      }
      static [entityKind] = "PgDateStringBuilder";
      constructor(name) {
        super(name, "string", "PgDateString");
      }
      /** @internal */
      build(table) {
        return new PgDateString(
          table,
          this.config
        );
      }
    };
    PgDateString = class extends PgColumn {
      static {
        __name(this, "PgDateString");
      }
      static [entityKind] = "PgDateString";
      getSQLType() {
        return "date";
      }
    };
    __name(date, "date");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/double-precision.js
function doublePrecision(name) {
  return new PgDoublePrecisionBuilder(name ?? "");
}
var PgDoublePrecisionBuilder, PgDoublePrecision;
var init_double_precision = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/double-precision.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgDoublePrecisionBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgDoublePrecisionBuilder");
      }
      static [entityKind] = "PgDoublePrecisionBuilder";
      constructor(name) {
        super(name, "number", "PgDoublePrecision");
      }
      /** @internal */
      build(table) {
        return new PgDoublePrecision(
          table,
          this.config
        );
      }
    };
    PgDoublePrecision = class extends PgColumn {
      static {
        __name(this, "PgDoublePrecision");
      }
      static [entityKind] = "PgDoublePrecision";
      getSQLType() {
        return "double precision";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number.parseFloat(value);
        }
        return value;
      }
    };
    __name(doublePrecision, "doublePrecision");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/inet.js
function inet(name) {
  return new PgInetBuilder(name ?? "");
}
var PgInetBuilder, PgInet;
var init_inet = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/inet.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgInetBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgInetBuilder");
      }
      static [entityKind] = "PgInetBuilder";
      constructor(name) {
        super(name, "string", "PgInet");
      }
      /** @internal */
      build(table) {
        return new PgInet(table, this.config);
      }
    };
    PgInet = class extends PgColumn {
      static {
        __name(this, "PgInet");
      }
      static [entityKind] = "PgInet";
      getSQLType() {
        return "inet";
      }
    };
    __name(inet, "inet");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/integer.js
function integer(name) {
  return new PgIntegerBuilder(name ?? "");
}
var PgIntegerBuilder, PgInteger;
var init_integer = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/integer.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    init_int_common();
    PgIntegerBuilder = class extends PgIntColumnBaseBuilder {
      static {
        __name(this, "PgIntegerBuilder");
      }
      static [entityKind] = "PgIntegerBuilder";
      constructor(name) {
        super(name, "number", "PgInteger");
      }
      /** @internal */
      build(table) {
        return new PgInteger(table, this.config);
      }
    };
    PgInteger = class extends PgColumn {
      static {
        __name(this, "PgInteger");
      }
      static [entityKind] = "PgInteger";
      getSQLType() {
        return "integer";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          return Number.parseInt(value);
        }
        return value;
      }
    };
    __name(integer, "integer");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/interval.js
function interval(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgIntervalBuilder(name, config);
}
var PgIntervalBuilder, PgInterval;
var init_interval = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/interval.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgIntervalBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgIntervalBuilder");
      }
      static [entityKind] = "PgIntervalBuilder";
      constructor(name, intervalConfig) {
        super(name, "string", "PgInterval");
        this.config.intervalConfig = intervalConfig;
      }
      /** @internal */
      build(table) {
        return new PgInterval(table, this.config);
      }
    };
    PgInterval = class extends PgColumn {
      static {
        __name(this, "PgInterval");
      }
      static [entityKind] = "PgInterval";
      fields = this.config.intervalConfig.fields;
      precision = this.config.intervalConfig.precision;
      getSQLType() {
        const fields = this.fields ? ` ${this.fields}` : "";
        const precision = this.precision ? `(${this.precision})` : "";
        return `interval${fields}${precision}`;
      }
    };
    __name(interval, "interval");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/json.js
function json(name) {
  return new PgJsonBuilder(name ?? "");
}
var PgJsonBuilder, PgJson;
var init_json = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/json.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgJsonBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgJsonBuilder");
      }
      static [entityKind] = "PgJsonBuilder";
      constructor(name) {
        super(name, "json", "PgJson");
      }
      /** @internal */
      build(table) {
        return new PgJson(table, this.config);
      }
    };
    PgJson = class extends PgColumn {
      static {
        __name(this, "PgJson");
      }
      static [entityKind] = "PgJson";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "json";
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          try {
            return JSON.parse(value);
          } catch {
            return value;
          }
        }
        return value;
      }
    };
    __name(json, "json");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/jsonb.js
function jsonb(name) {
  return new PgJsonbBuilder(name ?? "");
}
var PgJsonbBuilder, PgJsonb;
var init_jsonb = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/jsonb.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgJsonbBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgJsonbBuilder");
      }
      static [entityKind] = "PgJsonbBuilder";
      constructor(name) {
        super(name, "json", "PgJsonb");
      }
      /** @internal */
      build(table) {
        return new PgJsonb(table, this.config);
      }
    };
    PgJsonb = class extends PgColumn {
      static {
        __name(this, "PgJsonb");
      }
      static [entityKind] = "PgJsonb";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "jsonb";
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          try {
            return JSON.parse(value);
          } catch {
            return value;
          }
        }
        return value;
      }
    };
    __name(jsonb, "jsonb");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/line.js
function line(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgLineBuilder(name);
  }
  return new PgLineABCBuilder(name);
}
var PgLineBuilder, PgLineTuple, PgLineABCBuilder, PgLineABC;
var init_line = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/line.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgLineBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgLineBuilder");
      }
      static [entityKind] = "PgLineBuilder";
      constructor(name) {
        super(name, "array", "PgLine");
      }
      /** @internal */
      build(table) {
        return new PgLineTuple(
          table,
          this.config
        );
      }
    };
    PgLineTuple = class extends PgColumn {
      static {
        __name(this, "PgLineTuple");
      }
      static [entityKind] = "PgLine";
      getSQLType() {
        return "line";
      }
      mapFromDriverValue(value) {
        const [a2, b, c] = value.slice(1, -1).split(",");
        return [Number.parseFloat(a2), Number.parseFloat(b), Number.parseFloat(c)];
      }
      mapToDriverValue(value) {
        return `{${value[0]},${value[1]},${value[2]}}`;
      }
    };
    PgLineABCBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgLineABCBuilder");
      }
      static [entityKind] = "PgLineABCBuilder";
      constructor(name) {
        super(name, "json", "PgLineABC");
      }
      /** @internal */
      build(table) {
        return new PgLineABC(
          table,
          this.config
        );
      }
    };
    PgLineABC = class extends PgColumn {
      static {
        __name(this, "PgLineABC");
      }
      static [entityKind] = "PgLineABC";
      getSQLType() {
        return "line";
      }
      mapFromDriverValue(value) {
        const [a2, b, c] = value.slice(1, -1).split(",");
        return { a: Number.parseFloat(a2), b: Number.parseFloat(b), c: Number.parseFloat(c) };
      }
      mapToDriverValue(value) {
        return `{${value.a},${value.b},${value.c}}`;
      }
    };
    __name(line, "line");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/macaddr.js
function macaddr(name) {
  return new PgMacaddrBuilder(name ?? "");
}
var PgMacaddrBuilder, PgMacaddr;
var init_macaddr = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/macaddr.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgMacaddrBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgMacaddrBuilder");
      }
      static [entityKind] = "PgMacaddrBuilder";
      constructor(name) {
        super(name, "string", "PgMacaddr");
      }
      /** @internal */
      build(table) {
        return new PgMacaddr(table, this.config);
      }
    };
    PgMacaddr = class extends PgColumn {
      static {
        __name(this, "PgMacaddr");
      }
      static [entityKind] = "PgMacaddr";
      getSQLType() {
        return "macaddr";
      }
    };
    __name(macaddr, "macaddr");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/macaddr8.js
function macaddr8(name) {
  return new PgMacaddr8Builder(name ?? "");
}
var PgMacaddr8Builder, PgMacaddr8;
var init_macaddr8 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/macaddr8.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgMacaddr8Builder = class extends PgColumnBuilder {
      static {
        __name(this, "PgMacaddr8Builder");
      }
      static [entityKind] = "PgMacaddr8Builder";
      constructor(name) {
        super(name, "string", "PgMacaddr8");
      }
      /** @internal */
      build(table) {
        return new PgMacaddr8(table, this.config);
      }
    };
    PgMacaddr8 = class extends PgColumn {
      static {
        __name(this, "PgMacaddr8");
      }
      static [entityKind] = "PgMacaddr8";
      getSQLType() {
        return "macaddr8";
      }
    };
    __name(macaddr8, "macaddr8");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/numeric.js
function numeric(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  const mode = config?.mode;
  return mode === "number" ? new PgNumericNumberBuilder(name, config?.precision, config?.scale) : mode === "bigint" ? new PgNumericBigIntBuilder(name, config?.precision, config?.scale) : new PgNumericBuilder(name, config?.precision, config?.scale);
}
var PgNumericBuilder, PgNumeric, PgNumericNumberBuilder, PgNumericNumber, PgNumericBigIntBuilder, PgNumericBigInt;
var init_numeric = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/numeric.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgNumericBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgNumericBuilder");
      }
      static [entityKind] = "PgNumericBuilder";
      constructor(name, precision, scale) {
        super(name, "string", "PgNumeric");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumeric(table, this.config);
      }
    };
    PgNumeric = class extends PgColumn {
      static {
        __name(this, "PgNumeric");
      }
      static [entityKind] = "PgNumeric";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue(value) {
        if (typeof value === "string")
          return value;
        return String(value);
      }
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
    PgNumericNumberBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgNumericNumberBuilder");
      }
      static [entityKind] = "PgNumericNumberBuilder";
      constructor(name, precision, scale) {
        super(name, "number", "PgNumericNumber");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumericNumber(
          table,
          this.config
        );
      }
    };
    PgNumericNumber = class extends PgColumn {
      static {
        __name(this, "PgNumericNumber");
      }
      static [entityKind] = "PgNumericNumber";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue(value) {
        if (typeof value === "number")
          return value;
        return Number(value);
      }
      mapToDriverValue = String;
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
    PgNumericBigIntBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgNumericBigIntBuilder");
      }
      static [entityKind] = "PgNumericBigIntBuilder";
      constructor(name, precision, scale) {
        super(name, "bigint", "PgNumericBigInt");
        this.config.precision = precision;
        this.config.scale = scale;
      }
      /** @internal */
      build(table) {
        return new PgNumericBigInt(
          table,
          this.config
        );
      }
    };
    PgNumericBigInt = class extends PgColumn {
      static {
        __name(this, "PgNumericBigInt");
      }
      static [entityKind] = "PgNumericBigInt";
      precision;
      scale;
      constructor(table, config) {
        super(table, config);
        this.precision = config.precision;
        this.scale = config.scale;
      }
      mapFromDriverValue = BigInt;
      mapToDriverValue = String;
      getSQLType() {
        if (this.precision !== void 0 && this.scale !== void 0) {
          return `numeric(${this.precision}, ${this.scale})`;
        } else if (this.precision === void 0) {
          return "numeric";
        } else {
          return `numeric(${this.precision})`;
        }
      }
    };
    __name(numeric, "numeric");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/point.js
function point(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgPointTupleBuilder(name);
  }
  return new PgPointObjectBuilder(name);
}
var PgPointTupleBuilder, PgPointTuple, PgPointObjectBuilder, PgPointObject;
var init_point = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/point.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgPointTupleBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgPointTupleBuilder");
      }
      static [entityKind] = "PgPointTupleBuilder";
      constructor(name) {
        super(name, "array", "PgPointTuple");
      }
      /** @internal */
      build(table) {
        return new PgPointTuple(
          table,
          this.config
        );
      }
    };
    PgPointTuple = class extends PgColumn {
      static {
        __name(this, "PgPointTuple");
      }
      static [entityKind] = "PgPointTuple";
      getSQLType() {
        return "point";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          const [x2, y2] = value.slice(1, -1).split(",");
          return [Number.parseFloat(x2), Number.parseFloat(y2)];
        }
        return [value.x, value.y];
      }
      mapToDriverValue(value) {
        return `(${value[0]},${value[1]})`;
      }
    };
    PgPointObjectBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgPointObjectBuilder");
      }
      static [entityKind] = "PgPointObjectBuilder";
      constructor(name) {
        super(name, "json", "PgPointObject");
      }
      /** @internal */
      build(table) {
        return new PgPointObject(
          table,
          this.config
        );
      }
    };
    PgPointObject = class extends PgColumn {
      static {
        __name(this, "PgPointObject");
      }
      static [entityKind] = "PgPointObject";
      getSQLType() {
        return "point";
      }
      mapFromDriverValue(value) {
        if (typeof value === "string") {
          const [x2, y2] = value.slice(1, -1).split(",");
          return { x: Number.parseFloat(x2), y: Number.parseFloat(y2) };
        }
        return value;
      }
      mapToDriverValue(value) {
        return `(${value.x},${value.y})`;
      }
    };
    __name(point, "point");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/postgis_extension/utils.js
function hexToBytes(hex) {
  const bytes = [];
  for (let c = 0; c < hex.length; c += 2) {
    bytes.push(Number.parseInt(hex.slice(c, c + 2), 16));
  }
  return new Uint8Array(bytes);
}
function bytesToFloat64(bytes, offset) {
  const buffer = new ArrayBuffer(8);
  const view = new DataView(buffer);
  for (let i = 0; i < 8; i++) {
    view.setUint8(i, bytes[offset + i]);
  }
  return view.getFloat64(0, true);
}
function parseEWKB(hex) {
  const bytes = hexToBytes(hex);
  let offset = 0;
  const byteOrder = bytes[offset];
  offset += 1;
  const view = new DataView(bytes.buffer);
  const geomType = view.getUint32(offset, byteOrder === 1);
  offset += 4;
  let _srid;
  if (geomType & 536870912) {
    _srid = view.getUint32(offset, byteOrder === 1);
    offset += 4;
  }
  if ((geomType & 65535) === 1) {
    const x2 = bytesToFloat64(bytes, offset);
    offset += 8;
    const y2 = bytesToFloat64(bytes, offset);
    offset += 8;
    return [x2, y2];
  }
  throw new Error("Unsupported geometry type");
}
var init_utils2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/postgis_extension/utils.js"() {
    init_functionsRoutes_0_17677553668797852();
    __name(hexToBytes, "hexToBytes");
    __name(bytesToFloat64, "bytesToFloat64");
    __name(parseEWKB, "parseEWKB");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/postgis_extension/geometry.js
function geometry(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (!config?.mode || config.mode === "tuple") {
    return new PgGeometryBuilder(name);
  }
  return new PgGeometryObjectBuilder(name);
}
var PgGeometryBuilder, PgGeometry, PgGeometryObjectBuilder, PgGeometryObject;
var init_geometry = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/postgis_extension/geometry.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    init_utils2();
    PgGeometryBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgGeometryBuilder");
      }
      static [entityKind] = "PgGeometryBuilder";
      constructor(name) {
        super(name, "array", "PgGeometry");
      }
      /** @internal */
      build(table) {
        return new PgGeometry(
          table,
          this.config
        );
      }
    };
    PgGeometry = class extends PgColumn {
      static {
        __name(this, "PgGeometry");
      }
      static [entityKind] = "PgGeometry";
      getSQLType() {
        return "geometry(point)";
      }
      mapFromDriverValue(value) {
        return parseEWKB(value);
      }
      mapToDriverValue(value) {
        return `point(${value[0]} ${value[1]})`;
      }
    };
    PgGeometryObjectBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgGeometryObjectBuilder");
      }
      static [entityKind] = "PgGeometryObjectBuilder";
      constructor(name) {
        super(name, "json", "PgGeometryObject");
      }
      /** @internal */
      build(table) {
        return new PgGeometryObject(
          table,
          this.config
        );
      }
    };
    PgGeometryObject = class extends PgColumn {
      static {
        __name(this, "PgGeometryObject");
      }
      static [entityKind] = "PgGeometryObject";
      getSQLType() {
        return "geometry(point)";
      }
      mapFromDriverValue(value) {
        const parsed = parseEWKB(value);
        return { x: parsed[0], y: parsed[1] };
      }
      mapToDriverValue(value) {
        return `point(${value.x} ${value.y})`;
      }
    };
    __name(geometry, "geometry");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/real.js
function real(name) {
  return new PgRealBuilder(name ?? "");
}
var PgRealBuilder, PgReal;
var init_real = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/real.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgRealBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgRealBuilder");
      }
      static [entityKind] = "PgRealBuilder";
      constructor(name, length) {
        super(name, "number", "PgReal");
        this.config.length = length;
      }
      /** @internal */
      build(table) {
        return new PgReal(table, this.config);
      }
    };
    PgReal = class extends PgColumn {
      static {
        __name(this, "PgReal");
      }
      static [entityKind] = "PgReal";
      constructor(table, config) {
        super(table, config);
      }
      getSQLType() {
        return "real";
      }
      mapFromDriverValue = /* @__PURE__ */ __name((value) => {
        if (typeof value === "string") {
          return Number.parseFloat(value);
        }
        return value;
      }, "mapFromDriverValue");
    };
    __name(real, "real");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/serial.js
function serial(name) {
  return new PgSerialBuilder(name ?? "");
}
var PgSerialBuilder, PgSerial;
var init_serial = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/serial.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgSerialBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgSerialBuilder");
      }
      static [entityKind] = "PgSerialBuilder";
      constructor(name) {
        super(name, "number", "PgSerial");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgSerial(table, this.config);
      }
    };
    PgSerial = class extends PgColumn {
      static {
        __name(this, "PgSerial");
      }
      static [entityKind] = "PgSerial";
      getSQLType() {
        return "serial";
      }
    };
    __name(serial, "serial");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/smallint.js
function smallint(name) {
  return new PgSmallIntBuilder(name ?? "");
}
var PgSmallIntBuilder, PgSmallInt;
var init_smallint = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/smallint.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    init_int_common();
    PgSmallIntBuilder = class extends PgIntColumnBaseBuilder {
      static {
        __name(this, "PgSmallIntBuilder");
      }
      static [entityKind] = "PgSmallIntBuilder";
      constructor(name) {
        super(name, "number", "PgSmallInt");
      }
      /** @internal */
      build(table) {
        return new PgSmallInt(table, this.config);
      }
    };
    PgSmallInt = class extends PgColumn {
      static {
        __name(this, "PgSmallInt");
      }
      static [entityKind] = "PgSmallInt";
      getSQLType() {
        return "smallint";
      }
      mapFromDriverValue = /* @__PURE__ */ __name((value) => {
        if (typeof value === "string") {
          return Number(value);
        }
        return value;
      }, "mapFromDriverValue");
    };
    __name(smallint, "smallint");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/smallserial.js
function smallserial(name) {
  return new PgSmallSerialBuilder(name ?? "");
}
var PgSmallSerialBuilder, PgSmallSerial;
var init_smallserial = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/smallserial.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_common();
    PgSmallSerialBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgSmallSerialBuilder");
      }
      static [entityKind] = "PgSmallSerialBuilder";
      constructor(name) {
        super(name, "number", "PgSmallSerial");
        this.config.hasDefault = true;
        this.config.notNull = true;
      }
      /** @internal */
      build(table) {
        return new PgSmallSerial(
          table,
          this.config
        );
      }
    };
    PgSmallSerial = class extends PgColumn {
      static {
        __name(this, "PgSmallSerial");
      }
      static [entityKind] = "PgSmallSerial";
      getSQLType() {
        return "smallserial";
      }
    };
    __name(smallserial, "smallserial");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/text.js
function text(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgTextBuilder(name, config);
}
var PgTextBuilder, PgText;
var init_text = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/text.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgTextBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgTextBuilder");
      }
      static [entityKind] = "PgTextBuilder";
      constructor(name, config) {
        super(name, "string", "PgText");
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgText(table, this.config);
      }
    };
    PgText = class extends PgColumn {
      static {
        __name(this, "PgText");
      }
      static [entityKind] = "PgText";
      enumValues = this.config.enumValues;
      getSQLType() {
        return "text";
      }
    };
    __name(text, "text");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/time.js
function time(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgTimeBuilder(name, config.withTimezone ?? false, config.precision);
}
var PgTimeBuilder, PgTime;
var init_time = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/time.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgTimeBuilder = class extends PgDateColumnBaseBuilder {
      static {
        __name(this, "PgTimeBuilder");
      }
      constructor(name, withTimezone, precision) {
        super(name, "string", "PgTime");
        this.withTimezone = withTimezone;
        this.precision = precision;
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      static [entityKind] = "PgTimeBuilder";
      /** @internal */
      build(table) {
        return new PgTime(table, this.config);
      }
    };
    PgTime = class extends PgColumn {
      static {
        __name(this, "PgTime");
      }
      static [entityKind] = "PgTime";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : `(${this.precision})`;
        return `time${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
    };
    __name(time, "time");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/timestamp.js
function timestamp(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  if (config?.mode === "string") {
    return new PgTimestampStringBuilder(name, config.withTimezone ?? false, config.precision);
  }
  return new PgTimestampBuilder(name, config?.withTimezone ?? false, config?.precision);
}
var PgTimestampBuilder, PgTimestamp, PgTimestampStringBuilder, PgTimestampString;
var init_timestamp = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/timestamp.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    init_date_common();
    PgTimestampBuilder = class extends PgDateColumnBaseBuilder {
      static {
        __name(this, "PgTimestampBuilder");
      }
      static [entityKind] = "PgTimestampBuilder";
      constructor(name, withTimezone, precision) {
        super(name, "date", "PgTimestamp");
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      /** @internal */
      build(table) {
        return new PgTimestamp(table, this.config);
      }
    };
    PgTimestamp = class extends PgColumn {
      static {
        __name(this, "PgTimestamp");
      }
      static [entityKind] = "PgTimestamp";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : ` (${this.precision})`;
        return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
      mapFromDriverValue = /* @__PURE__ */ __name((value) => {
        return new Date(this.withTimezone ? value : value + "+0000");
      }, "mapFromDriverValue");
      mapToDriverValue = /* @__PURE__ */ __name((value) => {
        return value.toISOString();
      }, "mapToDriverValue");
    };
    PgTimestampStringBuilder = class extends PgDateColumnBaseBuilder {
      static {
        __name(this, "PgTimestampStringBuilder");
      }
      static [entityKind] = "PgTimestampStringBuilder";
      constructor(name, withTimezone, precision) {
        super(name, "string", "PgTimestampString");
        this.config.withTimezone = withTimezone;
        this.config.precision = precision;
      }
      /** @internal */
      build(table) {
        return new PgTimestampString(
          table,
          this.config
        );
      }
    };
    PgTimestampString = class extends PgColumn {
      static {
        __name(this, "PgTimestampString");
      }
      static [entityKind] = "PgTimestampString";
      withTimezone;
      precision;
      constructor(table, config) {
        super(table, config);
        this.withTimezone = config.withTimezone;
        this.precision = config.precision;
      }
      getSQLType() {
        const precision = this.precision === void 0 ? "" : `(${this.precision})`;
        return `timestamp${precision}${this.withTimezone ? " with time zone" : ""}`;
      }
    };
    __name(timestamp, "timestamp");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/uuid.js
function uuid(name) {
  return new PgUUIDBuilder(name ?? "");
}
var PgUUIDBuilder, PgUUID;
var init_uuid = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/uuid.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_sql();
    init_common();
    PgUUIDBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgUUIDBuilder");
      }
      static [entityKind] = "PgUUIDBuilder";
      constructor(name) {
        super(name, "string", "PgUUID");
      }
      /**
       * Adds `default gen_random_uuid()` to the column definition.
       */
      defaultRandom() {
        return this.default(sql`gen_random_uuid()`);
      }
      /** @internal */
      build(table) {
        return new PgUUID(table, this.config);
      }
    };
    PgUUID = class extends PgColumn {
      static {
        __name(this, "PgUUID");
      }
      static [entityKind] = "PgUUID";
      getSQLType() {
        return "uuid";
      }
    };
    __name(uuid, "uuid");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/varchar.js
function varchar(a2, b = {}) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgVarcharBuilder(name, config);
}
var PgVarcharBuilder, PgVarchar;
var init_varchar = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/varchar.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgVarcharBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgVarcharBuilder");
      }
      static [entityKind] = "PgVarcharBuilder";
      constructor(name, config) {
        super(name, "string", "PgVarchar");
        this.config.length = config.length;
        this.config.enumValues = config.enum;
      }
      /** @internal */
      build(table) {
        return new PgVarchar(
          table,
          this.config
        );
      }
    };
    PgVarchar = class extends PgColumn {
      static {
        __name(this, "PgVarchar");
      }
      static [entityKind] = "PgVarchar";
      length = this.config.length;
      enumValues = this.config.enumValues;
      getSQLType() {
        return this.length === void 0 ? `varchar` : `varchar(${this.length})`;
      }
    };
    __name(varchar, "varchar");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/bit.js
function bit(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgBinaryVectorBuilder(name, config);
}
var PgBinaryVectorBuilder, PgBinaryVector;
var init_bit = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/bit.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgBinaryVectorBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgBinaryVectorBuilder");
      }
      static [entityKind] = "PgBinaryVectorBuilder";
      constructor(name, config) {
        super(name, "string", "PgBinaryVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgBinaryVector(
          table,
          this.config
        );
      }
    };
    PgBinaryVector = class extends PgColumn {
      static {
        __name(this, "PgBinaryVector");
      }
      static [entityKind] = "PgBinaryVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `bit(${this.dimensions})`;
      }
    };
    __name(bit, "bit");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/halfvec.js
function halfvec(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgHalfVectorBuilder(name, config);
}
var PgHalfVectorBuilder, PgHalfVector;
var init_halfvec = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/halfvec.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgHalfVectorBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgHalfVectorBuilder");
      }
      static [entityKind] = "PgHalfVectorBuilder";
      constructor(name, config) {
        super(name, "array", "PgHalfVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgHalfVector(
          table,
          this.config
        );
      }
    };
    PgHalfVector = class extends PgColumn {
      static {
        __name(this, "PgHalfVector");
      }
      static [entityKind] = "PgHalfVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `halfvec(${this.dimensions})`;
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        return value.slice(1, -1).split(",").map((v2) => Number.parseFloat(v2));
      }
    };
    __name(halfvec, "halfvec");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/sparsevec.js
function sparsevec(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgSparseVectorBuilder(name, config);
}
var PgSparseVectorBuilder, PgSparseVector;
var init_sparsevec = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/sparsevec.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgSparseVectorBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgSparseVectorBuilder");
      }
      static [entityKind] = "PgSparseVectorBuilder";
      constructor(name, config) {
        super(name, "string", "PgSparseVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgSparseVector(
          table,
          this.config
        );
      }
    };
    PgSparseVector = class extends PgColumn {
      static {
        __name(this, "PgSparseVector");
      }
      static [entityKind] = "PgSparseVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `sparsevec(${this.dimensions})`;
      }
    };
    __name(sparsevec, "sparsevec");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/vector.js
function vector(a2, b) {
  const { name, config } = getColumnNameAndConfig(a2, b);
  return new PgVectorBuilder(name, config);
}
var PgVectorBuilder, PgVector;
var init_vector = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/vector_extension/vector.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_utils();
    init_common();
    PgVectorBuilder = class extends PgColumnBuilder {
      static {
        __name(this, "PgVectorBuilder");
      }
      static [entityKind] = "PgVectorBuilder";
      constructor(name, config) {
        super(name, "array", "PgVector");
        this.config.dimensions = config.dimensions;
      }
      /** @internal */
      build(table) {
        return new PgVector(
          table,
          this.config
        );
      }
    };
    PgVector = class extends PgColumn {
      static {
        __name(this, "PgVector");
      }
      static [entityKind] = "PgVector";
      dimensions = this.config.dimensions;
      getSQLType() {
        return `vector(${this.dimensions})`;
      }
      mapToDriverValue(value) {
        return JSON.stringify(value);
      }
      mapFromDriverValue(value) {
        return value.slice(1, -1).split(",").map((v2) => Number.parseFloat(v2));
      }
    };
    __name(vector, "vector");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/index.js
var init_columns = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_bigint();
    init_bigserial();
    init_boolean();
    init_char();
    init_cidr();
    init_common();
    init_custom();
    init_date();
    init_double_precision();
    init_enum();
    init_inet();
    init_int_common();
    init_integer();
    init_interval();
    init_json();
    init_jsonb();
    init_line();
    init_macaddr();
    init_macaddr8();
    init_numeric();
    init_point();
    init_geometry();
    init_real();
    init_serial();
    init_smallint();
    init_smallserial();
    init_text();
    init_time();
    init_timestamp();
    init_uuid();
    init_varchar();
    init_bit();
    init_halfvec();
    init_sparsevec();
    init_vector();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/all.js
function getPgColumnBuilders() {
  return {
    bigint,
    bigserial,
    boolean,
    char,
    cidr,
    customType,
    date,
    doublePrecision,
    inet,
    integer,
    interval,
    json,
    jsonb,
    line,
    macaddr,
    macaddr8,
    numeric,
    point,
    geometry,
    real,
    serial,
    smallint,
    smallserial,
    text,
    time,
    timestamp,
    uuid,
    varchar,
    bit,
    halfvec,
    sparsevec,
    vector
  };
}
var init_all = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/columns/all.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_bigint();
    init_bigserial();
    init_boolean();
    init_char();
    init_cidr();
    init_custom();
    init_date();
    init_double_precision();
    init_inet();
    init_integer();
    init_interval();
    init_json();
    init_jsonb();
    init_line();
    init_macaddr();
    init_macaddr8();
    init_numeric();
    init_point();
    init_geometry();
    init_real();
    init_serial();
    init_smallint();
    init_smallserial();
    init_text();
    init_time();
    init_timestamp();
    init_uuid();
    init_varchar();
    init_bit();
    init_halfvec();
    init_sparsevec();
    init_vector();
    __name(getPgColumnBuilders, "getPgColumnBuilders");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/table.js
function pgTableWithSchema(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new PgTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns(getPgColumnBuilders()) : columns;
  const builtColumns = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.build(rawTable);
      rawTable[InlineForeignKeys].push(...colBuilder.buildForeignKeys(column, rawTable));
      return [name2, column];
    })
  );
  const builtColumnsForExtraConfig = Object.fromEntries(
    Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
      const colBuilder = colBuilderBase;
      colBuilder.setName(name2);
      const column = colBuilder.buildExtraConfigColumn(rawTable);
      return [name2, column];
    })
  );
  const table = Object.assign(rawTable, builtColumns);
  table[Table.Symbol.Columns] = builtColumns;
  table[Table.Symbol.ExtraConfigColumns] = builtColumnsForExtraConfig;
  if (extraConfig) {
    table[PgTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return Object.assign(table, {
    enableRLS: /* @__PURE__ */ __name(() => {
      table[PgTable.Symbol.EnableRLS] = true;
      return table;
    }, "enableRLS")
  });
}
var InlineForeignKeys, EnableRLS, PgTable, pgTable;
var init_table2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/table.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table();
    init_all();
    InlineForeignKeys = /* @__PURE__ */ Symbol.for("drizzle:PgInlineForeignKeys");
    EnableRLS = /* @__PURE__ */ Symbol.for("drizzle:EnableRLS");
    PgTable = class extends Table {
      static {
        __name(this, "PgTable");
      }
      static [entityKind] = "PgTable";
      /** @internal */
      static Symbol = Object.assign({}, Table.Symbol, {
        InlineForeignKeys,
        EnableRLS
      });
      /**@internal */
      [InlineForeignKeys] = [];
      /** @internal */
      [EnableRLS] = false;
      /** @internal */
      [Table.Symbol.ExtraConfigBuilder] = void 0;
      /** @internal */
      [Table.Symbol.ExtraConfigColumns] = {};
    };
    __name(pgTableWithSchema, "pgTableWithSchema");
    pgTable = /* @__PURE__ */ __name((name, columns, extraConfig) => {
      return pgTableWithSchema(name, columns, extraConfig, void 0);
    }, "pgTable");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/primary-keys.js
var PrimaryKeyBuilder, PrimaryKey;
var init_primary_keys = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/primary-keys.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table2();
    PrimaryKeyBuilder = class {
      static {
        __name(this, "PrimaryKeyBuilder");
      }
      static [entityKind] = "PgPrimaryKeyBuilder";
      /** @internal */
      columns;
      /** @internal */
      name;
      constructor(columns, name) {
        this.columns = columns;
        this.name = name;
      }
      /** @internal */
      build(table) {
        return new PrimaryKey(table, this.columns, this.name);
      }
    };
    PrimaryKey = class {
      static {
        __name(this, "PrimaryKey");
      }
      constructor(table, columns, name) {
        this.table = table;
        this.columns = columns;
        this.name = name;
      }
      static [entityKind] = "PgPrimaryKey";
      columns;
      name;
      getName() {
        return this.name ?? `${this.table[PgTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/conditions.js
function bindIfParam(value, column) {
  if (isDriverValueEncoder(column) && !isSQLWrapper(value) && !is(value, Param) && !is(value, Placeholder) && !is(value, Column) && !is(value, Table) && !is(value, View)) {
    return new Param(value, column);
  }
  return value;
}
function and(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" and ")),
    new StringChunk(")")
  ]);
}
function or2(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter(
    (c) => c !== void 0
  );
  if (conditions.length === 0) {
    return void 0;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" or ")),
    new StringChunk(")")
  ]);
}
function not(condition) {
  return sql`not ${condition}`;
}
function inArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`false`;
    }
    return sql`${column} in ${values.map((v2) => bindIfParam(v2, column))}`;
  }
  return sql`${column} in ${bindIfParam(values, column)}`;
}
function notInArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`true`;
    }
    return sql`${column} not in ${values.map((v2) => bindIfParam(v2, column))}`;
  }
  return sql`${column} not in ${bindIfParam(values, column)}`;
}
function isNull(value) {
  return sql`${value} is null`;
}
function isNotNull(value) {
  return sql`${value} is not null`;
}
function exists(subquery) {
  return sql`exists ${subquery}`;
}
function notExists(subquery) {
  return sql`not exists ${subquery}`;
}
function between(column, min, max) {
  return sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(
    max,
    column
  )}`;
}
function notBetween(column, min, max) {
  return sql`${column} not between ${bindIfParam(
    min,
    column
  )} and ${bindIfParam(max, column)}`;
}
function like(column, value) {
  return sql`${column} like ${value}`;
}
function notLike(column, value) {
  return sql`${column} not like ${value}`;
}
function ilike(column, value) {
  return sql`${column} ilike ${value}`;
}
function notIlike(column, value) {
  return sql`${column} not ilike ${value}`;
}
var eq, ne, gt, gte, lt, lte;
var init_conditions = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/conditions.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_column();
    init_entity();
    init_table();
    init_sql();
    __name(bindIfParam, "bindIfParam");
    eq = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} = ${bindIfParam(right, left)}`;
    }, "eq");
    ne = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} <> ${bindIfParam(right, left)}`;
    }, "ne");
    __name(and, "and");
    __name(or2, "or");
    __name(not, "not");
    gt = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} > ${bindIfParam(right, left)}`;
    }, "gt");
    gte = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} >= ${bindIfParam(right, left)}`;
    }, "gte");
    lt = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} < ${bindIfParam(right, left)}`;
    }, "lt");
    lte = /* @__PURE__ */ __name((left, right) => {
      return sql`${left} <= ${bindIfParam(right, left)}`;
    }, "lte");
    __name(inArray, "inArray");
    __name(notInArray, "notInArray");
    __name(isNull, "isNull");
    __name(isNotNull, "isNotNull");
    __name(exists, "exists");
    __name(notExists, "notExists");
    __name(between, "between");
    __name(notBetween, "notBetween");
    __name(like, "like");
    __name(notLike, "notLike");
    __name(ilike, "ilike");
    __name(notIlike, "notIlike");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/select.js
function asc(column) {
  return sql`${column} asc`;
}
function desc(column) {
  return sql`${column} desc`;
}
var init_select = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/select.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_sql();
    __name(asc, "asc");
    __name(desc, "desc");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/index.js
var init_expressions = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/expressions/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_conditions();
    init_select();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/relations.js
function getOperators() {
  return {
    and,
    between,
    eq,
    exists,
    gt,
    gte,
    ilike,
    inArray,
    isNull,
    isNotNull,
    like,
    lt,
    lte,
    ne,
    not,
    notBetween,
    notExists,
    notLike,
    notIlike,
    notInArray,
    or: or2,
    sql
  };
}
function getOrderByOperators() {
  return {
    sql,
    asc,
    desc
  };
}
function extractTablesRelationalConfig(schema, configHelpers) {
  if (Object.keys(schema).length === 1 && "default" in schema && !is(schema["default"], Table)) {
    schema = schema["default"];
  }
  const tableNamesMap = {};
  const relationsBuffer = {};
  const tablesConfig = {};
  for (const [key, value] of Object.entries(schema)) {
    if (is(value, Table)) {
      const dbName = getTableUniqueName(value);
      const bufferedRelations = relationsBuffer[dbName];
      tableNamesMap[dbName] = key;
      tablesConfig[key] = {
        tsName: key,
        dbName: value[Table.Symbol.Name],
        schema: value[Table.Symbol.Schema],
        columns: value[Table.Symbol.Columns],
        relations: bufferedRelations?.relations ?? {},
        primaryKey: bufferedRelations?.primaryKey ?? []
      };
      for (const column of Object.values(
        value[Table.Symbol.Columns]
      )) {
        if (column.primary) {
          tablesConfig[key].primaryKey.push(column);
        }
      }
      const extraConfig = value[Table.Symbol.ExtraConfigBuilder]?.(value[Table.Symbol.ExtraConfigColumns]);
      if (extraConfig) {
        for (const configEntry of Object.values(extraConfig)) {
          if (is(configEntry, PrimaryKeyBuilder)) {
            tablesConfig[key].primaryKey.push(...configEntry.columns);
          }
        }
      }
    } else if (is(value, Relations)) {
      const dbName = getTableUniqueName(value.table);
      const tableName = tableNamesMap[dbName];
      const relations2 = value.config(
        configHelpers(value.table)
      );
      let primaryKey;
      for (const [relationName, relation] of Object.entries(relations2)) {
        if (tableName) {
          const tableConfig = tablesConfig[tableName];
          tableConfig.relations[relationName] = relation;
          if (primaryKey) {
            tableConfig.primaryKey.push(...primaryKey);
          }
        } else {
          if (!(dbName in relationsBuffer)) {
            relationsBuffer[dbName] = {
              relations: {},
              primaryKey
            };
          }
          relationsBuffer[dbName].relations[relationName] = relation;
        }
      }
    }
  }
  return { tables: tablesConfig, tableNamesMap };
}
function createOne(sourceTable) {
  return /* @__PURE__ */ __name(function one(table, config) {
    return new One(
      sourceTable,
      table,
      config,
      config?.fields.reduce((res, f) => res && f.notNull, true) ?? false
    );
  }, "one");
}
function createMany(sourceTable) {
  return /* @__PURE__ */ __name(function many(referencedTable, config) {
    return new Many(sourceTable, referencedTable, config);
  }, "many");
}
function normalizeRelation(schema, tableNamesMap, relation) {
  if (is(relation, One) && relation.config) {
    return {
      fields: relation.config.fields,
      references: relation.config.references
    };
  }
  const referencedTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
  if (!referencedTableTsName) {
    throw new Error(
      `Table "${relation.referencedTable[Table.Symbol.Name]}" not found in schema`
    );
  }
  const referencedTableConfig = schema[referencedTableTsName];
  if (!referencedTableConfig) {
    throw new Error(`Table "${referencedTableTsName}" not found in schema`);
  }
  const sourceTable = relation.sourceTable;
  const sourceTableTsName = tableNamesMap[getTableUniqueName(sourceTable)];
  if (!sourceTableTsName) {
    throw new Error(
      `Table "${sourceTable[Table.Symbol.Name]}" not found in schema`
    );
  }
  const reverseRelations = [];
  for (const referencedTableRelation of Object.values(
    referencedTableConfig.relations
  )) {
    if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) {
      reverseRelations.push(referencedTableRelation);
    }
  }
  if (reverseRelations.length > 1) {
    throw relation.relationName ? new Error(
      `There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`
    ) : new Error(
      `There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[Table.Symbol.Name]}". Please specify relation name`
    );
  }
  if (reverseRelations[0] && is(reverseRelations[0], One) && reverseRelations[0].config) {
    return {
      fields: reverseRelations[0].config.references,
      references: reverseRelations[0].config.fields
    };
  }
  throw new Error(
    `There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`
  );
}
function createTableRelationsHelpers(sourceTable) {
  return {
    one: createOne(sourceTable),
    many: createMany(sourceTable)
  };
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
  const result = {};
  for (const [
    selectionItemIndex,
    selectionItem
  ] of buildQueryResultSelection.entries()) {
    if (selectionItem.isJson) {
      const relation = tableConfig.relations[selectionItem.tsKey];
      const rawSubRows = row[selectionItemIndex];
      const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
      result[selectionItem.tsKey] = is(relation, One) ? subRows && mapRelationalRow(
        tablesConfig,
        tablesConfig[selectionItem.relationTableTsKey],
        subRows,
        selectionItem.selection,
        mapColumnValue
      ) : subRows.map(
        (subRow) => mapRelationalRow(
          tablesConfig,
          tablesConfig[selectionItem.relationTableTsKey],
          subRow,
          selectionItem.selection,
          mapColumnValue
        )
      );
    } else {
      const value = mapColumnValue(row[selectionItemIndex]);
      const field = selectionItem.field;
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
    }
  }
  return result;
}
var Relation, Relations, One, Many;
var init_relations = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/relations.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_table();
    init_column();
    init_entity();
    init_primary_keys();
    init_expressions();
    init_sql();
    Relation = class {
      static {
        __name(this, "Relation");
      }
      constructor(sourceTable, referencedTable, relationName) {
        this.sourceTable = sourceTable;
        this.referencedTable = referencedTable;
        this.relationName = relationName;
        this.referencedTableName = referencedTable[Table.Symbol.Name];
      }
      static [entityKind] = "Relation";
      referencedTableName;
      fieldName;
    };
    Relations = class {
      static {
        __name(this, "Relations");
      }
      constructor(table, config) {
        this.table = table;
        this.config = config;
      }
      static [entityKind] = "Relations";
    };
    One = class _One extends Relation {
      static {
        __name(this, "One");
      }
      constructor(sourceTable, referencedTable, config, isNullable) {
        super(sourceTable, referencedTable, config?.relationName);
        this.config = config;
        this.isNullable = isNullable;
      }
      static [entityKind] = "One";
      withFieldName(fieldName) {
        const relation = new _One(
          this.sourceTable,
          this.referencedTable,
          this.config,
          this.isNullable
        );
        relation.fieldName = fieldName;
        return relation;
      }
    };
    Many = class _Many extends Relation {
      static {
        __name(this, "Many");
      }
      constructor(sourceTable, referencedTable, config) {
        super(sourceTable, referencedTable, config?.relationName);
        this.config = config;
      }
      static [entityKind] = "Many";
      withFieldName(fieldName) {
        const relation = new _Many(
          this.sourceTable,
          this.referencedTable,
          this.config
        );
        relation.fieldName = fieldName;
        return relation;
      }
    };
    __name(getOperators, "getOperators");
    __name(getOrderByOperators, "getOrderByOperators");
    __name(extractTablesRelationalConfig, "extractTablesRelationalConfig");
    __name(createOne, "createOne");
    __name(createMany, "createMany");
    __name(normalizeRelation, "normalizeRelation");
    __name(createTableRelationsHelpers, "createTableRelationsHelpers");
    __name(mapRelationalRow, "mapRelationalRow");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/aggregate.js
var init_aggregate = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/aggregate.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/vector.js
var init_vector2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/vector.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/index.js
var init_functions = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/functions/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_aggregate();
    init_vector2();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/index.js
var init_sql2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/sql/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_expressions();
    init_functions();
    init_sql();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view-base.js
var PgViewBase;
var init_view_base = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view-base.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_sql();
    PgViewBase = class extends View {
      static {
        __name(this, "PgViewBase");
      }
      static [entityKind] = "PgViewBase";
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/dialect.js
var PgDialect;
var init_dialect = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/dialect.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_alias();
    init_casing();
    init_column();
    init_entity();
    init_errors();
    init_columns();
    init_table2();
    init_relations();
    init_sql2();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    init_view_base();
    PgDialect = class {
      static {
        __name(this, "PgDialect");
      }
      static [entityKind] = "PgDialect";
      /** @internal */
      casing;
      constructor(config) {
        this.casing = new CasingCache(config?.casing);
      }
      async migrate(migrations, session, config) {
        const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
        const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
        const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint
			)
		`;
        await session.execute(sql`CREATE SCHEMA IF NOT EXISTS ${sql.identifier(migrationsSchema)}`);
        await session.execute(migrationTableCreate);
        const dbMigrations = await session.all(
          sql`select id, hash, created_at from ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} order by created_at desc limit 1`
        );
        const lastDbMigration = dbMigrations[0];
        await session.transaction(async (tx) => {
          for await (const migration of migrations) {
            if (!lastDbMigration || Number(lastDbMigration.created_at) < migration.folderMillis) {
              for (const stmt of migration.sql) {
                await tx.execute(sql.raw(stmt));
              }
              await tx.execute(
                sql`insert into ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} ("hash", "created_at") values(${migration.hash}, ${migration.folderMillis})`
              );
            }
          }
        });
      }
      escapeName(name) {
        return `"${name}"`;
      }
      escapeParam(num) {
        return `$${num + 1}`;
      }
      escapeString(str) {
        return `'${str.replace(/'/g, "''")}'`;
      }
      buildWithCTE(queries) {
        if (!queries?.length)
          return void 0;
        const withSqlChunks = [sql`with `];
        for (const [i, w2] of queries.entries()) {
          withSqlChunks.push(sql`${sql.identifier(w2._.alias)} as (${w2._.sql})`);
          if (i < queries.length - 1) {
            withSqlChunks.push(sql`, `);
          }
        }
        withSqlChunks.push(sql` `);
        return sql.join(withSqlChunks);
      }
      buildDeleteQuery({ table, where, returning, withList }) {
        const withSql = this.buildWithCTE(withList);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        return sql`${withSql}delete from ${table}${whereSql}${returningSql}`;
      }
      buildUpdateSet(table, set) {
        const tableColumns = table[Table.Symbol.Columns];
        const columnNames = Object.keys(tableColumns).filter(
          (colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0
        );
        const setSize = columnNames.length;
        return sql.join(columnNames.flatMap((colName, i) => {
          const col2 = tableColumns[colName];
          const value = set[colName] ?? sql.param(col2.onUpdateFn(), col2);
          const res = sql`${sql.identifier(this.casing.getColumnCasing(col2))} = ${value}`;
          if (i < setSize - 1) {
            return [res, sql.raw(", ")];
          }
          return [res];
        }));
      }
      buildUpdateQuery({ table, set, where, returning, withList, from, joins }) {
        const withSql = this.buildWithCTE(withList);
        const tableName = table[PgTable.Symbol.Name];
        const tableSchema = table[PgTable.Symbol.Schema];
        const origTableName = table[PgTable.Symbol.OriginalName];
        const alias = tableName === origTableName ? void 0 : tableName;
        const tableSql = sql`${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}`;
        const setSql = this.buildUpdateSet(table, set);
        const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
        const joinsSql = this.buildJoins(joins);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: !from })}` : void 0;
        const whereSql = where ? sql` where ${where}` : void 0;
        return sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}`;
      }
      /**
       * Builds selection SQL with provided fields/expressions
       *
       * Examples:
       *
       * `select <selection> from`
       *
       * `insert ... returning <selection>`
       *
       * If `isSingleTable` is true, then columns won't be prefixed with table name
       */
      buildSelection(fields, { isSingleTable = false } = {}) {
        const columnsLen = fields.length;
        const chunks = fields.flatMap(({ field }, i) => {
          const chunk = [];
          if (is(field, SQL.Aliased) && field.isSelectionField) {
            chunk.push(sql.identifier(field.fieldAlias));
          } else if (is(field, SQL.Aliased) || is(field, SQL)) {
            const query = is(field, SQL.Aliased) ? field.sql : field;
            if (isSingleTable) {
              chunk.push(
                new SQL(
                  query.queryChunks.map((c) => {
                    if (is(c, PgColumn)) {
                      return sql.identifier(this.casing.getColumnCasing(c));
                    }
                    return c;
                  })
                )
              );
            } else {
              chunk.push(query);
            }
            if (is(field, SQL.Aliased)) {
              chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
            }
          } else if (is(field, Column)) {
            if (isSingleTable) {
              chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
            } else {
              chunk.push(field);
            }
          }
          if (i < columnsLen - 1) {
            chunk.push(sql`, `);
          }
          return chunk;
        });
        return sql.join(chunks);
      }
      buildJoins(joins) {
        if (!joins || joins.length === 0) {
          return void 0;
        }
        const joinsArray = [];
        for (const [index, joinMeta] of joins.entries()) {
          if (index === 0) {
            joinsArray.push(sql` `);
          }
          const table = joinMeta.table;
          const lateralSql = joinMeta.lateral ? sql` lateral` : void 0;
          const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
          if (is(table, PgTable)) {
            const tableName = table[PgTable.Symbol.Name];
            const tableSchema = table[PgTable.Symbol.Schema];
            const origTableName = table[PgTable.Symbol.OriginalName];
            const alias = tableName === origTableName ? void 0 : joinMeta.alias;
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
            );
          } else if (is(table, View)) {
            const viewName = table[ViewBaseConfig].name;
            const viewSchema = table[ViewBaseConfig].schema;
            const origViewName = table[ViewBaseConfig].originalName;
            const alias = viewName === origViewName ? void 0 : joinMeta.alias;
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? sql`${sql.identifier(viewSchema)}.` : void 0}${sql.identifier(origViewName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`
            );
          } else {
            joinsArray.push(
              sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`
            );
          }
          if (index < joins.length - 1) {
            joinsArray.push(sql` `);
          }
        }
        return sql.join(joinsArray);
      }
      buildFromTable(table) {
        if (is(table, Table) && table[Table.Symbol.IsAlias]) {
          let fullName = sql`${sql.identifier(table[Table.Symbol.OriginalName])}`;
          if (table[Table.Symbol.Schema]) {
            fullName = sql`${sql.identifier(table[Table.Symbol.Schema])}.${fullName}`;
          }
          return sql`${fullName} ${sql.identifier(table[Table.Symbol.Name])}`;
        }
        return table;
      }
      buildSelectQuery({
        withList,
        fields,
        fieldsFlat,
        where,
        having,
        table,
        joins,
        orderBy,
        groupBy,
        limit,
        offset,
        lockingClause,
        distinct,
        setOperators
      }) {
        const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
        for (const f of fieldsList) {
          if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, PgViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(
            ({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])
          ))(f.field.table)) {
            const tableName = getTableName(f.field.table);
            throw new Error(
              `Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`
            );
          }
        }
        const isSingleTable = !joins || joins.length === 0;
        const withSql = this.buildWithCTE(withList);
        let distinctSql;
        if (distinct) {
          distinctSql = distinct === true ? sql` distinct` : sql` distinct on (${sql.join(distinct.on, sql`, `)})`;
        }
        const selection = this.buildSelection(fieldsList, { isSingleTable });
        const tableSql = this.buildFromTable(table);
        const joinsSql = this.buildJoins(joins);
        const whereSql = where ? sql` where ${where}` : void 0;
        const havingSql = having ? sql` having ${having}` : void 0;
        let orderBySql;
        if (orderBy && orderBy.length > 0) {
          orderBySql = sql` order by ${sql.join(orderBy, sql`, `)}`;
        }
        let groupBySql;
        if (groupBy && groupBy.length > 0) {
          groupBySql = sql` group by ${sql.join(groupBy, sql`, `)}`;
        }
        const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        const lockingClauseSql = sql.empty();
        if (lockingClause) {
          const clauseSql = sql` for ${sql.raw(lockingClause.strength)}`;
          if (lockingClause.config.of) {
            clauseSql.append(
              sql` of ${sql.join(
                Array.isArray(lockingClause.config.of) ? lockingClause.config.of : [lockingClause.config.of],
                sql`, `
              )}`
            );
          }
          if (lockingClause.config.noWait) {
            clauseSql.append(sql` nowait`);
          } else if (lockingClause.config.skipLocked) {
            clauseSql.append(sql` skip locked`);
          }
          lockingClauseSql.append(clauseSql);
        }
        const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}`;
        if (setOperators.length > 0) {
          return this.buildSetOperations(finalQuery, setOperators);
        }
        return finalQuery;
      }
      buildSetOperations(leftSelect, setOperators) {
        const [setOperator, ...rest] = setOperators;
        if (!setOperator) {
          throw new Error("Cannot pass undefined values to any set operator");
        }
        if (rest.length === 0) {
          return this.buildSetOperationQuery({ leftSelect, setOperator });
        }
        return this.buildSetOperations(
          this.buildSetOperationQuery({ leftSelect, setOperator }),
          rest
        );
      }
      buildSetOperationQuery({
        leftSelect,
        setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
      }) {
        const leftChunk = sql`(${leftSelect.getSQL()}) `;
        const rightChunk = sql`(${rightSelect.getSQL()})`;
        let orderBySql;
        if (orderBy && orderBy.length > 0) {
          const orderByValues = [];
          for (const singleOrderBy of orderBy) {
            if (is(singleOrderBy, PgColumn)) {
              orderByValues.push(sql.identifier(singleOrderBy.name));
            } else if (is(singleOrderBy, SQL)) {
              for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
                const chunk = singleOrderBy.queryChunks[i];
                if (is(chunk, PgColumn)) {
                  singleOrderBy.queryChunks[i] = sql.identifier(chunk.name);
                }
              }
              orderByValues.push(sql`${singleOrderBy}`);
            } else {
              orderByValues.push(sql`${singleOrderBy}`);
            }
          }
          orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)} `;
        }
        const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
        const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
        const offsetSql = offset ? sql` offset ${offset}` : void 0;
        return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
      }
      buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_ }) {
        const valuesSqlList = [];
        const columns = table[Table.Symbol.Columns];
        const colEntries = Object.entries(columns).filter(([_2, col2]) => !col2.shouldDisableInsert());
        const insertOrder = colEntries.map(
          ([, column]) => sql.identifier(this.casing.getColumnCasing(column))
        );
        if (select) {
          const select2 = valuesOrSelect;
          if (is(select2, SQL)) {
            valuesSqlList.push(select2);
          } else {
            valuesSqlList.push(select2.getSQL());
          }
        } else {
          const values = valuesOrSelect;
          valuesSqlList.push(sql.raw("values "));
          for (const [valueIndex, value] of values.entries()) {
            const valueList = [];
            for (const [fieldName, col2] of colEntries) {
              const colValue = value[fieldName];
              if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
                if (col2.defaultFn !== void 0) {
                  const defaultFnResult = col2.defaultFn();
                  const defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col2);
                  valueList.push(defaultValue);
                } else if (!col2.default && col2.onUpdateFn !== void 0) {
                  const onUpdateFnResult = col2.onUpdateFn();
                  const newValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col2);
                  valueList.push(newValue);
                } else {
                  valueList.push(sql`default`);
                }
              } else {
                valueList.push(colValue);
              }
            }
            valuesSqlList.push(valueList);
            if (valueIndex < values.length - 1) {
              valuesSqlList.push(sql`, `);
            }
          }
        }
        const withSql = this.buildWithCTE(withList);
        const valuesSql = sql.join(valuesSqlList);
        const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
        const onConflictSql = onConflict ? sql` on conflict ${onConflict}` : void 0;
        const overridingSql = overridingSystemValue_ === true ? sql`overriding system value ` : void 0;
        return sql`${withSql}insert into ${table} ${insertOrder} ${overridingSql}${valuesSql}${onConflictSql}${returningSql}`;
      }
      buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
        const concurrentlySql = concurrently ? sql` concurrently` : void 0;
        const withNoDataSql = withNoData ? sql` with no data` : void 0;
        return sql`refresh materialized view${concurrentlySql} ${view}${withNoDataSql}`;
      }
      prepareTyping(encoder) {
        if (is(encoder, PgJsonb) || is(encoder, PgJson)) {
          return "json";
        } else if (is(encoder, PgNumeric)) {
          return "decimal";
        } else if (is(encoder, PgTime)) {
          return "time";
        } else if (is(encoder, PgTimestamp) || is(encoder, PgTimestampString)) {
          return "timestamp";
        } else if (is(encoder, PgDate) || is(encoder, PgDateString)) {
          return "date";
        } else if (is(encoder, PgUUID)) {
          return "uuid";
        } else {
          return "none";
        }
      }
      sqlToQuery(sql22, invokeSource) {
        return sql22.toQuery({
          casing: this.casing,
          escapeName: this.escapeName,
          escapeParam: this.escapeParam,
          escapeString: this.escapeString,
          prepareTyping: this.prepareTyping,
          invokeSource
        });
      }
      // buildRelationalQueryWithPK({
      // 	fullSchema,
      // 	schema,
      // 	tableNamesMap,
      // 	table,
      // 	tableConfig,
      // 	queryConfig: config,
      // 	tableAlias,
      // 	isRoot = false,
      // 	joinOn,
      // }: {
      // 	fullSchema: Record<string, unknown>;
      // 	schema: TablesRelationalConfig;
      // 	tableNamesMap: Record<string, string>;
      // 	table: PgTable;
      // 	tableConfig: TableRelationalConfig;
      // 	queryConfig: true | DBQueryConfig<'many', true>;
      // 	tableAlias: string;
      // 	isRoot?: boolean;
      // 	joinOn?: SQL;
      // }): BuildRelationalQueryResult<PgTable, PgColumn> {
      // 	// For { "<relation>": true }, return a table with selection of all columns
      // 	if (config === true) {
      // 		const selectionEntries = Object.entries(tableConfig.columns);
      // 		const selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = selectionEntries.map((
      // 			[key, value],
      // 		) => ({
      // 			dbKey: value.name,
      // 			tsKey: key,
      // 			field: value as PgColumn,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 		return {
      // 			tableTsKey: tableConfig.tsName,
      // 			sql: table,
      // 			selection,
      // 		};
      // 	}
      // 	// let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
      // 	// let selectionForBuild = selection;
      // 	const aliasedColumns = Object.fromEntries(
      // 		Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]),
      // 	);
      // 	const aliasedRelations = Object.fromEntries(
      // 		Object.entries(tableConfig.relations).map(([key, value]) => [key, aliasedRelation(value, tableAlias)]),
      // 	);
      // 	const aliasedFields = Object.assign({}, aliasedColumns, aliasedRelations);
      // 	let where, hasUserDefinedWhere;
      // 	if (config.where) {
      // 		const whereSql = typeof config.where === 'function' ? config.where(aliasedFields, operators) : config.where;
      // 		where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
      // 		hasUserDefinedWhere = !!where;
      // 	}
      // 	where = and(joinOn, where);
      // 	// const fieldsSelection: { tsKey: string; value: PgColumn | SQL.Aliased; isExtra?: boolean }[] = [];
      // 	let joins: Join[] = [];
      // 	let selectedColumns: string[] = [];
      // 	// Figure out which columns to select
      // 	if (config.columns) {
      // 		let isIncludeMode = false;
      // 		for (const [field, value] of Object.entries(config.columns)) {
      // 			if (value === undefined) {
      // 				continue;
      // 			}
      // 			if (field in tableConfig.columns) {
      // 				if (!isIncludeMode && value === true) {
      // 					isIncludeMode = true;
      // 				}
      // 				selectedColumns.push(field);
      // 			}
      // 		}
      // 		if (selectedColumns.length > 0) {
      // 			selectedColumns = isIncludeMode
      // 				? selectedColumns.filter((c) => config.columns?.[c] === true)
      // 				: Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
      // 		}
      // 	} else {
      // 		// Select all columns if selection is not specified
      // 		selectedColumns = Object.keys(tableConfig.columns);
      // 	}
      // 	// for (const field of selectedColumns) {
      // 	// 	const column = tableConfig.columns[field]! as PgColumn;
      // 	// 	fieldsSelection.push({ tsKey: field, value: column });
      // 	// }
      // 	let initiallySelectedRelations: {
      // 		tsKey: string;
      // 		queryConfig: true | DBQueryConfig<'many', false>;
      // 		relation: Relation;
      // 	}[] = [];
      // 	// let selectedRelations: BuildRelationalQueryResult<PgTable, PgColumn>['selection'] = [];
      // 	// Figure out which relations to select
      // 	if (config.with) {
      // 		initiallySelectedRelations = Object.entries(config.with)
      // 			.filter((entry): entry is [typeof entry[0], NonNullable<typeof entry[1]>] => !!entry[1])
      // 			.map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey]! }));
      // 	}
      // 	const manyRelations = initiallySelectedRelations.filter((r) =>
      // 		is(r.relation, Many)
      // 		&& (schema[tableNamesMap[r.relation.referencedTable[Table.Symbol.Name]]!]?.primaryKey.length ?? 0) > 0
      // 	);
      // 	// If this is the last Many relation (or there are no Many relations), we are on the innermost subquery level
      // 	const isInnermostQuery = manyRelations.length < 2;
      // 	const selectedExtras: {
      // 		tsKey: string;
      // 		value: SQL.Aliased;
      // 	}[] = [];
      // 	// Figure out which extras to select
      // 	if (isInnermostQuery && config.extras) {
      // 		const extras = typeof config.extras === 'function'
      // 			? config.extras(aliasedFields, { sql })
      // 			: config.extras;
      // 		for (const [tsKey, value] of Object.entries(extras)) {
      // 			selectedExtras.push({
      // 				tsKey,
      // 				value: mapColumnsInAliasedSQLToAlias(value, tableAlias),
      // 			});
      // 		}
      // 	}
      // 	// Transform `fieldsSelection` into `selection`
      // 	// `fieldsSelection` shouldn't be used after this point
      // 	// for (const { tsKey, value, isExtra } of fieldsSelection) {
      // 	// 	selection.push({
      // 	// 		dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey]!.name,
      // 	// 		tsKey,
      // 	// 		field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
      // 	// 		relationTableTsKey: undefined,
      // 	// 		isJson: false,
      // 	// 		isExtra,
      // 	// 		selection: [],
      // 	// 	});
      // 	// }
      // 	let orderByOrig = typeof config.orderBy === 'function'
      // 		? config.orderBy(aliasedFields, orderByOperators)
      // 		: config.orderBy ?? [];
      // 	if (!Array.isArray(orderByOrig)) {
      // 		orderByOrig = [orderByOrig];
      // 	}
      // 	const orderBy = orderByOrig.map((orderByValue) => {
      // 		if (is(orderByValue, Column)) {
      // 			return aliasedTableColumn(orderByValue, tableAlias) as PgColumn;
      // 		}
      // 		return mapColumnsInSQLToAlias(orderByValue, tableAlias);
      // 	});
      // 	const limit = isInnermostQuery ? config.limit : undefined;
      // 	const offset = isInnermostQuery ? config.offset : undefined;
      // 	// For non-root queries without additional config except columns, return a table with selection
      // 	if (
      // 		!isRoot
      // 		&& initiallySelectedRelations.length === 0
      // 		&& selectedExtras.length === 0
      // 		&& !where
      // 		&& orderBy.length === 0
      // 		&& limit === undefined
      // 		&& offset === undefined
      // 	) {
      // 		return {
      // 			tableTsKey: tableConfig.tsName,
      // 			sql: table,
      // 			selection: selectedColumns.map((key) => ({
      // 				dbKey: tableConfig.columns[key]!.name,
      // 				tsKey: key,
      // 				field: tableConfig.columns[key] as PgColumn,
      // 				relationTableTsKey: undefined,
      // 				isJson: false,
      // 				selection: [],
      // 			})),
      // 		};
      // 	}
      // 	const selectedRelationsWithoutPK:
      // 	// Process all relations without primary keys, because they need to be joined differently and will all be on the same query level
      // 	for (
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationConfigValue,
      // 			relation,
      // 		} of initiallySelectedRelations
      // 	) {
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTable = schema[relationTableTsName]!;
      // 		if (relationTable.primaryKey.length > 0) {
      // 			continue;
      // 		}
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelation = this.buildRelationalQueryWithoutPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationConfigValue,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 			nestedQueryRelation: relation,
      // 		});
      // 		const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier('data')}`.as(selectedRelationTsKey);
      // 		joins.push({
      // 			on: sql`true`,
      // 			table: new Subquery(builtRelation.sql as SQL, {}, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: true,
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelation.selection,
      // 		});
      // 	}
      // 	const oneRelations = initiallySelectedRelations.filter((r): r is typeof r & { relation: One } =>
      // 		is(r.relation, One)
      // 	);
      // 	// Process all One relations with PKs, because they can all be joined on the same level
      // 	for (
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationConfigValue,
      // 			relation,
      // 		} of oneRelations
      // 	) {
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const relationTable = schema[relationTableTsName]!;
      // 		if (relationTable.primaryKey.length === 0) {
      // 			continue;
      // 		}
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelation = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationConfigValue,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 		});
      // 		const field = sql`case when ${sql.identifier(relationTableAlias)} is null then null else json_build_array(${
      // 			sql.join(
      // 				builtRelation.selection.map(({ field }) =>
      // 					is(field, SQL.Aliased)
      // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
      // 						: is(field, Column)
      // 						? aliasedTableColumn(field, relationTableAlias)
      // 						: field
      // 				),
      // 				sql`, `,
      // 			)
      // 		}) end`.as(selectedRelationTsKey);
      // 		const isLateralJoin = is(builtRelation.sql, SQL);
      // 		joins.push({
      // 			on: isLateralJoin ? sql`true` : joinOn,
      // 			table: is(builtRelation.sql, SQL)
      // 				? new Subquery(builtRelation.sql, {}, relationTableAlias)
      // 				: aliasedTable(builtRelation.sql, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: is(builtRelation.sql, SQL),
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelation.selection,
      // 		});
      // 	}
      // 	let distinct: PgSelectConfig['distinct'];
      // 	let tableFrom: PgTable | Subquery = table;
      // 	// Process first Many relation - each one requires a nested subquery
      // 	const manyRelation = manyRelations[0];
      // 	if (manyRelation) {
      // 		const {
      // 			tsKey: selectedRelationTsKey,
      // 			queryConfig: selectedRelationQueryConfig,
      // 			relation,
      // 		} = manyRelation;
      // 		distinct = {
      // 			on: tableConfig.primaryKey.map((c) => aliasedTableColumn(c as PgColumn, tableAlias)),
      // 		};
      // 		const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
      // 		const relationTableName = relation.referencedTable[Table.Symbol.Name];
      // 		const relationTableTsName = tableNamesMap[relationTableName]!;
      // 		const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
      // 		const joinOn = and(
      // 			...normalizedRelation.fields.map((field, i) =>
      // 				eq(
      // 					aliasedTableColumn(normalizedRelation.references[i]!, relationTableAlias),
      // 					aliasedTableColumn(field, tableAlias),
      // 				)
      // 			),
      // 		);
      // 		const builtRelationJoin = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table: fullSchema[relationTableTsName] as PgTable,
      // 			tableConfig: schema[relationTableTsName]!,
      // 			queryConfig: selectedRelationQueryConfig,
      // 			tableAlias: relationTableAlias,
      // 			joinOn,
      // 		});
      // 		const builtRelationSelectionField = sql`case when ${
      // 			sql.identifier(relationTableAlias)
      // 		} is null then '[]' else json_agg(json_build_array(${
      // 			sql.join(
      // 				builtRelationJoin.selection.map(({ field }) =>
      // 					is(field, SQL.Aliased)
      // 						? sql`${sql.identifier(relationTableAlias)}.${sql.identifier(field.fieldAlias)}`
      // 						: is(field, Column)
      // 						? aliasedTableColumn(field, relationTableAlias)
      // 						: field
      // 				),
      // 				sql`, `,
      // 			)
      // 		})) over (partition by ${sql.join(distinct.on, sql`, `)}) end`.as(selectedRelationTsKey);
      // 		const isLateralJoin = is(builtRelationJoin.sql, SQL);
      // 		joins.push({
      // 			on: isLateralJoin ? sql`true` : joinOn,
      // 			table: isLateralJoin
      // 				? new Subquery(builtRelationJoin.sql as SQL, {}, relationTableAlias)
      // 				: aliasedTable(builtRelationJoin.sql as PgTable, relationTableAlias),
      // 			alias: relationTableAlias,
      // 			joinType: 'left',
      // 			lateral: isLateralJoin,
      // 		});
      // 		// Build the "from" subquery with the remaining Many relations
      // 		const builtTableFrom = this.buildRelationalQueryWithPK({
      // 			fullSchema,
      // 			schema,
      // 			tableNamesMap,
      // 			table,
      // 			tableConfig,
      // 			queryConfig: {
      // 				...config,
      // 				where: undefined,
      // 				orderBy: undefined,
      // 				limit: undefined,
      // 				offset: undefined,
      // 				with: manyRelations.slice(1).reduce<NonNullable<typeof config['with']>>(
      // 					(result, { tsKey, queryConfig: configValue }) => {
      // 						result[tsKey] = configValue;
      // 						return result;
      // 					},
      // 					{},
      // 				),
      // 			},
      // 			tableAlias,
      // 		});
      // 		selectedRelations.push({
      // 			dbKey: selectedRelationTsKey,
      // 			tsKey: selectedRelationTsKey,
      // 			field: builtRelationSelectionField,
      // 			relationTableTsKey: relationTableTsName,
      // 			isJson: true,
      // 			selection: builtRelationJoin.selection,
      // 		});
      // 		// selection = builtTableFrom.selection.map((item) =>
      // 		// 	is(item.field, SQL.Aliased)
      // 		// 		? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
      // 		// 		: item
      // 		// );
      // 		// selectionForBuild = [{
      // 		// 	dbKey: '*',
      // 		// 	tsKey: '*',
      // 		// 	field: sql`${sql.identifier(tableAlias)}.*`,
      // 		// 	selection: [],
      // 		// 	isJson: false,
      // 		// 	relationTableTsKey: undefined,
      // 		// }];
      // 		// const newSelectionItem: (typeof selection)[number] = {
      // 		// 	dbKey: selectedRelationTsKey,
      // 		// 	tsKey: selectedRelationTsKey,
      // 		// 	field,
      // 		// 	relationTableTsKey: relationTableTsName,
      // 		// 	isJson: true,
      // 		// 	selection: builtRelationJoin.selection,
      // 		// };
      // 		// selection.push(newSelectionItem);
      // 		// selectionForBuild.push(newSelectionItem);
      // 		tableFrom = is(builtTableFrom.sql, PgTable)
      // 			? builtTableFrom.sql
      // 			: new Subquery(builtTableFrom.sql, {}, tableAlias);
      // 	}
      // 	if (selectedColumns.length === 0 && selectedRelations.length === 0 && selectedExtras.length === 0) {
      // 		throw new DrizzleError(`No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")`);
      // 	}
      // 	let selection: BuildRelationalQueryResult<PgTable, PgColumn>['selection'];
      // 	function prepareSelectedColumns() {
      // 		return selectedColumns.map((key) => ({
      // 			dbKey: tableConfig.columns[key]!.name,
      // 			tsKey: key,
      // 			field: tableConfig.columns[key] as PgColumn,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 	}
      // 	function prepareSelectedExtras() {
      // 		return selectedExtras.map((item) => ({
      // 			dbKey: item.value.fieldAlias,
      // 			tsKey: item.tsKey,
      // 			field: item.value,
      // 			relationTableTsKey: undefined,
      // 			isJson: false,
      // 			selection: [],
      // 		}));
      // 	}
      // 	if (isRoot) {
      // 		selection = [
      // 			...prepareSelectedColumns(),
      // 			...prepareSelectedExtras(),
      // 		];
      // 	}
      // 	if (hasUserDefinedWhere || orderBy.length > 0) {
      // 		tableFrom = new Subquery(
      // 			this.buildSelectQuery({
      // 				table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
      // 				fields: {},
      // 				fieldsFlat: selectionForBuild.map(({ field }) => ({
      // 					path: [],
      // 					field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
      // 				})),
      // 				joins,
      // 				distinct,
      // 			}),
      // 			{},
      // 			tableAlias,
      // 		);
      // 		selectionForBuild = selection.map((item) =>
      // 			is(item.field, SQL.Aliased)
      // 				? { ...item, field: sql`${sql.identifier(tableAlias)}.${sql.identifier(item.field.fieldAlias)}` }
      // 				: item
      // 		);
      // 		joins = [];
      // 		distinct = undefined;
      // 	}
      // 	const result = this.buildSelectQuery({
      // 		table: is(tableFrom, PgTable) ? aliasedTable(tableFrom, tableAlias) : tableFrom,
      // 		fields: {},
      // 		fieldsFlat: selectionForBuild.map(({ field }) => ({
      // 			path: [],
      // 			field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field,
      // 		})),
      // 		where,
      // 		limit,
      // 		offset,
      // 		joins,
      // 		orderBy,
      // 		distinct,
      // 	});
      // 	return {
      // 		tableTsKey: tableConfig.tsName,
      // 		sql: result,
      // 		selection,
      // 	};
      // }
      buildRelationalQueryWithoutPK({
        fullSchema,
        schema,
        tableNamesMap,
        table,
        tableConfig,
        queryConfig: config,
        tableAlias,
        nestedQueryRelation,
        joinOn
      }) {
        let selection = [];
        let limit, offset, orderBy = [], where;
        const joins = [];
        if (config === true) {
          const selectionEntries = Object.entries(tableConfig.columns);
          selection = selectionEntries.map(([key, value]) => ({
            dbKey: value.name,
            tsKey: key,
            field: aliasedTableColumn(value, tableAlias),
            relationTableTsKey: void 0,
            isJson: false,
            selection: []
          }));
        } else {
          const aliasedColumns = Object.fromEntries(
            Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)])
          );
          if (config.where) {
            const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
            where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
          }
          const fieldsSelection = [];
          let selectedColumns = [];
          if (config.columns) {
            let isIncludeMode = false;
            for (const [field, value] of Object.entries(config.columns)) {
              if (value === void 0) {
                continue;
              }
              if (field in tableConfig.columns) {
                if (!isIncludeMode && value === true) {
                  isIncludeMode = true;
                }
                selectedColumns.push(field);
              }
            }
            if (selectedColumns.length > 0) {
              selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
            }
          } else {
            selectedColumns = Object.keys(tableConfig.columns);
          }
          for (const field of selectedColumns) {
            const column = tableConfig.columns[field];
            fieldsSelection.push({ tsKey: field, value: column });
          }
          let selectedRelations = [];
          if (config.with) {
            selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig2]) => ({ tsKey, queryConfig: queryConfig2, relation: tableConfig.relations[tsKey] }));
          }
          let extras;
          if (config.extras) {
            extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
            for (const [tsKey, value] of Object.entries(extras)) {
              fieldsSelection.push({
                tsKey,
                value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
              });
            }
          }
          for (const { tsKey, value } of fieldsSelection) {
            selection.push({
              dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
              tsKey,
              field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
              relationTableTsKey: void 0,
              isJson: false,
              selection: []
            });
          }
          let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
          if (!Array.isArray(orderByOrig)) {
            orderByOrig = [orderByOrig];
          }
          orderBy = orderByOrig.map((orderByValue) => {
            if (is(orderByValue, Column)) {
              return aliasedTableColumn(orderByValue, tableAlias);
            }
            return mapColumnsInSQLToAlias(orderByValue, tableAlias);
          });
          limit = config.limit;
          offset = config.offset;
          for (const {
            tsKey: selectedRelationTsKey,
            queryConfig: selectedRelationConfigValue,
            relation
          } of selectedRelations) {
            const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
            const relationTableName = getTableUniqueName(relation.referencedTable);
            const relationTableTsName = tableNamesMap[relationTableName];
            const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
            const joinOn2 = and(
              ...normalizedRelation.fields.map(
                (field2, i) => eq(
                  aliasedTableColumn(normalizedRelation.references[i], relationTableAlias),
                  aliasedTableColumn(field2, tableAlias)
                )
              )
            );
            const builtRelation = this.buildRelationalQueryWithoutPK({
              fullSchema,
              schema,
              tableNamesMap,
              table: fullSchema[relationTableTsName],
              tableConfig: schema[relationTableTsName],
              queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
              tableAlias: relationTableAlias,
              joinOn: joinOn2,
              nestedQueryRelation: relation
            });
            const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier("data")}`.as(selectedRelationTsKey);
            joins.push({
              on: sql`true`,
              table: new Subquery(builtRelation.sql, {}, relationTableAlias),
              alias: relationTableAlias,
              joinType: "left",
              lateral: true
            });
            selection.push({
              dbKey: selectedRelationTsKey,
              tsKey: selectedRelationTsKey,
              field,
              relationTableTsKey: relationTableTsName,
              isJson: true,
              selection: builtRelation.selection
            });
          }
        }
        if (selection.length === 0) {
          throw new DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")` });
        }
        let result;
        where = and(joinOn, where);
        if (nestedQueryRelation) {
          let field = sql`json_build_array(${sql.join(
            selection.map(
              ({ field: field2, tsKey, isJson }) => isJson ? sql`${sql.identifier(`${tableAlias}_${tsKey}`)}.${sql.identifier("data")}` : is(field2, SQL.Aliased) ? field2.sql : field2
            ),
            sql`, `
          )})`;
          if (is(nestedQueryRelation, Many)) {
            field = sql`coalesce(json_agg(${field}${orderBy.length > 0 ? sql` order by ${sql.join(orderBy, sql`, `)}` : void 0}), '[]'::json)`;
          }
          const nestedSelection = [{
            dbKey: "data",
            tsKey: "data",
            field: field.as("data"),
            isJson: true,
            relationTableTsKey: tableConfig.tsName,
            selection
          }];
          const needsSubquery = limit !== void 0 || offset !== void 0 || orderBy.length > 0;
          if (needsSubquery) {
            result = this.buildSelectQuery({
              table: aliasedTable(table, tableAlias),
              fields: {},
              fieldsFlat: [{
                path: [],
                field: sql.raw("*")
              }],
              where,
              limit,
              offset,
              orderBy,
              setOperators: []
            });
            where = void 0;
            limit = void 0;
            offset = void 0;
            orderBy = [];
          } else {
            result = aliasedTable(table, tableAlias);
          }
          result = this.buildSelectQuery({
            table: is(result, PgTable) ? result : new Subquery(result, {}, tableAlias),
            fields: {},
            fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
              path: [],
              field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        } else {
          result = this.buildSelectQuery({
            table: aliasedTable(table, tableAlias),
            fields: {},
            fieldsFlat: selection.map(({ field }) => ({
              path: [],
              field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
            })),
            joins,
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
        }
        return {
          tableTsKey: tableConfig.tsName,
          sql: result,
          selection
        };
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/query-builders/query-builder.js
var TypedQueryBuilder;
var init_query_builder = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/query-builders/query-builder.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    TypedQueryBuilder = class {
      static {
        __name(this, "TypedQueryBuilder");
      }
      static [entityKind] = "TypedQueryBuilder";
      /** @internal */
      getSelectedFields() {
        return this._.selectedFields;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/select.js
function createSetOperator(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error(
          "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
        );
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
var PgSelectBuilder, PgSelectQueryBuilderBase, PgSelectBase, getPgSetOperators, union, unionAll, intersect, intersectAll, except, exceptAll;
var init_select2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/select.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_view_base();
    init_query_builder();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_table();
    init_tracing();
    init_utils();
    init_utils();
    init_view_common();
    PgSelectBuilder = class {
      static {
        __name(this, "PgSelectBuilder");
      }
      static [entityKind] = "PgSelectBuilder";
      fields;
      session;
      dialect;
      withList = [];
      distinct;
      constructor(config) {
        this.fields = config.fields;
        this.session = config.session;
        this.dialect = config.dialect;
        if (config.withList) {
          this.withList = config.withList;
        }
        this.distinct = config.distinct;
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      /**
       * Specify the table, subquery, or other target that you're
       * building a select query against.
       *
       * {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FROM | Postgres from documentation}
       */
      from(source) {
        const isPartialSelect = !!this.fields;
        const src = source;
        let fields;
        if (this.fields) {
          fields = this.fields;
        } else if (is(src, Subquery)) {
          fields = Object.fromEntries(
            Object.keys(src._.selectedFields).map((key) => [key, src[key]])
          );
        } else if (is(src, PgViewBase)) {
          fields = src[ViewBaseConfig].selectedFields;
        } else if (is(src, SQL)) {
          fields = {};
        } else {
          fields = getTableColumns(src);
        }
        return new PgSelectBase({
          table: src,
          fields,
          isPartialSelect,
          session: this.session,
          dialect: this.dialect,
          withList: this.withList,
          distinct: this.distinct
        }).setToken(this.authToken);
      }
    };
    PgSelectQueryBuilderBase = class extends TypedQueryBuilder {
      static {
        __name(this, "PgSelectQueryBuilderBase");
      }
      static [entityKind] = "PgSelectQueryBuilder";
      _;
      config;
      joinsNotNullableMap;
      tableName;
      isPartialSelect;
      session;
      dialect;
      constructor({ table, fields, isPartialSelect, session, dialect: dialect2, withList, distinct }) {
        super();
        this.config = {
          withList,
          table,
          fields: { ...fields },
          distinct,
          setOperators: []
        };
        this.isPartialSelect = isPartialSelect;
        this.session = session;
        this.dialect = dialect2;
        this._ = {
          selectedFields: fields
        };
        this.tableName = getTableLikeName(table);
        this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
      }
      createJoin(joinType, lateral) {
        return (table, on) => {
          const baseTableName = this.tableName;
          const tableName = getTableLikeName(table);
          if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
            throw new Error(`Alias "${tableName}" is already used in this query`);
          }
          if (!this.isPartialSelect) {
            if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
              this.config.fields = {
                [baseTableName]: this.config.fields
              };
            }
            if (typeof tableName === "string" && !is(table, SQL)) {
              const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
              this.config.fields[tableName] = selection;
            }
          }
          if (typeof on === "function") {
            on = on(
              new Proxy(
                this.config.fields,
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              )
            );
          }
          if (!this.config.joins) {
            this.config.joins = [];
          }
          this.config.joins.push({ on, table, joinType, alias: tableName, lateral });
          if (typeof tableName === "string") {
            switch (joinType) {
              case "left": {
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
              case "right": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "cross":
              case "inner": {
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "full": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
            }
          }
          return this;
        };
      }
      /**
       * Executes a `left join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .leftJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      leftJoin = this.createJoin("left", false);
      /**
       * Executes a `left join lateral` operation by adding subquery to the current query.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#left-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      leftJoinLateral = this.createJoin("left", true);
      /**
       * Executes a `right join` operation by adding another table to the current query.
       *
       * Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .rightJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      rightJoin = this.createJoin("right", false);
      /**
       * Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .innerJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      innerJoin = this.createJoin("inner", false);
      /**
       * Executes an `inner join lateral` operation, creating a new table by combining rows from two queries that have matching values.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#inner-join-lateral}
       *
       * @param table the subquery to join.
       * @param on the `on` clause.
       */
      innerJoinLateral = this.createJoin("inner", true);
      /**
       * Executes a `full join` operation by combining rows from two tables into a new table.
       *
       * Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
       *
       * @param table the table to join.
       * @param on the `on` clause.
       *
       * @example
       *
       * ```ts
       * // Select all users and their pets
       * const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
       *   .from(users)
       *   .fullJoin(pets, eq(users.id, pets.ownerId))
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .fullJoin(pets, eq(users.id, pets.ownerId))
       * ```
       */
      fullJoin = this.createJoin("full", false);
      /**
       * Executes a `cross join` operation by combining rows from two tables into a new table.
       *
       * Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
       *
       * @param table the table to join.
       *
       * @example
       *
       * ```ts
       * // Select all users, each user with every pet
       * const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
       *   .from(users)
       *   .crossJoin(pets)
       *
       * // Select userId and petId
       * const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
       *   userId: users.id,
       *   petId: pets.id,
       * })
       *   .from(users)
       *   .crossJoin(pets)
       * ```
       */
      crossJoin = this.createJoin("cross", false);
      /**
       * Executes a `cross join lateral` operation by combining rows from two queries into a new table.
       *
       * A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
       *
       * Calling this method retrieves all rows from both main and joined queries, merging all rows from each query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/joins#cross-join-lateral}
       *
       * @param table the query to join.
       */
      crossJoinLateral = this.createJoin("cross", true);
      createSetOperator(type, isAll) {
        return (rightSelection) => {
          const rightSelect = typeof rightSelection === "function" ? rightSelection(getPgSetOperators()) : rightSelection;
          if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
            throw new Error(
              "Set operator error (union / intersect / except): selected fields are not the same or are in a different order"
            );
          }
          this.config.setOperators.push({ type, isAll, rightSelect });
          return this;
        };
      }
      /**
       * Adds `union` set operator to the query.
       *
       * Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
       *
       * @example
       *
       * ```ts
       * // Select all unique names from customers and users tables
       * await db.select({ name: users.name })
       *   .from(users)
       *   .union(
       *     db.select({ name: customers.name }).from(customers)
       *   );
       * // or
       * import { union } from 'drizzle-orm/pg-core'
       *
       * await union(
       *   db.select({ name: users.name }).from(users),
       *   db.select({ name: customers.name }).from(customers)
       * );
       * ```
       */
      union = this.createSetOperator("union", false);
      /**
       * Adds `union all` set operator to the query.
       *
       * Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
       *
       * @example
       *
       * ```ts
       * // Select all transaction ids from both online and in-store sales
       * await db.select({ transaction: onlineSales.transactionId })
       *   .from(onlineSales)
       *   .unionAll(
       *     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       *   );
       * // or
       * import { unionAll } from 'drizzle-orm/pg-core'
       *
       * await unionAll(
       *   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
       *   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
       * );
       * ```
       */
      unionAll = this.createSetOperator("union", true);
      /**
       * Adds `intersect` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
       *
       * @example
       *
       * ```ts
       * // Select course names that are offered in both departments A and B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .intersect(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { intersect } from 'drizzle-orm/pg-core'
       *
       * await intersect(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      intersect = this.createSetOperator("intersect", false);
      /**
       * Adds `intersect all` set operator to the query.
       *
       * Calling this method will retain only the rows that are present in both result sets including all duplicates.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect-all}
       *
       * @example
       *
       * ```ts
       * // Select all products and quantities that are ordered by both regular and VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered
       * })
       * .from(regularCustomerOrders)
       * .intersectAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { intersectAll } from 'drizzle-orm/pg-core'
       *
       * await intersectAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      intersectAll = this.createSetOperator("intersect", true);
      /**
       * Adds `except` set operator to the query.
       *
       * Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
       *
       * @example
       *
       * ```ts
       * // Select all courses offered in department A but not in department B
       * await db.select({ courseName: depA.courseName })
       *   .from(depA)
       *   .except(
       *     db.select({ courseName: depB.courseName }).from(depB)
       *   );
       * // or
       * import { except } from 'drizzle-orm/pg-core'
       *
       * await except(
       *   db.select({ courseName: depA.courseName }).from(depA),
       *   db.select({ courseName: depB.courseName }).from(depB)
       * );
       * ```
       */
      except = this.createSetOperator("except", false);
      /**
       * Adds `except all` set operator to the query.
       *
       * Calling this method will retrieve all rows from the left query, except for the rows that are present in the result set of the right query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/set-operations#except-all}
       *
       * @example
       *
       * ```ts
       * // Select all products that are ordered by regular customers but not by VIP customers
       * await db.select({
       *   productId: regularCustomerOrders.productId,
       *   quantityOrdered: regularCustomerOrders.quantityOrdered,
       * })
       * .from(regularCustomerOrders)
       * .exceptAll(
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered,
       *   })
       *   .from(vipCustomerOrders)
       * );
       * // or
       * import { exceptAll } from 'drizzle-orm/pg-core'
       *
       * await exceptAll(
       *   db.select({
       *     productId: regularCustomerOrders.productId,
       *     quantityOrdered: regularCustomerOrders.quantityOrdered
       *   })
       *   .from(regularCustomerOrders),
       *   db.select({
       *     productId: vipCustomerOrders.productId,
       *     quantityOrdered: vipCustomerOrders.quantityOrdered
       *   })
       *   .from(vipCustomerOrders)
       * );
       * ```
       */
      exceptAll = this.createSetOperator("except", true);
      /** @internal */
      addSetOperators(setOperators) {
        this.config.setOperators.push(...setOperators);
        return this;
      }
      /**
       * Adds a `where` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#filtering}
       *
       * @param where the `where` clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be selected.
       *
       * ```ts
       * // Select all cars with green color
       * await db.select().from(cars).where(eq(cars.color, 'green'));
       * // or
       * await db.select().from(cars).where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Select all BMW cars with a green color
       * await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Select all cars with the green or blue color
       * await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        if (typeof where === "function") {
          where = where(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.where = where;
        return this;
      }
      /**
       * Adds a `having` clause to the query.
       *
       * Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
       *
       * @param having the `having` clause.
       *
       * @example
       *
       * ```ts
       * // Select all brands with more than one car
       * await db.select({
       * 	brand: cars.brand,
       * 	count: sql<number>`cast(count(${cars.id}) as int)`,
       * })
       *   .from(cars)
       *   .groupBy(cars.brand)
       *   .having(({ count }) => gt(count, 1));
       * ```
       */
      having(having) {
        if (typeof having === "function") {
          having = having(
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
            )
          );
        }
        this.config.having = having;
        return this;
      }
      groupBy(...columns) {
        if (typeof columns[0] === "function") {
          const groupBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
        } else {
          this.config.groupBy = columns;
        }
        return this;
      }
      orderBy(...columns) {
        if (typeof columns[0] === "function") {
          const orderBy = columns[0](
            new Proxy(
              this.config.fields,
              new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })
            )
          );
          const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        } else {
          const orderByArray = columns;
          if (this.config.setOperators.length > 0) {
            this.config.setOperators.at(-1).orderBy = orderByArray;
          } else {
            this.config.orderBy = orderByArray;
          }
        }
        return this;
      }
      /**
       * Adds a `limit` clause to the query.
       *
       * Calling this method will set the maximum number of rows that will be returned by this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param limit the `limit` clause.
       *
       * @example
       *
       * ```ts
       * // Get the first 10 people from this query.
       * await db.select().from(people).limit(10);
       * ```
       */
      limit(limit) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).limit = limit;
        } else {
          this.config.limit = limit;
        }
        return this;
      }
      /**
       * Adds an `offset` clause to the query.
       *
       * Calling this method will skip a number of rows when returning results from this query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
       *
       * @param offset the `offset` clause.
       *
       * @example
       *
       * ```ts
       * // Get the 10th-20th people from this query.
       * await db.select().from(people).offset(10).limit(10);
       * ```
       */
      offset(offset) {
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).offset = offset;
        } else {
          this.config.offset = offset;
        }
        return this;
      }
      /**
       * Adds a `for` clause to the query.
       *
       * Calling this method will specify a lock strength for this query that controls how strictly it acquires exclusive access to the rows being queried.
       *
       * See docs: {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FOR-UPDATE-SHARE}
       *
       * @param strength the lock strength.
       * @param config the lock configuration.
       */
      for(strength, config = {}) {
        this.config.lockingClause = { strength, config };
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildSelectQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      as(alias) {
        return new Proxy(
          new Subquery(this.getSQL(), this.config.fields, alias),
          new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      /** @internal */
      getSelectedFields() {
        return new Proxy(
          this.config.fields,
          new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
        );
      }
      $dynamic() {
        return this;
      }
    };
    PgSelectBase = class extends PgSelectQueryBuilderBase {
      static {
        __name(this, "PgSelectBase");
      }
      static [entityKind] = "PgSelect";
      /** @internal */
      _prepare(name) {
        const { session, config, dialect: dialect2, joinsNotNullableMap, authToken } = this;
        if (!session) {
          throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
        }
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          const fieldsList = orderSelectedFields(config.fields);
          const query = session.prepareQuery(dialect2.sqlToQuery(this.getSQL()), fieldsList, name, true);
          query.joinsNotNullableMap = joinsNotNullableMap;
          return query.setToken(authToken);
        });
      }
      /**
       * Create a prepared statement for this query. This allows
       * the database to remember this query for the given session
       * and call it by name, rather than specifying the full query.
       *
       * {@link https://www.postgresql.org/docs/current/sql-prepare.html | Postgres prepare documentation}
       */
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = /* @__PURE__ */ __name((placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      }, "execute");
    };
    applyMixins(PgSelectBase, [QueryPromise]);
    __name(createSetOperator, "createSetOperator");
    getPgSetOperators = /* @__PURE__ */ __name(() => ({
      union,
      unionAll,
      intersect,
      intersectAll,
      except,
      exceptAll
    }), "getPgSetOperators");
    union = createSetOperator("union", false);
    unionAll = createSetOperator("union", true);
    intersect = createSetOperator("intersect", false);
    intersectAll = createSetOperator("intersect", true);
    except = createSetOperator("except", false);
    exceptAll = createSetOperator("except", true);
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/query-builder.js
var QueryBuilder;
var init_query_builder2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/query-builder.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_dialect();
    init_selection_proxy();
    init_subquery();
    init_select2();
    QueryBuilder = class {
      static {
        __name(this, "QueryBuilder");
      }
      static [entityKind] = "PgQueryBuilder";
      dialect;
      dialectConfig;
      constructor(dialect2) {
        this.dialect = is(dialect2, PgDialect) ? dialect2 : void 0;
        this.dialectConfig = is(dialect2, PgDialect) ? void 0 : dialect2;
      }
      $with = /* @__PURE__ */ __name((alias, selection) => {
        const queryBuilder = this;
        const as = /* @__PURE__ */ __name((qb) => {
          if (typeof qb === "function") {
            qb = qb(queryBuilder);
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        }, "as");
        return { as };
      }, "$with");
      with(...queries) {
        const self = this;
        function select(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            withList: queries
          });
        }
        __name(select, "select");
        function selectDistinct(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            distinct: true
          });
        }
        __name(selectDistinct, "selectDistinct");
        function selectDistinctOn(on, fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: void 0,
            dialect: self.getDialect(),
            distinct: { on }
          });
        }
        __name(selectDistinctOn, "selectDistinctOn");
        return { select, selectDistinct, selectDistinctOn };
      }
      select(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect()
        });
      }
      selectDistinct(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect(),
          distinct: true
        });
      }
      selectDistinctOn(on, fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: void 0,
          dialect: this.getDialect(),
          distinct: { on }
        });
      }
      // Lazy load dialect to avoid circular dependency
      getDialect() {
        if (!this.dialect) {
          this.dialect = new PgDialect(this.dialectConfig);
        }
        return this.dialect;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/insert.js
var PgInsertBuilder, PgInsertBase;
var init_insert = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/insert.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_table();
    init_tracing();
    init_utils();
    init_query_builder2();
    PgInsertBuilder = class {
      static {
        __name(this, "PgInsertBuilder");
      }
      constructor(table, session, dialect2, withList, overridingSystemValue_) {
        this.table = table;
        this.session = session;
        this.dialect = dialect2;
        this.withList = withList;
        this.overridingSystemValue_ = overridingSystemValue_;
      }
      static [entityKind] = "PgInsertBuilder";
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      overridingSystemValue() {
        this.overridingSystemValue_ = true;
        return this;
      }
      values(values) {
        values = Array.isArray(values) ? values : [values];
        if (values.length === 0) {
          throw new Error("values() must be called with at least one value");
        }
        const mappedValues = values.map((entry) => {
          const result = {};
          const cols = this.table[Table.Symbol.Columns];
          for (const colKey of Object.keys(entry)) {
            const colValue = entry[colKey];
            result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
          }
          return result;
        });
        return new PgInsertBase(
          this.table,
          mappedValues,
          this.session,
          this.dialect,
          this.withList,
          false,
          this.overridingSystemValue_
        ).setToken(this.authToken);
      }
      select(selectQuery) {
        const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder()) : selectQuery;
        if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) {
          throw new Error(
            "Insert select error: selected fields are not the same or are in a different order compared to the table definition"
          );
        }
        return new PgInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
      }
    };
    PgInsertBase = class extends QueryPromise {
      static {
        __name(this, "PgInsertBase");
      }
      constructor(table, values, session, dialect2, withList, select, overridingSystemValue_) {
        super();
        this.session = session;
        this.dialect = dialect2;
        this.config = { table, values, withList, select, overridingSystemValue_ };
      }
      static [entityKind] = "PgInsert";
      config;
      returning(fields = this.config.table[Table.Symbol.Columns]) {
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /**
       * Adds an `on conflict do nothing` clause to the query.
       *
       * Calling this method simply avoids inserting a row as its alternative action.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
       *
       * @param config The `target` and `where` clauses.
       *
       * @example
       * ```ts
       * // Insert one row and cancel the insert if there's a conflict
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoNothing();
       *
       * // Explicitly specify conflict target
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoNothing({ target: cars.id });
       * ```
       */
      onConflictDoNothing(config = {}) {
        if (config.target === void 0) {
          this.config.onConflict = sql`do nothing`;
        } else {
          let targetColumn = "";
          targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
          const whereSql = config.where ? sql` where ${config.where}` : void 0;
          this.config.onConflict = sql`(${sql.raw(targetColumn)})${whereSql} do nothing`;
        }
        return this;
      }
      /**
       * Adds an `on conflict do update` clause to the query.
       *
       * Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
       *
       * @param config The `target`, `set` and `where` clauses.
       *
       * @example
       * ```ts
       * // Update the row if there's a conflict
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoUpdate({
       *     target: cars.id,
       *     set: { brand: 'Porsche' }
       *   });
       *
       * // Upsert with 'where' clause
       * await db.insert(cars)
       *   .values({ id: 1, brand: 'BMW' })
       *   .onConflictDoUpdate({
       *     target: cars.id,
       *     set: { brand: 'newBMW' },
       *     targetWhere: sql`${cars.createdAt} > '2023-01-01'::date`,
       *   });
       * ```
       */
      onConflictDoUpdate(config) {
        if (config.where && (config.targetWhere || config.setWhere)) {
          throw new Error(
            'You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.'
          );
        }
        const whereSql = config.where ? sql` where ${config.where}` : void 0;
        const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : void 0;
        const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : void 0;
        const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
        let targetColumn = "";
        targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
        this.config.onConflict = sql`(${sql.raw(targetColumn)})${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildInsertQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = /* @__PURE__ */ __name((placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      }, "execute");
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/refresh-materialized-view.js
var PgRefreshMaterializedView;
var init_refresh_materialized_view = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/refresh-materialized-view.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_promise();
    init_tracing();
    PgRefreshMaterializedView = class extends QueryPromise {
      static {
        __name(this, "PgRefreshMaterializedView");
      }
      constructor(view, session, dialect2) {
        super();
        this.session = session;
        this.dialect = dialect2;
        this.config = { view };
      }
      static [entityKind] = "PgRefreshMaterializedView";
      config;
      concurrently() {
        if (this.config.withNoData !== void 0) {
          throw new Error("Cannot use concurrently and withNoData together");
        }
        this.config.concurrently = true;
        return this;
      }
      withNoData() {
        if (this.config.concurrently !== void 0) {
          throw new Error("Cannot use concurrently and withNoData together");
        }
        this.config.withNoData = true;
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildRefreshMaterializedViewQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), void 0, name, true);
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = /* @__PURE__ */ __name((placeholderValues) => {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(placeholderValues, this.authToken);
        });
      }, "execute");
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/select.types.js
var init_select_types = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/select.types.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/update.js
var PgUpdateBuilder, PgUpdateBase;
var init_update = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/update.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table2();
    init_query_promise();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
    PgUpdateBuilder = class {
      static {
        __name(this, "PgUpdateBuilder");
      }
      constructor(table, session, dialect2, withList) {
        this.table = table;
        this.session = session;
        this.dialect = dialect2;
        this.withList = withList;
      }
      static [entityKind] = "PgUpdateBuilder";
      authToken;
      setToken(token) {
        this.authToken = token;
        return this;
      }
      set(values) {
        return new PgUpdateBase(
          this.table,
          mapUpdateSet(this.table, values),
          this.session,
          this.dialect,
          this.withList
        ).setToken(this.authToken);
      }
    };
    PgUpdateBase = class extends QueryPromise {
      static {
        __name(this, "PgUpdateBase");
      }
      constructor(table, set, session, dialect2, withList) {
        super();
        this.session = session;
        this.dialect = dialect2;
        this.config = { set, table, withList, joins: [] };
        this.tableName = getTableLikeName(table);
        this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
      }
      static [entityKind] = "PgUpdate";
      config;
      tableName;
      joinsNotNullableMap;
      from(source) {
        const src = source;
        const tableName = getTableLikeName(src);
        if (typeof tableName === "string") {
          this.joinsNotNullableMap[tableName] = true;
        }
        this.config.from = src;
        return this;
      }
      getTableLikeFields(table) {
        if (is(table, PgTable)) {
          return table[Table.Symbol.Columns];
        } else if (is(table, Subquery)) {
          return table._.selectedFields;
        }
        return table[ViewBaseConfig].selectedFields;
      }
      createJoin(joinType) {
        return (table, on) => {
          const tableName = getTableLikeName(table);
          if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) {
            throw new Error(`Alias "${tableName}" is already used in this query`);
          }
          if (typeof on === "function") {
            const from = this.config.from && !is(this.config.from, SQL) ? this.getTableLikeFields(this.config.from) : void 0;
            on = on(
              new Proxy(
                this.config.table[Table.Symbol.Columns],
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              ),
              from && new Proxy(
                from,
                new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })
              )
            );
          }
          this.config.joins.push({ on, table, joinType, alias: tableName });
          if (typeof tableName === "string") {
            switch (joinType) {
              case "left": {
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
              case "right": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "inner": {
                this.joinsNotNullableMap[tableName] = true;
                break;
              }
              case "full": {
                this.joinsNotNullableMap = Object.fromEntries(
                  Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false])
                );
                this.joinsNotNullableMap[tableName] = false;
                break;
              }
            }
          }
          return this;
        };
      }
      leftJoin = this.createJoin("left");
      rightJoin = this.createJoin("right");
      innerJoin = this.createJoin("inner");
      fullJoin = this.createJoin("full");
      /**
       * Adds a 'where' clause to the query.
       *
       * Calling this method will update only those rows that fulfill a specified condition.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param where the 'where' clause.
       *
       * @example
       * You can use conditional operators and `sql function` to filter the rows to be updated.
       *
       * ```ts
       * // Update all cars with green color
       * await db.update(cars).set({ color: 'red' })
       *   .where(eq(cars.color, 'green'));
       * // or
       * await db.update(cars).set({ color: 'red' })
       *   .where(sql`${cars.color} = 'green'`)
       * ```
       *
       * You can logically combine conditional operators with `and()` and `or()` operators:
       *
       * ```ts
       * // Update all BMW cars with a green color
       * await db.update(cars).set({ color: 'red' })
       *   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
       *
       * // Update all cars with the green or blue color
       * await db.update(cars).set({ color: 'red' })
       *   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
       * ```
       */
      where(where) {
        this.config.where = where;
        return this;
      }
      returning(fields) {
        if (!fields) {
          fields = Object.assign({}, this.config.table[Table.Symbol.Columns]);
          if (this.config.from) {
            const tableName = getTableLikeName(this.config.from);
            if (typeof tableName === "string" && this.config.from && !is(this.config.from, SQL)) {
              const fromFields = this.getTableLikeFields(this.config.from);
              fields[tableName] = fromFields;
            }
            for (const join of this.config.joins) {
              const tableName2 = getTableLikeName(join.table);
              if (typeof tableName2 === "string" && !is(join.table, SQL)) {
                const fromFields = this.getTableLikeFields(join.table);
                fields[tableName2] = fromFields;
              }
            }
          }
        }
        this.config.returningFields = fields;
        this.config.returning = orderSelectedFields(fields);
        return this;
      }
      /** @internal */
      getSQL() {
        return this.dialect.buildUpdateQuery(this.config);
      }
      toSQL() {
        const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
        return rest;
      }
      /** @internal */
      _prepare(name) {
        const query = this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true);
        query.joinsNotNullableMap = this.joinsNotNullableMap;
        return query;
      }
      prepare(name) {
        return this._prepare(name);
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute = /* @__PURE__ */ __name((placeholderValues) => {
        return this._prepare().execute(placeholderValues, this.authToken);
      }, "execute");
      /** @internal */
      getSelectedFields() {
        return this.config.returningFields ? new Proxy(
          this.config.returningFields,
          new SelectionProxyHandler({
            alias: getTableName(this.config.table),
            sqlAliasedBehavior: "alias",
            sqlBehavior: "error"
          })
        ) : void 0;
      }
      $dynamic() {
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/index.js
var init_query_builders = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_delete();
    init_insert();
    init_query_builder2();
    init_refresh_materialized_view();
    init_select2();
    init_select_types();
    init_update();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/count.js
var PgCountBuilder;
var init_count = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/count.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_sql();
    PgCountBuilder = class _PgCountBuilder extends SQL {
      static {
        __name(this, "PgCountBuilder");
      }
      constructor(params) {
        super(_PgCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
        this.params = params;
        this.mapWith(Number);
        this.session = params.session;
        this.sql = _PgCountBuilder.buildCount(
          params.source,
          params.filters
        );
      }
      sql;
      token;
      static [entityKind] = "PgCountBuilder";
      [Symbol.toStringTag] = "PgCountBuilder";
      session;
      static buildEmbeddedCount(source, filters) {
        return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
      }
      static buildCount(source, filters) {
        return sql`select count(*) as count from ${source}${sql.raw(" where ").if(filters)}${filters};`;
      }
      /** @intrnal */
      setToken(token) {
        this.token = token;
        return this;
      }
      then(onfulfilled, onrejected) {
        return Promise.resolve(this.session.count(this.sql, this.token)).then(
          onfulfilled,
          onrejected
        );
      }
      catch(onRejected) {
        return this.then(void 0, onRejected);
      }
      finally(onFinally) {
        return this.then(
          (value) => {
            onFinally?.();
            return value;
          },
          (reason) => {
            onFinally?.();
            throw reason;
          }
        );
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/query.js
var RelationalQueryBuilder, PgRelationalQuery;
var init_query = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/query.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_promise();
    init_relations();
    init_tracing();
    RelationalQueryBuilder = class {
      static {
        __name(this, "RelationalQueryBuilder");
      }
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect2, session) {
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect2;
        this.session = session;
      }
      static [entityKind] = "PgRelationalQueryBuilder";
      findMany(config) {
        return new PgRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? config : {},
          "many"
        );
      }
      findFirst(config) {
        return new PgRelationalQuery(
          this.fullSchema,
          this.schema,
          this.tableNamesMap,
          this.table,
          this.tableConfig,
          this.dialect,
          this.session,
          config ? { ...config, limit: 1 } : { limit: 1 },
          "first"
        );
      }
    };
    PgRelationalQuery = class extends QueryPromise {
      static {
        __name(this, "PgRelationalQuery");
      }
      constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect2, session, config, mode) {
        super();
        this.fullSchema = fullSchema;
        this.schema = schema;
        this.tableNamesMap = tableNamesMap;
        this.table = table;
        this.tableConfig = tableConfig;
        this.dialect = dialect2;
        this.session = session;
        this.config = config;
        this.mode = mode;
      }
      static [entityKind] = "PgRelationalQuery";
      /** @internal */
      _prepare(name) {
        return tracer.startActiveSpan("drizzle.prepareQuery", () => {
          const { query, builtQuery } = this._toSQL();
          return this.session.prepareQuery(
            builtQuery,
            void 0,
            name,
            true,
            (rawRows, mapColumnValue) => {
              const rows = rawRows.map(
                (row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue)
              );
              if (this.mode === "first") {
                return rows[0];
              }
              return rows;
            }
          );
        });
      }
      prepare(name) {
        return this._prepare(name);
      }
      _getQuery() {
        return this.dialect.buildRelationalQueryWithoutPK({
          fullSchema: this.fullSchema,
          schema: this.schema,
          tableNamesMap: this.tableNamesMap,
          table: this.table,
          tableConfig: this.tableConfig,
          queryConfig: this.config,
          tableAlias: this.tableConfig.tsName
        });
      }
      /** @internal */
      getSQL() {
        return this._getQuery().sql;
      }
      _toSQL() {
        const query = this._getQuery();
        const builtQuery = this.dialect.sqlToQuery(query.sql);
        return { query, builtQuery };
      }
      toSQL() {
        return this._toSQL().builtQuery;
      }
      authToken;
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      execute() {
        return tracer.startActiveSpan("drizzle.operation", () => {
          return this._prepare().execute(void 0, this.authToken);
        });
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/raw.js
var PgRaw;
var init_raw = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/query-builders/raw.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_promise();
    PgRaw = class extends QueryPromise {
      static {
        __name(this, "PgRaw");
      }
      constructor(execute, sql4, query, mapBatchResult) {
        super();
        this.execute = execute;
        this.sql = sql4;
        this.query = query;
        this.mapBatchResult = mapBatchResult;
      }
      static [entityKind] = "PgRaw";
      /** @internal */
      getSQL() {
        return this.sql;
      }
      getQuery() {
        return this.query;
      }
      mapResult(result, isFromBatch) {
        return isFromBatch ? this.mapBatchResult(result) : result;
      }
      _prepare() {
        return this;
      }
      /** @internal */
      isResponseInArrayMode() {
        return false;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/db.js
var PgDatabase;
var init_db = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/db.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_query_builders();
    init_selection_proxy();
    init_sql();
    init_subquery();
    init_count();
    init_query();
    init_raw();
    init_refresh_materialized_view();
    PgDatabase = class {
      static {
        __name(this, "PgDatabase");
      }
      constructor(dialect2, session, schema) {
        this.dialect = dialect2;
        this.session = session;
        this._ = schema ? {
          schema: schema.schema,
          fullSchema: schema.fullSchema,
          tableNamesMap: schema.tableNamesMap,
          session
        } : {
          schema: void 0,
          fullSchema: {},
          tableNamesMap: {},
          session
        };
        this.query = {};
        if (this._.schema) {
          for (const [tableName, columns] of Object.entries(this._.schema)) {
            this.query[tableName] = new RelationalQueryBuilder(
              schema.fullSchema,
              this._.schema,
              this._.tableNamesMap,
              schema.fullSchema[tableName],
              columns,
              dialect2,
              session
            );
          }
        }
      }
      static [entityKind] = "PgDatabase";
      query;
      /**
       * Creates a subquery that defines a temporary named result set as a CTE.
       *
       * It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param alias The alias for the subquery.
       *
       * Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
       *
       * @example
       *
       * ```ts
       * // Create a subquery with alias 'sq' and use it in the select query
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * const result = await db.with(sq).select().from(sq);
       * ```
       *
       * To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
       *
       * ```ts
       * // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
       * const sq = db.$with('sq').as(db.select({
       *   name: sql<string>`upper(${users.name})`.as('name'),
       * })
       * .from(users));
       *
       * const result = await db.with(sq).select({ name: sq.name }).from(sq);
       * ```
       */
      $with = /* @__PURE__ */ __name((alias, selection) => {
        const self = this;
        const as = /* @__PURE__ */ __name((qb) => {
          if (typeof qb === "function") {
            qb = qb(new QueryBuilder(self.dialect));
          }
          return new Proxy(
            new WithSubquery(
              qb.getSQL(),
              selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}),
              alias,
              true
            ),
            new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" })
          );
        }, "as");
        return { as };
      }, "$with");
      $count(source, filters) {
        return new PgCountBuilder({ source, filters, session: this.session });
      }
      /**
       * Incorporates a previously defined CTE (using `$with`) into the main query.
       *
       * This method allows the main query to reference a temporary named result set.
       *
       * See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
       *
       * @param queries The CTEs to incorporate into the main query.
       *
       * @example
       *
       * ```ts
       * // Define a subquery 'sq' as a CTE using $with
       * const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
       *
       * // Incorporate the CTE 'sq' into the main query and select from it
       * const result = await db.with(sq).select().from(sq);
       * ```
       */
      with(...queries) {
        const self = this;
        function select(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries
          });
        }
        __name(select, "select");
        function selectDistinct(fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries,
            distinct: true
          });
        }
        __name(selectDistinct, "selectDistinct");
        function selectDistinctOn(on, fields) {
          return new PgSelectBuilder({
            fields: fields ?? void 0,
            session: self.session,
            dialect: self.dialect,
            withList: queries,
            distinct: { on }
          });
        }
        __name(selectDistinctOn, "selectDistinctOn");
        function update(table) {
          return new PgUpdateBuilder(table, self.session, self.dialect, queries);
        }
        __name(update, "update");
        function insert(table) {
          return new PgInsertBuilder(table, self.session, self.dialect, queries);
        }
        __name(insert, "insert");
        function delete_(table) {
          return new PgDeleteBase(table, self.session, self.dialect, queries);
        }
        __name(delete_, "delete_");
        return { select, selectDistinct, selectDistinctOn, update, insert, delete: delete_ };
      }
      select(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect
        });
      }
      selectDistinct(fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect,
          distinct: true
        });
      }
      selectDistinctOn(on, fields) {
        return new PgSelectBuilder({
          fields: fields ?? void 0,
          session: this.session,
          dialect: this.dialect,
          distinct: { on }
        });
      }
      /**
       * Creates an update query.
       *
       * Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
       *
       * Use `.set()` method to specify which values to update.
       *
       * See docs: {@link https://orm.drizzle.team/docs/update}
       *
       * @param table The table to update.
       *
       * @example
       *
       * ```ts
       * // Update all rows in the 'cars' table
       * await db.update(cars).set({ color: 'red' });
       *
       * // Update rows with filters and conditions
       * await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
       *
       * // Update with returning clause
       * const updatedCar: Car[] = await db.update(cars)
       *   .set({ color: 'red' })
       *   .where(eq(cars.id, 1))
       *   .returning();
       * ```
       */
      update(table) {
        return new PgUpdateBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates an insert query.
       *
       * Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
       *
       * See docs: {@link https://orm.drizzle.team/docs/insert}
       *
       * @param table The table to insert into.
       *
       * @example
       *
       * ```ts
       * // Insert one row
       * await db.insert(cars).values({ brand: 'BMW' });
       *
       * // Insert multiple rows
       * await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
       *
       * // Insert with returning clause
       * const insertedCar: Car[] = await db.insert(cars)
       *   .values({ brand: 'BMW' })
       *   .returning();
       * ```
       */
      insert(table) {
        return new PgInsertBuilder(table, this.session, this.dialect);
      }
      /**
       * Creates a delete query.
       *
       * Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
       *
       * See docs: {@link https://orm.drizzle.team/docs/delete}
       *
       * @param table The table to delete from.
       *
       * @example
       *
       * ```ts
       * // Delete all rows in the 'cars' table
       * await db.delete(cars);
       *
       * // Delete rows with filters and conditions
       * await db.delete(cars).where(eq(cars.color, 'green'));
       *
       * // Delete with returning clause
       * const deletedCar: Car[] = await db.delete(cars)
       *   .where(eq(cars.id, 1))
       *   .returning();
       * ```
       */
      delete(table) {
        return new PgDeleteBase(table, this.session, this.dialect);
      }
      refreshMaterializedView(view) {
        return new PgRefreshMaterializedView(view, this.session, this.dialect);
      }
      authToken;
      execute(query) {
        const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
        const builtQuery = this.dialect.sqlToQuery(sequel);
        const prepared = this.session.prepareQuery(
          builtQuery,
          void 0,
          void 0,
          false
        );
        return new PgRaw(
          () => prepared.execute(void 0, this.authToken),
          sequel,
          builtQuery,
          (result) => prepared.mapResult(result, true)
        );
      }
      transaction(transaction, config) {
        return this.session.transaction(transaction, config);
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/alias.js
var init_alias2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/alias.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/checks.js
var CheckBuilder, Check;
var init_checks = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/checks.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    CheckBuilder = class {
      static {
        __name(this, "CheckBuilder");
      }
      constructor(name, value) {
        this.name = name;
        this.value = value;
      }
      static [entityKind] = "PgCheckBuilder";
      brand;
      /** @internal */
      build(table) {
        return new Check(table, this);
      }
    };
    Check = class {
      static {
        __name(this, "Check");
      }
      constructor(table, builder) {
        this.table = table;
        this.name = builder.name;
        this.value = builder.value;
      }
      static [entityKind] = "PgCheck";
      name;
      value;
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/indexes.js
var IndexBuilderOn, IndexBuilder, Index;
var init_indexes = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/indexes.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_sql();
    init_entity();
    init_columns();
    IndexBuilderOn = class {
      static {
        __name(this, "IndexBuilderOn");
      }
      constructor(unique, name) {
        this.unique = unique;
        this.name = name;
      }
      static [entityKind] = "PgIndexBuilderOn";
      on(...columns) {
        return new IndexBuilder(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
            return clonedIndexedColumn;
          }),
          this.unique,
          false,
          this.name
        );
      }
      onOnly(...columns) {
        return new IndexBuilder(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = it.defaultConfig;
            return clonedIndexedColumn;
          }),
          this.unique,
          true,
          this.name
        );
      }
      /**
       * Specify what index method to use. Choices are `btree`, `hash`, `gist`, `spgist`, `gin`, `brin`, or user-installed access methods like `bloom`. The default method is `btree.
       *
       * If you have the `pg_vector` extension installed in your database, you can use the `hnsw` and `ivfflat` options, which are predefined types.
       *
       * **You can always specify any string you want in the method, in case Drizzle doesn't have it natively in its types**
       *
       * @param method The name of the index method to be used
       * @param columns
       * @returns
       */
      using(method, ...columns) {
        return new IndexBuilder(
          columns.map((it) => {
            if (is(it, SQL)) {
              return it;
            }
            it = it;
            const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
            it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
            return clonedIndexedColumn;
          }),
          this.unique,
          true,
          this.name,
          method
        );
      }
    };
    IndexBuilder = class {
      static {
        __name(this, "IndexBuilder");
      }
      static [entityKind] = "PgIndexBuilder";
      /** @internal */
      config;
      constructor(columns, unique, only, name, method = "btree") {
        this.config = {
          name,
          columns,
          unique,
          only,
          method
        };
      }
      concurrently() {
        this.config.concurrently = true;
        return this;
      }
      with(obj) {
        this.config.with = obj;
        return this;
      }
      where(condition) {
        this.config.where = condition;
        return this;
      }
      /** @internal */
      build(table) {
        return new Index(this.config, table);
      }
    };
    Index = class {
      static {
        __name(this, "Index");
      }
      static [entityKind] = "PgIndex";
      config;
      constructor(config, table) {
        this.config = { ...config, table };
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/policies.js
var PgPolicy;
var init_policies = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/policies.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    PgPolicy = class {
      static {
        __name(this, "PgPolicy");
      }
      constructor(name, config) {
        this.name = name;
        if (config) {
          this.as = config.as;
          this.for = config.for;
          this.to = config.to;
          this.using = config.using;
          this.withCheck = config.withCheck;
        }
      }
      static [entityKind] = "PgPolicy";
      as;
      for;
      to;
      using;
      withCheck;
      /** @internal */
      _linkedTable;
      link(table) {
        this._linkedTable = table;
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/roles.js
var PgRole;
var init_roles = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/roles.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    PgRole = class {
      static {
        __name(this, "PgRole");
      }
      constructor(name, config) {
        this.name = name;
        if (config) {
          this.createDb = config.createDb;
          this.createRole = config.createRole;
          this.inherit = config.inherit;
        }
      }
      static [entityKind] = "PgRole";
      /** @internal */
      _existing;
      /** @internal */
      createDb;
      /** @internal */
      createRole;
      /** @internal */
      inherit;
      existing() {
        this._existing = true;
        return this;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/sequence.js
function pgSequenceWithSchema(name, options, schema) {
  return new PgSequence(name, options, schema);
}
var PgSequence;
var init_sequence = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/sequence.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    PgSequence = class {
      static {
        __name(this, "PgSequence");
      }
      constructor(seqName, seqOptions, schema) {
        this.seqName = seqName;
        this.seqOptions = seqOptions;
        this.schema = schema;
      }
      static [entityKind] = "PgSequence";
    };
    __name(pgSequenceWithSchema, "pgSequenceWithSchema");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view-common.js
var PgViewConfig;
var init_view_common2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view-common.js"() {
    init_functionsRoutes_0_17677553668797852();
    PgViewConfig = /* @__PURE__ */ Symbol.for("drizzle:PgViewConfig");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view.js
function pgViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualViewBuilder(name, selection, schema);
  }
  return new ViewBuilder(name, schema);
}
function pgMaterializedViewWithSchema(name, selection, schema) {
  if (selection) {
    return new ManualMaterializedViewBuilder(name, selection, schema);
  }
  return new MaterializedViewBuilder(name, schema);
}
var DefaultViewBuilderCore, ViewBuilder, ManualViewBuilder, MaterializedViewBuilderCore, MaterializedViewBuilder, ManualMaterializedViewBuilder, PgView, PgMaterializedViewConfig, PgMaterializedView;
var init_view = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/view.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_selection_proxy();
    init_utils();
    init_query_builder2();
    init_table2();
    init_view_base();
    init_view_common2();
    DefaultViewBuilderCore = class {
      static {
        __name(this, "DefaultViewBuilderCore");
      }
      constructor(name, schema) {
        this.name = name;
        this.schema = schema;
      }
      static [entityKind] = "PgDefaultViewBuilderCore";
      config = {};
      with(config) {
        this.config.with = config;
        return this;
      }
    };
    ViewBuilder = class extends DefaultViewBuilderCore {
      static {
        __name(this, "ViewBuilder");
      }
      static [entityKind] = "PgViewBuilder";
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder());
        }
        const selectionProxy = new SelectionProxyHandler({
          alias: this.name,
          sqlBehavior: "error",
          sqlAliasedBehavior: "alias",
          replaceOriginalName: true
        });
        const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
        return new Proxy(
          new PgView({
            pgConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: aliasedSelection,
              query: qb.getSQL().inlineParams()
            }
          }),
          selectionProxy
        );
      }
    };
    ManualViewBuilder = class extends DefaultViewBuilderCore {
      static {
        __name(this, "ManualViewBuilder");
      }
      static [entityKind] = "PgManualViewBuilder";
      columns;
      constructor(name, columns, schema) {
        super(name, schema);
        this.columns = getTableColumns(pgTable(name, columns));
      }
      existing() {
        return new Proxy(
          new PgView({
            pgConfig: void 0,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: void 0
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
      as(query) {
        return new Proxy(
          new PgView({
            pgConfig: this.config,
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: query.inlineParams()
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
    };
    MaterializedViewBuilderCore = class {
      static {
        __name(this, "MaterializedViewBuilderCore");
      }
      constructor(name, schema) {
        this.name = name;
        this.schema = schema;
      }
      static [entityKind] = "PgMaterializedViewBuilderCore";
      config = {};
      using(using) {
        this.config.using = using;
        return this;
      }
      with(config) {
        this.config.with = config;
        return this;
      }
      tablespace(tablespace) {
        this.config.tablespace = tablespace;
        return this;
      }
      withNoData() {
        this.config.withNoData = true;
        return this;
      }
    };
    MaterializedViewBuilder = class extends MaterializedViewBuilderCore {
      static {
        __name(this, "MaterializedViewBuilder");
      }
      static [entityKind] = "PgMaterializedViewBuilder";
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder());
        }
        const selectionProxy = new SelectionProxyHandler({
          alias: this.name,
          sqlBehavior: "error",
          sqlAliasedBehavior: "alias",
          replaceOriginalName: true
        });
        const aliasedSelection = new Proxy(qb.getSelectedFields(), selectionProxy);
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              with: this.config.with,
              using: this.config.using,
              tablespace: this.config.tablespace,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: aliasedSelection,
              query: qb.getSQL().inlineParams()
            }
          }),
          selectionProxy
        );
      }
    };
    ManualMaterializedViewBuilder = class extends MaterializedViewBuilderCore {
      static {
        __name(this, "ManualMaterializedViewBuilder");
      }
      static [entityKind] = "PgManualMaterializedViewBuilder";
      columns;
      constructor(name, columns, schema) {
        super(name, schema);
        this.columns = getTableColumns(pgTable(name, columns));
      }
      existing() {
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              tablespace: this.config.tablespace,
              using: this.config.using,
              with: this.config.with,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: void 0
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
      as(query) {
        return new Proxy(
          new PgMaterializedView({
            pgConfig: {
              tablespace: this.config.tablespace,
              using: this.config.using,
              with: this.config.with,
              withNoData: this.config.withNoData
            },
            config: {
              name: this.name,
              schema: this.schema,
              selectedFields: this.columns,
              query: query.inlineParams()
            }
          }),
          new SelectionProxyHandler({
            alias: this.name,
            sqlBehavior: "error",
            sqlAliasedBehavior: "alias",
            replaceOriginalName: true
          })
        );
      }
    };
    PgView = class extends PgViewBase {
      static {
        __name(this, "PgView");
      }
      static [entityKind] = "PgView";
      [PgViewConfig];
      constructor({ pgConfig, config }) {
        super(config);
        if (pgConfig) {
          this[PgViewConfig] = {
            with: pgConfig.with
          };
        }
      }
    };
    PgMaterializedViewConfig = /* @__PURE__ */ Symbol.for("drizzle:PgMaterializedViewConfig");
    PgMaterializedView = class extends PgViewBase {
      static {
        __name(this, "PgMaterializedView");
      }
      static [entityKind] = "PgMaterializedView";
      [PgMaterializedViewConfig];
      constructor({ pgConfig, config }) {
        super(config);
        this[PgMaterializedViewConfig] = {
          with: pgConfig?.with,
          using: pgConfig?.using,
          tablespace: pgConfig?.tablespace,
          withNoData: pgConfig?.withNoData
        };
      }
    };
    __name(pgViewWithSchema, "pgViewWithSchema");
    __name(pgMaterializedViewWithSchema, "pgMaterializedViewWithSchema");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/schema.js
var PgSchema;
var init_schema = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/schema.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_sql();
    init_enum();
    init_sequence();
    init_table2();
    init_view();
    PgSchema = class {
      static {
        __name(this, "PgSchema");
      }
      constructor(schemaName) {
        this.schemaName = schemaName;
      }
      static [entityKind] = "PgSchema";
      table = /* @__PURE__ */ __name((name, columns, extraConfig) => {
        return pgTableWithSchema(name, columns, extraConfig, this.schemaName);
      }, "table");
      view = /* @__PURE__ */ __name((name, columns) => {
        return pgViewWithSchema(name, columns, this.schemaName);
      }, "view");
      materializedView = /* @__PURE__ */ __name((name, columns) => {
        return pgMaterializedViewWithSchema(name, columns, this.schemaName);
      }, "materializedView");
      enum(enumName, input) {
        return Array.isArray(input) ? pgEnumWithSchema(
          enumName,
          [...input],
          this.schemaName
        ) : pgEnumObjectWithSchema(enumName, input, this.schemaName);
      }
      sequence = /* @__PURE__ */ __name((name, options) => {
        return pgSequenceWithSchema(name, options, this.schemaName);
      }, "sequence");
      getSQL() {
        return new SQL([sql.identifier(this.schemaName)]);
      }
      shouldOmitSQLParens() {
        return true;
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/session.js
var PgPreparedQuery, PgSession, PgTransaction;
var init_session = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/session.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_errors();
    init_sql2();
    init_tracing();
    init_db();
    PgPreparedQuery = class {
      static {
        __name(this, "PgPreparedQuery");
      }
      constructor(query) {
        this.query = query;
      }
      authToken;
      getQuery() {
        return this.query;
      }
      mapResult(response, _isFromBatch) {
        return response;
      }
      /** @internal */
      setToken(token) {
        this.authToken = token;
        return this;
      }
      static [entityKind] = "PgPreparedQuery";
      /** @internal */
      joinsNotNullableMap;
    };
    PgSession = class {
      static {
        __name(this, "PgSession");
      }
      constructor(dialect2) {
        this.dialect = dialect2;
      }
      static [entityKind] = "PgSession";
      /** @internal */
      execute(query, token) {
        return tracer.startActiveSpan("drizzle.operation", () => {
          const prepared = tracer.startActiveSpan("drizzle.prepareQuery", () => {
            return this.prepareQuery(
              this.dialect.sqlToQuery(query),
              void 0,
              void 0,
              false
            );
          });
          return prepared.setToken(token).execute(void 0, token);
        });
      }
      all(query) {
        return this.prepareQuery(
          this.dialect.sqlToQuery(query),
          void 0,
          void 0,
          false
        ).all();
      }
      /** @internal */
      async count(sql22, token) {
        const res = await this.execute(sql22, token);
        return Number(
          res[0]["count"]
        );
      }
    };
    PgTransaction = class extends PgDatabase {
      static {
        __name(this, "PgTransaction");
      }
      constructor(dialect2, session, schema, nestedIndex = 0) {
        super(dialect2, session, schema);
        this.schema = schema;
        this.nestedIndex = nestedIndex;
      }
      static [entityKind] = "PgTransaction";
      rollback() {
        throw new TransactionRollbackError();
      }
      /** @internal */
      getTransactionConfigSQL(config) {
        const chunks = [];
        if (config.isolationLevel) {
          chunks.push(`isolation level ${config.isolationLevel}`);
        }
        if (config.accessMode) {
          chunks.push(config.accessMode);
        }
        if (typeof config.deferrable === "boolean") {
          chunks.push(config.deferrable ? "deferrable" : "not deferrable");
        }
        return sql.raw(chunks.join(" "));
      }
      setTransaction(config) {
        return this.session.execute(sql`set transaction ${this.getTransactionConfigSQL(config)}`);
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/subquery.js
var init_subquery2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/subquery.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils.js
function getTableConfig(table) {
  const columns = Object.values(table[Table.Symbol.Columns]);
  const indexes = [];
  const checks = [];
  const primaryKeys = [];
  const foreignKeys = Object.values(table[PgTable.Symbol.InlineForeignKeys]);
  const uniqueConstraints = [];
  const name = table[Table.Symbol.Name];
  const schema = table[Table.Symbol.Schema];
  const policies = [];
  const enableRLS = table[PgTable.Symbol.EnableRLS];
  const extraConfigBuilder = table[PgTable.Symbol.ExtraConfigBuilder];
  if (extraConfigBuilder !== void 0) {
    const extraConfig = extraConfigBuilder(table[Table.Symbol.ExtraConfigColumns]);
    const extraValues = Array.isArray(extraConfig) ? extraConfig.flat(1) : Object.values(extraConfig);
    for (const builder of extraValues) {
      if (is(builder, IndexBuilder)) {
        indexes.push(builder.build(table));
      } else if (is(builder, CheckBuilder)) {
        checks.push(builder.build(table));
      } else if (is(builder, UniqueConstraintBuilder)) {
        uniqueConstraints.push(builder.build(table));
      } else if (is(builder, PrimaryKeyBuilder)) {
        primaryKeys.push(builder.build(table));
      } else if (is(builder, ForeignKeyBuilder)) {
        foreignKeys.push(builder.build(table));
      } else if (is(builder, PgPolicy)) {
        policies.push(builder);
      }
    }
  }
  return {
    columns,
    indexes,
    foreignKeys,
    checks,
    primaryKeys,
    uniqueConstraints,
    name,
    schema,
    policies,
    enableRLS
  };
}
var init_utils3 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_table2();
    init_table();
    init_checks();
    init_foreign_keys();
    init_indexes();
    init_policies();
    init_primary_keys();
    init_unique_constraint();
    __name(getTableConfig, "getTableConfig");
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils/index.js
var init_utils4 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/utils/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_array();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/index.js
var init_pg_core = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/pg-core/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_alias2();
    init_checks();
    init_columns();
    init_db();
    init_dialect();
    init_foreign_keys();
    init_indexes();
    init_policies();
    init_primary_keys();
    init_query_builders();
    init_roles();
    init_schema();
    init_sequence();
    init_session();
    init_subquery2();
    init_table2();
    init_unique_constraint();
    init_utils3();
    init_utils4();
    init_view_common2();
    init_view();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/session.js
var rawQueryConfig, queryConfig, NeonHttpPreparedQuery, NeonHttpSession, NeonTransaction;
var init_session2 = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/session.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_entity();
    init_logger();
    init_pg_core();
    init_session();
    init_sql();
    init_utils();
    rawQueryConfig = {
      arrayMode: false,
      fullResults: true
    };
    queryConfig = {
      arrayMode: true,
      fullResults: true
    };
    NeonHttpPreparedQuery = class extends PgPreparedQuery {
      static {
        __name(this, "NeonHttpPreparedQuery");
      }
      constructor(client, query, logger, fields, _isResponseInArrayMode, customResultMapper) {
        super(query);
        this.client = client;
        this.logger = logger;
        this.fields = fields;
        this._isResponseInArrayMode = _isResponseInArrayMode;
        this.customResultMapper = customResultMapper;
        this.clientQuery = client.query ?? client;
      }
      static [entityKind] = "NeonHttpPreparedQuery";
      clientQuery;
      /** @internal */
      async execute(placeholderValues = {}, token = this.authToken) {
        const params = fillPlaceholders(this.query.params, placeholderValues);
        this.logger.logQuery(this.query.sql, params);
        const { fields, clientQuery, query, customResultMapper } = this;
        if (!fields && !customResultMapper) {
          return clientQuery(
            query.sql,
            params,
            token === void 0 ? rawQueryConfig : {
              ...rawQueryConfig,
              authToken: token
            }
          );
        }
        const result = await clientQuery(
          query.sql,
          params,
          token === void 0 ? queryConfig : {
            ...queryConfig,
            authToken: token
          }
        );
        return this.mapResult(result);
      }
      mapResult(result) {
        if (!this.fields && !this.customResultMapper) {
          return result;
        }
        const rows = result.rows;
        if (this.customResultMapper) {
          return this.customResultMapper(rows);
        }
        return rows.map((row) => mapResultRow(this.fields, row, this.joinsNotNullableMap));
      }
      all(placeholderValues = {}) {
        const params = fillPlaceholders(this.query.params, placeholderValues);
        this.logger.logQuery(this.query.sql, params);
        return this.clientQuery(
          this.query.sql,
          params,
          this.authToken === void 0 ? rawQueryConfig : {
            ...rawQueryConfig,
            authToken: this.authToken
          }
        ).then((result) => result.rows);
      }
      /** @internal */
      values(placeholderValues = {}, token) {
        const params = fillPlaceholders(this.query.params, placeholderValues);
        this.logger.logQuery(this.query.sql, params);
        return this.clientQuery(this.query.sql, params, { arrayMode: true, fullResults: true, authToken: token }).then((result) => result.rows);
      }
      /** @internal */
      isResponseInArrayMode() {
        return this._isResponseInArrayMode;
      }
    };
    NeonHttpSession = class extends PgSession {
      static {
        __name(this, "NeonHttpSession");
      }
      constructor(client, dialect2, schema, options = {}) {
        super(dialect2);
        this.client = client;
        this.schema = schema;
        this.options = options;
        this.clientQuery = client.query ?? client;
        this.logger = options.logger ?? new NoopLogger();
      }
      static [entityKind] = "NeonHttpSession";
      clientQuery;
      logger;
      prepareQuery(query, fields, name, isResponseInArrayMode, customResultMapper) {
        return new NeonHttpPreparedQuery(
          this.client,
          query,
          this.logger,
          fields,
          isResponseInArrayMode,
          customResultMapper
        );
      }
      async batch(queries) {
        const preparedQueries = [];
        const builtQueries = [];
        for (const query of queries) {
          const preparedQuery = query._prepare();
          const builtQuery = preparedQuery.getQuery();
          preparedQueries.push(preparedQuery);
          builtQueries.push(
            this.clientQuery(builtQuery.sql, builtQuery.params, {
              fullResults: true,
              arrayMode: preparedQuery.isResponseInArrayMode()
            })
          );
        }
        const batchResults = await this.client.transaction(builtQueries, queryConfig);
        return batchResults.map((result, i) => preparedQueries[i].mapResult(result, true));
      }
      // change return type to QueryRows<true>
      async query(query, params) {
        this.logger.logQuery(query, params);
        const result = await this.clientQuery(query, params, { arrayMode: true, fullResults: true });
        return result;
      }
      // change return type to QueryRows<false>
      async queryObjects(query, params) {
        return this.clientQuery(query, params, { arrayMode: false, fullResults: true });
      }
      /** @internal */
      async count(sql4, token) {
        const res = await this.execute(sql4, token);
        return Number(
          res["rows"][0]["count"]
        );
      }
      async transaction(_transaction, _config = {}) {
        throw new Error("No transactions support in neon-http driver");
      }
    };
    NeonTransaction = class extends PgTransaction {
      static {
        __name(this, "NeonTransaction");
      }
      static [entityKind] = "NeonHttpTransaction";
      async transaction(_transaction) {
        throw new Error("No transactions support in neon-http driver");
      }
    };
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/driver.js
function wrap(target, token, cb, deep) {
  return new Proxy(target, {
    get(target2, p2) {
      const element = target2[p2];
      if (typeof element !== "function" && (typeof element !== "object" || element === null))
        return element;
      if (deep)
        return wrap(element, token, cb);
      if (p2 === "query")
        return wrap(element, token, cb, true);
      return new Proxy(element, {
        apply(target3, thisArg, argArray) {
          const res = target3.call(thisArg, ...argArray);
          if (typeof res === "object" && res !== null && "setToken" in res && typeof res.setToken === "function") {
            res.setToken(token);
          }
          return cb(target3, p2, res);
        }
      });
    }
  });
}
function construct(client, config = {}) {
  const dialect2 = new PgDialect({ casing: config.casing });
  let logger;
  if (config.logger === true) {
    logger = new DefaultLogger();
  } else if (config.logger !== false) {
    logger = config.logger;
  }
  let schema;
  if (config.schema) {
    const tablesConfig = extractTablesRelationalConfig(
      config.schema,
      createTableRelationsHelpers
    );
    schema = {
      fullSchema: config.schema,
      schema: tablesConfig.tables,
      tableNamesMap: tablesConfig.tableNamesMap
    };
  }
  const driver = new NeonHttpDriver(client, dialect2, { logger });
  const session = driver.createSession(schema);
  const db = new NeonHttpDatabase(
    dialect2,
    session,
    schema
  );
  db.$client = client;
  return db;
}
function drizzle(...params) {
  if (typeof params[0] === "string") {
    const instance = Xs(params[0]);
    return construct(instance, params[1]);
  }
  if (isConfig(params[0])) {
    const { connection, client, ...drizzleConfig } = params[0];
    if (client)
      return construct(client, drizzleConfig);
    if (typeof connection === "object") {
      const { connectionString, ...options } = connection;
      const instance2 = Xs(connectionString, options);
      return construct(instance2, drizzleConfig);
    }
    const instance = Xs(connection);
    return construct(instance, drizzleConfig);
  }
  return construct(params[0], params[1]);
}
var NeonHttpDriver, NeonHttpDatabase;
var init_driver = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/driver.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_serverless();
    init_entity();
    init_logger();
    init_db();
    init_dialect();
    init_relations();
    init_utils();
    init_session2();
    NeonHttpDriver = class {
      static {
        __name(this, "NeonHttpDriver");
      }
      constructor(client, dialect2, options = {}) {
        this.client = client;
        this.dialect = dialect2;
        this.options = options;
        this.initMappers();
      }
      static [entityKind] = "NeonHttpDriver";
      createSession(schema) {
        return new NeonHttpSession(this.client, this.dialect, schema, { logger: this.options.logger });
      }
      initMappers() {
        export_types.setTypeParser(export_types.builtins.TIMESTAMPTZ, (val) => val);
        export_types.setTypeParser(export_types.builtins.TIMESTAMP, (val) => val);
        export_types.setTypeParser(export_types.builtins.DATE, (val) => val);
        export_types.setTypeParser(export_types.builtins.INTERVAL, (val) => val);
        export_types.setTypeParser(1231, (val) => val);
        export_types.setTypeParser(1115, (val) => val);
        export_types.setTypeParser(1185, (val) => val);
        export_types.setTypeParser(1187, (val) => val);
        export_types.setTypeParser(1182, (val) => val);
      }
    };
    __name(wrap, "wrap");
    NeonHttpDatabase = class extends PgDatabase {
      static {
        __name(this, "NeonHttpDatabase");
      }
      static [entityKind] = "NeonHttpDatabase";
      $withAuth(token) {
        this.authToken = token;
        return wrap(this, token, (target, p2, res) => {
          if (p2 === "with") {
            return wrap(res, token, (_2, __, res2) => res2);
          }
          return res;
        });
      }
      async batch(batch) {
        return this.session.batch(batch);
      }
    };
    __name(construct, "construct");
    __name(drizzle, "drizzle");
    ((drizzle2) => {
      function mock(config) {
        return construct({}, config);
      }
      __name(mock, "mock");
      drizzle2.mock = mock;
    })(drizzle || (drizzle = {}));
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/index.js
var init_neon_http = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/neon-http/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_driver();
    init_session2();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/operations.js
var init_operations = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/operations.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/index.js
var init_drizzle_orm = __esm({
  "../node_modules/.pnpm/drizzle-orm@0.43.1_@cloudflare+workers-types@4.20260701.1_@neondatabase+serverless@0.10.4_@types+pg@8.20.0_pg@8.22.0/node_modules/drizzle-orm/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_alias();
    init_column_builder();
    init_column();
    init_entity();
    init_errors();
    init_logger();
    init_operations();
    init_query_promise();
    init_relations();
    init_sql2();
    init_subquery();
    init_table();
    init_utils();
    init_view_common();
  }
});

// ../db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  auditLogs: () => auditLogs,
  bancaResults: () => bancaResults,
  blockedDates: () => blockedDates,
  cfcRequests: () => cfcRequests,
  cfcScheduleSlots: () => cfcScheduleSlots,
  cities: () => cities,
  cnhbrasilRequests: () => cnhbrasilRequests,
  cpfLookupQuotas: () => cpfLookupQuotas,
  drivingSchools: () => drivingSchools,
  examLocations: () => examLocations,
  examRequests: () => examRequests,
  examScheduleSlots: () => examScheduleSlots,
  examSchedules: () => examSchedules,
  examiners: () => examiners,
  instructors: () => instructors,
  otpCodes: () => otpCodes,
  pcdRequests: () => pcdRequests,
  pcdScheduleSlots: () => pcdScheduleSlots,
  systemSettings: () => systemSettings,
  users: () => users,
  vehicles: () => vehicles
});
var users, otpCodes, drivingSchools, examiners, instructors, vehicles, examLocations, examSchedules, examRequests, systemSettings, cpfLookupQuotas, auditLogs, blockedDates, cities, examScheduleSlots, bancaResults, cnhbrasilRequests, cfcRequests, pcdRequests, cfcScheduleSlots, pcdScheduleSlots;
var init_schema2 = __esm({
  "../db/schema.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_pg_core();
    users = pgTable("usuarios", {
      id: text("id").primaryKey(),
      name: text("nome").notNull(),
      login: text("login").notNull().unique(),
      password: text("senha"),
      role: text("perfil").notNull(),
      schoolId: text("autoescola_id"),
      examinerId: text("examinador_id"),
      instructorId: text("instrutor_id"),
      forcePasswordChange: boolean("forcar_troca_senha").default(true),
      allowedModules: jsonb("modulos_permitidos").$type().default([]),
      allowedLocationIds: jsonb("locais_permitidos_ids").$type().default([]),
      allowedCadastroTabs: jsonb("abas_cadastro_permitidas").$type().default([]),
      email: text("email"),
      phone: text("telefone"),
      twoFactorEnabled: boolean("dois_fatores_ativo").default(false),
      createdAt: timestamp("criado_em").defaultNow()
    });
    otpCodes = pgTable("codigos_otp", {
      id: text("id").primaryKey(),
      userId: text("usuario_id").notNull(),
      code: text("codigo").notNull(),
      // SHA-256 hash do código real
      expiresAt: timestamp("expira_em").notNull(),
      used: boolean("usado").default(false),
      failedAttempts: integer("tentativas_falhas").default(0),
      createdAt: timestamp("criado_em").defaultNow()
    });
    drivingSchools = pgTable("autoescolas", {
      id: text("id").primaryKey(),
      name: text("nome").notNull(),
      phone: text("telefone"),
      email: text("email"),
      address: text("endereco"),
      city: text("cidade"),
      services: jsonb("servicos").$type().default([]),
      doNotCreateUser: boolean("nao_criar_usuario").notNull().default(false),
      examRotation: boolean("rodizio_provas").notNull().default(false),
      cnhBrasilProfile: boolean("perfil_cnh_brasil").notNull().default(false),
      motoYardAddress: text("endereco_patio_moto"),
      carYardAddress: text("endereco_patio_carro"),
      categoryChangeYardAddress: text("endereco_patio_mudanca"),
      // Pátios: lista com tipo (MOTO | CARRO | MUDANCA), endereço e referência
      yards: jsonb("patios").$type().default([]),
      mainSchedule: jsonb("banca_principal").$type(),
      provisionalSchedule: jsonb("banca_provisoria").$type(),
      createdAt: timestamp("criado_em").defaultNow()
    });
    examiners = pgTable("examinadores", {
      id: text("id").primaryKey(),
      name: text("nome").notNull(),
      registrationNumber: text("matricula").notNull(),
      canExamCommon: boolean("pode_examinar_comum").default(true),
      canExamPCD: boolean("pode_examinar_pcd").default(false),
      categories: jsonb("categorias").$type().default([]),
      defaultMaxSlotsA: integer("max_vagas_a_padrao"),
      defaultMaxSlotsB: integer("max_vagas_b_padrao"),
      defaultMaxSlotsMudanca: integer("max_vagas_mudanca_padrao"),
      examRotation: boolean("rodizio_provas").notNull().default(false),
      rotationAvailability: jsonb("disponibilidade_rodizio").$type(),
      blockedPeriods: jsonb("periodos_bloqueio").$type().default([]),
      createdAt: timestamp("criado_em").defaultNow()
    });
    instructors = pgTable("instrutores", {
      id: text("id").primaryKey(),
      name: text("nome").notNull(),
      cpf: text("cpf").notNull(),
      phone: text("telefone"),
      category: text("categoria"),
      plate: text("placa"),
      createdAt: timestamp("criado_em").defaultNow()
    });
    vehicles = pgTable("veiculos", {
      id: text("id").primaryKey(),
      instructorId: text("instrutor_id").notNull(),
      type: text("tipo").notNull(),
      brand: text("marca").notNull(),
      model: text("modelo").notNull(),
      plate: text("placa").notNull(),
      active: boolean("ativo").default(true),
      transmission: text("transmissao"),
      accessories: jsonb("acessorios").$type().default([]),
      duploComando: boolean("duplo_comando").default(false),
      procuracao: boolean("procuracao").default(false),
      anoFabricacao: text("ano_fabricacao"),
      createdAt: timestamp("criado_em").defaultNow()
    });
    examLocations = pgTable("locais_exame", {
      id: text("id").primaryKey(),
      cityId: text("cidade_id").notNull(),
      address: text("endereco"),
      mapsUrl: text("url_maps"),
      regionsServed: jsonb("regioes_atendidas").$type().default([]),
      createdAt: timestamp("criado_em").defaultNow()
    });
    examSchedules = pgTable("bancas", {
      id: text("id").primaryKey(),
      code: text("codigo").unique(),
      date: text("data").notNull(),
      time: text("hora").notNull(),
      examinerIds: jsonb("examinadores_ids").$type().default([]),
      maxSlotsA: integer("max_vagas_a").default(10),
      maxSlotsB: integer("max_vagas_b").default(10),
      type: text("tipo").notNull(),
      status: text("status").notNull(),
      cancellationReason: text("motivo_cancelamento"),
      locationId: text("local_id"),
      createdAt: timestamp("criado_em").defaultNow()
    });
    examRequests = pgTable("solicitacoes", {
      id: text("id").primaryKey(),
      studentName: text("nome_candidato"),
      socialName: text("nome_social"),
      cpf: text("cpf"),
      phone: text("telefone"),
      email: text("email"),
      address: text("endereco"),
      city: text("cidade"),
      requestType: text("tipo_solicitacao").default("EXTRA"),
      examType: text("tipo_exame").notNull(),
      intendedCategory: text("categoria_pretendida").default("B"),
      source: text("origem").notNull(),
      schoolId: text("autoescola_id"),
      paidFee: boolean("taxa_paga_bool").default(false),
      completedPracticalCourse: boolean("curso_pratico_concluido").default(false),
      practicalHours: integer("horas_praticas").default(0),
      hasVehicle: boolean("tem_veiculo").default(false),
      cnhRestriction: text("restricao_cnh"),
      instructor: text("instrutor"),
      vehiclePlate: text("placa_veiculo"),
      semDuploComando: boolean("sem_duplo_comando").default(false),
      checklistVehicle: boolean("checklist_veiculo").default(false),
      practicalCourseInserted: boolean("curso_pratico_inserido").default(false),
      taxaPaga: boolean("taxa_paga").default(false),
      disabilityType: text("tipo_deficiencia"),
      specialNeeds: text("necessidades_especiais"),
      status: text("status").notNull(),
      result: text("resultado"),
      scheduleId: text("banca_id"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      scheduledCategory: text("categoria_agendada"),
      examinerId: text("examinador_id"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      categoryQuantities: jsonb("quantidades_categoria").$type(),
      examHistory: jsonb("historico_exames").default([]),
      modulo: text("modulo"),
      rowColor: text("cor_linha"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow(),
      queueUpdatedAt: timestamp("fila_atualizado_em"),
      scheduledBy: text("agendado_por")
    });
    systemSettings = pgTable("configuracoes", {
      id: integer("id").primaryKey().default(1),
      agencyName: text("nome_orgao").default("DETRAN"),
      agencyAddress: text("endereco_orgao"),
      logoUrl: text("url_logo"),
      maintenanceMode: boolean("modo_manutencao").default(false),
      minDaysForScheduling: integer("min_dias_agendamento").default(2),
      maxDailySlots: integer("max_vagas_diarias").default(50),
      defaultMaxSlotsA: integer("max_vagas_a_padrao").default(10),
      defaultMaxSlotsB: integer("max_vagas_b_padrao").default(10),
      defaultMaxSlotsMudanca: integer("max_vagas_mudanca_padrao").default(10),
      whatsappMessageTemplate: text("template_whatsapp"),
      cfcWhatsappMessageTemplate: text("template_whatsapp_cfc"),
      defaultExamAddress: text("endereco_exame_padrao"),
      defaultExamAddressLink: text("link_exame_padrao"),
      restrictions: jsonb("restricoes").default([]),
      pcdExamName: text("nome_exame_pcd"),
      pcdDefaultExamAddress: text("endereco_exame_pcd_padrao"),
      pcdDefaultExamAddressLink: text("link_exame_pcd_padrao"),
      pcdMainSchedule: jsonb("banca_principal_pcd"),
      cnhBrasilMainSchedule: jsonb("banca_principal_cnh_brasil"),
      blockWeekends: boolean("bloquear_fins_semana").default(false),
      riskAreaKey: text("chave_area_risco"),
      anoFabricacaoMaximo: jsonb("ano_fabricacao_maximo"),
      cnhCpfAutofillEnabled: boolean("preencher_nome_cpf_cnh").notNull().default(false)
    });
    cpfLookupQuotas = pgTable("cotas_consulta_cpf", {
      id: text("id").primaryKey(),
      windowMinute: integer("janela_minuto").notNull(),
      count: integer("consultas").notNull().default(0)
    });
    auditLogs = pgTable("logs_auditoria", {
      id: text("id").primaryKey(),
      userId: text("usuario_id"),
      userName: text("nome_usuario"),
      userRole: text("perfil_usuario"),
      action: text("acao").notNull(),
      entity: text("entidade").notNull(),
      entityId: text("entidade_id"),
      details: jsonb("detalhes").$type(),
      createdAt: timestamp("criado_em").defaultNow()
    });
    blockedDates = pgTable("datas_bloqueadas", {
      id: text("id").primaryKey(),
      date: text("data").notNull(),
      description: text("descricao"),
      isHoliday: boolean("feriado").default(false),
      createdAt: timestamp("criado_em").defaultNow()
    });
    cities = pgTable("cidades", {
      id: text("id").primaryKey(),
      name: text("nome").notNull().unique(),
      createdAt: timestamp("criado_em").defaultNow()
    });
    examScheduleSlots = pgTable("vagas_banca", {
      id: text("id").primaryKey(),
      schoolId: text("autoescola_id").notNull(),
      examType: text("tipo_exame").notNull(),
      requestType: text("tipo_solicitacao").notNull(),
      intendedCategory: text("categoria_pretendida"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      examinerId: text("examinador_id"),
      scheduleId: text("banca_id"),
      scheduledCategory: text("categoria_agendada"),
      status: text("status").notNull().default("SCHEDULED"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow()
    });
    bancaResults = pgTable("resultados_banca", {
      id: text("id").primaryKey(),
      scheduleId: text("banca_id").notNull(),
      schoolId: text("autoescola_id").notNull(),
      category: text("categoria").notNull(),
      totalSlots: integer("total_vagas").default(0),
      usedSlots: integer("vagas_usadas").default(0),
      approved: integer("aprovados").default(0),
      failed: integer("reprovados").default(0),
      absent: integer("ausentes").default(0),
      cancelled: integer("cancelados").default(0),
      modulo: text("modulo"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow()
    });
    cnhbrasilRequests = pgTable("solicitacoes_cnhbrasil", {
      id: text("id").primaryKey(),
      studentName: text("nome_candidato"),
      socialName: text("nome_social"),
      cpf: text("cpf"),
      phone: text("telefone"),
      email: text("email"),
      address: text("endereco"),
      city: text("cidade"),
      requestType: text("tipo_solicitacao").default("EXTRA"),
      examType: text("tipo_exame").notNull(),
      intendedCategory: text("categoria_pretendida").default("B"),
      source: text("origem").notNull(),
      schoolId: text("autoescola_id"),
      paidFee: boolean("taxa_paga_bool").default(false),
      completedPracticalCourse: boolean("curso_pratico_concluido").default(false),
      practicalHours: integer("horas_praticas").default(0),
      hasVehicle: boolean("tem_veiculo").default(false),
      cnhRestriction: text("restricao_cnh"),
      instructor: text("instrutor"),
      examModalityA: text("modalidade_exame_a"),
      examModalityB: text("modalidade_exame_b"),
      vehiclePlate: text("placa_veiculo"),
      semDuploComando: boolean("sem_duplo_comando").default(false),
      checklistVehicle: boolean("checklist_veiculo").default(false),
      practicalCourseInserted: boolean("curso_pratico_inserido").default(false),
      taxaPaga: boolean("taxa_paga").default(false),
      status: text("status").notNull(),
      result: text("resultado"),
      scheduleId: text("banca_id"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      scheduledCategory: text("categoria_agendada"),
      examinerId: text("examinador_id"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      examHistory: jsonb("historico_exames").default([]),
      modulo: text("modulo"),
      rowColor: text("cor_linha"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow(),
      queueUpdatedAt: timestamp("fila_atualizado_em"),
      scheduledBy: text("agendado_por")
    });
    cfcRequests = pgTable("solicitacoes_cfc", {
      id: text("id").primaryKey(),
      studentName: text("nome_candidato"),
      socialName: text("nome_social"),
      cpf: text("cpf"),
      phone: text("telefone"),
      email: text("email"),
      address: text("endereco"),
      city: text("cidade"),
      requestType: text("tipo_solicitacao").default("EXTRA"),
      examType: text("tipo_exame").notNull(),
      intendedCategory: text("categoria_pretendida").default("B"),
      source: text("origem").notNull(),
      schoolId: text("autoescola_id"),
      paidFee: boolean("taxa_paga_bool").default(false),
      completedPracticalCourse: boolean("curso_pratico_concluido").default(false),
      practicalHours: integer("horas_praticas").default(0),
      hasVehicle: boolean("tem_veiculo").default(false),
      cnhRestriction: text("restricao_cnh"),
      instructor: text("instrutor"),
      vehiclePlate: text("placa_veiculo"),
      semDuploComando: boolean("sem_duplo_comando").default(false),
      checklistVehicle: boolean("checklist_veiculo").default(false),
      practicalCourseInserted: boolean("curso_pratico_inserido").default(false),
      taxaPaga: boolean("taxa_paga").default(false),
      status: text("status").notNull(),
      result: text("resultado"),
      scheduleId: text("banca_id"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      scheduledCategory: text("categoria_agendada"),
      examinerId: text("examinador_id"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      categoryQuantities: jsonb("quantidades_categoria").$type(),
      // Examinadores que registraram interesse no pedido de prova extra
      interestedExaminers: jsonb("examinadores_interessados").$type().default([]),
      examHistory: jsonb("historico_exames").default([]),
      modulo: text("modulo"),
      rowColor: text("cor_linha"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow(),
      queueUpdatedAt: timestamp("fila_atualizado_em"),
      scheduledBy: text("agendado_por")
    });
    pcdRequests = pgTable("solicitacoes_pcd", {
      id: text("id").primaryKey(),
      studentName: text("nome_candidato"),
      socialName: text("nome_social"),
      cpf: text("cpf"),
      phone: text("telefone"),
      email: text("email"),
      address: text("endereco"),
      city: text("cidade"),
      requestType: text("tipo_solicitacao").default("EXTRA"),
      examType: text("tipo_exame").notNull(),
      intendedCategory: text("categoria_pretendida").default("B"),
      source: text("origem").notNull(),
      schoolId: text("autoescola_id"),
      paidFee: boolean("taxa_paga_bool").default(false),
      completedPracticalCourse: boolean("curso_pratico_concluido").default(false),
      practicalHours: integer("horas_praticas").default(0),
      hasVehicle: boolean("tem_veiculo").default(false),
      cnhRestriction: text("restricao_cnh"),
      instructor: text("instrutor"),
      vehiclePlate: text("placa_veiculo"),
      checklistVehicle: boolean("checklist_veiculo").default(false),
      practicalCourseInserted: boolean("curso_pratico_inserido").default(false),
      taxaPaga: boolean("taxa_paga").default(false),
      disabilityType: text("tipo_deficiencia"),
      specialNeeds: text("necessidades_especiais"),
      status: text("status").notNull(),
      result: text("resultado"),
      scheduleId: text("banca_id"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      scheduledCategory: text("categoria_agendada"),
      examinerId: text("examinador_id"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      examHistory: jsonb("historico_exames").default([]),
      modulo: text("modulo"),
      rowColor: text("cor_linha"),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow(),
      queueUpdatedAt: timestamp("fila_atualizado_em"),
      scheduledBy: text("agendado_por")
    });
    cfcScheduleSlots = pgTable("vagas_cfc", {
      id: text("id").primaryKey(),
      schoolId: text("autoescola_id").notNull(),
      examType: text("tipo_exame").notNull(),
      requestType: text("tipo_solicitacao").notNull(),
      intendedCategory: text("categoria_pretendida"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      examinerId: text("examinador_id"),
      scheduleId: text("banca_id"),
      scheduledCategory: text("categoria_agendada"),
      status: text("status").notNull().default("SCHEDULED"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      categoryQuantities: jsonb("quantidades_categoria").$type(),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow()
    });
    pcdScheduleSlots = pgTable("vagas_pcd", {
      id: text("id").primaryKey(),
      schoolId: text("autoescola_id").notNull(),
      examType: text("tipo_exame").notNull(),
      requestType: text("tipo_solicitacao").notNull(),
      intendedCategory: text("categoria_pretendida"),
      scheduledDate: text("data_agendada"),
      scheduledTime: text("hora_agendada"),
      examinerId: text("examinador_id"),
      scheduleId: text("banca_id"),
      scheduledCategory: text("categoria_agendada"),
      status: text("status").notNull().default("SCHEDULED"),
      attendanceConfirmed: boolean("presenca_confirmada").default(false),
      cancellationReason: text("motivo_cancelamento"),
      observation: text("observacao"),
      categoryQuantities: jsonb("quantidades_categoria").$type(),
      createdAt: timestamp("criado_em").defaultNow(),
      updatedAt: timestamp("atualizado_em").defaultNow()
    });
  }
});

// ../db/cpf-migration.ts
async function cpfD1Checksum() {
  const hash2 = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(CPF_D1_STATEMENTS.join(";\n")));
  return Array.from(new Uint8Array(hash2), (x2) => x2.toString(16).padStart(2, "0")).join("");
}
var CPF_D1_VERSION, CPF_D1_STATEMENTS;
var init_cpf_migration = __esm({
  "../db/cpf-migration.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    CPF_D1_VERSION = "d1_cpf_autofill_v1";
    CPF_D1_STATEMENTS = [
      "ALTER TABLE configuracoes ADD COLUMN preencher_nome_cpf_cnh INTEGER NOT NULL DEFAULT 0 CHECK (preencher_nome_cpf_cnh IN (0, 1))",
      "CREATE TABLE cotas_consulta_cpf (id TEXT PRIMARY KEY NOT NULL, janela_minuto INTEGER NOT NULL, consultas INTEGER NOT NULL DEFAULT 0)",
      // This existing ORM field also postdates the frozen D1 baseline.
      `ALTER TABLE examinadores ADD COLUMN periodos_bloqueio TEXT DEFAULT '[]' CHECK (periodos_bloqueio IS NULL OR json_valid(periodos_bloqueio))`
    ];
    __name(cpfD1Checksum, "cpfD1Checksum");
  }
});

// ../db/cadastro-tabs-migration.ts
async function cadastroTabsD1Checksum() {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(CADASTRO_TABS_D1_STATEMENTS.join(";\n"))
  );
  const checksum = Array.from(new Uint8Array(digest), (x2) => x2.toString(16).padStart(2, "0")).join("");
  if (checksum !== CADASTRO_TABS_D1_CHECKSUM) throw new Error("A migra\xE7\xE3o D1 de abas de cadastro foi alterada. Crie uma nova vers\xE3o.");
  return checksum;
}
var CADASTRO_TABS_D1_VERSION, CADASTRO_TABS_D1_STATEMENTS, CADASTRO_TABS_D1_CHECKSUM;
var init_cadastro_tabs_migration = __esm({
  "../db/cadastro-tabs-migration.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    CADASTRO_TABS_D1_VERSION = "d1_cadastro_tabs_v1";
    CADASTRO_TABS_D1_STATEMENTS = [
      `ALTER TABLE usuarios ADD COLUMN abas_cadastro_permitidas TEXT DEFAULT '[]' CHECK (abas_cadastro_permitidas IS NULL OR json_valid(abas_cadastro_permitidas))`
    ];
    CADASTRO_TABS_D1_CHECKSUM = "dc93e86433a03f5eeb92f902529c485f6babe0669d88a28cfcb3b3a2986b3496";
    __name(cadastroTabsD1Checksum, "cadastroTabsD1Checksum");
  }
});

// ../db/cnh-exam-modality-migration.ts
async function cnhModalityChecksum() {
  const hash2 = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(CNH_MODALITY_STATEMENTS.join(";\n")));
  return Array.from(new Uint8Array(hash2), (x2) => x2.toString(16).padStart(2, "0")).join("");
}
var CNH_MODALITY_VERSION, CNH_MODALITY_STATEMENTS, CNH_MODALITY_NEON_SQL;
var init_cnh_exam_modality_migration = __esm({
  "../db/cnh-exam-modality-migration.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    CNH_MODALITY_VERSION = "d1_cnh_exam_modality_v1";
    CNH_MODALITY_STATEMENTS = ["a", "b"].map((category) => `ALTER TABLE solicitacoes_cnhbrasil ADD COLUMN modalidade_exame_${category} TEXT CHECK (modalidade_exame_${category} IS NULL OR modalidade_exame_${category} IN ('STANDARD', 'PCD', 'REABILITACAO'))`);
    CNH_MODALITY_NEON_SQL = `DO $$ BEGIN
  ALTER TABLE solicitacoes_cnhbrasil ADD COLUMN IF NOT EXISTS modalidade_exame_a text
    CHECK (modalidade_exame_a IS NULL OR modalidade_exame_a IN ('STANDARD', 'PCD', 'REABILITACAO'));
  ALTER TABLE solicitacoes_cnhbrasil ADD COLUMN IF NOT EXISTS modalidade_exame_b text
    CHECK (modalidade_exame_b IS NULL OR modalidade_exame_b IN ('STANDARD', 'PCD', 'REABILITACAO'));
END $$`;
    __name(cnhModalityChecksum, "cnhModalityChecksum");
  }
});

// ../db/school-yards-interest-migration.ts
async function yardsInterestChecksum() {
  const hash2 = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(YARDS_INTEREST_STATEMENTS.join(";\n")));
  return Array.from(new Uint8Array(hash2), (x2) => x2.toString(16).padStart(2, "0")).join("");
}
var YARDS_INTEREST_VERSION, YARDS_INTEREST_STATEMENTS, YARDS_INTEREST_NEON_SQL;
var init_school_yards_interest_migration = __esm({
  "../db/school-yards-interest-migration.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    YARDS_INTEREST_VERSION = "d1_school_yards_interest_v1";
    YARDS_INTEREST_STATEMENTS = [
      `ALTER TABLE autoescolas ADD COLUMN patios TEXT DEFAULT '[]' CHECK (patios IS NULL OR json_valid(patios))`,
      `ALTER TABLE solicitacoes_cfc ADD COLUMN examinadores_interessados TEXT DEFAULT '[]' CHECK (examinadores_interessados IS NULL OR json_valid(examinadores_interessados))`
    ];
    YARDS_INTEREST_NEON_SQL = `DO $$ BEGIN
  ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS patios jsonb DEFAULT '[]'::jsonb;
  ALTER TABLE solicitacoes_cfc ADD COLUMN IF NOT EXISTS examinadores_interessados jsonb DEFAULT '[]'::jsonb;
END $$`;
    __name(yardsInterestChecksum, "yardsInterestChecksum");
  }
});

// ../db/d1-schema.ts
function initialD1Statements() {
  const tables = Object.entries(d1Tables).filter(([name]) => name !== "cotas_consulta_cpf").map(([name, allColumns]) => {
    const columns = allColumns.filter((c) => !(name === "configuracoes" && c.name === "preencher_nome_cpf_cnh") && !(name === "solicitacoes_cnhbrasil" && ["modalidade_exame_a", "modalidade_exame_b"].includes(c.name)) && !(name === "usuarios" && c.name === "abas_cadastro_permitidas") && !(name === "examinadores" && c.name === "periodos_bloqueio") && !(name === "autoescolas" && c.name === "patios") && !(name === "solicitacoes_cfc" && c.name === "examinadores_interessados"));
    return `CREATE TABLE IF NOT EXISTS ${quote(name)} (${columns.map(
      (c) => `${quote(c.name)} ${["number", "boolean"].includes(c.kind) ? "INTEGER" : "TEXT"}` + (c.primary ? " PRIMARY KEY" : "") + (c.required ? " NOT NULL" : "") + (c.unique ? " UNIQUE" : "") + (c.defaultSql !== "NULL" ? ` DEFAULT ${c.defaultSql}` : "") + (c.kind === "json" ? ` CHECK (${quote(c.name)} IS NULL OR json_valid(${quote(c.name)}))` : "") + (c.kind === "boolean" ? ` CHECK (${quote(c.name)} IS NULL OR ${quote(c.name)} IN (0, 1))` : "")
    ).join(", ")})`;
  });
  return [
    ...tables,
    "CREATE TABLE IF NOT EXISTS migracoes_d1 (versao TEXT PRIMARY KEY, checksum TEXT NOT NULL, aplicado_em TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS backups_partes (backup_id TEXT NOT NULL REFERENCES backups(id) ON DELETE CASCADE, parte INTEGER NOT NULL, dados TEXT NOT NULL, PRIMARY KEY (backup_id, parte))",
    "CREATE UNIQUE INDEX IF NOT EXISTS backups_auto_daily ON backups (date(criado_em)) WHERE tipo_gatilho = 'auto'",
    "CREATE INDEX IF NOT EXISTS sessoes_usuario_expira ON sessoes (usuario_id, expira_em)",
    "CREATE INDEX IF NOT EXISTS otp_usuario_expira ON codigos_otp (usuario_id, expira_em)",
    ...["solicitacoes_cnhbrasil", "solicitacoes_cfc", "solicitacoes_pcd"].map((t) => `CREATE INDEX IF NOT EXISTS ${t}_banca_status ON ${t} (banca_id, status)`),
    "CREATE INDEX IF NOT EXISTS vagas_cfc_examinador_data ON vagas_cfc (examinador_id, data_agendada, hora_agendada)",
    "CREATE INDEX IF NOT EXISTS vagas_cfc_autoescola_data ON vagas_cfc (autoescola_id, data_agendada)",
    "CREATE INDEX IF NOT EXISTS vagas_pcd_examinador_data ON vagas_pcd (examinador_id, data_agendada)",
    ...["INSERT", "UPDATE"].map((event) => `CREATE TRIGGER IF NOT EXISTS vagas_cfc_guard_${event.toLowerCase()}
      BEFORE ${event} ON vagas_cfc
       WHEN ${event === "INSERT" ? "true" : `(NEW.examinador_id IS NOT OLD.examinador_id
         OR NEW.data_agendada IS NOT OLD.data_agendada OR NEW.hora_agendada IS NOT OLD.hora_agendada
         OR (OLD.status = 'CANCELLED' AND NEW.status != 'CANCELLED'))`}
         AND NEW.status != 'CANCELLED' AND NEW.examinador_id IS NOT NULL
        AND NEW.data_agendada IS NOT NULL AND NEW.hora_agendada IS NOT NULL
      BEGIN
        SELECT CASE WHEN EXISTS (
          SELECT 1 FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND hora_agendada = NEW.hora_agendada
          AND status != 'CANCELLED' AND id != NEW.id
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CONFLICT') END;
        SELECT CASE WHEN (
          SELECT count(*) FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND status != 'CANCELLED' AND id != NEW.id
        ) >= (
          SELECT json_extract(disponibilidade_rodizio, '$.examsPerDay')
          FROM examinadores WHERE id = NEW.examinador_id AND rodizio_provas = 1
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CAPACITY') END;
      END`)
  ];
}
async function d1Checksum() {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(initialD1Statements().join(";\n")));
  const checksum = Array.from(new Uint8Array(digest), (x2) => x2.toString(16).padStart(2, "0")).join("");
  if (D1_VERSION === "d1_schema_v1" && checksum !== D1_INITIAL_CHECKSUM) {
    throw new Error("A defini\xE7\xE3o da migra\xE7\xE3o D1 inicial foi alterada. Prepare uma nova vers\xE3o; n\xE3o reescreva o checksum liberado.");
  }
  return checksum;
}
var D1_NOW, D1_VERSION, D1_INITIAL_CHECKSUM, quote, dialect, d1Tables, extra, d1AllocationTriggers, d1DropAllocationTriggers;
var init_d1_schema = __esm({
  "../db/d1-schema.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    init_pg_core();
    init_schema2();
    init_cpf_migration();
    init_cadastro_tabs_migration();
    init_cnh_exam_modality_migration();
    init_school_yards_interest_migration();
    D1_NOW = "(strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))";
    D1_VERSION = "d1_schema_v1";
    D1_INITIAL_CHECKSUM = "cccc65180e383fdeabad6b239c1a2cc9f51d116b42953cd287e8224372ad3d11";
    quote = /* @__PURE__ */ __name((name) => `"${name.replaceAll('"', '""')}"`, "quote");
    dialect = new PgDialect();
    d1Tables = Object.fromEntries(
      Object.values(schema_exports).map((table) => {
        const config = getTableConfig(table);
        return [config.name, Object.values(getTableColumns(table)).map((column) => {
          const kind = column.dataType === "json" ? "json" : column.dataType === "boolean" ? "boolean" : column.dataType === "date" ? "timestamp" : column.dataType;
          let defaultSql = "NULL";
          if (column.default !== void 0) {
            if (column.default && typeof column.default === "object" && "queryChunks" in column.default) {
              defaultSql = dialect.sqlToQuery(column.default).sql.replace(/now\(\)/gi, D1_NOW);
            } else if (kind === "json") defaultSql = `'${JSON.stringify(column.default).replaceAll("'", "''")}'`;
            else if (typeof column.default === "string") defaultSql = `'${column.default.replaceAll("'", "''")}'`;
            else if (typeof column.default === "boolean") defaultSql = column.default ? "1" : "0";
            else defaultSql = String(column.default);
          }
          return {
            name: column.name,
            kind,
            required: column.notNull,
            primary: column.primary,
            unique: column.isUnique,
            defaultSql
          };
        })];
      })
    );
    d1Tables.sessoes = [
      { name: "id", kind: "string", primary: true, required: true, unique: false, defaultSql: "NULL" },
      { name: "usuario_id", kind: "string", primary: false, required: true, unique: false, defaultSql: "NULL" },
      { name: "expira_em", kind: "timestamp", primary: false, required: true, unique: false, defaultSql: "NULL" },
      { name: "criado_em", kind: "timestamp", primary: false, required: false, unique: false, defaultSql: D1_NOW }
    ];
    d1Tables.backups = [
      { name: "id", kind: "string", primary: true, required: true, unique: false, defaultSql: "NULL" },
      { name: "tipo_gatilho", kind: "string", primary: false, required: true, unique: false, defaultSql: "'manual'" },
      { name: "dados", kind: "json", primary: false, required: false, unique: false, defaultSql: "NULL" },
      { name: "tamanho_bytes", kind: "number", primary: false, required: false, unique: false, defaultSql: "0" },
      { name: "criado_em", kind: "timestamp", primary: false, required: true, unique: false, defaultSql: D1_NOW }
    ];
    extra = /* @__PURE__ */ __name((name, kind = "string") => ({ name, kind, primary: false, required: false, unique: false, defaultSql: "NULL" }), "extra");
    d1Tables.backups.push(extra("tamanho_armazenado_bytes", "number"), extra("checksum_sha256"));
    d1Tables.sessions = d1Tables.sessoes.map((c) => ({
      ...c,
      name: { usuario_id: "user_id", expira_em: "expires_at", criado_em: "created_at" }[c.name] ?? c.name
    }));
    d1Tables.migracoes_schema = [
      { ...extra("versao"), primary: true, required: true },
      { ...extra("aplicado_em", "timestamp"), defaultSql: D1_NOW }
    ];
    d1Tables.bancas.push(extra("location_id"));
    d1Tables.configuracoes.push(...["zapi_instance_id", "zapi_token", "zapi_client_token"].map((n) => extra(n)));
    d1Tables.examinadores.push(
      extra("categories", "json"),
      ...["default_max_slots_a", "default_max_slots_b", "default_max_slots_mudanca"].map((n) => extra(n, "number"))
    );
    for (const t of ["instrutores", "solicitacoes", "solicitacoes_cfc", "solicitacoes_cnhbrasil", "solicitacoes_pcd"]) d1Tables[t].push(extra("cpf_hash"));
    d1Tables.veiculos.push(extra("ano_modelo"));
    __name(initialD1Statements, "initialD1Statements");
    d1AllocationTriggers = /* @__PURE__ */ __name(() => initialD1Statements().filter((s) => s.startsWith("CREATE TRIGGER")), "d1AllocationTriggers");
    d1DropAllocationTriggers = /* @__PURE__ */ __name(() => ["insert", "update"].map((event) => `DROP TRIGGER IF EXISTS vagas_cfc_guard_${event}`), "d1DropAllocationTriggers");
    __name(d1Checksum, "d1Checksum");
  }
});

// _d1-sql.ts
function translateD1Sql(source, params) {
  if (/\b(DO\s+\$|information_schema|INCLUDING\s+ALL|ILIKE|JSONB_SET)\b/i.test(source)) {
    throw new Error("SQL PostgreSQL n\xE3o suportado no D1; use a migra\xE7\xE3o ou uma consulta D1 expl\xEDcita.");
  }
  const insert = /^\s*insert\s+into\s+"([^"]+)"\s*\(([^)]+)\)\s*values\s*/i.exec(source);
  if (insert) {
    const columns = [...insert[2].matchAll(/"([^"]+)"/g)].map((m2) => m2[1]);
    const defaults = d1Tables[insert[1]];
    if (!defaults) throw new Error("Tabela D1 desconhecida.");
    const suffix = source.slice(insert[0].length);
    let level = 0, col2 = 0;
    source = insert[0] + (suffix.match(tokens) ?? []).map((token) => {
      if (token === "(") {
        level++;
        if (level === 1) col2 = 0;
      }
      if (token === ")" && level > 0) level--;
      if (token === "," && level === 1) col2++;
      if (/^default$/i.test(token) && level === 1) {
        return defaults.find((c) => c.name === columns[col2])?.defaultSql ?? "NULL";
      }
      return token;
    }).join("");
  }
  const pieces = source.match(tokens) ?? [];
  const bound = [];
  let output = "";
  for (let i = 0; i < pieces.length; i++) {
    const token = pieces[i];
    if (/^\$\d+$/.test(token)) {
      const value = params[Number(token.slice(1)) - 1];
      bound.push(value instanceof Date ? value.toISOString() : typeof value === "boolean" ? Number(value) : value ?? null);
      output += "?";
    } else if (/^now$/i.test(token) && pieces[i + 1] === "(" && pieces[i + 2] === ")") {
      output += D1_NOW;
      i += 2;
    } else if (token === ":" && pieces[i + 1] === ":" && /^jsonb$/i.test(pieces[i + 2])) {
      i += 2;
    } else if (token === ":" && pieces[i + 1] === ":" && /^date$/i.test(pieces[i + 2])) {
      const identifier = /("[^"]+"|[a-z_][a-z_0-9]*)$/i.exec(output);
      if (!identifier) throw new Error("Convers\xE3o de data D1 n\xE3o suportada.");
      output = output.slice(0, -identifier[0].length) + `date(${identifier[0]})`;
      i += 2;
    } else if (/^public$/i.test(token) && pieces[i + 1] === ".") {
      i++;
    } else {
      output += token;
    }
  }
  if (bound.length > 100 || new TextEncoder().encode(output).length > 1e5) {
    throw new Error("Consulta excede os limites D1 (100 par\xE2metros / 100 KB). Use um lote at\xF4mico.");
  }
  for (const value of bound) {
    if (typeof value === "string" && new TextEncoder().encode(value).length > 19e5) {
      throw new Error("Valor excede o limite de registro D1. Divida o conte\xFAdo antes de gravar.");
    }
  }
  return { sql: output, params: bound };
}
function decodeD1Row(row, arrayMode = false) {
  const entries = Object.entries(row).map(([key, value]) => {
    const kind = kinds.get(aliases[key] ?? key);
    if (value != null && kind === "boolean") value = value === 1 || value === true;
    if (typeof value === "string" && kind === "json") value = JSON.parse(value);
    if (typeof value === "string" && kind === "timestamp" && arrayMode) value = value.replace(/Z$/, "");
    return [key, value];
  });
  return arrayMode ? entries.map(([, v2]) => v2) : Object.fromEntries(entries);
}
var tokens, kinds, aliases;
var init_d1_sql = __esm({
  "_d1-sql.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_d1_schema();
    tokens = /'(?:''|[^'])*'|"(?: ""|""|[^"])*"|\$\d+|[a-z_][a-z_0-9]*|\s+|./gis;
    __name(translateD1Sql, "translateD1Sql");
    kinds = new Map(Object.values(d1Tables).flatMap((cols) => cols.map((c) => [c.name, c.kind])));
    aliases = {
      name: "nome",
      role: "perfil",
      force_password_change: "forcar_troca_senha",
      allowed_modules: "modulos_permitidos",
      allowed_location_ids: "locais_permitidos_ids",
      two_factor_enabled: "dois_fatores_ativo",
      payload: "dados",
      details: "detalhes"
    };
    __name(decodeD1Row, "decodeD1Row");
  }
});

// _d1.ts
async function verifyD1Schema(db) {
  if (!isD1(db)) return;
  if (db.$d1Verified) return;
  const binding = d1Binding(db);
  const applied = await binding.prepare("SELECT checksum FROM migracoes_d1 WHERE versao = ?").bind(D1_VERSION).first();
  if (!applied || applied.checksum !== await d1Checksum()) throw new Error("Migra\xE7\xF5es D1 ausentes ou incompat\xEDveis. Execute a manuten\xE7\xE3o de schema antes de usar o ambiente.");
  const cpf = await binding.prepare("SELECT checksum FROM migracoes_d1 WHERE versao = ?").bind(CPF_D1_VERSION).first();
  if (!cpf || cpf.checksum !== await cpfD1Checksum()) throw new Error("Migra\xE7\xE3o D1 de autopreenchimento ausente ou incompat\xEDvel. Execute a manuten\xE7\xE3o de schema.");
  const tabs = await binding.prepare("SELECT checksum FROM migracoes_d1 WHERE versao = ?").bind(CADASTRO_TABS_D1_VERSION).first();
  if (!tabs || tabs.checksum !== await cadastroTabsD1Checksum()) throw new Error("Migra\xE7\xE3o D1 de abas de cadastro ausente ou incompat\xEDvel. Execute a manuten\xE7\xE3o de schema.");
  const modality = await binding.prepare("SELECT checksum FROM migracoes_d1 WHERE versao = ?").bind(CNH_MODALITY_VERSION).first();
  if (!modality || modality.checksum !== await cnhModalityChecksum()) throw new Error("Migra\xE7\xE3o D1 de modalidades CNH ausente ou incompat\xEDvel. Execute a manuten\xE7\xE3o de schema.");
  const yards = await binding.prepare("SELECT checksum FROM migracoes_d1 WHERE versao = ?").bind(YARDS_INTEREST_VERSION).first();
  if (!yards || yards.checksum !== await yardsInterestChecksum()) throw new Error("Migra\xE7\xE3o D1 de p\xE1tios/interesse ausente ou incompat\xEDvel. Execute a manuten\xE7\xE3o de schema.");
  db.$d1Verified = true;
}
function createD1Db(binding) {
  const prepared = /* @__PURE__ */ __name((q) => {
    const translated = translateD1Sql(q.sql, q.params);
    return binding.prepare(translated.sql).bind(...translated.params);
  }, "prepared");
  const result = /* @__PURE__ */ __name((r, q) => ({
    rows: (r.results ?? []).map((row) => decodeD1Row(row, q.options.arrayMode)),
    rowCount: r.meta.changes,
    command: q.sql.trim().split(/\s/)[0].toUpperCase()
  }), "result");
  const client = /* @__PURE__ */ __name((sql4, params = [], options = {}) => {
    const descriptor = { sql: sql4, params, options };
    let execution;
    const run = /* @__PURE__ */ __name(async () => {
      const alter = /^\s*ALTER TABLE (?:public\.)?(\w+) ADD COLUMN IF NOT EXISTS (\w+)/i.exec(sql4);
      if (alter) {
        const info = await binding.prepare(`PRAGMA table_info("${alter[1]}")`).all();
        if (!info.results.some((c) => c.name === alter[2])) throw new Error("Coluna D1 ausente; aplique uma migra\xE7\xE3o versionada.");
        return { rows: [], rowCount: 0 };
      }
      return result(await prepared(descriptor).all(), descriptor);
    }, "run");
    return Object.assign(descriptor, {
      then(resolve, reject) {
        execution ??= run();
        return execution.then(resolve, reject);
      }
    });
  }, "client");
  client.transaction = async (queries) => {
    if (queries.length > 40) throw new Error("Lote D1 excede o limite seguro de 40 consultas; nenhuma grava\xE7\xE3o foi executada.");
    const results = await binding.batch(queries.map(prepared));
    return results.map((r, i) => result(r, queries[i]));
  };
  const db = drizzle(client, { schema: schema_exports });
  Object.assign(db, { $d1: binding });
  return db;
}
var isD1, d1Binding;
var init_d1 = __esm({
  "_d1.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_neon_http();
    init_schema2();
    init_d1_schema();
    init_cpf_migration();
    init_cadastro_tabs_migration();
    init_cnh_exam_modality_migration();
    init_school_yards_interest_migration();
    init_d1_sql();
    isD1 = /* @__PURE__ */ __name((db) => !!db.$d1, "isD1");
    d1Binding = /* @__PURE__ */ __name((db) => {
      if (!db.$d1) throw new Error("Opera\xE7\xE3o requer D1.");
      return db.$d1;
    }, "d1Binding");
    __name(verifyD1Schema, "verifyD1Schema");
    __name(createD1Db, "createD1Db");
  }
});

// _migration-sql.mjs
function tbl(oldName, newName) {
  return `BEGIN ALTER TABLE IF EXISTS ${oldName} RENAME TO ${newName}; EXCEPTION WHEN OTHERS THEN NULL; END;`;
}
function col(table, oldCol, newCol) {
  return `BEGIN ALTER TABLE IF EXISTS ${table} RENAME COLUMN ${oldCol} TO ${newCol}; EXCEPTION WHEN OTHERS THEN NULL; END;`;
}
var solicitacoesTables, vagasTables, tableRenames, colRenames, PT_SCHEMA_DO_BLOCK, PT_SCHEMA_VERIFY_SQL, PT_SCHEMA_MARKER_SQL;
var init_migration_sql = __esm({
  "_migration-sql.mjs"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(tbl, "tbl");
    __name(col, "col");
    solicitacoesTables = ["solicitacoes", "solicitacoes_cnhbrasil", "solicitacoes_cfc", "solicitacoes_pcd"];
    vagasTables = ["vagas_banca", "vagas_cfc", "vagas_pcd"];
    tableRenames = [
      tbl("users", "usuarios"),
      tbl("otp_codes", "codigos_otp"),
      tbl("driving_schools", "autoescolas"),
      tbl("examiners", "examinadores"),
      tbl("instructors", "instrutores"),
      tbl("vehicles", "veiculos"),
      tbl("exam_locations", "locais_exame"),
      tbl("exam_schedules", "bancas"),
      tbl("exam_requests", "solicitacoes"),
      tbl("system_settings", "configuracoes"),
      tbl("audit_logs", "logs_auditoria"),
      tbl("blocked_dates", "datas_bloqueadas"),
      tbl("cities", "cidades"),
      tbl("exam_schedule_slots", "vagas_banca"),
      tbl("banca_results", "resultados_banca"),
      tbl("cnhbrasil_requests", "solicitacoes_cnhbrasil"),
      tbl("exam_requests_cnh_brasil", "solicitacoes_cnhbrasil"),
      tbl("cfc_requests", "solicitacoes_cfc"),
      tbl("exam_requests_cfc", "solicitacoes_cfc"),
      tbl("pcd_requests", "solicitacoes_pcd"),
      tbl("exam_requests_pcd", "solicitacoes_pcd"),
      tbl("cfc_schedule_slots", "vagas_cfc"),
      tbl("pcd_schedule_slots", "vagas_pcd"),
      tbl("schema_migrations", "migracoes_schema"),
      tbl("sessions", "sessoes")
    ];
    colRenames = [
      // backups
      col("backups", "trigger_type", "tipo_gatilho"),
      col("backups", "payload", "dados"),
      col("backups", "size_bytes", "tamanho_bytes"),
      col("backups", "created_at", "criado_em"),
      // usuarios
      col("usuarios", "name", "nome"),
      col("usuarios", "password", "senha"),
      col("usuarios", "role", "perfil"),
      col("usuarios", "school_id", "autoescola_id"),
      col("usuarios", "examiner_id", "examinador_id"),
      col("usuarios", "instructor_id", "instrutor_id"),
      col("usuarios", "force_password_change", "forcar_troca_senha"),
      col("usuarios", "allowed_modules", "modulos_permitidos"),
      col("usuarios", "allowed_location_ids", "locais_permitidos_ids"),
      col("usuarios", "phone", "telefone"),
      col("usuarios", "two_factor_enabled", "dois_fatores_ativo"),
      col("usuarios", "created_at", "criado_em"),
      // codigos_otp
      col("codigos_otp", "user_id", "usuario_id"),
      col("codigos_otp", "code", "codigo"),
      col("codigos_otp", "expires_at", "expira_em"),
      col("codigos_otp", "used", "usado"),
      col("codigos_otp", "failed_attempts", "tentativas_falhas"),
      col("codigos_otp", "created_at", "criado_em"),
      // sessoes
      col("sessoes", "user_id", "usuario_id"),
      col("sessoes", "expires_at", "expira_em"),
      col("sessoes", "created_at", "criado_em"),
      // autoescolas
      col("autoescolas", "name", "nome"),
      col("autoescolas", "phone", "telefone"),
      col("autoescolas", "address", "endereco"),
      col("autoescolas", "city", "cidade"),
      col("autoescolas", "services", "servicos"),
      col("autoescolas", "moto_yard_address", "endereco_patio_moto"),
      col("autoescolas", "car_yard_address", "endereco_patio_carro"),
      col("autoescolas", "category_change_yard_address", "endereco_patio_mudanca"),
      col("autoescolas", "main_schedule", "banca_principal"),
      col("autoescolas", "provisional_schedule", "banca_provisoria"),
      col("autoescolas", "created_at", "criado_em"),
      // examinadores
      col("examinadores", "name", "nome"),
      col("examinadores", "registration_number", "matricula"),
      col("examinadores", "can_exam_common", "pode_examinar_comum"),
      col("examinadores", "can_exam_pcd", "pode_examinar_pcd"),
      col("examinadores", "categories", "categorias"),
      col("examinadores", "default_max_slots_a", "max_vagas_a_padrao"),
      col("examinadores", "default_max_slots_b", "max_vagas_b_padrao"),
      col("examinadores", "default_max_slots_mudanca", "max_vagas_mudanca_padrao"),
      col("examinadores", "created_at", "criado_em"),
      // instrutores
      col("instrutores", "name", "nome"),
      col("instrutores", "phone", "telefone"),
      col("instrutores", "category", "categoria"),
      col("instrutores", "plate", "placa"),
      col("instrutores", "created_at", "criado_em"),
      // veiculos
      col("veiculos", "instructor_id", "instrutor_id"),
      col("veiculos", "type", "tipo"),
      col("veiculos", "brand", "marca"),
      col("veiculos", "model", "modelo"),
      col("veiculos", "plate", "placa"),
      col("veiculos", "active", "ativo"),
      col("veiculos", "transmission", "transmissao"),
      col("veiculos", "accessories", "acessorios"),
      col("veiculos", "created_at", "criado_em"),
      // locais_exame
      col("locais_exame", "city_id", "cidade_id"),
      col("locais_exame", "address", "endereco"),
      col("locais_exame", "maps_url", "url_maps"),
      col("locais_exame", "regions_served", "regioes_atendidas"),
      col("locais_exame", "created_at", "criado_em"),
      // bancas
      col("bancas", "code", "codigo"),
      col("bancas", "date", "data"),
      col("bancas", "time", "hora"),
      col("bancas", "examiner_ids", "examinadores_ids"),
      col("bancas", "max_slots_a", "max_vagas_a"),
      col("bancas", "max_slots_b", "max_vagas_b"),
      col("bancas", "type", "tipo"),
      col("bancas", "cancellation_reason", "motivo_cancelamento"),
      col("bancas", "location_id", "local_id"),
      col("bancas", "created_at", "criado_em"),
      // solicitacoes (4 tabelas)
      ...solicitacoesTables.flatMap((t) => [
        col(t, "student_name", "nome_candidato"),
        col(t, "social_name", "nome_social"),
        col(t, "phone", "telefone"),
        col(t, "address", "endereco"),
        col(t, "city", "cidade"),
        col(t, "request_type", "tipo_solicitacao"),
        col(t, "exam_type", "tipo_exame"),
        col(t, "intended_category", "categoria_pretendida"),
        col(t, "source", "origem"),
        col(t, "school_id", "autoescola_id"),
        col(t, "paid_fee", "taxa_paga_bool"),
        col(t, "completed_practical_course", "curso_pratico_concluido"),
        col(t, "practical_hours", "horas_praticas"),
        col(t, "has_vehicle", "tem_veiculo"),
        col(t, "cnh_restriction", "restricao_cnh"),
        col(t, "instructor", "instrutor"),
        col(t, "vehicle_plate", "placa_veiculo"),
        col(t, "disability_type", "tipo_deficiencia"),
        col(t, "special_needs", "necessidades_especiais"),
        col(t, "result", "resultado"),
        col(t, "schedule_id", "banca_id"),
        col(t, "scheduled_date", "data_agendada"),
        col(t, "scheduled_time", "hora_agendada"),
        col(t, "scheduled_category", "categoria_agendada"),
        col(t, "examiner_id", "examinador_id"),
        col(t, "attendance_confirmed", "presenca_confirmada"),
        col(t, "cancellation_reason", "motivo_cancelamento"),
        col(t, "observation", "observacao"),
        col(t, "exam_history", "historico_exames"),
        col(t, "category_quantities", "quantidades_categoria"),
        col(t, "checklist_vehicle", "checklist_veiculo"),
        col(t, "practical_course_inserted", "curso_pratico_inserido"),
        col(t, "row_color", "cor_linha"),
        col(t, "created_at", "criado_em"),
        col(t, "updated_at", "atualizado_em"),
        col(t, "queue_updated_at", "fila_atualizado_em"),
        col(t, "scheduled_by", "agendado_por")
      ]),
      // configuracoes
      col("configuracoes", "agency_name", "nome_orgao"),
      col("configuracoes", "agency_address", "endereco_orgao"),
      col("configuracoes", "logo_url", "url_logo"),
      col("configuracoes", "maintenance_mode", "modo_manutencao"),
      col("configuracoes", "min_days_scheduling", "min_dias_agendamento"),
      col("configuracoes", "max_daily_slots", "max_vagas_diarias"),
      col("configuracoes", "default_max_slots_a", "max_vagas_a_padrao"),
      col("configuracoes", "default_max_slots_b", "max_vagas_b_padrao"),
      col("configuracoes", "default_max_slots_mudanca", "max_vagas_mudanca_padrao"),
      col("configuracoes", "whatsapp_message_template", "template_whatsapp"),
      col("configuracoes", "whatsapp_template", "template_whatsapp"),
      // variante antiga encontrada em produção
      col("configuracoes", "cfc_whatsapp_template", "template_whatsapp_cfc"),
      col("configuracoes", "default_exam_address", "endereco_exame_padrao"),
      col("configuracoes", "default_exam_address_link", "link_exame_padrao"),
      col("configuracoes", "restrictions", "restricoes"),
      col("configuracoes", "pcd_exam_name", "nome_exame_pcd"),
      col("configuracoes", "pcd_default_exam_address", "endereco_exame_pcd_padrao"),
      col("configuracoes", "pcd_default_exam_address_link", "link_exame_pcd_padrao"),
      col("configuracoes", "pcd_main_schedule", "banca_principal_pcd"),
      col("configuracoes", "cnh_brasil_main_schedule", "banca_principal_cnh_brasil"),
      col("configuracoes", "block_weekends", "bloquear_fins_semana"),
      col("configuracoes", "risk_area_key", "chave_area_risco"),
      // logs_auditoria
      col("logs_auditoria", "user_id", "usuario_id"),
      col("logs_auditoria", "user_name", "nome_usuario"),
      col("logs_auditoria", "user_role", "perfil_usuario"),
      col("logs_auditoria", "action", "acao"),
      col("logs_auditoria", "entity", "entidade"),
      col("logs_auditoria", "entity_id", "entidade_id"),
      col("logs_auditoria", "details", "detalhes"),
      col("logs_auditoria", "created_at", "criado_em"),
      // datas_bloqueadas
      col("datas_bloqueadas", "date", "data"),
      col("datas_bloqueadas", "description", "descricao"),
      col("datas_bloqueadas", "is_holiday", "feriado"),
      col("datas_bloqueadas", "created_at", "criado_em"),
      // cidades
      col("cidades", "name", "nome"),
      col("cidades", "created_at", "criado_em"),
      // vagas (3 tabelas)
      ...vagasTables.flatMap((t) => [
        col(t, "school_id", "autoescola_id"),
        col(t, "exam_type", "tipo_exame"),
        col(t, "request_type", "tipo_solicitacao"),
        col(t, "intended_category", "categoria_pretendida"),
        col(t, "scheduled_date", "data_agendada"),
        col(t, "scheduled_time", "hora_agendada"),
        col(t, "examiner_id", "examinador_id"),
        col(t, "schedule_id", "banca_id"),
        col(t, "scheduled_category", "categoria_agendada"),
        col(t, "attendance_confirmed", "presenca_confirmada"),
        col(t, "cancellation_reason", "motivo_cancelamento"),
        col(t, "observation", "observacao"),
        col(t, "created_at", "criado_em"),
        col(t, "updated_at", "atualizado_em")
      ]),
      // resultados_banca
      col("resultados_banca", "schedule_id", "banca_id"),
      col("resultados_banca", "school_id", "autoescola_id"),
      col("resultados_banca", "category", "categoria"),
      col("resultados_banca", "total_slots", "total_vagas"),
      col("resultados_banca", "used_slots", "vagas_usadas"),
      col("resultados_banca", "approved", "aprovados"),
      col("resultados_banca", "failed", "reprovados"),
      col("resultados_banca", "absent", "ausentes"),
      col("resultados_banca", "cancelled", "cancelados"),
      col("resultados_banca", "created_at", "criado_em"),
      col("resultados_banca", "updated_at", "atualizado_em"),
      // migracoes_schema
      col("migracoes_schema", "version", "versao"),
      col("migracoes_schema", "applied_at", "aplicado_em")
    ];
    PT_SCHEMA_DO_BLOCK = `
DO $ptmig$
BEGIN
  -- Renomear tabelas (cada uma protegida: alvo j\xE1 existente n\xE3o aborta o bloco)
  ${tableRenames.join("\n  ")}

  -- Recriar \xEDndice \xFAnico de backups com coluna renomeada
  BEGIN
    DROP INDEX IF EXISTS backups_auto_daily;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  -- Renomear colunas
  ${colRenames.join("\n  ")}

  BEGIN
    CREATE UNIQUE INDEX IF NOT EXISTS backups_auto_daily ON backups ((criado_em::date)) WHERE tipo_gatilho = 'auto';
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
END $ptmig$;
`;
    PT_SCHEMA_VERIFY_SQL = `
SELECT
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='usuarios'       AND column_name='perfil')           AS c1,
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='sessoes'        AND column_name='usuario_id')       AS c2,
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='bancas'         AND column_name='examinadores_ids') AS c3,
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='configuracoes'  AND column_name='nome_orgao')       AS c4,
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='solicitacoes'   AND column_name='nome_candidato')   AS c5,
  (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='logs_auditoria' AND column_name='acao')             AS c6
`;
    PT_SCHEMA_MARKER_SQL = `
DO $ptmarker$
BEGIN
  CREATE TABLE IF NOT EXISTS migracoes_schema (versao text PRIMARY KEY, aplicado_em timestamp DEFAULT now());
  INSERT INTO migracoes_schema (versao) VALUES ('pt_schema_v1') ON CONFLICT DO NOTHING;
END $ptmarker$;
`;
  }
});

// _db.ts
async function ensureSlotQuantities(db) {
  if (isD1(db)) return verifyD1Schema(db);
  if (_slotQuantitiesReady) return;
  await db.execute(sql`DO $$ BEGIN
    ALTER TABLE vagas_cfc ADD COLUMN IF NOT EXISTS quantidades_categoria jsonb;
    ALTER TABLE vagas_pcd ADD COLUMN IF NOT EXISTS quantidades_categoria jsonb;
  END $$`);
  _slotQuantitiesReady = true;
}
async function verifyPtSchema(db) {
  try {
    const v2 = await db.execute(sql.raw(PT_SCHEMA_VERIFY_SQL));
    const row = (v2.rows ?? v2)[0] ?? {};
    return !!(row.c1 && row.c2 && row.c3 && row.c4 && row.c5 && row.c6);
  } catch {
    return false;
  }
}
async function ensurePortugueseSchema(db) {
  if (isD1(db)) return verifyD1Schema(db);
  if (_schemaMigrated) return;
  try {
    const r = await db.execute(sql`SELECT 1 FROM migracoes_schema WHERE versao = 'pt_schema_v1' LIMIT 1`);
    if ((r.rows ?? r).length > 0) {
      _schemaMigrated = true;
      return;
    }
  } catch {
  }
  try {
    await db.execute(sql.raw(PT_SCHEMA_DO_BLOCK));
  } catch (e) {
    console.error("[schema-migrate] DO block failed:", e);
  }
  if (await verifyPtSchema(db)) {
    try {
      await db.execute(sql.raw(PT_SCHEMA_MARKER_SQL));
    } catch {
    }
    _schemaMigrated = true;
  }
}
async function ensureCnhBrasilSdcStorage(db) {
  if (isD1(db)) return verifyD1Schema(db);
  if (_cnhBrasilSdcStorageReady) return;
  await db.execute(sql`
    ALTER TABLE solicitacoes_cnhbrasil
    ADD COLUMN IF NOT EXISTS sem_duplo_comando boolean DEFAULT false
  `);
  _cnhBrasilSdcStorageReady = true;
}
async function ensureColumnMigrations(db) {
  if (isD1(db)) return verifyD1Schema(db);
  if (_columnMigrationsReady) return;
  try {
    await db.execute(sql`ALTER TABLE veiculos ADD COLUMN IF NOT EXISTS duplo_comando boolean DEFAULT false`);
    await db.execute(sql`ALTER TABLE veiculos ADD COLUMN IF NOT EXISTS procuracao boolean DEFAULT false`);
    await db.execute(sql`ALTER TABLE veiculos ADD COLUMN IF NOT EXISTS ano_fabricacao text`);
    await db.execute(sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS banca_principal_cnh_brasil JSONB`);
    await db.execute(sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS max_vagas_mudanca_padrao INTEGER DEFAULT 10`);
    await db.execute(sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS chave_area_risco text`);
    await db.execute(sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS ano_fabricacao_maximo JSONB`);
    await db.execute(sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS sem_duplo_comando boolean DEFAULT false`);
    await db.execute(sql`ALTER TABLE examinadores ADD COLUMN IF NOT EXISTS periodos_bloqueio JSONB DEFAULT '[]'::jsonb`);
  } catch {
  }
  await db.execute(sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS preencher_nome_cpf_cnh boolean NOT NULL DEFAULT false`);
  await db.execute(sql`CREATE TABLE IF NOT EXISTS cotas_consulta_cpf (id text PRIMARY KEY, janela_minuto integer NOT NULL, consultas integer NOT NULL DEFAULT 0)`);
  await db.execute(sql.raw(CNH_MODALITY_NEON_SQL));
  await db.execute(sql.raw(YARDS_INTEREST_NEON_SQL));
  _columnMigrationsReady = true;
}
function getDb(env) {
  if (env.DB_PROVIDER === "d1") {
    if (!env.DB?.prepare) throw new Error("D1 selecionado sem binding DB. Conex\xE3o Neon n\xE3o ser\xE1 usada como fallback.");
    return createD1Db(env.DB);
  }
  if (env.DB_PROVIDER && env.DB_PROVIDER !== "neon") throw new Error("DB_PROVIDER inv\xE1lido.");
  const url = env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL not set in environment");
  const sqlClient = Xs(url);
  return drizzle(sqlClient, { schema: schema_exports });
}
function json2(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function error(message, status = 500) {
  return json2({ error: message }, status);
}
async function parseBody(req) {
  try {
    return await req.json();
  } catch {
    return {};
  }
}
function getQuery(url) {
  const { searchParams } = new URL(url);
  const result = {};
  searchParams.forEach((v2, k) => {
    result[k] = v2;
  });
  return result;
}
function extractActor(req) {
  return {
    userId: req.headers.get("X-User-Id") ?? null,
    userName: req.headers.get("X-User-Name") ?? null,
    userRole: req.headers.get("X-User-Role") ?? null
  };
}
async function writeAuditLog(db, actor, action, entity, entityId, details) {
  try {
    if (!_auditTableReady) {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS logs_auditoria (
          id text PRIMARY KEY,
          usuario_id text,
          nome_usuario text,
          perfil_usuario text,
          acao text NOT NULL,
          entidade text NOT NULL,
          entidade_id text,
          detalhes jsonb,
          criado_em timestamp DEFAULT (now())
        )
      `);
      _auditTableReady = true;
    }
    const id = crypto.randomUUID();
    const det = details ? JSON.stringify(details) : null;
    await db.execute(sql`
      INSERT INTO logs_auditoria (id, usuario_id, nome_usuario, perfil_usuario, acao, entidade, entidade_id, detalhes, criado_em)
      VALUES (
        ${id},
        ${actor.userId},
        ${actor.userName},
        ${actor.userRole},
        ${action},
        ${entity},
        ${entityId},
        ${det}::jsonb,
        now()
      )
    `);
  } catch (e) {
    console.error("[audit] write failed:", e);
  }
}
var _schemaMigrated, _cnhBrasilSdcStorageReady, _columnMigrationsReady, _slotQuantitiesReady, _auditTableReady;
var init_db2 = __esm({
  "_db.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_serverless();
    init_neon_http();
    init_drizzle_orm();
    init_schema2();
    init_d1();
    init_cnh_exam_modality_migration();
    init_school_yards_interest_migration();
    init_migration_sql();
    _schemaMigrated = false;
    _cnhBrasilSdcStorageReady = false;
    _columnMigrationsReady = false;
    _slotQuantitiesReady = false;
    __name(ensureSlotQuantities, "ensureSlotQuantities");
    __name(verifyPtSchema, "verifyPtSchema");
    __name(ensurePortugueseSchema, "ensurePortugueseSchema");
    __name(ensureCnhBrasilSdcStorage, "ensureCnhBrasilSdcStorage");
    __name(ensureColumnMigrations, "ensureColumnMigrations");
    __name(getDb, "getDb");
    __name(json2, "json");
    __name(error, "error");
    __name(parseBody, "parseBody");
    __name(getQuery, "getQuery");
    __name(extractActor, "extractActor");
    _auditTableReady = false;
    __name(writeAuditLog, "writeAuditLog");
  }
});

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/bcryptjs@3.0.3/node_modules/bcryptjs/index.js
function randomBytes(len) {
  try {
    return crypto.getRandomValues(new Uint8Array(len));
  } catch {
  }
  try {
    return import_crypto.default.randomBytes(len);
  } catch {
  }
  if (!randomFallback) {
    throw Error(
      "Neither WebCryptoAPI nor a crypto module is available. Use bcrypt.setRandomFallback to set an alternative"
    );
  }
  return randomFallback(len);
}
function setRandomFallback(random) {
  randomFallback = random;
}
function genSaltSync(rounds, seed_length) {
  rounds = rounds || GENSALT_DEFAULT_LOG2_ROUNDS;
  if (typeof rounds !== "number")
    throw Error(
      "Illegal arguments: " + typeof rounds + ", " + typeof seed_length
    );
  if (rounds < 4) rounds = 4;
  else if (rounds > 31) rounds = 31;
  var salt = [];
  salt.push("$2b$");
  if (rounds < 10) salt.push("0");
  salt.push(rounds.toString());
  salt.push("$");
  salt.push(base64_encode(randomBytes(BCRYPT_SALT_LEN), BCRYPT_SALT_LEN));
  return salt.join("");
}
function genSalt(rounds, seed_length, callback) {
  if (typeof seed_length === "function")
    callback = seed_length, seed_length = void 0;
  if (typeof rounds === "function") callback = rounds, rounds = void 0;
  if (typeof rounds === "undefined") rounds = GENSALT_DEFAULT_LOG2_ROUNDS;
  else if (typeof rounds !== "number")
    throw Error("illegal arguments: " + typeof rounds);
  function _async(callback2) {
    nextTick(function() {
      try {
        callback2(null, genSaltSync(rounds));
      } catch (err) {
        callback2(err);
      }
    });
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function hashSync(password, salt) {
  if (typeof salt === "undefined") salt = GENSALT_DEFAULT_LOG2_ROUNDS;
  if (typeof salt === "number") salt = genSaltSync(salt);
  if (typeof password !== "string" || typeof salt !== "string")
    throw Error("Illegal arguments: " + typeof password + ", " + typeof salt);
  return _hash(password, salt);
}
function hash(password, salt, callback, progressCallback) {
  function _async(callback2) {
    if (typeof password === "string" && typeof salt === "number")
      genSalt(salt, function(err, salt2) {
        _hash(password, salt2, callback2, progressCallback);
      });
    else if (typeof password === "string" && typeof salt === "string")
      _hash(password, salt, callback2, progressCallback);
    else
      nextTick(
        callback2.bind(
          this,
          Error("Illegal arguments: " + typeof password + ", " + typeof salt)
        )
      );
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function safeStringCompare(known, unknown) {
  var diff = known.length ^ unknown.length;
  for (var i = 0; i < known.length; ++i) {
    diff |= known.charCodeAt(i) ^ unknown.charCodeAt(i);
  }
  return diff === 0;
}
function compareSync(password, hash2) {
  if (typeof password !== "string" || typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof password + ", " + typeof hash2);
  if (hash2.length !== 60) return false;
  return safeStringCompare(
    hashSync(password, hash2.substring(0, hash2.length - 31)),
    hash2
  );
}
function compare(password, hashValue, callback, progressCallback) {
  function _async(callback2) {
    if (typeof password !== "string" || typeof hashValue !== "string") {
      nextTick(
        callback2.bind(
          this,
          Error(
            "Illegal arguments: " + typeof password + ", " + typeof hashValue
          )
        )
      );
      return;
    }
    if (hashValue.length !== 60) {
      nextTick(callback2.bind(this, null, false));
      return;
    }
    hash(
      password,
      hashValue.substring(0, 29),
      function(err, comp) {
        if (err) callback2(err);
        else callback2(null, safeStringCompare(comp, hashValue));
      },
      progressCallback
    );
  }
  __name(_async, "_async");
  if (callback) {
    if (typeof callback !== "function")
      throw Error("Illegal callback: " + typeof callback);
    _async(callback);
  } else
    return new Promise(function(resolve, reject) {
      _async(function(err, res) {
        if (err) {
          reject(err);
          return;
        }
        resolve(res);
      });
    });
}
function getRounds(hash2) {
  if (typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof hash2);
  return parseInt(hash2.split("$")[2], 10);
}
function getSalt(hash2) {
  if (typeof hash2 !== "string")
    throw Error("Illegal arguments: " + typeof hash2);
  if (hash2.length !== 60)
    throw Error("Illegal hash length: " + hash2.length + " != 60");
  return hash2.substring(0, 29);
}
function truncates(password) {
  if (typeof password !== "string")
    throw Error("Illegal arguments: " + typeof password);
  return utf8Length(password) > 72;
}
function utf8Length(string) {
  var len = 0, c = 0;
  for (var i = 0; i < string.length; ++i) {
    c = string.charCodeAt(i);
    if (c < 128) len += 1;
    else if (c < 2048) len += 2;
    else if ((c & 64512) === 55296 && (string.charCodeAt(i + 1) & 64512) === 56320) {
      ++i;
      len += 4;
    } else len += 3;
  }
  return len;
}
function utf8Array(string) {
  var offset = 0, c1, c2;
  var buffer = new Array(utf8Length(string));
  for (var i = 0, k = string.length; i < k; ++i) {
    c1 = string.charCodeAt(i);
    if (c1 < 128) {
      buffer[offset++] = c1;
    } else if (c1 < 2048) {
      buffer[offset++] = c1 >> 6 | 192;
      buffer[offset++] = c1 & 63 | 128;
    } else if ((c1 & 64512) === 55296 && ((c2 = string.charCodeAt(i + 1)) & 64512) === 56320) {
      c1 = 65536 + ((c1 & 1023) << 10) + (c2 & 1023);
      ++i;
      buffer[offset++] = c1 >> 18 | 240;
      buffer[offset++] = c1 >> 12 & 63 | 128;
      buffer[offset++] = c1 >> 6 & 63 | 128;
      buffer[offset++] = c1 & 63 | 128;
    } else {
      buffer[offset++] = c1 >> 12 | 224;
      buffer[offset++] = c1 >> 6 & 63 | 128;
      buffer[offset++] = c1 & 63 | 128;
    }
  }
  return buffer;
}
function base64_encode(b, len) {
  var off = 0, rs2 = [], c1, c2;
  if (len <= 0 || len > b.length) throw Error("Illegal len: " + len);
  while (off < len) {
    c1 = b[off++] & 255;
    rs2.push(BASE64_CODE[c1 >> 2 & 63]);
    c1 = (c1 & 3) << 4;
    if (off >= len) {
      rs2.push(BASE64_CODE[c1 & 63]);
      break;
    }
    c2 = b[off++] & 255;
    c1 |= c2 >> 4 & 15;
    rs2.push(BASE64_CODE[c1 & 63]);
    c1 = (c2 & 15) << 2;
    if (off >= len) {
      rs2.push(BASE64_CODE[c1 & 63]);
      break;
    }
    c2 = b[off++] & 255;
    c1 |= c2 >> 6 & 3;
    rs2.push(BASE64_CODE[c1 & 63]);
    rs2.push(BASE64_CODE[c2 & 63]);
  }
  return rs2.join("");
}
function base64_decode(s, len) {
  var off = 0, slen = s.length, olen = 0, rs2 = [], c1, c2, c3, c4, o, code;
  if (len <= 0) throw Error("Illegal len: " + len);
  while (off < slen - 1 && olen < len) {
    code = s.charCodeAt(off++);
    c1 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    code = s.charCodeAt(off++);
    c2 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    if (c1 == -1 || c2 == -1) break;
    o = c1 << 2 >>> 0;
    o |= (c2 & 48) >> 4;
    rs2.push(String.fromCharCode(o));
    if (++olen >= len || off >= slen) break;
    code = s.charCodeAt(off++);
    c3 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    if (c3 == -1) break;
    o = (c2 & 15) << 4 >>> 0;
    o |= (c3 & 60) >> 2;
    rs2.push(String.fromCharCode(o));
    if (++olen >= len || off >= slen) break;
    code = s.charCodeAt(off++);
    c4 = code < BASE64_INDEX.length ? BASE64_INDEX[code] : -1;
    o = (c3 & 3) << 6 >>> 0;
    o |= c4;
    rs2.push(String.fromCharCode(o));
    ++olen;
  }
  var res = [];
  for (off = 0; off < olen; off++) res.push(rs2[off].charCodeAt(0));
  return res;
}
function _encipher(lr2, off, P, S2) {
  var n, l = lr2[off], r = lr2[off + 1];
  l ^= P[0];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[1];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[2];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[3];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[4];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[5];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[6];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[7];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[8];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[9];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[10];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[11];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[12];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[13];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[14];
  n = S2[l >>> 24];
  n += S2[256 | l >> 16 & 255];
  n ^= S2[512 | l >> 8 & 255];
  n += S2[768 | l & 255];
  r ^= n ^ P[15];
  n = S2[r >>> 24];
  n += S2[256 | r >> 16 & 255];
  n ^= S2[512 | r >> 8 & 255];
  n += S2[768 | r & 255];
  l ^= n ^ P[16];
  lr2[off] = r ^ P[BLOWFISH_NUM_ROUNDS + 1];
  lr2[off + 1] = l;
  return lr2;
}
function _streamtoword(data, offp) {
  for (var i = 0, word = 0; i < 4; ++i)
    word = word << 8 | data[offp] & 255, offp = (offp + 1) % data.length;
  return { key: word, offp };
}
function _key(key, P, S2) {
  var offset = 0, lr2 = [0, 0], plen = P.length, slen = S2.length, sw;
  for (var i = 0; i < plen; i++)
    sw = _streamtoword(key, offset), offset = sw.offp, P[i] = P[i] ^ sw.key;
  for (i = 0; i < plen; i += 2)
    lr2 = _encipher(lr2, 0, P, S2), P[i] = lr2[0], P[i + 1] = lr2[1];
  for (i = 0; i < slen; i += 2)
    lr2 = _encipher(lr2, 0, P, S2), S2[i] = lr2[0], S2[i + 1] = lr2[1];
}
function _ekskey(data, key, P, S2) {
  var offp = 0, lr2 = [0, 0], plen = P.length, slen = S2.length, sw;
  for (var i = 0; i < plen; i++)
    sw = _streamtoword(key, offp), offp = sw.offp, P[i] = P[i] ^ sw.key;
  offp = 0;
  for (i = 0; i < plen; i += 2)
    sw = _streamtoword(data, offp), offp = sw.offp, lr2[0] ^= sw.key, sw = _streamtoword(data, offp), offp = sw.offp, lr2[1] ^= sw.key, lr2 = _encipher(lr2, 0, P, S2), P[i] = lr2[0], P[i + 1] = lr2[1];
  for (i = 0; i < slen; i += 2)
    sw = _streamtoword(data, offp), offp = sw.offp, lr2[0] ^= sw.key, sw = _streamtoword(data, offp), offp = sw.offp, lr2[1] ^= sw.key, lr2 = _encipher(lr2, 0, P, S2), S2[i] = lr2[0], S2[i + 1] = lr2[1];
}
function _crypt(b, salt, rounds, callback, progressCallback) {
  var cdata = C_ORIG.slice(), clen = cdata.length, err;
  if (rounds < 4 || rounds > 31) {
    err = Error("Illegal number of rounds (4-31): " + rounds);
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  if (salt.length !== BCRYPT_SALT_LEN) {
    err = Error(
      "Illegal salt length: " + salt.length + " != " + BCRYPT_SALT_LEN
    );
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  rounds = 1 << rounds >>> 0;
  var P, S2, i = 0, j;
  if (typeof Int32Array === "function") {
    P = new Int32Array(P_ORIG);
    S2 = new Int32Array(S_ORIG);
  } else {
    P = P_ORIG.slice();
    S2 = S_ORIG.slice();
  }
  _ekskey(salt, b, P, S2);
  function next() {
    if (progressCallback) progressCallback(i / rounds);
    if (i < rounds) {
      var start = Date.now();
      for (; i < rounds; ) {
        i = i + 1;
        _key(b, P, S2);
        _key(salt, P, S2);
        if (Date.now() - start > MAX_EXECUTION_TIME) break;
      }
    } else {
      for (i = 0; i < 64; i++)
        for (j = 0; j < clen >> 1; j++) _encipher(cdata, j << 1, P, S2);
      var ret = [];
      for (i = 0; i < clen; i++)
        ret.push((cdata[i] >> 24 & 255) >>> 0), ret.push((cdata[i] >> 16 & 255) >>> 0), ret.push((cdata[i] >> 8 & 255) >>> 0), ret.push((cdata[i] & 255) >>> 0);
      if (callback) {
        callback(null, ret);
        return;
      } else return ret;
    }
    if (callback) nextTick(next);
  }
  __name(next, "next");
  if (typeof callback !== "undefined") {
    next();
  } else {
    var res;
    while (true) if (typeof (res = next()) !== "undefined") return res || [];
  }
}
function _hash(password, salt, callback, progressCallback) {
  var err;
  if (typeof password !== "string" || typeof salt !== "string") {
    err = Error("Invalid string / salt: Not a string");
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  var minor, offset;
  if (salt.charAt(0) !== "$" || salt.charAt(1) !== "2") {
    err = Error("Invalid salt version: " + salt.substring(0, 2));
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  if (salt.charAt(2) === "$") minor = String.fromCharCode(0), offset = 3;
  else {
    minor = salt.charAt(2);
    if (minor !== "a" && minor !== "b" && minor !== "y" || salt.charAt(3) !== "$") {
      err = Error("Invalid salt revision: " + salt.substring(2, 4));
      if (callback) {
        nextTick(callback.bind(this, err));
        return;
      } else throw err;
    }
    offset = 4;
  }
  if (salt.charAt(offset + 2) > "$") {
    err = Error("Missing salt rounds");
    if (callback) {
      nextTick(callback.bind(this, err));
      return;
    } else throw err;
  }
  var r1 = parseInt(salt.substring(offset, offset + 1), 10) * 10, r2 = parseInt(salt.substring(offset + 1, offset + 2), 10), rounds = r1 + r2, real_salt = salt.substring(offset + 3, offset + 25);
  password += minor >= "a" ? "\0" : "";
  var passwordb = utf8Array(password), saltb = base64_decode(real_salt, BCRYPT_SALT_LEN);
  function finish(bytes) {
    var res = [];
    res.push("$2");
    if (minor >= "a") res.push(minor);
    res.push("$");
    if (rounds < 10) res.push("0");
    res.push(rounds.toString());
    res.push("$");
    res.push(base64_encode(saltb, saltb.length));
    res.push(base64_encode(bytes, C_ORIG.length * 4 - 1));
    return res.join("");
  }
  __name(finish, "finish");
  if (typeof callback == "undefined")
    return finish(_crypt(passwordb, saltb, rounds));
  else {
    _crypt(
      passwordb,
      saltb,
      rounds,
      function(err2, bytes) {
        if (err2) callback(err2, null);
        else callback(null, finish(bytes));
      },
      progressCallback
    );
  }
}
function encodeBase64(bytes, length) {
  return base64_encode(bytes, length);
}
function decodeBase64(string, length) {
  return base64_decode(string, length);
}
var import_crypto, randomFallback, nextTick, BASE64_CODE, BASE64_INDEX, BCRYPT_SALT_LEN, GENSALT_DEFAULT_LOG2_ROUNDS, BLOWFISH_NUM_ROUNDS, MAX_EXECUTION_TIME, P_ORIG, S_ORIG, C_ORIG, bcryptjs_default;
var init_bcryptjs = __esm({
  "../node_modules/.pnpm/bcryptjs@3.0.3/node_modules/bcryptjs/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    import_crypto = __toESM(require_crypto(), 1);
    randomFallback = null;
    __name(randomBytes, "randomBytes");
    __name(setRandomFallback, "setRandomFallback");
    __name(genSaltSync, "genSaltSync");
    __name(genSalt, "genSalt");
    __name(hashSync, "hashSync");
    __name(hash, "hash");
    __name(safeStringCompare, "safeStringCompare");
    __name(compareSync, "compareSync");
    __name(compare, "compare");
    __name(getRounds, "getRounds");
    __name(getSalt, "getSalt");
    __name(truncates, "truncates");
    nextTick = typeof setImmediate === "function" ? setImmediate : typeof scheduler === "object" && typeof scheduler.postTask === "function" ? scheduler.postTask.bind(scheduler) : setTimeout;
    __name(utf8Length, "utf8Length");
    __name(utf8Array, "utf8Array");
    BASE64_CODE = "./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");
    BASE64_INDEX = [
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      0,
      1,
      54,
      55,
      56,
      57,
      58,
      59,
      60,
      61,
      62,
      63,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      16,
      17,
      18,
      19,
      20,
      21,
      22,
      23,
      24,
      25,
      26,
      27,
      -1,
      -1,
      -1,
      -1,
      -1,
      -1,
      28,
      29,
      30,
      31,
      32,
      33,
      34,
      35,
      36,
      37,
      38,
      39,
      40,
      41,
      42,
      43,
      44,
      45,
      46,
      47,
      48,
      49,
      50,
      51,
      52,
      53,
      -1,
      -1,
      -1,
      -1,
      -1
    ];
    __name(base64_encode, "base64_encode");
    __name(base64_decode, "base64_decode");
    BCRYPT_SALT_LEN = 16;
    GENSALT_DEFAULT_LOG2_ROUNDS = 10;
    BLOWFISH_NUM_ROUNDS = 16;
    MAX_EXECUTION_TIME = 100;
    P_ORIG = [
      608135816,
      2242054355,
      320440878,
      57701188,
      2752067618,
      698298832,
      137296536,
      3964562569,
      1160258022,
      953160567,
      3193202383,
      887688300,
      3232508343,
      3380367581,
      1065670069,
      3041331479,
      2450970073,
      2306472731
    ];
    S_ORIG = [
      3509652390,
      2564797868,
      805139163,
      3491422135,
      3101798381,
      1780907670,
      3128725573,
      4046225305,
      614570311,
      3012652279,
      134345442,
      2240740374,
      1667834072,
      1901547113,
      2757295779,
      4103290238,
      227898511,
      1921955416,
      1904987480,
      2182433518,
      2069144605,
      3260701109,
      2620446009,
      720527379,
      3318853667,
      677414384,
      3393288472,
      3101374703,
      2390351024,
      1614419982,
      1822297739,
      2954791486,
      3608508353,
      3174124327,
      2024746970,
      1432378464,
      3864339955,
      2857741204,
      1464375394,
      1676153920,
      1439316330,
      715854006,
      3033291828,
      289532110,
      2706671279,
      2087905683,
      3018724369,
      1668267050,
      732546397,
      1947742710,
      3462151702,
      2609353502,
      2950085171,
      1814351708,
      2050118529,
      680887927,
      999245976,
      1800124847,
      3300911131,
      1713906067,
      1641548236,
      4213287313,
      1216130144,
      1575780402,
      4018429277,
      3917837745,
      3693486850,
      3949271944,
      596196993,
      3549867205,
      258830323,
      2213823033,
      772490370,
      2760122372,
      1774776394,
      2652871518,
      566650946,
      4142492826,
      1728879713,
      2882767088,
      1783734482,
      3629395816,
      2517608232,
      2874225571,
      1861159788,
      326777828,
      3124490320,
      2130389656,
      2716951837,
      967770486,
      1724537150,
      2185432712,
      2364442137,
      1164943284,
      2105845187,
      998989502,
      3765401048,
      2244026483,
      1075463327,
      1455516326,
      1322494562,
      910128902,
      469688178,
      1117454909,
      936433444,
      3490320968,
      3675253459,
      1240580251,
      122909385,
      2157517691,
      634681816,
      4142456567,
      3825094682,
      3061402683,
      2540495037,
      79693498,
      3249098678,
      1084186820,
      1583128258,
      426386531,
      1761308591,
      1047286709,
      322548459,
      995290223,
      1845252383,
      2603652396,
      3431023940,
      2942221577,
      3202600964,
      3727903485,
      1712269319,
      422464435,
      3234572375,
      1170764815,
      3523960633,
      3117677531,
      1434042557,
      442511882,
      3600875718,
      1076654713,
      1738483198,
      4213154764,
      2393238008,
      3677496056,
      1014306527,
      4251020053,
      793779912,
      2902807211,
      842905082,
      4246964064,
      1395751752,
      1040244610,
      2656851899,
      3396308128,
      445077038,
      3742853595,
      3577915638,
      679411651,
      2892444358,
      2354009459,
      1767581616,
      3150600392,
      3791627101,
      3102740896,
      284835224,
      4246832056,
      1258075500,
      768725851,
      2589189241,
      3069724005,
      3532540348,
      1274779536,
      3789419226,
      2764799539,
      1660621633,
      3471099624,
      4011903706,
      913787905,
      3497959166,
      737222580,
      2514213453,
      2928710040,
      3937242737,
      1804850592,
      3499020752,
      2949064160,
      2386320175,
      2390070455,
      2415321851,
      4061277028,
      2290661394,
      2416832540,
      1336762016,
      1754252060,
      3520065937,
      3014181293,
      791618072,
      3188594551,
      3933548030,
      2332172193,
      3852520463,
      3043980520,
      413987798,
      3465142937,
      3030929376,
      4245938359,
      2093235073,
      3534596313,
      375366246,
      2157278981,
      2479649556,
      555357303,
      3870105701,
      2008414854,
      3344188149,
      4221384143,
      3956125452,
      2067696032,
      3594591187,
      2921233993,
      2428461,
      544322398,
      577241275,
      1471733935,
      610547355,
      4027169054,
      1432588573,
      1507829418,
      2025931657,
      3646575487,
      545086370,
      48609733,
      2200306550,
      1653985193,
      298326376,
      1316178497,
      3007786442,
      2064951626,
      458293330,
      2589141269,
      3591329599,
      3164325604,
      727753846,
      2179363840,
      146436021,
      1461446943,
      4069977195,
      705550613,
      3059967265,
      3887724982,
      4281599278,
      3313849956,
      1404054877,
      2845806497,
      146425753,
      1854211946,
      1266315497,
      3048417604,
      3681880366,
      3289982499,
      290971e4,
      1235738493,
      2632868024,
      2414719590,
      3970600049,
      1771706367,
      1449415276,
      3266420449,
      422970021,
      1963543593,
      2690192192,
      3826793022,
      1062508698,
      1531092325,
      1804592342,
      2583117782,
      2714934279,
      4024971509,
      1294809318,
      4028980673,
      1289560198,
      2221992742,
      1669523910,
      35572830,
      157838143,
      1052438473,
      1016535060,
      1802137761,
      1753167236,
      1386275462,
      3080475397,
      2857371447,
      1040679964,
      2145300060,
      2390574316,
      1461121720,
      2956646967,
      4031777805,
      4028374788,
      33600511,
      2920084762,
      1018524850,
      629373528,
      3691585981,
      3515945977,
      2091462646,
      2486323059,
      586499841,
      988145025,
      935516892,
      3367335476,
      2599673255,
      2839830854,
      265290510,
      3972581182,
      2759138881,
      3795373465,
      1005194799,
      847297441,
      406762289,
      1314163512,
      1332590856,
      1866599683,
      4127851711,
      750260880,
      613907577,
      1450815602,
      3165620655,
      3734664991,
      3650291728,
      3012275730,
      3704569646,
      1427272223,
      778793252,
      1343938022,
      2676280711,
      2052605720,
      1946737175,
      3164576444,
      3914038668,
      3967478842,
      3682934266,
      1661551462,
      3294938066,
      4011595847,
      840292616,
      3712170807,
      616741398,
      312560963,
      711312465,
      1351876610,
      322626781,
      1910503582,
      271666773,
      2175563734,
      1594956187,
      70604529,
      3617834859,
      1007753275,
      1495573769,
      4069517037,
      2549218298,
      2663038764,
      504708206,
      2263041392,
      3941167025,
      2249088522,
      1514023603,
      1998579484,
      1312622330,
      694541497,
      2582060303,
      2151582166,
      1382467621,
      776784248,
      2618340202,
      3323268794,
      2497899128,
      2784771155,
      503983604,
      4076293799,
      907881277,
      423175695,
      432175456,
      1378068232,
      4145222326,
      3954048622,
      3938656102,
      3820766613,
      2793130115,
      2977904593,
      26017576,
      3274890735,
      3194772133,
      1700274565,
      1756076034,
      4006520079,
      3677328699,
      720338349,
      1533947780,
      354530856,
      688349552,
      3973924725,
      1637815568,
      332179504,
      3949051286,
      53804574,
      2852348879,
      3044236432,
      1282449977,
      3583942155,
      3416972820,
      4006381244,
      1617046695,
      2628476075,
      3002303598,
      1686838959,
      431878346,
      2686675385,
      1700445008,
      1080580658,
      1009431731,
      832498133,
      3223435511,
      2605976345,
      2271191193,
      2516031870,
      1648197032,
      4164389018,
      2548247927,
      300782431,
      375919233,
      238389289,
      3353747414,
      2531188641,
      2019080857,
      1475708069,
      455242339,
      2609103871,
      448939670,
      3451063019,
      1395535956,
      2413381860,
      1841049896,
      1491858159,
      885456874,
      4264095073,
      4001119347,
      1565136089,
      3898914787,
      1108368660,
      540939232,
      1173283510,
      2745871338,
      3681308437,
      4207628240,
      3343053890,
      4016749493,
      1699691293,
      1103962373,
      3625875870,
      2256883143,
      3830138730,
      1031889488,
      3479347698,
      1535977030,
      4236805024,
      3251091107,
      2132092099,
      1774941330,
      1199868427,
      1452454533,
      157007616,
      2904115357,
      342012276,
      595725824,
      1480756522,
      206960106,
      497939518,
      591360097,
      863170706,
      2375253569,
      3596610801,
      1814182875,
      2094937945,
      3421402208,
      1082520231,
      3463918190,
      2785509508,
      435703966,
      3908032597,
      1641649973,
      2842273706,
      3305899714,
      1510255612,
      2148256476,
      2655287854,
      3276092548,
      4258621189,
      236887753,
      3681803219,
      274041037,
      1734335097,
      3815195456,
      3317970021,
      1899903192,
      1026095262,
      4050517792,
      356393447,
      2410691914,
      3873677099,
      3682840055,
      3913112168,
      2491498743,
      4132185628,
      2489919796,
      1091903735,
      1979897079,
      3170134830,
      3567386728,
      3557303409,
      857797738,
      1136121015,
      1342202287,
      507115054,
      2535736646,
      337727348,
      3213592640,
      1301675037,
      2528481711,
      1895095763,
      1721773893,
      3216771564,
      62756741,
      2142006736,
      835421444,
      2531993523,
      1442658625,
      3659876326,
      2882144922,
      676362277,
      1392781812,
      170690266,
      3921047035,
      1759253602,
      3611846912,
      1745797284,
      664899054,
      1329594018,
      3901205900,
      3045908486,
      2062866102,
      2865634940,
      3543621612,
      3464012697,
      1080764994,
      553557557,
      3656615353,
      3996768171,
      991055499,
      499776247,
      1265440854,
      648242737,
      3940784050,
      980351604,
      3713745714,
      1749149687,
      3396870395,
      4211799374,
      3640570775,
      1161844396,
      3125318951,
      1431517754,
      545492359,
      4268468663,
      3499529547,
      1437099964,
      2702547544,
      3433638243,
      2581715763,
      2787789398,
      1060185593,
      1593081372,
      2418618748,
      4260947970,
      69676912,
      2159744348,
      86519011,
      2512459080,
      3838209314,
      1220612927,
      3339683548,
      133810670,
      1090789135,
      1078426020,
      1569222167,
      845107691,
      3583754449,
      4072456591,
      1091646820,
      628848692,
      1613405280,
      3757631651,
      526609435,
      236106946,
      48312990,
      2942717905,
      3402727701,
      1797494240,
      859738849,
      992217954,
      4005476642,
      2243076622,
      3870952857,
      3732016268,
      765654824,
      3490871365,
      2511836413,
      1685915746,
      3888969200,
      1414112111,
      2273134842,
      3281911079,
      4080962846,
      172450625,
      2569994100,
      980381355,
      4109958455,
      2819808352,
      2716589560,
      2568741196,
      3681446669,
      3329971472,
      1835478071,
      660984891,
      3704678404,
      4045999559,
      3422617507,
      3040415634,
      1762651403,
      1719377915,
      3470491036,
      2693910283,
      3642056355,
      3138596744,
      1364962596,
      2073328063,
      1983633131,
      926494387,
      3423689081,
      2150032023,
      4096667949,
      1749200295,
      3328846651,
      309677260,
      2016342300,
      1779581495,
      3079819751,
      111262694,
      1274766160,
      443224088,
      298511866,
      1025883608,
      3806446537,
      1145181785,
      168956806,
      3641502830,
      3584813610,
      1689216846,
      3666258015,
      3200248200,
      1692713982,
      2646376535,
      4042768518,
      1618508792,
      1610833997,
      3523052358,
      4130873264,
      2001055236,
      3610705100,
      2202168115,
      4028541809,
      2961195399,
      1006657119,
      2006996926,
      3186142756,
      1430667929,
      3210227297,
      1314452623,
      4074634658,
      4101304120,
      2273951170,
      1399257539,
      3367210612,
      3027628629,
      1190975929,
      2062231137,
      2333990788,
      2221543033,
      2438960610,
      1181637006,
      548689776,
      2362791313,
      3372408396,
      3104550113,
      3145860560,
      296247880,
      1970579870,
      3078560182,
      3769228297,
      1714227617,
      3291629107,
      3898220290,
      166772364,
      1251581989,
      493813264,
      448347421,
      195405023,
      2709975567,
      677966185,
      3703036547,
      1463355134,
      2715995803,
      1338867538,
      1343315457,
      2802222074,
      2684532164,
      233230375,
      2599980071,
      2000651841,
      3277868038,
      1638401717,
      4028070440,
      3237316320,
      6314154,
      819756386,
      300326615,
      590932579,
      1405279636,
      3267499572,
      3150704214,
      2428286686,
      3959192993,
      3461946742,
      1862657033,
      1266418056,
      963775037,
      2089974820,
      2263052895,
      1917689273,
      448879540,
      3550394620,
      3981727096,
      150775221,
      3627908307,
      1303187396,
      508620638,
      2975983352,
      2726630617,
      1817252668,
      1876281319,
      1457606340,
      908771278,
      3720792119,
      3617206836,
      2455994898,
      1729034894,
      1080033504,
      976866871,
      3556439503,
      2881648439,
      1522871579,
      1555064734,
      1336096578,
      3548522304,
      2579274686,
      3574697629,
      3205460757,
      3593280638,
      3338716283,
      3079412587,
      564236357,
      2993598910,
      1781952180,
      1464380207,
      3163844217,
      3332601554,
      1699332808,
      1393555694,
      1183702653,
      3581086237,
      1288719814,
      691649499,
      2847557200,
      2895455976,
      3193889540,
      2717570544,
      1781354906,
      1676643554,
      2592534050,
      3230253752,
      1126444790,
      2770207658,
      2633158820,
      2210423226,
      2615765581,
      2414155088,
      3127139286,
      673620729,
      2805611233,
      1269405062,
      4015350505,
      3341807571,
      4149409754,
      1057255273,
      2012875353,
      2162469141,
      2276492801,
      2601117357,
      993977747,
      3918593370,
      2654263191,
      753973209,
      36408145,
      2530585658,
      25011837,
      3520020182,
      2088578344,
      530523599,
      2918365339,
      1524020338,
      1518925132,
      3760827505,
      3759777254,
      1202760957,
      3985898139,
      3906192525,
      674977740,
      4174734889,
      2031300136,
      2019492241,
      3983892565,
      4153806404,
      3822280332,
      352677332,
      2297720250,
      60907813,
      90501309,
      3286998549,
      1016092578,
      2535922412,
      2839152426,
      457141659,
      509813237,
      4120667899,
      652014361,
      1966332200,
      2975202805,
      55981186,
      2327461051,
      676427537,
      3255491064,
      2882294119,
      3433927263,
      1307055953,
      942726286,
      933058658,
      2468411793,
      3933900994,
      4215176142,
      1361170020,
      2001714738,
      2830558078,
      3274259782,
      1222529897,
      1679025792,
      2729314320,
      3714953764,
      1770335741,
      151462246,
      3013232138,
      1682292957,
      1483529935,
      471910574,
      1539241949,
      458788160,
      3436315007,
      1807016891,
      3718408830,
      978976581,
      1043663428,
      3165965781,
      1927990952,
      4200891579,
      2372276910,
      3208408903,
      3533431907,
      1412390302,
      2931980059,
      4132332400,
      1947078029,
      3881505623,
      4168226417,
      2941484381,
      1077988104,
      1320477388,
      886195818,
      18198404,
      3786409e3,
      2509781533,
      112762804,
      3463356488,
      1866414978,
      891333506,
      18488651,
      661792760,
      1628790961,
      3885187036,
      3141171499,
      876946877,
      2693282273,
      1372485963,
      791857591,
      2686433993,
      3759982718,
      3167212022,
      3472953795,
      2716379847,
      445679433,
      3561995674,
      3504004811,
      3574258232,
      54117162,
      3331405415,
      2381918588,
      3769707343,
      4154350007,
      1140177722,
      4074052095,
      668550556,
      3214352940,
      367459370,
      261225585,
      2610173221,
      4209349473,
      3468074219,
      3265815641,
      314222801,
      3066103646,
      3808782860,
      282218597,
      3406013506,
      3773591054,
      379116347,
      1285071038,
      846784868,
      2669647154,
      3771962079,
      3550491691,
      2305946142,
      453669953,
      1268987020,
      3317592352,
      3279303384,
      3744833421,
      2610507566,
      3859509063,
      266596637,
      3847019092,
      517658769,
      3462560207,
      3443424879,
      370717030,
      4247526661,
      2224018117,
      4143653529,
      4112773975,
      2788324899,
      2477274417,
      1456262402,
      2901442914,
      1517677493,
      1846949527,
      2295493580,
      3734397586,
      2176403920,
      1280348187,
      1908823572,
      3871786941,
      846861322,
      1172426758,
      3287448474,
      3383383037,
      1655181056,
      3139813346,
      901632758,
      1897031941,
      2986607138,
      3066810236,
      3447102507,
      1393639104,
      373351379,
      950779232,
      625454576,
      3124240540,
      4148612726,
      2007998917,
      544563296,
      2244738638,
      2330496472,
      2058025392,
      1291430526,
      424198748,
      50039436,
      29584100,
      3605783033,
      2429876329,
      2791104160,
      1057563949,
      3255363231,
      3075367218,
      3463963227,
      1469046755,
      985887462
    ];
    C_ORIG = [
      1332899944,
      1700884034,
      1701343084,
      1684370003,
      1668446532,
      1869963892
    ];
    __name(_encipher, "_encipher");
    __name(_streamtoword, "_streamtoword");
    __name(_key, "_key");
    __name(_ekskey, "_ekskey");
    __name(_crypt, "_crypt");
    __name(_hash, "_hash");
    __name(encodeBase64, "encodeBase64");
    __name(decodeBase64, "decodeBase64");
    bcryptjs_default = {
      setRandomFallback,
      genSaltSync,
      genSalt,
      hashSync,
      hash,
      compareSync,
      compare,
      getRounds,
      getSalt,
      truncates,
      encodeBase64,
      decodeBase64
    };
  }
});

// _password.ts
function hashPassword(plain) {
  return bcryptjs_default.hash(plain, SALT_ROUNDS);
}
async function verifyPassword(plain, stored) {
  if (!stored) return { ok: false };
  if (stored.startsWith("$2b$") || stored.startsWith("$2a$")) {
    const ok = await bcryptjs_default.compare(plain, stored);
    return { ok };
  }
  if (plain === stored) {
    const hash2 = await hashPassword(plain);
    return { ok: true, needsRehash: true, hash: hash2 };
  }
  return { ok: false };
}
var SALT_ROUNDS;
var init_password = __esm({
  "_password.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_bcryptjs();
    SALT_ROUNDS = 10;
    __name(hashPassword, "hashPassword");
    __name(verifyPassword, "verifyPassword");
  }
});

// api/users/change-own-password.ts
var onRequest;
var init_change_own_password = __esm({
  "api/users/change-own-password.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_password();
    onRequest = /* @__PURE__ */ __name(async (context) => {
      const { request, env, data } = context;
      if (request.method !== "POST") return error("Method Not Allowed", 405);
      const sessionUserId = data?.sessionUserId ?? "";
      if (!sessionUserId) return error("N\xE3o autenticado.", 401);
      try {
        const db = getDb(env);
        const body = await parseBody(request);
        const { password } = body;
        if (!password || password.length < 6) {
          return error("A senha deve ter no m\xEDnimo 6 caracteres.", 400);
        }
        const hashed = await hashPassword(password);
        const updated = await db.update(users).set({ password: hashed, forcePasswordChange: false }).where(eq(users.id, sessionUserId)).returning();
        if (!updated.length) return error("Usu\xE1rio n\xE3o encontrado.", 404);
        const { password: _p, ...safe } = updated[0];
        return json2(safe);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _resend.ts
async function sendOtpEmail(apiKey, to2, code, agencyName = "Pr\xE1ticoSys", fromEmail = "onboarding@resend.dev") {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8e3);
  try {
    const resp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: `${agencyName} <${fromEmail}>`,
        to: [to2],
        subject: `[${agencyName}] C\xF3digo de verifica\xE7\xE3o: ${code}`,
        html: `
          <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px;">
            <h2 style="color:#1e40af;margin-bottom:8px;">Verifica\xE7\xE3o em 2 etapas</h2>
            <p style="color:#374151;margin-bottom:20px;">Use o c\xF3digo abaixo para concluir seu acesso ao <strong>${agencyName}</strong>:</p>
            <div style="font-size:2.5rem;font-weight:900;letter-spacing:0.35em;color:#1e40af;margin:20px 0;padding:20px;background:#eff6ff;border-radius:12px;text-align:center;border:2px solid #bfdbfe;">${code}</div>
            <p style="color:#6b7280;font-size:0.875rem;">\u23F1\uFE0F Este c\xF3digo expira em <strong>10 minutos</strong>.</p>
            <p style="color:#6b7280;font-size:0.875rem;">\u{1F512} Nunca compartilhe este c\xF3digo com ningu\xE9m.</p>
            <hr style="margin:24px 0;border:none;border-top:1px solid #e5e7eb;" />
            <p style="color:#9ca3af;font-size:0.75rem;">Se voc\xEA n\xE3o tentou acessar o sistema, ignore este e-mail.</p>
          </div>
        `
      })
    });
    if (resp.ok) return { ok: true };
    console.error("[2fa] Resend recusou o envio do OTP", { status: resp.status });
    if (resp.status === 429) {
      return { ok: false, status: resp.status, message: "O servi\xE7o de e-mail recebeu muitas solicita\xE7\xF5es. Aguarde um minuto e tente novamente." };
    }
    if (resp.status === 400 || resp.status === 422) {
      return { ok: false, status: resp.status, message: "O endere\xE7o de e-mail ou o remetente configurado n\xE3o foi aceito. Confirme o e-mail cadastrado e a configura\xE7\xE3o do dom\xEDnio de envio." };
    }
    if (resp.status === 401) {
      return {
        ok: false,
        status: resp.status,
        message: "A chave do Resend configurada no Cloudflare Pages foi recusada. Atualize RESEND_API_KEY no ambiente Production e fa\xE7a um novo deploy."
      };
    }
    if (resp.status === 403) {
      return {
        ok: false,
        status: resp.status,
        message: "O Resend recusou o remetente ou a permiss\xE3o de envio. Configure RESEND_FROM_EMAIL com um endere\xE7o de dom\xEDnio verificado no Resend e confirme que a chave possui permiss\xE3o de envio."
      };
    }
    return { ok: false, status: resp.status, message: "O servi\xE7o de e-mail n\xE3o p\xF4de enviar o c\xF3digo agora. Tente novamente em alguns minutos." };
  } catch (cause) {
    const timedOut = controller.signal.aborted;
    console.error("[2fa] Falha ao chamar o Resend", {
      reason: timedOut ? "timeout" : "network_error",
      error: cause instanceof Error ? cause.name : "unknown"
    });
    return {
      ok: false,
      message: timedOut ? "O servi\xE7o de e-mail demorou demais para responder. Tente novamente em alguns minutos." : "N\xE3o foi poss\xEDvel conectar ao servi\xE7o de e-mail. Tente novamente em alguns minutos."
    };
  } finally {
    clearTimeout(timeout);
  }
}
var init_resend = __esm({
  "_resend.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(sendOtpEmail, "sendOtpEmail");
  }
});

// _d1-backup.ts
function splitD1Text(text2) {
  const bytes = new TextEncoder().encode(text2);
  if (bytes.length > D1_PAYLOAD_LIMIT) throw new Error("Conte\xFAdo excede o limite seguro de 8 MB deste fluxo D1. Avalie R2/processamento dedicado; nenhuma grava\xE7\xE3o foi feita.");
  const parts = [];
  const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: false });
  for (let start = 0; start < bytes.length; ) {
    let end = Math.min(start + PART_BYTES, bytes.length);
    while (end < bytes.length && (bytes[end] & 192) === 128) end--;
    parts.push(decoder.decode(bytes.slice(start, end)));
    start = end;
  }
  return parts.length ? parts : [""];
}
function backupPartStatements(binding, id, text2) {
  return splitD1Text(text2).map((part, index) => binding.prepare(
    "INSERT INTO backups_partes (backup_id, parte, dados) VALUES (?, ?, ?)"
  ).bind(id, index, part));
}
async function d1PayloadChecksum(text2) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text2));
  return Array.from(new Uint8Array(bytes), (v2) => v2.toString(16).padStart(2, "0")).join("");
}
async function createD1Backup(db, trigger) {
  const binding = d1Binding(db);
  if (trigger === "auto") {
    const existing = await binding.prepare("SELECT id FROM backups WHERE tipo_gatilho = 'auto' AND date(criado_em) = date('now')").first();
    if (existing) return { skipped: true };
  }
  const userColumns = d1Tables.usuarios.filter((c) => c.name !== "senha").map((c) => quote(c.name)).join(", ");
  const results = await binding.batch([
    ...BACKUP_TABLES.map((t) => binding.prepare(`SELECT * FROM ${quote(t)}`)),
    binding.prepare(`SELECT ${userColumns} FROM usuarios`)
  ]);
  const payload = Object.fromEntries([...BACKUP_TABLES, "usuarios"].map((t, index) => [t, results[index].results.map((row) => decodeD1Row(row))]));
  const text2 = JSON.stringify(payload), id = crypto.randomUUID();
  const parts = backupPartStatements(binding, id, text2);
  const bytes = new TextEncoder().encode(text2).length, checksum = await d1PayloadChecksum(text2);
  try {
    await binding.batch([
      binding.prepare("INSERT INTO backups (id, tipo_gatilho, dados, tamanho_bytes, criado_em, tamanho_armazenado_bytes, checksum_sha256) VALUES (?, ?, NULL, ?, ?, ?, ?)").bind(id, trigger, bytes, (/* @__PURE__ */ new Date()).toISOString(), bytes, checksum),
      ...parts,
      binding.prepare("DELETE FROM backups WHERE id NOT IN (SELECT id FROM backups ORDER BY criado_em DESC, id DESC LIMIT 15)")
    ]);
  } catch (e) {
    if (trigger === "auto" && String(e).includes("UNIQUE constraint failed: index")) {
      const exists2 = await binding.prepare("SELECT id FROM backups WHERE tipo_gatilho = 'auto' AND date(criado_em) = date('now')").first();
      if (exists2) return { skipped: true };
    }
    throw e;
  }
  return { id };
}
async function readD1Backup(db, id) {
  const binding = d1Binding(db);
  const stored = await binding.prepare("SELECT id, dados, tamanho_bytes, criado_em, tamanho_armazenado_bytes, checksum_sha256 FROM backups WHERE id = ?").bind(id).first();
  if (!stored) return null;
  let text2 = stored.dados;
  if (text2 === null) {
    const chunks = await binding.prepare("SELECT parte, dados FROM backups_partes WHERE backup_id = ? ORDER BY parte").bind(id).all();
    if (!chunks.results.length || chunks.results.some((p2, i) => p2.parte !== i)) throw new Error("Backup incompleto: partes ausentes.");
    text2 = chunks.results.map((p2) => p2.dados).join("");
    if (new TextEncoder().encode(text2).length !== (stored.tamanho_armazenado_bytes ?? stored.tamanho_bytes)) throw new Error("Backup incompleto: tamanho diferente do original.");
  }
  if (stored.checksum_sha256 && await d1PayloadChecksum(text2) !== stored.checksum_sha256) throw new Error("Backup corrompido: checksum n\xE3o confere.");
  return { id: stored.id, payload: JSON.parse(text2), created_at: stored.criado_em };
}
function d1ImportStatements(binding, tableName, rows) {
  const columns = d1Tables[tableName];
  if (!columns) throw new Error("Tabela desconhecida na importa\xE7\xE3o D1.");
  const groups = /* @__PURE__ */ new Map();
  for (const row of rows) {
    if (row.id === void 0 || row.id === null) throw new Error("Registro de importa\xE7\xE3o sem ID.");
    const names = Object.keys(row).sort();
    if (names.some((name) => !columns.some((c) => c.name === name))) throw new Error("Coluna desconhecida na importa\xE7\xE3o D1; revise o mapeamento.");
    const key = names.join("|");
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  const statements = [];
  for (const [key, group] of groups) {
    const names = key.split("|"), nonId = names.filter((n) => n !== "id");
    const select = names.map((n) => `json_extract(value, '$.${n}')`).join(", ");
    const conflict = nonId.length ? `DO UPDATE SET ${nonId.map((n) => `${quote(n)} = excluded.${quote(n)}`).join(", ")}` : "DO NOTHING";
    const query = `INSERT INTO ${quote(tableName)} (${names.map(quote).join(", ")}) SELECT ${select} FROM json_each(?) WHERE true ON CONFLICT (id) ${conflict}`;
    let chunk = [], size = 2;
    for (const row of group) {
      const bytes = new TextEncoder().encode(JSON.stringify(row)).length + 1;
      if (bytes > PART_BYTES) throw new Error("Registro excede o tamanho seguro para importar no D1.");
      if (size + bytes > PART_BYTES && chunk.length) {
        statements.push(binding.prepare(query).bind(JSON.stringify(chunk)));
        chunk = [];
        size = 2;
      }
      chunk.push(row);
      size += bytes;
    }
    if (chunk.length) statements.push(binding.prepare(query).bind(JSON.stringify(chunk)));
  }
  return statements;
}
async function restoreD1Backup(db, normalized) {
  const binding = d1Binding(db);
  if (new TextEncoder().encode(JSON.stringify(normalized)).length > D1_PAYLOAD_LIMIT) {
    throw new Error("Restaura\xE7\xE3o excede o limite seguro de 8 MB; nenhuma grava\xE7\xE3o foi feita.");
  }
  const records = Object.entries(normalized).flatMap(([t, rows]) => d1ImportStatements(binding, t, rows));
  const statements = !records.length ? [] : [
    ...d1DropAllocationTriggers().map((s) => binding.prepare(s)),
    ...records,
    ...d1AllocationTriggers().map((s) => binding.prepare(s))
  ];
  if (statements.length > 40) throw new Error("Restaura\xE7\xE3o excede o limite seguro de 40 consultas D1; nada foi alterado. Use um procedimento dedicado.");
  if (statements.length) await binding.batch(statements);
}
var D1_PAYLOAD_LIMIT, PART_BYTES, BACKUP_TABLES;
var init_d1_backup = __esm({
  "_d1-backup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_d1();
    init_d1_sql();
    init_d1_schema();
    D1_PAYLOAD_LIMIT = 8e6;
    PART_BYTES = 9e5;
    BACKUP_TABLES = [
      "autoescolas",
      "examinadores",
      "instrutores",
      "veiculos",
      "cidades",
      "solicitacoes_cnhbrasil",
      "solicitacoes_cfc",
      "solicitacoes_pcd",
      "vagas_cfc",
      "vagas_pcd",
      "resultados_banca",
      "locais_exame",
      "datas_bloqueadas",
      "configuracoes",
      "solicitacoes",
      "bancas",
      "vagas_banca"
    ];
    __name(splitD1Text, "splitD1Text");
    __name(backupPartStatements, "backupPartStatements");
    __name(d1PayloadChecksum, "d1PayloadChecksum");
    __name(createD1Backup, "createD1Backup");
    __name(readD1Backup, "readD1Backup");
    __name(d1ImportStatements, "d1ImportStatements");
    __name(restoreD1Backup, "restoreD1Backup");
  }
});

// _backup-restore.ts
function isObject(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function normalizeRow(table, value) {
  if (!isObject(value)) return null;
  const allowed = new Set(TABLE_COLUMNS[table]);
  const row = {};
  for (const [sourceColumn, sourceValue] of Object.entries(value)) {
    const targetColumn = COLUMN_ALIASES[table][sourceColumn] ?? sourceColumn;
    if (allowed.has(targetColumn) && (row[targetColumn] === void 0 || sourceColumn === targetColumn)) {
      row[targetColumn] = sourceValue;
    }
  }
  return row.id === void 0 || row.id === null ? null : row;
}
function normalizeBackupPayload(input) {
  const normalized = {};
  if (!isObject(input)) throw new Error("Arquivo de backup inv\xE1lido: objeto esperado.");
  for (const [sourceTable, sourceRows] of Object.entries(input)) {
    const table = TABLE_ALIASES[sourceTable];
    if (!table || !Array.isArray(sourceRows)) continue;
    const rows = sourceRows.map((value) => normalizeRow(table, value)).filter((row) => row !== null);
    normalized[table] = [...normalized[table] ?? [], ...rows];
  }
  return normalized;
}
function quoteIdentifier(identifier) {
  return `"${identifier.replaceAll('"', '""')}"`;
}
function valueSql(column, value) {
  if (value === void 0) return sql`NULL`;
  if (value === null) return sql`NULL`;
  if (JSON_COLUMNS.has(column) && typeof value === "object") {
    return sql`${JSON.stringify(value)}::jsonb`;
  }
  return sql`${value}`;
}
async function restoreRows(db, normalized) {
  const restored = {};
  for (const table of RESTORE_TABLES) {
    const rows = normalized[table] ?? [];
    if (rows.length === 0) continue;
    for (const row of rows) {
      const columns = TABLE_COLUMNS[table].filter((column) => row[column] !== void 0);
      if (!columns.includes("id")) continue;
      const quotedColumns = columns.map(quoteIdentifier).join(", ");
      const values = sql.join(columns.map((column) => valueSql(column, row[column])), sql`, `);
      const updates = columns.filter((column) => column !== "id").map((column) => `${quoteIdentifier(column)} = EXCLUDED.${quoteIdentifier(column)}`).join(", ");
      const conflict = updates ? sql`ON CONFLICT ("id") DO UPDATE SET ${sql.raw(updates)}` : sql`ON CONFLICT ("id") DO NOTHING`;
      await db.execute(sql`
        INSERT INTO ${sql.raw(quoteIdentifier(table))} (${sql.raw(quotedColumns)})
        VALUES (${values})
        ${conflict}
      `);
      restored[table] = (restored[table] ?? 0) + 1;
    }
  }
  return restored;
}
function prepareRestore(input) {
  const normalized = normalizeBackupPayload(input);
  const source = isObject(input) ? Object.keys(input) : [];
  const hasEnglish = source.some((key) => !!TABLE_ALIASES[key] && key !== TABLE_ALIASES[key]);
  const hasPortuguese = source.some((key) => !!TABLE_ALIASES[key] && key === TABLE_ALIASES[key]);
  const format = hasEnglish && hasPortuguese ? "mixed" : hasEnglish ? "english" : hasPortuguese ? "portuguese" : "unknown";
  return { normalized, format };
}
function restoreCounts(normalized) {
  return Object.fromEntries(
    RESTORE_TABLES.map((table) => [table, normalized[table]?.length ?? 0]).filter(([, count]) => count > 0)
  );
}
function toDrizzleValue(columnName, value) {
  if (value !== null && typeof value === "string" && ["criado_em", "atualizado_em", "fila_atualizado_em"].includes(columnName)) {
    return new Date(value);
  }
  return value;
}
async function restoreWithBatch(db, normalized, schemaTables) {
  const queries = [];
  for (const tableName of RESTORE_TABLES) {
    const table = schemaTables[tableName];
    if (!table) continue;
    const columns = getTableColumns(table);
    const propertyBySqlName = new Map(
      Object.entries(columns).map(([property, column]) => [column.name, property])
    );
    const idProperty = propertyBySqlName.get("id");
    if (!idProperty) continue;
    for (const row of normalized[tableName] ?? []) {
      const values = {};
      for (const [sqlName, value] of Object.entries(row)) {
        const property = propertyBySqlName.get(sqlName);
        if (property) values[property] = toDrizzleValue(sqlName, value);
      }
      if (values[idProperty] === void 0 || values[idProperty] === null) continue;
      const updates = { ...values };
      delete updates[idProperty];
      const insert = db.insert(table).values(values);
      queries.push(
        Object.keys(updates).length > 0 ? insert.onConflictDoUpdate({ target: columns[idProperty], set: updates }) : insert.onConflictDoNothing({ target: columns[idProperty] })
      );
    }
  }
  if (queries.length > 0) await db.batch(queries);
}
async function restoreBackup(db, input, options) {
  const { normalized, format } = prepareRestore(input);
  if (isD1(db)) {
    if (format === "unknown" || !isObject(input)) throw new Error("Backup D1 inv\xE1lido: tabelas reconhecidas ausentes.");
    for (const [sourceTable, sourceRows] of Object.entries(input)) {
      const table = TABLE_ALIASES[sourceTable];
      if (!table) continue;
      if (!Array.isArray(sourceRows) || sourceRows.some((row) => !isObject(row) || row.id == null)) {
        throw new Error("Backup D1 inv\xE1lido: registros sem ID ou tabela malformada. Nada foi restaurado.");
      }
      if (sourceTable === table) {
        const originals = new Map(sourceRows.map((row) => [row.id, row]));
        for (const row of normalized[table] ?? []) {
          const original = originals.get(row.id);
          for (const column of d1Tables[table]) {
            if (Object.hasOwn(original, column.name)) row[column.name] = original[column.name];
          }
        }
      }
    }
    await restoreD1Backup(db, normalized);
    return { restored: restoreCounts(normalized), format };
  }
  if (options?.batchTables) {
    await restoreWithBatch(db, normalized, options.batchTables);
    return { restored: restoreCounts(normalized), format };
  }
  if (typeof db.transaction !== "function") {
    throw new Error("O banco atual n\xE3o oferece restaura\xE7\xE3o transacional.");
  }
  const restored = await db.transaction(async (transaction) => restoreRows(transaction, normalized));
  return { restored, format };
}
var RESTORE_TABLES, TABLE_ALIASES, COMMON_REQUEST_COLUMNS, COMMON_SLOT_COLUMNS, TABLE_COLUMNS, COLUMN_ALIASES, JSON_COLUMNS;
var init_backup_restore = __esm({
  "_backup-restore.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    init_d1();
    init_d1_backup();
    init_d1_schema();
    RESTORE_TABLES = [
      "autoescolas",
      "examinadores",
      "instrutores",
      "veiculos",
      "cidades",
      "bancas",
      "solicitacoes",
      "solicitacoes_cnhbrasil",
      "solicitacoes_cfc",
      "solicitacoes_pcd",
      "vagas_banca",
      "vagas_cfc",
      "vagas_pcd",
      "resultados_banca",
      "locais_exame",
      "datas_bloqueadas",
      "configuracoes",
      "usuarios"
    ];
    TABLE_ALIASES = {
      autoescolas: "autoescolas",
      driving_schools: "autoescolas",
      examinadores: "examinadores",
      examiners: "examinadores",
      instrutores: "instrutores",
      instructors: "instrutores",
      veiculos: "veiculos",
      vehicles: "veiculos",
      cidades: "cidades",
      cities: "cidades",
      bancas: "bancas",
      exam_schedules: "bancas",
      solicitacoes: "solicitacoes",
      exam_requests: "solicitacoes",
      solicitacoes_cnhbrasil: "solicitacoes_cnhbrasil",
      cnhbrasil_requests: "solicitacoes_cnhbrasil",
      exam_requests_cnh_brasil: "solicitacoes_cnhbrasil",
      solicitacoes_cfc: "solicitacoes_cfc",
      cfc_requests: "solicitacoes_cfc",
      exam_requests_cfc: "solicitacoes_cfc",
      solicitacoes_pcd: "solicitacoes_pcd",
      pcd_requests: "solicitacoes_pcd",
      exam_requests_pcd: "solicitacoes_pcd",
      vagas_banca: "vagas_banca",
      exam_schedule_slots: "vagas_banca",
      vagas_cfc: "vagas_cfc",
      cfc_schedule_slots: "vagas_cfc",
      vagas_pcd: "vagas_pcd",
      pcd_schedule_slots: "vagas_pcd",
      resultados_banca: "resultados_banca",
      banca_results: "resultados_banca",
      locais_exame: "locais_exame",
      exam_locations: "locais_exame",
      datas_bloqueadas: "datas_bloqueadas",
      blocked_dates: "datas_bloqueadas",
      configuracoes: "configuracoes",
      system_settings: "configuracoes",
      usuarios: "usuarios",
      users: "usuarios"
    };
    COMMON_REQUEST_COLUMNS = [
      "id",
      "nome_candidato",
      "nome_social",
      "cpf",
      "telefone",
      "email",
      "endereco",
      "cidade",
      "tipo_solicitacao",
      "tipo_exame",
      "categoria_pretendida",
      "origem",
      "autoescola_id",
      "taxa_paga_bool",
      "curso_pratico_concluido",
      "horas_praticas",
      "tem_veiculo",
      "restricao_cnh",
      "instrutor",
      "placa_veiculo",
      "sem_duplo_comando",
      "checklist_veiculo",
      "curso_pratico_inserido",
      "taxa_paga",
      "tipo_deficiencia",
      "necessidades_especiais",
      "status",
      "resultado",
      "banca_id",
      "data_agendada",
      "hora_agendada",
      "categoria_agendada",
      "examinador_id",
      "presenca_confirmada",
      "motivo_cancelamento",
      "observacao",
      "quantidades_categoria",
      "historico_exames",
      "modulo",
      "cor_linha",
      "criado_em",
      "atualizado_em",
      "fila_atualizado_em",
      "agendado_por"
    ];
    COMMON_SLOT_COLUMNS = [
      "id",
      "autoescola_id",
      "tipo_exame",
      "tipo_solicitacao",
      "categoria_pretendida",
      "data_agendada",
      "hora_agendada",
      "examinador_id",
      "banca_id",
      "categoria_agendada",
      "status",
      "presenca_confirmada",
      "motivo_cancelamento",
      "observacao",
      "criado_em",
      "atualizado_em"
    ];
    TABLE_COLUMNS = {
      autoescolas: [
        "id",
        "nome",
        "telefone",
        "email",
        "endereco",
        "cidade",
        "servicos",
        "endereco_patio_moto",
        "endereco_patio_carro",
        "endereco_patio_mudanca",
        "banca_principal",
        "banca_provisoria",
        "criado_em",
        "nao_criar_usuario",
        "rodizio_provas",
        "perfil_cnh_brasil",
        "patios"
      ],
      examinadores: [
        "id",
        "nome",
        "matricula",
        "pode_examinar_comum",
        "pode_examinar_pcd",
        "categorias",
        "max_vagas_a_padrao",
        "max_vagas_b_padrao",
        "max_vagas_mudanca_padrao",
        "criado_em",
        "rodizio_provas",
        "disponibilidade_rodizio"
      ],
      instrutores: ["id", "nome", "cpf", "telefone", "categoria", "placa", "criado_em"],
      veiculos: [
        "id",
        "instrutor_id",
        "tipo",
        "marca",
        "modelo",
        "placa",
        "ativo",
        "transmissao",
        "acessorios",
        "duplo_comando",
        "procuracao",
        "criado_em",
        "ano_fabricacao"
      ],
      cidades: ["id", "nome", "criado_em"],
      bancas: [
        "id",
        "codigo",
        "data",
        "hora",
        "examinadores_ids",
        "max_vagas_a",
        "max_vagas_b",
        "tipo",
        "status",
        "motivo_cancelamento",
        "local_id",
        "criado_em"
      ],
      solicitacoes: COMMON_REQUEST_COLUMNS,
      solicitacoes_cnhbrasil: COMMON_REQUEST_COLUMNS.filter(
        (column) => !["tipo_deficiencia", "necessidades_especiais", "quantidades_categoria"].includes(column)
      ),
      solicitacoes_cfc: [
        ...COMMON_REQUEST_COLUMNS.filter(
          (column) => !["tipo_deficiencia", "necessidades_especiais"].includes(column)
        ),
        "examinadores_interessados"
      ],
      solicitacoes_pcd: COMMON_REQUEST_COLUMNS.filter(
        (column) => !["sem_duplo_comando", "quantidades_categoria"].includes(column)
      ),
      vagas_banca: COMMON_SLOT_COLUMNS,
      vagas_cfc: [...COMMON_SLOT_COLUMNS, "quantidades_categoria"],
      vagas_pcd: [...COMMON_SLOT_COLUMNS, "quantidades_categoria"],
      resultados_banca: [
        "id",
        "banca_id",
        "autoescola_id",
        "categoria",
        "total_vagas",
        "vagas_usadas",
        "aprovados",
        "reprovados",
        "ausentes",
        "cancelados",
        "modulo",
        "criado_em",
        "atualizado_em"
      ],
      locais_exame: ["id", "cidade_id", "endereco", "url_maps", "regioes_atendidas", "criado_em"],
      datas_bloqueadas: ["id", "data", "descricao", "feriado", "criado_em"],
      configuracoes: [
        "id",
        "nome_orgao",
        "endereco_orgao",
        "url_logo",
        "modo_manutencao",
        "min_dias_agendamento",
        "max_vagas_diarias",
        "max_vagas_a_padrao",
        "max_vagas_b_padrao",
        "max_vagas_mudanca_padrao",
        "template_whatsapp",
        "template_whatsapp_cfc",
        "endereco_exame_padrao",
        "link_exame_padrao",
        "restricoes",
        "nome_exame_pcd",
        "endereco_exame_pcd_padrao",
        "link_exame_pcd_padrao",
        "banca_principal_pcd",
        "banca_principal_cnh_brasil",
        "bloquear_fins_semana",
        "chave_area_risco",
        "ano_fabricacao_maximo",
        "preencher_nome_cpf_cnh"
      ],
      usuarios: [
        "id",
        "nome",
        "login",
        "senha",
        "perfil",
        "autoescola_id",
        "examinador_id",
        "instrutor_id",
        "email",
        "telefone",
        "dois_fatores_ativo",
        "forcar_troca_senha",
        "modulos_permitidos",
        "locais_permitidos_ids",
        "criado_em"
      ]
    };
    COLUMN_ALIASES = {
      autoescolas: {
        name: "nome",
        phone: "telefone",
        address: "endereco",
        city: "cidade",
        services: "servicos",
        moto_yard_address: "endereco_patio_moto",
        car_yard_address: "endereco_patio_carro",
        category_change_yard_address: "endereco_patio_mudanca",
        main_schedule: "banca_principal",
        provisional_schedule: "banca_provisoria",
        created_at: "criado_em",
        do_not_create_user: "nao_criar_usuario",
        exam_rotation: "rodizio_provas",
        cnh_brasil_profile: "perfil_cnh_brasil"
      },
      examinadores: {
        name: "nome",
        registration_number: "matricula",
        can_exam_common: "pode_examinar_comum",
        can_exam_pcd: "pode_examinar_pcd",
        categories: "categorias",
        default_max_slots_a: "max_vagas_a_padrao",
        default_max_slots_b: "max_vagas_b_padrao",
        default_max_slots_mudanca: "max_vagas_mudanca_padrao",
        created_at: "criado_em",
        exam_rotation: "rodizio_provas",
        rotation_availability: "disponibilidade_rodizio"
      },
      instrutores: {
        name: "nome",
        phone: "telefone",
        category: "categoria",
        plate: "placa",
        created_at: "criado_em"
      },
      veiculos: {
        instructor_id: "instrutor_id",
        type: "tipo",
        brand: "marca",
        model: "modelo",
        plate: "placa",
        active: "ativo",
        transmission: "transmissao",
        accessories: "acessorios",
        created_at: "criado_em",
        ano_fabricacao: "ano_fabricacao"
      },
      cidades: { name: "nome", created_at: "criado_em" },
      bancas: {
        code: "codigo",
        date: "data",
        time: "hora",
        examiner_ids: "examinadores_ids",
        max_slots_a: "max_vagas_a",
        max_slots_b: "max_vagas_b",
        cancellation_reason: "motivo_cancelamento",
        location_id: "local_id",
        created_at: "criado_em"
      },
      solicitacoes: {},
      solicitacoes_cnhbrasil: {},
      solicitacoes_cfc: {},
      solicitacoes_pcd: {},
      vagas_banca: {},
      vagas_cfc: {},
      vagas_pcd: {},
      resultados_banca: {
        schedule_id: "banca_id",
        school_id: "autoescola_id",
        category: "categoria",
        total_slots: "total_vagas",
        used_slots: "vagas_usadas",
        approved: "aprovados",
        failed: "reprovados",
        absent: "ausentes",
        cancelled: "cancelados",
        created_at: "criado_em",
        updated_at: "atualizado_em"
      },
      locais_exame: {
        city_id: "cidade_id",
        address: "endereco",
        maps_url: "url_maps",
        regions_served: "regioes_atendidas",
        created_at: "criado_em"
      },
      datas_bloqueadas: {
        date: "data",
        description: "descricao",
        is_holiday: "feriado",
        created_at: "criado_em"
      },
      configuracoes: {
        agency_name: "nome_orgao",
        agency_address: "endereco_orgao",
        logo_url: "url_logo",
        maintenance_mode: "modo_manutencao",
        min_days_scheduling: "min_dias_agendamento",
        max_daily_slots: "max_vagas_diarias",
        default_max_slots_a: "max_vagas_a_padrao",
        default_max_slots_b: "max_vagas_b_padrao",
        default_max_slots_mudanca: "max_vagas_mudanca_padrao",
        whatsapp_message_template: "template_whatsapp",
        whatsapp_template: "template_whatsapp",
        cfc_whatsapp_template: "template_whatsapp_cfc",
        default_exam_address: "endereco_exame_padrao",
        default_exam_address_link: "link_exame_padrao",
        restrictions: "restricoes",
        pcd_exam_name: "nome_exame_pcd",
        pcd_default_exam_address: "endereco_exame_pcd_padrao",
        pcd_default_exam_address_link: "link_exame_pcd_padrao",
        pcd_main_schedule: "banca_principal_pcd",
        cnh_brasil_main_schedule: "banca_principal_cnh_brasil",
        block_weekends: "bloquear_fins_semana",
        risk_area_key: "chave_area_risco",
        ano_fabricacao_maximo: "ano_fabricacao_maximo"
      },
      usuarios: {
        name: "nome",
        password: "senha",
        role: "perfil",
        school_id: "autoescola_id",
        examiner_id: "examinador_id",
        instructor_id: "instrutor_id",
        force_password_change: "forcar_troca_senha",
        allowed_modules: "modulos_permitidos",
        allowed_location_ids: "locais_permitidos_ids",
        phone: "telefone",
        two_factor_enabled: "dois_fatores_ativo",
        created_at: "criado_em"
      }
    };
    for (const table of ["solicitacoes", "solicitacoes_cnhbrasil", "solicitacoes_cfc", "solicitacoes_pcd"]) {
      COLUMN_ALIASES[table] = {
        student_name: "nome_candidato",
        social_name: "nome_social",
        phone: "telefone",
        address: "endereco",
        city: "cidade",
        request_type: "tipo_solicitacao",
        exam_type: "tipo_exame",
        intended_category: "categoria_pretendida",
        source: "origem",
        school_id: "autoescola_id",
        paid_fee: "taxa_paga_bool",
        completed_practical_course: "curso_pratico_concluido",
        practical_hours: "horas_praticas",
        has_vehicle: "tem_veiculo",
        cnh_restriction: "restricao_cnh",
        vehicle_plate: "placa_veiculo",
        sem_duplo_comando: "sem_duplo_comando",
        checklist_vehicle: "checklist_veiculo",
        practical_course_inserted: "curso_pratico_inserido",
        disability_type: "tipo_deficiencia",
        special_needs: "necessidades_especiais",
        schedule_id: "banca_id",
        scheduled_date: "data_agendada",
        scheduled_time: "hora_agendada",
        scheduled_category: "categoria_agendada",
        examiner_id: "examinador_id",
        attendance_confirmed: "presenca_confirmada",
        cancellation_reason: "motivo_cancelamento",
        observation: "observacao",
        exam_history: "historico_exames",
        category_quantities: "quantidades_categoria",
        row_color: "cor_linha",
        created_at: "criado_em",
        updated_at: "atualizado_em",
        queue_updated_at: "fila_atualizado_em",
        scheduled_by: "agendado_por"
      };
    }
    for (const table of ["vagas_banca", "vagas_cfc", "vagas_pcd"]) {
      COLUMN_ALIASES[table] = {
        school_id: "autoescola_id",
        exam_type: "tipo_exame",
        request_type: "tipo_solicitacao",
        intended_category: "categoria_pretendida",
        scheduled_date: "data_agendada",
        scheduled_time: "hora_agendada",
        examiner_id: "examinador_id",
        schedule_id: "banca_id",
        scheduled_category: "categoria_agendada",
        attendance_confirmed: "presenca_confirmada",
        cancellation_reason: "motivo_cancelamento",
        created_at: "criado_em",
        updated_at: "atualizado_em",
        category_quantities: "quantidades_categoria"
      };
    }
    JSON_COLUMNS = /* @__PURE__ */ new Set([
      "servicos",
      "banca_principal",
      "banca_provisoria",
      "categorias",
      "acessorios",
      "examinadores_ids",
      "quantidades_categoria",
      "historico_exames",
      "restricoes",
      "banca_principal_pcd",
      "banca_principal_cnh_brasil",
      "modulos_permitidos",
      "locais_permitidos_ids",
      "regioes_atendidas",
      "disponibilidade_rodizio",
      "ano_fabricacao_maximo",
      "patios",
      "examinadores_interessados"
    ]);
    __name(isObject, "isObject");
    __name(normalizeRow, "normalizeRow");
    __name(normalizeBackupPayload, "normalizeBackupPayload");
    __name(quoteIdentifier, "quoteIdentifier");
    __name(valueSql, "valueSql");
    __name(restoreRows, "restoreRows");
    __name(prepareRestore, "prepareRestore");
    __name(restoreCounts, "restoreCounts");
    __name(toDrizzleValue, "toDrizzleValue");
    __name(restoreWithBatch, "restoreWithBatch");
    __name(restoreBackup, "restoreBackup");
  }
});

// _backup.ts
async function ensureBackupSchema(db) {
  if (isD1(db)) return verifyD1Schema(db);
  try {
    await db.execute(sql`CREATE TABLE IF NOT EXISTS backups (
      id text PRIMARY KEY,
      tipo_gatilho text NOT NULL DEFAULT 'manual',
      dados jsonb NOT NULL,
      tamanho_bytes integer DEFAULT 0,
      criado_em timestamp DEFAULT now()
    )`);
    await db.execute(sql`CREATE UNIQUE INDEX IF NOT EXISTS backups_auto_daily
      ON backups ((criado_em::date)) WHERE tipo_gatilho = 'auto'`);
  } catch {
  }
}
async function createBackup(db, trigger) {
  if (isD1(db)) return createD1Backup(db, trigger);
  await ensureBackupSchema(db);
  if (trigger === "auto") {
    const existing = await db.execute(sql`
      SELECT id FROM backups WHERE tipo_gatilho = 'auto' AND criado_em::date = CURRENT_DATE LIMIT 1
    `);
    const rows = existing.rows ?? existing;
    if (rows && rows.length > 0) return { skipped: true };
  }
  const payload = {};
  for (const t of BACKUP_TABLES2) {
    try {
      const res = await db.execute(sql.raw(`SELECT * FROM ${t}`));
      payload[t] = res.rows ?? res;
    } catch {
      payload[t] = [];
    }
  }
  try {
    const res = await db.execute(sql`
      SELECT id, nome AS name, login, perfil AS role,
             autoescola_id AS school_id, examinador_id AS examiner_id, instrutor_id AS instructor_id,
             email, telefone AS phone, dois_fatores_ativo AS two_factor_enabled,
             forcar_troca_senha AS force_password_change,
             modulos_permitidos AS allowed_modules, locais_permitidos_ids AS allowed_location_ids,
             criado_em AS created_at
      FROM usuarios
    `);
    payload["users"] = res.rows ?? res;
  } catch {
    payload["users"] = [];
  }
  const id = crypto.randomUUID();
  const jsonStr = JSON.stringify(payload);
  const size = new TextEncoder().encode(jsonStr).length;
  const inserted = await db.execute(sql`
    INSERT INTO backups (id, tipo_gatilho, dados, tamanho_bytes)
    VALUES (${id}, ${trigger}, ${jsonStr}::jsonb, ${size})
    ON CONFLICT DO NOTHING
    RETURNING id
  `);
  const insertedRows = inserted.rows ?? inserted;
  if (!insertedRows || insertedRows.length === 0) return { skipped: true };
  await db.execute(sql`
    DELETE FROM backups
    WHERE id NOT IN (SELECT id FROM backups ORDER BY criado_em DESC LIMIT ${MAX_BACKUPS})
  `);
  return { id };
}
var BACKUP_TABLES2, MAX_BACKUPS;
var init_backup = __esm({
  "_backup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    init_d1();
    init_d1_backup();
    init_backup_restore();
    BACKUP_TABLES2 = [
      "autoescolas",
      "examinadores",
      "instrutores",
      "veiculos",
      "cidades",
      // Tabelas separadas por módulo
      "solicitacoes_cnhbrasil",
      "solicitacoes_cfc",
      "solicitacoes_pcd",
      "vagas_cfc",
      "vagas_pcd",
      "resultados_banca",
      "locais_exame",
      "datas_bloqueadas",
      "configuracoes",
      // Tabelas legadas mantidas para segurança/rollback
      "solicitacoes",
      "bancas",
      "vagas_banca"
    ];
    MAX_BACKUPS = 15;
    __name(ensureBackupSchema, "ensureBackupSchema");
    __name(createBackup, "createBackup");
  }
});

// api/auth.ts
function generateCode() {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return String(1e5 + arr[0] % 9e5);
}
async function hashCode(code) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(code));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function createSession(db, userId) {
  const sessionId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1e3);
  await db.execute(sql`
    INSERT INTO sessoes (id, usuario_id, expira_em, criado_em)
    VALUES (${sessionId}, ${userId}, ${expiresAt.toISOString()}, now())
  `);
  return sessionId;
}
function maskEmail(email) {
  const [local, domain] = email.split("@");
  return `${local.slice(0, 2)}***@${domain}`;
}
async function handle2FA(db, user, resendApiKey, resendFromEmail) {
  if (!resendApiKey) {
    return error("Autentica\xE7\xE3o em 2 etapas requer RESEND_API_KEY. Contate o administrador.", 503);
  }
  const rawCode = generateCode();
  const hashedCode = await hashCode(rawCode);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1e3);
  await db.execute(sql`UPDATE codigos_otp SET usado = true WHERE usuario_id = ${user.id} AND usado = false`);
  const delivery = await sendOtpEmail(resendApiKey, user.email, rawCode, "Pr\xE1ticoSys", resendFromEmail);
  if (delivery.ok === false) {
    return error(delivery.message, 424);
  }
  await db.insert(otpCodes).values({
    id: crypto.randomUUID(),
    userId: user.id,
    code: hashedCode,
    expiresAt,
    used: false,
    failedAttempts: 0
  });
  return { requiresOtp: true, userId: user.id, sentTo: maskEmail(user.email) };
}
async function ensureSchema(db) {
  const stmts = [
    sql`CREATE TABLE IF NOT EXISTS sessoes (id text PRIMARY KEY, usuario_id text NOT NULL, expira_em timestamp NOT NULL, criado_em timestamp DEFAULT now())`,
    sql`CREATE TABLE IF NOT EXISTS codigos_otp (id text PRIMARY KEY, usuario_id text NOT NULL, codigo text NOT NULL, expira_em timestamp NOT NULL, usado boolean DEFAULT false, tentativas_falhas integer DEFAULT 0, criado_em timestamp DEFAULT now())`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS email text`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS telefone text`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS dois_fatores_ativo boolean DEFAULT false`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS forcar_troca_senha boolean DEFAULT true`,
    sql`ALTER TABLE codigos_otp ADD COLUMN IF NOT EXISTS tentativas_falhas integer DEFAULT 0`
  ];
  for (const s of stmts) {
    try {
      await db.execute(s);
    } catch {
    }
  }
}
var onRequestPost;
var init_auth = __esm({
  "api/auth.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_resend();
    init_backup();
    init_password();
    __name(generateCode, "generateCode");
    __name(hashCode, "hashCode");
    __name(createSession, "createSession");
    __name(maskEmail, "maskEmail");
    __name(handle2FA, "handle2FA");
    __name(ensureSchema, "ensureSchema");
    onRequestPost = /* @__PURE__ */ __name(async (context) => {
      const { request, env } = context;
      try {
        const db = getDb(env);
        await ensurePortugueseSchema(db);
        await ensureSchema(db);
        const body = await parseBody(request);
        const { login, password } = body;
        if (!login || !password) return error("Login e senha s\xE3o obrigat\xF3rios", 400);
        const result = await db.select().from(users).where(eq(users.login, login));
        if (result.length === 0) return error("Usu\xE1rio n\xE3o encontrado", 401);
        const user = result[0];
        if (login === "admin" && !user.password) {
          const hashed = await hashPassword(password);
          const updated = await db.update(users).set({ password: hashed, forcePasswordChange: false }).where(eq(users.id, user.id)).returning();
          const u = updated[0] ?? user;
          if (u.twoFactorEnabled && u.email) {
            const result2fa = await handle2FA(db, u, env.RESEND_API_KEY, env.RESEND_FROM_EMAIL);
            if (result2fa instanceof Response) return result2fa;
            return json2(result2fa);
          }
          if (u.twoFactorEnabled && !u.email) {
            return error("2FA ativo sem e-mail cadastrado. Contate o administrador.", 403);
          }
          const sessionToken2 = await createSession(db, u.id);
          context.waitUntil(createBackup(db, "auto").catch(() => {
          }));
          const { password: _p2, ...safe2 } = u;
          return json2({ ...safe2, sessionToken: sessionToken2 });
        }
        if (user.password) {
          const check = await verifyPassword(password, user.password);
          if (!check.ok) return error("Senha incorreta", 401);
          if (check.needsRehash && check.hash) {
            await db.update(users).set({ password: check.hash }).where(eq(users.login, login));
          }
        }
        if (user.twoFactorEnabled && !user.email) {
          return error("2FA ativo sem e-mail cadastrado. Contate o administrador.", 403);
        }
        if (user.twoFactorEnabled && user.email) {
          const result2fa = await handle2FA(db, user, env.RESEND_API_KEY, env.RESEND_FROM_EMAIL);
          if (result2fa instanceof Response) return result2fa;
          return json2(result2fa);
        }
        const sessionToken = await createSession(db, user.id);
        if (user.role === "ADMIN") {
          context.waitUntil(createBackup(db, "auto").catch(() => {
          }));
        }
        const { password: _p, ...safe } = user;
        return json2({ ...safe, sessionToken });
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequestPost");
  }
});

// api/events.ts
var onRequestGet;
var init_events = __esm({
  "api/events.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    onRequestGet = /* @__PURE__ */ __name(async () => {
      const body = "event: ping\ndata: {}\n\n";
      return new Response(body, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          "Connection": "keep-alive",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }, "onRequestGet");
  }
});

// api/health.ts
var onRequestGet2;
var init_health = __esm({
  "api/health.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    onRequestGet2 = /* @__PURE__ */ __name(async ({ env }) => {
      return new Response(JSON.stringify({
        status: "ok",
        runtime: "cloudflare-pages",
        emailConfigured: Boolean(env.RESEND_API_KEY),
        databaseConfigured: Boolean(env.DATABASE_URL)
      }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }, "onRequestGet");
  }
});

// api/risk-area.ts
var onRequestPost2;
var init_risk_area = __esm({
  "api/risk-area.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    onRequestPost2 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const body = await parseBody(request);
        const settingsRows = await db.select({ riskAreaKey: systemSettings.riskAreaKey }).from(systemSettings).where(eq(systemSettings.id, 1));
        const storedKey = settingsRows[0]?.riskAreaKey;
        if (storedKey && body.securityKey !== storedKey) {
          return error("Chave de seguran\xE7a inv\xE1lida. Opera\xE7\xE3o bloqueada.", 403);
        }
        if (body.action === "RESET_DATA") {
          await db.execute(sql`DELETE FROM resultados_banca`);
          await db.execute(sql`DELETE FROM solicitacoes_cnhbrasil`);
          await db.execute(sql`DELETE FROM solicitacoes_cfc`);
          await db.execute(sql`DELETE FROM solicitacoes_pcd`);
          try {
            await db.execute(sql`DELETE FROM vagas_cfc`);
          } catch {
          }
          try {
            await db.execute(sql`DELETE FROM vagas_pcd`);
          } catch {
          }
          await db.execute(sql`DELETE FROM bancas`);
          try {
            await db.execute(sql`DELETE FROM solicitacoes`);
          } catch {
          }
          try {
            await db.execute(sql`DELETE FROM vagas_banca`);
          } catch {
          }
          return json2({ success: true, message: "Todos os agendamentos, escalas e resultados foram zerados com sucesso." });
        }
        if (body.action === "CLEANUP_PHANTOM_REQUESTS") {
          let totalCount = 0;
          for (const tableName of ["solicitacoes_cnhbrasil", "solicitacoes_cfc", "solicitacoes_pcd", "solicitacoes"]) {
            try {
              const result = await db.execute(sql.raw(`
            DELETE FROM ${tableName}
            WHERE (nome_candidato IS NULL OR nome_candidato = '' OR nome_candidato = 'Vaga Dispon\xEDvel')
              AND (cpf IS NULL OR cpf = '' OR cpf = '00000000000')
          `));
              totalCount += result.rowCount ?? 0;
            } catch {
            }
          }
          return json2({ success: true, message: `${totalCount} candidatos fantasma removidos do banco de dados.`, removed: totalCount });
        }
        return error("A\xE7\xE3o n\xE3o reconhecida", 400);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequestPost");
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.js
var util, objectUtil, ZodParsedType, getParsedType;
var init_util = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.js"() {
    init_functionsRoutes_0_17677553668797852();
    (function(util2) {
      util2.assertEqual = (_2) => {
      };
      function assertIs(_arg) {
      }
      __name(assertIs, "assertIs");
      util2.assertIs = assertIs;
      function assertNever(_x) {
        throw new Error();
      }
      __name(assertNever, "assertNever");
      util2.assertNever = assertNever;
      util2.arrayToEnum = (items) => {
        const obj = {};
        for (const item of items) {
          obj[item] = item;
        }
        return obj;
      };
      util2.getValidEnumValues = (obj) => {
        const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
        const filtered = {};
        for (const k of validKeys) {
          filtered[k] = obj[k];
        }
        return util2.objectValues(filtered);
      };
      util2.objectValues = (obj) => {
        return util2.objectKeys(obj).map(function(e) {
          return obj[e];
        });
      };
      util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
        const keys = [];
        for (const key in object) {
          if (Object.prototype.hasOwnProperty.call(object, key)) {
            keys.push(key);
          }
        }
        return keys;
      };
      util2.find = (arr, checker) => {
        for (const item of arr) {
          if (checker(item))
            return item;
        }
        return void 0;
      };
      util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
      function joinValues(array, separator = " | ") {
        return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
      }
      __name(joinValues, "joinValues");
      util2.joinValues = joinValues;
      util2.jsonStringifyReplacer = (_2, value) => {
        if (typeof value === "bigint") {
          return value.toString();
        }
        return value;
      };
    })(util || (util = {}));
    (function(objectUtil2) {
      objectUtil2.mergeShapes = (first, second) => {
        return {
          ...first,
          ...second
          // second overwrites first
        };
      };
    })(objectUtil || (objectUtil = {}));
    ZodParsedType = util.arrayToEnum([
      "string",
      "nan",
      "number",
      "integer",
      "float",
      "boolean",
      "date",
      "bigint",
      "symbol",
      "function",
      "undefined",
      "null",
      "array",
      "object",
      "unknown",
      "promise",
      "void",
      "never",
      "map",
      "set"
    ]);
    getParsedType = /* @__PURE__ */ __name((data) => {
      const t = typeof data;
      switch (t) {
        case "undefined":
          return ZodParsedType.undefined;
        case "string":
          return ZodParsedType.string;
        case "number":
          return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
        case "boolean":
          return ZodParsedType.boolean;
        case "function":
          return ZodParsedType.function;
        case "bigint":
          return ZodParsedType.bigint;
        case "symbol":
          return ZodParsedType.symbol;
        case "object":
          if (Array.isArray(data)) {
            return ZodParsedType.array;
          }
          if (data === null) {
            return ZodParsedType.null;
          }
          if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
            return ZodParsedType.promise;
          }
          if (typeof Map !== "undefined" && data instanceof Map) {
            return ZodParsedType.map;
          }
          if (typeof Set !== "undefined" && data instanceof Set) {
            return ZodParsedType.set;
          }
          if (typeof Date !== "undefined" && data instanceof Date) {
            return ZodParsedType.date;
          }
          return ZodParsedType.object;
        default:
          return ZodParsedType.unknown;
      }
    }, "getParsedType");
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js
var ZodIssueCode, ZodError;
var init_ZodError = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_util();
    ZodIssueCode = util.arrayToEnum([
      "invalid_type",
      "invalid_literal",
      "custom",
      "invalid_union",
      "invalid_union_discriminator",
      "invalid_enum_value",
      "unrecognized_keys",
      "invalid_arguments",
      "invalid_return_type",
      "invalid_date",
      "invalid_string",
      "too_small",
      "too_big",
      "invalid_intersection_types",
      "not_multiple_of",
      "not_finite"
    ]);
    ZodError = class _ZodError extends Error {
      static {
        __name(this, "ZodError");
      }
      get errors() {
        return this.issues;
      }
      constructor(issues) {
        super();
        this.issues = [];
        this.addIssue = (sub) => {
          this.issues = [...this.issues, sub];
        };
        this.addIssues = (subs = []) => {
          this.issues = [...this.issues, ...subs];
        };
        const actualProto = new.target.prototype;
        if (Object.setPrototypeOf) {
          Object.setPrototypeOf(this, actualProto);
        } else {
          this.__proto__ = actualProto;
        }
        this.name = "ZodError";
        this.issues = issues;
      }
      format(_mapper) {
        const mapper = _mapper || function(issue) {
          return issue.message;
        };
        const fieldErrors = { _errors: [] };
        const processError = /* @__PURE__ */ __name((error2) => {
          for (const issue of error2.issues) {
            if (issue.code === "invalid_union") {
              issue.unionErrors.map(processError);
            } else if (issue.code === "invalid_return_type") {
              processError(issue.returnTypeError);
            } else if (issue.code === "invalid_arguments") {
              processError(issue.argumentsError);
            } else if (issue.path.length === 0) {
              fieldErrors._errors.push(mapper(issue));
            } else {
              let curr = fieldErrors;
              let i = 0;
              while (i < issue.path.length) {
                const el = issue.path[i];
                const terminal = i === issue.path.length - 1;
                if (!terminal) {
                  curr[el] = curr[el] || { _errors: [] };
                } else {
                  curr[el] = curr[el] || { _errors: [] };
                  curr[el]._errors.push(mapper(issue));
                }
                curr = curr[el];
                i++;
              }
            }
          }
        }, "processError");
        processError(this);
        return fieldErrors;
      }
      static assert(value) {
        if (!(value instanceof _ZodError)) {
          throw new Error(`Not a ZodError: ${value}`);
        }
      }
      toString() {
        return this.message;
      }
      get message() {
        return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
      }
      get isEmpty() {
        return this.issues.length === 0;
      }
      flatten(mapper = (issue) => issue.message) {
        const fieldErrors = {};
        const formErrors = [];
        for (const sub of this.issues) {
          if (sub.path.length > 0) {
            const firstEl = sub.path[0];
            fieldErrors[firstEl] = fieldErrors[firstEl] || [];
            fieldErrors[firstEl].push(mapper(sub));
          } else {
            formErrors.push(mapper(sub));
          }
        }
        return { formErrors, fieldErrors };
      }
      get formErrors() {
        return this.flatten();
      }
    };
    ZodError.create = (issues) => {
      const error2 = new ZodError(issues);
      return error2;
    };
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.js
var errorMap, en_default;
var init_en = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_ZodError();
    init_util();
    errorMap = /* @__PURE__ */ __name((issue, _ctx) => {
      let message;
      switch (issue.code) {
        case ZodIssueCode.invalid_type:
          if (issue.received === ZodParsedType.undefined) {
            message = "Required";
          } else {
            message = `Expected ${issue.expected}, received ${issue.received}`;
          }
          break;
        case ZodIssueCode.invalid_literal:
          message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
          break;
        case ZodIssueCode.unrecognized_keys:
          message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
          break;
        case ZodIssueCode.invalid_union:
          message = `Invalid input`;
          break;
        case ZodIssueCode.invalid_union_discriminator:
          message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
          break;
        case ZodIssueCode.invalid_enum_value:
          message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
          break;
        case ZodIssueCode.invalid_arguments:
          message = `Invalid function arguments`;
          break;
        case ZodIssueCode.invalid_return_type:
          message = `Invalid function return type`;
          break;
        case ZodIssueCode.invalid_date:
          message = `Invalid date`;
          break;
        case ZodIssueCode.invalid_string:
          if (typeof issue.validation === "object") {
            if ("includes" in issue.validation) {
              message = `Invalid input: must include "${issue.validation.includes}"`;
              if (typeof issue.validation.position === "number") {
                message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
              }
            } else if ("startsWith" in issue.validation) {
              message = `Invalid input: must start with "${issue.validation.startsWith}"`;
            } else if ("endsWith" in issue.validation) {
              message = `Invalid input: must end with "${issue.validation.endsWith}"`;
            } else {
              util.assertNever(issue.validation);
            }
          } else if (issue.validation !== "regex") {
            message = `Invalid ${issue.validation}`;
          } else {
            message = "Invalid";
          }
          break;
        case ZodIssueCode.too_small:
          if (issue.type === "array")
            message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
          else if (issue.type === "string")
            message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
          else if (issue.type === "number")
            message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
          else if (issue.type === "bigint")
            message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
          else if (issue.type === "date")
            message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
          else
            message = "Invalid input";
          break;
        case ZodIssueCode.too_big:
          if (issue.type === "array")
            message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
          else if (issue.type === "string")
            message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
          else if (issue.type === "number")
            message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
          else if (issue.type === "bigint")
            message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
          else if (issue.type === "date")
            message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
          else
            message = "Invalid input";
          break;
        case ZodIssueCode.custom:
          message = `Invalid input`;
          break;
        case ZodIssueCode.invalid_intersection_types:
          message = `Intersection results could not be merged`;
          break;
        case ZodIssueCode.not_multiple_of:
          message = `Number must be a multiple of ${issue.multipleOf}`;
          break;
        case ZodIssueCode.not_finite:
          message = "Number must be finite";
          break;
        default:
          message = _ctx.defaultError;
          util.assertNever(issue);
      }
      return { message };
    }, "errorMap");
    en_default = errorMap;
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.js
function getErrorMap() {
  return overrideErrorMap;
}
var overrideErrorMap;
var init_errors2 = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_en();
    overrideErrorMap = en_default;
    __name(getErrorMap, "getErrorMap");
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.js
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x2) => !!x2)
  });
  ctx.common.issues.push(issue);
}
var makeIssue, ParseStatus, INVALID, DIRTY, OK, isAborted, isDirty, isValid, isAsync;
var init_parseUtil = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_errors2();
    init_en();
    makeIssue = /* @__PURE__ */ __name((params) => {
      const { data, path, errorMaps, issueData } = params;
      const fullPath = [...path, ...issueData.path || []];
      const fullIssue = {
        ...issueData,
        path: fullPath
      };
      if (issueData.message !== void 0) {
        return {
          ...issueData,
          path: fullPath,
          message: issueData.message
        };
      }
      let errorMessage = "";
      const maps = errorMaps.filter((m2) => !!m2).slice().reverse();
      for (const map of maps) {
        errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
      }
      return {
        ...issueData,
        path: fullPath,
        message: errorMessage
      };
    }, "makeIssue");
    __name(addIssueToContext, "addIssueToContext");
    ParseStatus = class _ParseStatus {
      static {
        __name(this, "ParseStatus");
      }
      constructor() {
        this.value = "valid";
      }
      dirty() {
        if (this.value === "valid")
          this.value = "dirty";
      }
      abort() {
        if (this.value !== "aborted")
          this.value = "aborted";
      }
      static mergeArray(status, results) {
        const arrayValue = [];
        for (const s of results) {
          if (s.status === "aborted")
            return INVALID;
          if (s.status === "dirty")
            status.dirty();
          arrayValue.push(s.value);
        }
        return { status: status.value, value: arrayValue };
      }
      static async mergeObjectAsync(status, pairs) {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value
          });
        }
        return _ParseStatus.mergeObjectSync(status, syncPairs);
      }
      static mergeObjectSync(status, pairs) {
        const finalObject = {};
        for (const pair of pairs) {
          const { key, value } = pair;
          if (key.status === "aborted")
            return INVALID;
          if (value.status === "aborted")
            return INVALID;
          if (key.status === "dirty")
            status.dirty();
          if (value.status === "dirty")
            status.dirty();
          if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
            finalObject[key.value] = value.value;
          }
        }
        return { status: status.value, value: finalObject };
      }
    };
    INVALID = Object.freeze({
      status: "aborted"
    });
    DIRTY = /* @__PURE__ */ __name((value) => ({ status: "dirty", value }), "DIRTY");
    OK = /* @__PURE__ */ __name((value) => ({ status: "valid", value }), "OK");
    isAborted = /* @__PURE__ */ __name((x2) => x2.status === "aborted", "isAborted");
    isDirty = /* @__PURE__ */ __name((x2) => x2.status === "dirty", "isDirty");
    isValid = /* @__PURE__ */ __name((x2) => x2.status === "valid", "isValid");
    isAsync = /* @__PURE__ */ __name((x2) => typeof Promise !== "undefined" && x2 instanceof Promise, "isAsync");
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/typeAliases.js
var init_typeAliases = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/typeAliases.js"() {
    init_functionsRoutes_0_17677553668797852();
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
var init_errorUtil = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.js"() {
    init_functionsRoutes_0_17677553668797852();
    (function(errorUtil2) {
      errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
      errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
    })(errorUtil || (errorUtil = {}));
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = /* @__PURE__ */ __name((iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  }, "customMap");
  return { errorMap: customMap, description };
}
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
function isValidIP(ip, version2) {
  if ((version2 === "v4" || !version2) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version2 === "v6" || !version2) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
function isValidCidr(ip, version2) {
  if ((version2 === "v4" || !version2) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version2 === "v6" || !version2) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: /* @__PURE__ */ __name(() => newShape, "shape")
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
function mergeValues(a2, b) {
  const aType = getParsedType(a2);
  const bType = getParsedType(b);
  if (a2 === b) {
    return { valid: true, data: a2 };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a2).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a2, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a2[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a2.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a2.length; index++) {
      const itemA = a2[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a2 === +b) {
    return { valid: true, data: a2 };
  } else {
    return { valid: false };
  }
}
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
var ParseInputLazyPath, handleResult, ZodType, cuidRegex, cuid2Regex, ulidRegex, uuidRegex, nanoidRegex, jwtRegex, durationRegex, emailRegex, _emojiRegex, emojiRegex, ipv4Regex, ipv4CidrRegex, ipv6Regex, ipv6CidrRegex, base64Regex, base64urlRegex, dateRegexSource, dateRegex, ZodString, ZodNumber, ZodBigInt, ZodBoolean, ZodDate, ZodSymbol, ZodUndefined, ZodNull, ZodAny, ZodUnknown, ZodNever, ZodVoid, ZodArray, ZodObject, ZodUnion, getDiscriminator, ZodDiscriminatedUnion, ZodIntersection, ZodTuple, ZodRecord, ZodMap, ZodSet, ZodFunction, ZodLazy, ZodLiteral, ZodEnum, ZodNativeEnum, ZodPromise, ZodEffects, ZodOptional, ZodNullable, ZodDefault, ZodCatch, ZodNaN, ZodBranded, ZodPipeline, ZodReadonly, late, ZodFirstPartyTypeKind, stringType, numberType, nanType, bigIntType, booleanType, dateType, symbolType, undefinedType, nullType, anyType, unknownType, neverType, voidType, arrayType, objectType, strictObjectType, unionType, discriminatedUnionType, intersectionType, tupleType, recordType, mapType, setType, functionType, lazyType, literalType, enumType, nativeEnumType, promiseType, effectsType, optionalType, nullableType, preprocessType, pipelineType;
var init_types = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_ZodError();
    init_errors2();
    init_errorUtil();
    init_parseUtil();
    init_util();
    ParseInputLazyPath = class {
      static {
        __name(this, "ParseInputLazyPath");
      }
      constructor(parent, value, path, key) {
        this._cachedPath = [];
        this.parent = parent;
        this.data = value;
        this._path = path;
        this._key = key;
      }
      get path() {
        if (!this._cachedPath.length) {
          if (Array.isArray(this._key)) {
            this._cachedPath.push(...this._path, ...this._key);
          } else {
            this._cachedPath.push(...this._path, this._key);
          }
        }
        return this._cachedPath;
      }
    };
    handleResult = /* @__PURE__ */ __name((ctx, result) => {
      if (isValid(result)) {
        return { success: true, data: result.value };
      } else {
        if (!ctx.common.issues.length) {
          throw new Error("Validation failed but no issues detected.");
        }
        return {
          success: false,
          get error() {
            if (this._error)
              return this._error;
            const error2 = new ZodError(ctx.common.issues);
            this._error = error2;
            return this._error;
          }
        };
      }
    }, "handleResult");
    __name(processCreateParams, "processCreateParams");
    ZodType = class {
      static {
        __name(this, "ZodType");
      }
      get description() {
        return this._def.description;
      }
      _getType(input) {
        return getParsedType(input.data);
      }
      _getOrReturnCtx(input, ctx) {
        return ctx || {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        };
      }
      _processInputParams(input) {
        return {
          status: new ParseStatus(),
          ctx: {
            common: input.parent.common,
            data: input.data,
            parsedType: getParsedType(input.data),
            schemaErrorMap: this._def.errorMap,
            path: input.path,
            parent: input.parent
          }
        };
      }
      _parseSync(input) {
        const result = this._parse(input);
        if (isAsync(result)) {
          throw new Error("Synchronous parse encountered promise.");
        }
        return result;
      }
      _parseAsync(input) {
        const result = this._parse(input);
        return Promise.resolve(result);
      }
      parse(data, params) {
        const result = this.safeParse(data, params);
        if (result.success)
          return result.data;
        throw result.error;
      }
      safeParse(data, params) {
        const ctx = {
          common: {
            issues: [],
            async: params?.async ?? false,
            contextualErrorMap: params?.errorMap
          },
          path: params?.path || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: getParsedType(data)
        };
        const result = this._parseSync({ data, path: ctx.path, parent: ctx });
        return handleResult(ctx, result);
      }
      "~validate"(data) {
        const ctx = {
          common: {
            issues: [],
            async: !!this["~standard"].async
          },
          path: [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: getParsedType(data)
        };
        if (!this["~standard"].async) {
          try {
            const result = this._parseSync({ data, path: [], parent: ctx });
            return isValid(result) ? {
              value: result.value
            } : {
              issues: ctx.common.issues
            };
          } catch (err) {
            if (err?.message?.toLowerCase()?.includes("encountered")) {
              this["~standard"].async = true;
            }
            ctx.common = {
              issues: [],
              async: true
            };
          }
        }
        return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        });
      }
      async parseAsync(data, params) {
        const result = await this.safeParseAsync(data, params);
        if (result.success)
          return result.data;
        throw result.error;
      }
      async safeParseAsync(data, params) {
        const ctx = {
          common: {
            issues: [],
            contextualErrorMap: params?.errorMap,
            async: true
          },
          path: params?.path || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: getParsedType(data)
        };
        const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
        const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
        return handleResult(ctx, result);
      }
      refine(check, message) {
        const getIssueProperties = /* @__PURE__ */ __name((val) => {
          if (typeof message === "string" || typeof message === "undefined") {
            return { message };
          } else if (typeof message === "function") {
            return message(val);
          } else {
            return message;
          }
        }, "getIssueProperties");
        return this._refinement((val, ctx) => {
          const result = check(val);
          const setError = /* @__PURE__ */ __name(() => ctx.addIssue({
            code: ZodIssueCode.custom,
            ...getIssueProperties(val)
          }), "setError");
          if (typeof Promise !== "undefined" && result instanceof Promise) {
            return result.then((data) => {
              if (!data) {
                setError();
                return false;
              } else {
                return true;
              }
            });
          }
          if (!result) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      refinement(check, refinementData) {
        return this._refinement((val, ctx) => {
          if (!check(val)) {
            ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
            return false;
          } else {
            return true;
          }
        });
      }
      _refinement(refinement) {
        return new ZodEffects({
          schema: this,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect: { type: "refinement", refinement }
        });
      }
      superRefine(refinement) {
        return this._refinement(refinement);
      }
      constructor(def) {
        this.spa = this.safeParseAsync;
        this._def = def;
        this.parse = this.parse.bind(this);
        this.safeParse = this.safeParse.bind(this);
        this.parseAsync = this.parseAsync.bind(this);
        this.safeParseAsync = this.safeParseAsync.bind(this);
        this.spa = this.spa.bind(this);
        this.refine = this.refine.bind(this);
        this.refinement = this.refinement.bind(this);
        this.superRefine = this.superRefine.bind(this);
        this.optional = this.optional.bind(this);
        this.nullable = this.nullable.bind(this);
        this.nullish = this.nullish.bind(this);
        this.array = this.array.bind(this);
        this.promise = this.promise.bind(this);
        this.or = this.or.bind(this);
        this.and = this.and.bind(this);
        this.transform = this.transform.bind(this);
        this.brand = this.brand.bind(this);
        this.default = this.default.bind(this);
        this.catch = this.catch.bind(this);
        this.describe = this.describe.bind(this);
        this.pipe = this.pipe.bind(this);
        this.readonly = this.readonly.bind(this);
        this.isNullable = this.isNullable.bind(this);
        this.isOptional = this.isOptional.bind(this);
        this["~standard"] = {
          version: 1,
          vendor: "zod",
          validate: /* @__PURE__ */ __name((data) => this["~validate"](data), "validate")
        };
      }
      optional() {
        return ZodOptional.create(this, this._def);
      }
      nullable() {
        return ZodNullable.create(this, this._def);
      }
      nullish() {
        return this.nullable().optional();
      }
      array() {
        return ZodArray.create(this);
      }
      promise() {
        return ZodPromise.create(this, this._def);
      }
      or(option) {
        return ZodUnion.create([this, option], this._def);
      }
      and(incoming) {
        return ZodIntersection.create(this, incoming, this._def);
      }
      transform(transform) {
        return new ZodEffects({
          ...processCreateParams(this._def),
          schema: this,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect: { type: "transform", transform }
        });
      }
      default(def) {
        const defaultValueFunc = typeof def === "function" ? def : () => def;
        return new ZodDefault({
          ...processCreateParams(this._def),
          innerType: this,
          defaultValue: defaultValueFunc,
          typeName: ZodFirstPartyTypeKind.ZodDefault
        });
      }
      brand() {
        return new ZodBranded({
          typeName: ZodFirstPartyTypeKind.ZodBranded,
          type: this,
          ...processCreateParams(this._def)
        });
      }
      catch(def) {
        const catchValueFunc = typeof def === "function" ? def : () => def;
        return new ZodCatch({
          ...processCreateParams(this._def),
          innerType: this,
          catchValue: catchValueFunc,
          typeName: ZodFirstPartyTypeKind.ZodCatch
        });
      }
      describe(description) {
        const This = this.constructor;
        return new This({
          ...this._def,
          description
        });
      }
      pipe(target) {
        return ZodPipeline.create(this, target);
      }
      readonly() {
        return ZodReadonly.create(this);
      }
      isOptional() {
        return this.safeParse(void 0).success;
      }
      isNullable() {
        return this.safeParse(null).success;
      }
    };
    cuidRegex = /^c[^\s-]{8,}$/i;
    cuid2Regex = /^[0-9a-z]+$/;
    ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
    uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
    nanoidRegex = /^[a-z0-9_-]{21}$/i;
    jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
    durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
    emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
    _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
    ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
    ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
    ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
    ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
    base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
    base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
    dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
    dateRegex = new RegExp(`^${dateRegexSource}$`);
    __name(timeRegexSource, "timeRegexSource");
    __name(timeRegex, "timeRegex");
    __name(datetimeRegex, "datetimeRegex");
    __name(isValidIP, "isValidIP");
    __name(isValidJWT, "isValidJWT");
    __name(isValidCidr, "isValidCidr");
    ZodString = class _ZodString extends ZodType {
      static {
        __name(this, "ZodString");
      }
      _parse(input) {
        if (this._def.coerce) {
          input.data = String(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.string) {
          const ctx2 = this._getOrReturnCtx(input);
          addIssueToContext(ctx2, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.string,
            received: ctx2.parsedType
          });
          return INVALID;
        }
        const status = new ParseStatus();
        let ctx = void 0;
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            if (input.data.length < check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            if (input.data.length > check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "length") {
            const tooBig = input.data.length > check.value;
            const tooSmall = input.data.length < check.value;
            if (tooBig || tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              if (tooBig) {
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: check.message
                });
              } else if (tooSmall) {
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: check.message
                });
              }
              status.dirty();
            }
          } else if (check.kind === "email") {
            if (!emailRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "email",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "emoji") {
            if (!emojiRegex) {
              emojiRegex = new RegExp(_emojiRegex, "u");
            }
            if (!emojiRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "emoji",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "uuid") {
            if (!uuidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "uuid",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "nanoid") {
            if (!nanoidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "nanoid",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cuid") {
            if (!cuidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "cuid",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cuid2") {
            if (!cuid2Regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "cuid2",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "ulid") {
            if (!ulidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "ulid",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "url") {
            try {
              new URL(input.data);
            } catch {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "url",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "regex") {
            check.regex.lastIndex = 0;
            const testResult = check.regex.test(input.data);
            if (!testResult) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "regex",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "trim") {
            input.data = input.data.trim();
          } else if (check.kind === "includes") {
            if (!input.data.includes(check.value, check.position)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: { includes: check.value, position: check.position },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "toLowerCase") {
            input.data = input.data.toLowerCase();
          } else if (check.kind === "toUpperCase") {
            input.data = input.data.toUpperCase();
          } else if (check.kind === "startsWith") {
            if (!input.data.startsWith(check.value)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: { startsWith: check.value },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "endsWith") {
            if (!input.data.endsWith(check.value)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: { endsWith: check.value },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "datetime") {
            const regex = datetimeRegex(check);
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: "datetime",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "date") {
            const regex = dateRegex;
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: "date",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "time") {
            const regex = timeRegex(check);
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_string,
                validation: "time",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "duration") {
            if (!durationRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "duration",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "ip") {
            if (!isValidIP(input.data, check.version)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "ip",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "jwt") {
            if (!isValidJWT(input.data, check.alg)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "jwt",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cidr") {
            if (!isValidCidr(input.data, check.version)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "cidr",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "base64") {
            if (!base64Regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "base64",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "base64url") {
            if (!base64urlRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                validation: "base64url",
                code: ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      _regex(regex, validation, message) {
        return this.refinement((data) => regex.test(data), {
          validation,
          code: ZodIssueCode.invalid_string,
          ...errorUtil.errToObj(message)
        });
      }
      _addCheck(check) {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      email(message) {
        return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
      }
      url(message) {
        return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
      }
      emoji(message) {
        return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
      }
      uuid(message) {
        return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
      }
      nanoid(message) {
        return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
      }
      cuid(message) {
        return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
      }
      cuid2(message) {
        return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
      }
      ulid(message) {
        return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
      }
      base64(message) {
        return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
      }
      base64url(message) {
        return this._addCheck({
          kind: "base64url",
          ...errorUtil.errToObj(message)
        });
      }
      jwt(options) {
        return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
      }
      ip(options) {
        return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
      }
      cidr(options) {
        return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
      }
      datetime(options) {
        if (typeof options === "string") {
          return this._addCheck({
            kind: "datetime",
            precision: null,
            offset: false,
            local: false,
            message: options
          });
        }
        return this._addCheck({
          kind: "datetime",
          precision: typeof options?.precision === "undefined" ? null : options?.precision,
          offset: options?.offset ?? false,
          local: options?.local ?? false,
          ...errorUtil.errToObj(options?.message)
        });
      }
      date(message) {
        return this._addCheck({ kind: "date", message });
      }
      time(options) {
        if (typeof options === "string") {
          return this._addCheck({
            kind: "time",
            precision: null,
            message: options
          });
        }
        return this._addCheck({
          kind: "time",
          precision: typeof options?.precision === "undefined" ? null : options?.precision,
          ...errorUtil.errToObj(options?.message)
        });
      }
      duration(message) {
        return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
      }
      regex(regex, message) {
        return this._addCheck({
          kind: "regex",
          regex,
          ...errorUtil.errToObj(message)
        });
      }
      includes(value, options) {
        return this._addCheck({
          kind: "includes",
          value,
          position: options?.position,
          ...errorUtil.errToObj(options?.message)
        });
      }
      startsWith(value, message) {
        return this._addCheck({
          kind: "startsWith",
          value,
          ...errorUtil.errToObj(message)
        });
      }
      endsWith(value, message) {
        return this._addCheck({
          kind: "endsWith",
          value,
          ...errorUtil.errToObj(message)
        });
      }
      min(minLength, message) {
        return this._addCheck({
          kind: "min",
          value: minLength,
          ...errorUtil.errToObj(message)
        });
      }
      max(maxLength, message) {
        return this._addCheck({
          kind: "max",
          value: maxLength,
          ...errorUtil.errToObj(message)
        });
      }
      length(len, message) {
        return this._addCheck({
          kind: "length",
          value: len,
          ...errorUtil.errToObj(message)
        });
      }
      /**
       * Equivalent to `.min(1)`
       */
      nonempty(message) {
        return this.min(1, errorUtil.errToObj(message));
      }
      trim() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "trim" }]
        });
      }
      toLowerCase() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "toLowerCase" }]
        });
      }
      toUpperCase() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "toUpperCase" }]
        });
      }
      get isDatetime() {
        return !!this._def.checks.find((ch) => ch.kind === "datetime");
      }
      get isDate() {
        return !!this._def.checks.find((ch) => ch.kind === "date");
      }
      get isTime() {
        return !!this._def.checks.find((ch) => ch.kind === "time");
      }
      get isDuration() {
        return !!this._def.checks.find((ch) => ch.kind === "duration");
      }
      get isEmail() {
        return !!this._def.checks.find((ch) => ch.kind === "email");
      }
      get isURL() {
        return !!this._def.checks.find((ch) => ch.kind === "url");
      }
      get isEmoji() {
        return !!this._def.checks.find((ch) => ch.kind === "emoji");
      }
      get isUUID() {
        return !!this._def.checks.find((ch) => ch.kind === "uuid");
      }
      get isNANOID() {
        return !!this._def.checks.find((ch) => ch.kind === "nanoid");
      }
      get isCUID() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid");
      }
      get isCUID2() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid2");
      }
      get isULID() {
        return !!this._def.checks.find((ch) => ch.kind === "ulid");
      }
      get isIP() {
        return !!this._def.checks.find((ch) => ch.kind === "ip");
      }
      get isCIDR() {
        return !!this._def.checks.find((ch) => ch.kind === "cidr");
      }
      get isBase64() {
        return !!this._def.checks.find((ch) => ch.kind === "base64");
      }
      get isBase64url() {
        return !!this._def.checks.find((ch) => ch.kind === "base64url");
      }
      get minLength() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxLength() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
    };
    ZodString.create = (params) => {
      return new ZodString({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodString,
        coerce: params?.coerce ?? false,
        ...processCreateParams(params)
      });
    };
    __name(floatSafeRemainder, "floatSafeRemainder");
    ZodNumber = class _ZodNumber extends ZodType {
      static {
        __name(this, "ZodNumber");
      }
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
        this.step = this.multipleOf;
      }
      _parse(input) {
        if (this._def.coerce) {
          input.data = Number(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.number) {
          const ctx2 = this._getOrReturnCtx(input);
          addIssueToContext(ctx2, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.number,
            received: ctx2.parsedType
          });
          return INVALID;
        }
        let ctx = void 0;
        const status = new ParseStatus();
        for (const check of this._def.checks) {
          if (check.kind === "int") {
            if (!util.isInteger(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_type,
                expected: "integer",
                received: "float",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "min") {
            const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
            if (tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "number",
                inclusive: check.inclusive,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
            if (tooBig) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "number",
                inclusive: check.inclusive,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "multipleOf") {
            if (floatSafeRemainder(input.data, check.value) !== 0) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.not_multiple_of,
                multipleOf: check.value,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "finite") {
            if (!Number.isFinite(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.not_finite,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      gte(value, message) {
        return this.setLimit("min", value, true, errorUtil.toString(message));
      }
      gt(value, message) {
        return this.setLimit("min", value, false, errorUtil.toString(message));
      }
      lte(value, message) {
        return this.setLimit("max", value, true, errorUtil.toString(message));
      }
      lt(value, message) {
        return this.setLimit("max", value, false, errorUtil.toString(message));
      }
      setLimit(kind, value, inclusive, message) {
        return new _ZodNumber({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind,
              value,
              inclusive,
              message: errorUtil.toString(message)
            }
          ]
        });
      }
      _addCheck(check) {
        return new _ZodNumber({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      int(message) {
        return this._addCheck({
          kind: "int",
          message: errorUtil.toString(message)
        });
      }
      positive(message) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: false,
          message: errorUtil.toString(message)
        });
      }
      negative(message) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: false,
          message: errorUtil.toString(message)
        });
      }
      nonpositive(message) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: true,
          message: errorUtil.toString(message)
        });
      }
      nonnegative(message) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: true,
          message: errorUtil.toString(message)
        });
      }
      multipleOf(value, message) {
        return this._addCheck({
          kind: "multipleOf",
          value,
          message: errorUtil.toString(message)
        });
      }
      finite(message) {
        return this._addCheck({
          kind: "finite",
          message: errorUtil.toString(message)
        });
      }
      safe(message) {
        return this._addCheck({
          kind: "min",
          inclusive: true,
          value: Number.MIN_SAFE_INTEGER,
          message: errorUtil.toString(message)
        })._addCheck({
          kind: "max",
          inclusive: true,
          value: Number.MAX_SAFE_INTEGER,
          message: errorUtil.toString(message)
        });
      }
      get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
      get isInt() {
        return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
      }
      get isFinite() {
        let max = null;
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
            return true;
          } else if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          } else if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return Number.isFinite(min) && Number.isFinite(max);
      }
    };
    ZodNumber.create = (params) => {
      return new ZodNumber({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodNumber,
        coerce: params?.coerce || false,
        ...processCreateParams(params)
      });
    };
    ZodBigInt = class _ZodBigInt extends ZodType {
      static {
        __name(this, "ZodBigInt");
      }
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
      }
      _parse(input) {
        if (this._def.coerce) {
          try {
            input.data = BigInt(input.data);
          } catch {
            return this._getInvalidInput(input);
          }
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.bigint) {
          return this._getInvalidInput(input);
        }
        let ctx = void 0;
        const status = new ParseStatus();
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
            if (tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                type: "bigint",
                minimum: check.value,
                inclusive: check.inclusive,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
            if (tooBig) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                type: "bigint",
                maximum: check.value,
                inclusive: check.inclusive,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "multipleOf") {
            if (input.data % check.value !== BigInt(0)) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.not_multiple_of,
                multipleOf: check.value,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      _getInvalidInput(input) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.bigint,
          received: ctx.parsedType
        });
        return INVALID;
      }
      gte(value, message) {
        return this.setLimit("min", value, true, errorUtil.toString(message));
      }
      gt(value, message) {
        return this.setLimit("min", value, false, errorUtil.toString(message));
      }
      lte(value, message) {
        return this.setLimit("max", value, true, errorUtil.toString(message));
      }
      lt(value, message) {
        return this.setLimit("max", value, false, errorUtil.toString(message));
      }
      setLimit(kind, value, inclusive, message) {
        return new _ZodBigInt({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind,
              value,
              inclusive,
              message: errorUtil.toString(message)
            }
          ]
        });
      }
      _addCheck(check) {
        return new _ZodBigInt({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      positive(message) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: false,
          message: errorUtil.toString(message)
        });
      }
      negative(message) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: false,
          message: errorUtil.toString(message)
        });
      }
      nonpositive(message) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: true,
          message: errorUtil.toString(message)
        });
      }
      nonnegative(message) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: true,
          message: errorUtil.toString(message)
        });
      }
      multipleOf(value, message) {
        return this._addCheck({
          kind: "multipleOf",
          value,
          message: errorUtil.toString(message)
        });
      }
      get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
    };
    ZodBigInt.create = (params) => {
      return new ZodBigInt({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodBigInt,
        coerce: params?.coerce ?? false,
        ...processCreateParams(params)
      });
    };
    ZodBoolean = class extends ZodType {
      static {
        __name(this, "ZodBoolean");
      }
      _parse(input) {
        if (this._def.coerce) {
          input.data = Boolean(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.boolean) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.boolean,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return OK(input.data);
      }
    };
    ZodBoolean.create = (params) => {
      return new ZodBoolean({
        typeName: ZodFirstPartyTypeKind.ZodBoolean,
        coerce: params?.coerce || false,
        ...processCreateParams(params)
      });
    };
    ZodDate = class _ZodDate extends ZodType {
      static {
        __name(this, "ZodDate");
      }
      _parse(input) {
        if (this._def.coerce) {
          input.data = new Date(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.date) {
          const ctx2 = this._getOrReturnCtx(input);
          addIssueToContext(ctx2, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.date,
            received: ctx2.parsedType
          });
          return INVALID;
        }
        if (Number.isNaN(input.data.getTime())) {
          const ctx2 = this._getOrReturnCtx(input);
          addIssueToContext(ctx2, {
            code: ZodIssueCode.invalid_date
          });
          return INVALID;
        }
        const status = new ParseStatus();
        let ctx = void 0;
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            if (input.data.getTime() < check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                message: check.message,
                inclusive: true,
                exact: false,
                minimum: check.value,
                type: "date"
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            if (input.data.getTime() > check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                message: check.message,
                inclusive: true,
                exact: false,
                maximum: check.value,
                type: "date"
              });
              status.dirty();
            }
          } else {
            util.assertNever(check);
          }
        }
        return {
          status: status.value,
          value: new Date(input.data.getTime())
        };
      }
      _addCheck(check) {
        return new _ZodDate({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      min(minDate, message) {
        return this._addCheck({
          kind: "min",
          value: minDate.getTime(),
          message: errorUtil.toString(message)
        });
      }
      max(maxDate, message) {
        return this._addCheck({
          kind: "max",
          value: maxDate.getTime(),
          message: errorUtil.toString(message)
        });
      }
      get minDate() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min != null ? new Date(min) : null;
      }
      get maxDate() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max != null ? new Date(max) : null;
      }
    };
    ZodDate.create = (params) => {
      return new ZodDate({
        checks: [],
        coerce: params?.coerce || false,
        typeName: ZodFirstPartyTypeKind.ZodDate,
        ...processCreateParams(params)
      });
    };
    ZodSymbol = class extends ZodType {
      static {
        __name(this, "ZodSymbol");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.symbol) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.symbol,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return OK(input.data);
      }
    };
    ZodSymbol.create = (params) => {
      return new ZodSymbol({
        typeName: ZodFirstPartyTypeKind.ZodSymbol,
        ...processCreateParams(params)
      });
    };
    ZodUndefined = class extends ZodType {
      static {
        __name(this, "ZodUndefined");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.undefined) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.undefined,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return OK(input.data);
      }
    };
    ZodUndefined.create = (params) => {
      return new ZodUndefined({
        typeName: ZodFirstPartyTypeKind.ZodUndefined,
        ...processCreateParams(params)
      });
    };
    ZodNull = class extends ZodType {
      static {
        __name(this, "ZodNull");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.null) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.null,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return OK(input.data);
      }
    };
    ZodNull.create = (params) => {
      return new ZodNull({
        typeName: ZodFirstPartyTypeKind.ZodNull,
        ...processCreateParams(params)
      });
    };
    ZodAny = class extends ZodType {
      static {
        __name(this, "ZodAny");
      }
      constructor() {
        super(...arguments);
        this._any = true;
      }
      _parse(input) {
        return OK(input.data);
      }
    };
    ZodAny.create = (params) => {
      return new ZodAny({
        typeName: ZodFirstPartyTypeKind.ZodAny,
        ...processCreateParams(params)
      });
    };
    ZodUnknown = class extends ZodType {
      static {
        __name(this, "ZodUnknown");
      }
      constructor() {
        super(...arguments);
        this._unknown = true;
      }
      _parse(input) {
        return OK(input.data);
      }
    };
    ZodUnknown.create = (params) => {
      return new ZodUnknown({
        typeName: ZodFirstPartyTypeKind.ZodUnknown,
        ...processCreateParams(params)
      });
    };
    ZodNever = class extends ZodType {
      static {
        __name(this, "ZodNever");
      }
      _parse(input) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.never,
          received: ctx.parsedType
        });
        return INVALID;
      }
    };
    ZodNever.create = (params) => {
      return new ZodNever({
        typeName: ZodFirstPartyTypeKind.ZodNever,
        ...processCreateParams(params)
      });
    };
    ZodVoid = class extends ZodType {
      static {
        __name(this, "ZodVoid");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.undefined) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.void,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return OK(input.data);
      }
    };
    ZodVoid.create = (params) => {
      return new ZodVoid({
        typeName: ZodFirstPartyTypeKind.ZodVoid,
        ...processCreateParams(params)
      });
    };
    ZodArray = class _ZodArray extends ZodType {
      static {
        __name(this, "ZodArray");
      }
      _parse(input) {
        const { ctx, status } = this._processInputParams(input);
        const def = this._def;
        if (ctx.parsedType !== ZodParsedType.array) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.array,
            received: ctx.parsedType
          });
          return INVALID;
        }
        if (def.exactLength !== null) {
          const tooBig = ctx.data.length > def.exactLength.value;
          const tooSmall = ctx.data.length < def.exactLength.value;
          if (tooBig || tooSmall) {
            addIssueToContext(ctx, {
              code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
              minimum: tooSmall ? def.exactLength.value : void 0,
              maximum: tooBig ? def.exactLength.value : void 0,
              type: "array",
              inclusive: true,
              exact: true,
              message: def.exactLength.message
            });
            status.dirty();
          }
        }
        if (def.minLength !== null) {
          if (ctx.data.length < def.minLength.value) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: def.minLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: def.minLength.message
            });
            status.dirty();
          }
        }
        if (def.maxLength !== null) {
          if (ctx.data.length > def.maxLength.value) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: def.maxLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: def.maxLength.message
            });
            status.dirty();
          }
        }
        if (ctx.common.async) {
          return Promise.all([...ctx.data].map((item, i) => {
            return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
          })).then((result2) => {
            return ParseStatus.mergeArray(status, result2);
          });
        }
        const result = [...ctx.data].map((item, i) => {
          return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        });
        return ParseStatus.mergeArray(status, result);
      }
      get element() {
        return this._def.type;
      }
      min(minLength, message) {
        return new _ZodArray({
          ...this._def,
          minLength: { value: minLength, message: errorUtil.toString(message) }
        });
      }
      max(maxLength, message) {
        return new _ZodArray({
          ...this._def,
          maxLength: { value: maxLength, message: errorUtil.toString(message) }
        });
      }
      length(len, message) {
        return new _ZodArray({
          ...this._def,
          exactLength: { value: len, message: errorUtil.toString(message) }
        });
      }
      nonempty(message) {
        return this.min(1, message);
      }
    };
    ZodArray.create = (schema, params) => {
      return new ZodArray({
        type: schema,
        minLength: null,
        maxLength: null,
        exactLength: null,
        typeName: ZodFirstPartyTypeKind.ZodArray,
        ...processCreateParams(params)
      });
    };
    __name(deepPartialify, "deepPartialify");
    ZodObject = class _ZodObject extends ZodType {
      static {
        __name(this, "ZodObject");
      }
      constructor() {
        super(...arguments);
        this._cached = null;
        this.nonstrict = this.passthrough;
        this.augment = this.extend;
      }
      _getCached() {
        if (this._cached !== null)
          return this._cached;
        const shape = this._def.shape();
        const keys = util.objectKeys(shape);
        this._cached = { shape, keys };
        return this._cached;
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.object) {
          const ctx2 = this._getOrReturnCtx(input);
          addIssueToContext(ctx2, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.object,
            received: ctx2.parsedType
          });
          return INVALID;
        }
        const { status, ctx } = this._processInputParams(input);
        const { shape, keys: shapeKeys } = this._getCached();
        const extraKeys = [];
        if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
          for (const key in ctx.data) {
            if (!shapeKeys.includes(key)) {
              extraKeys.push(key);
            }
          }
        }
        const pairs = [];
        for (const key of shapeKeys) {
          const keyValidator = shape[key];
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
            alwaysSet: key in ctx.data
          });
        }
        if (this._def.catchall instanceof ZodNever) {
          const unknownKeys = this._def.unknownKeys;
          if (unknownKeys === "passthrough") {
            for (const key of extraKeys) {
              pairs.push({
                key: { status: "valid", value: key },
                value: { status: "valid", value: ctx.data[key] }
              });
            }
          } else if (unknownKeys === "strict") {
            if (extraKeys.length > 0) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.unrecognized_keys,
                keys: extraKeys
              });
              status.dirty();
            }
          } else if (unknownKeys === "strip") {
          } else {
            throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
          }
        } else {
          const catchall = this._def.catchall;
          for (const key of extraKeys) {
            const value = ctx.data[key];
            pairs.push({
              key: { status: "valid", value: key },
              value: catchall._parse(
                new ParseInputLazyPath(ctx, value, ctx.path, key)
                //, ctx.child(key), value, getParsedType(value)
              ),
              alwaysSet: key in ctx.data
            });
          }
        }
        if (ctx.common.async) {
          return Promise.resolve().then(async () => {
            const syncPairs = [];
            for (const pair of pairs) {
              const key = await pair.key;
              const value = await pair.value;
              syncPairs.push({
                key,
                value,
                alwaysSet: pair.alwaysSet
              });
            }
            return syncPairs;
          }).then((syncPairs) => {
            return ParseStatus.mergeObjectSync(status, syncPairs);
          });
        } else {
          return ParseStatus.mergeObjectSync(status, pairs);
        }
      }
      get shape() {
        return this._def.shape();
      }
      strict(message) {
        errorUtil.errToObj;
        return new _ZodObject({
          ...this._def,
          unknownKeys: "strict",
          ...message !== void 0 ? {
            errorMap: /* @__PURE__ */ __name((issue, ctx) => {
              const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
              if (issue.code === "unrecognized_keys")
                return {
                  message: errorUtil.errToObj(message).message ?? defaultError
                };
              return {
                message: defaultError
              };
            }, "errorMap")
          } : {}
        });
      }
      strip() {
        return new _ZodObject({
          ...this._def,
          unknownKeys: "strip"
        });
      }
      passthrough() {
        return new _ZodObject({
          ...this._def,
          unknownKeys: "passthrough"
        });
      }
      // const AugmentFactory =
      //   <Def extends ZodObjectDef>(def: Def) =>
      //   <Augmentation extends ZodRawShape>(
      //     augmentation: Augmentation
      //   ): ZodObject<
      //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
      //     Def["unknownKeys"],
      //     Def["catchall"]
      //   > => {
      //     return new ZodObject({
      //       ...def,
      //       shape: () => ({
      //         ...def.shape(),
      //         ...augmentation,
      //       }),
      //     }) as any;
      //   };
      extend(augmentation) {
        return new _ZodObject({
          ...this._def,
          shape: /* @__PURE__ */ __name(() => ({
            ...this._def.shape(),
            ...augmentation
          }), "shape")
        });
      }
      /**
       * Prior to zod@1.0.12 there was a bug in the
       * inferred type of merged objects. Please
       * upgrade if you are experiencing issues.
       */
      merge(merging) {
        const merged = new _ZodObject({
          unknownKeys: merging._def.unknownKeys,
          catchall: merging._def.catchall,
          shape: /* @__PURE__ */ __name(() => ({
            ...this._def.shape(),
            ...merging._def.shape()
          }), "shape"),
          typeName: ZodFirstPartyTypeKind.ZodObject
        });
        return merged;
      }
      // merge<
      //   Incoming extends AnyZodObject,
      //   Augmentation extends Incoming["shape"],
      //   NewOutput extends {
      //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
      //       ? Augmentation[k]["_output"]
      //       : k extends keyof Output
      //       ? Output[k]
      //       : never;
      //   },
      //   NewInput extends {
      //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
      //       ? Augmentation[k]["_input"]
      //       : k extends keyof Input
      //       ? Input[k]
      //       : never;
      //   }
      // >(
      //   merging: Incoming
      // ): ZodObject<
      //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
      //   Incoming["_def"]["unknownKeys"],
      //   Incoming["_def"]["catchall"],
      //   NewOutput,
      //   NewInput
      // > {
      //   const merged: any = new ZodObject({
      //     unknownKeys: merging._def.unknownKeys,
      //     catchall: merging._def.catchall,
      //     shape: () =>
      //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
      //     typeName: ZodFirstPartyTypeKind.ZodObject,
      //   }) as any;
      //   return merged;
      // }
      setKey(key, schema) {
        return this.augment({ [key]: schema });
      }
      // merge<Incoming extends AnyZodObject>(
      //   merging: Incoming
      // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
      // ZodObject<
      //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
      //   Incoming["_def"]["unknownKeys"],
      //   Incoming["_def"]["catchall"]
      // > {
      //   // const mergedShape = objectUtil.mergeShapes(
      //   //   this._def.shape(),
      //   //   merging._def.shape()
      //   // );
      //   const merged: any = new ZodObject({
      //     unknownKeys: merging._def.unknownKeys,
      //     catchall: merging._def.catchall,
      //     shape: () =>
      //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
      //     typeName: ZodFirstPartyTypeKind.ZodObject,
      //   }) as any;
      //   return merged;
      // }
      catchall(index) {
        return new _ZodObject({
          ...this._def,
          catchall: index
        });
      }
      pick(mask) {
        const shape = {};
        for (const key of util.objectKeys(mask)) {
          if (mask[key] && this.shape[key]) {
            shape[key] = this.shape[key];
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: /* @__PURE__ */ __name(() => shape, "shape")
        });
      }
      omit(mask) {
        const shape = {};
        for (const key of util.objectKeys(this.shape)) {
          if (!mask[key]) {
            shape[key] = this.shape[key];
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: /* @__PURE__ */ __name(() => shape, "shape")
        });
      }
      /**
       * @deprecated
       */
      deepPartial() {
        return deepPartialify(this);
      }
      partial(mask) {
        const newShape = {};
        for (const key of util.objectKeys(this.shape)) {
          const fieldSchema = this.shape[key];
          if (mask && !mask[key]) {
            newShape[key] = fieldSchema;
          } else {
            newShape[key] = fieldSchema.optional();
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: /* @__PURE__ */ __name(() => newShape, "shape")
        });
      }
      required(mask) {
        const newShape = {};
        for (const key of util.objectKeys(this.shape)) {
          if (mask && !mask[key]) {
            newShape[key] = this.shape[key];
          } else {
            const fieldSchema = this.shape[key];
            let newField = fieldSchema;
            while (newField instanceof ZodOptional) {
              newField = newField._def.innerType;
            }
            newShape[key] = newField;
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: /* @__PURE__ */ __name(() => newShape, "shape")
        });
      }
      keyof() {
        return createZodEnum(util.objectKeys(this.shape));
      }
    };
    ZodObject.create = (shape, params) => {
      return new ZodObject({
        shape: /* @__PURE__ */ __name(() => shape, "shape"),
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    ZodObject.strictCreate = (shape, params) => {
      return new ZodObject({
        shape: /* @__PURE__ */ __name(() => shape, "shape"),
        unknownKeys: "strict",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    ZodObject.lazycreate = (shape, params) => {
      return new ZodObject({
        shape,
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    ZodUnion = class extends ZodType {
      static {
        __name(this, "ZodUnion");
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const options = this._def.options;
        function handleResults(results) {
          for (const result of results) {
            if (result.result.status === "valid") {
              return result.result;
            }
          }
          for (const result of results) {
            if (result.result.status === "dirty") {
              ctx.common.issues.push(...result.ctx.common.issues);
              return result.result;
            }
          }
          const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_union,
            unionErrors
          });
          return INVALID;
        }
        __name(handleResults, "handleResults");
        if (ctx.common.async) {
          return Promise.all(options.map(async (option) => {
            const childCtx = {
              ...ctx,
              common: {
                ...ctx.common,
                issues: []
              },
              parent: null
            };
            return {
              result: await option._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: childCtx
              }),
              ctx: childCtx
            };
          })).then(handleResults);
        } else {
          let dirty = void 0;
          const issues = [];
          for (const option of options) {
            const childCtx = {
              ...ctx,
              common: {
                ...ctx.common,
                issues: []
              },
              parent: null
            };
            const result = option._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            });
            if (result.status === "valid") {
              return result;
            } else if (result.status === "dirty" && !dirty) {
              dirty = { result, ctx: childCtx };
            }
            if (childCtx.common.issues.length) {
              issues.push(childCtx.common.issues);
            }
          }
          if (dirty) {
            ctx.common.issues.push(...dirty.ctx.common.issues);
            return dirty.result;
          }
          const unionErrors = issues.map((issues2) => new ZodError(issues2));
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_union,
            unionErrors
          });
          return INVALID;
        }
      }
      get options() {
        return this._def.options;
      }
    };
    ZodUnion.create = (types, params) => {
      return new ZodUnion({
        options: types,
        typeName: ZodFirstPartyTypeKind.ZodUnion,
        ...processCreateParams(params)
      });
    };
    getDiscriminator = /* @__PURE__ */ __name((type) => {
      if (type instanceof ZodLazy) {
        return getDiscriminator(type.schema);
      } else if (type instanceof ZodEffects) {
        return getDiscriminator(type.innerType());
      } else if (type instanceof ZodLiteral) {
        return [type.value];
      } else if (type instanceof ZodEnum) {
        return type.options;
      } else if (type instanceof ZodNativeEnum) {
        return util.objectValues(type.enum);
      } else if (type instanceof ZodDefault) {
        return getDiscriminator(type._def.innerType);
      } else if (type instanceof ZodUndefined) {
        return [void 0];
      } else if (type instanceof ZodNull) {
        return [null];
      } else if (type instanceof ZodOptional) {
        return [void 0, ...getDiscriminator(type.unwrap())];
      } else if (type instanceof ZodNullable) {
        return [null, ...getDiscriminator(type.unwrap())];
      } else if (type instanceof ZodBranded) {
        return getDiscriminator(type.unwrap());
      } else if (type instanceof ZodReadonly) {
        return getDiscriminator(type.unwrap());
      } else if (type instanceof ZodCatch) {
        return getDiscriminator(type._def.innerType);
      } else {
        return [];
      }
    }, "getDiscriminator");
    ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
      static {
        __name(this, "ZodDiscriminatedUnion");
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.object) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.object,
            received: ctx.parsedType
          });
          return INVALID;
        }
        const discriminator = this.discriminator;
        const discriminatorValue = ctx.data[discriminator];
        const option = this.optionsMap.get(discriminatorValue);
        if (!option) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_union_discriminator,
            options: Array.from(this.optionsMap.keys()),
            path: [discriminator]
          });
          return INVALID;
        }
        if (ctx.common.async) {
          return option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
        } else {
          return option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
        }
      }
      get discriminator() {
        return this._def.discriminator;
      }
      get options() {
        return this._def.options;
      }
      get optionsMap() {
        return this._def.optionsMap;
      }
      /**
       * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
       * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
       * have a different value for each object in the union.
       * @param discriminator the name of the discriminator property
       * @param types an array of object schemas
       * @param params
       */
      static create(discriminator, options, params) {
        const optionsMap = /* @__PURE__ */ new Map();
        for (const type of options) {
          const discriminatorValues = getDiscriminator(type.shape[discriminator]);
          if (!discriminatorValues.length) {
            throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
          }
          for (const value of discriminatorValues) {
            if (optionsMap.has(value)) {
              throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
            }
            optionsMap.set(value, type);
          }
        }
        return new _ZodDiscriminatedUnion({
          typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
          discriminator,
          options,
          optionsMap,
          ...processCreateParams(params)
        });
      }
    };
    __name(mergeValues, "mergeValues");
    ZodIntersection = class extends ZodType {
      static {
        __name(this, "ZodIntersection");
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const handleParsed = /* @__PURE__ */ __name((parsedLeft, parsedRight) => {
          if (isAborted(parsedLeft) || isAborted(parsedRight)) {
            return INVALID;
          }
          const merged = mergeValues(parsedLeft.value, parsedRight.value);
          if (!merged.valid) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_intersection_types
            });
            return INVALID;
          }
          if (isDirty(parsedLeft) || isDirty(parsedRight)) {
            status.dirty();
          }
          return { status: status.value, value: merged.data };
        }, "handleParsed");
        if (ctx.common.async) {
          return Promise.all([
            this._def.left._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }),
            this._def.right._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            })
          ]).then(([left, right]) => handleParsed(left, right));
        } else {
          return handleParsed(this._def.left._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }), this._def.right._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }));
        }
      }
    };
    ZodIntersection.create = (left, right, params) => {
      return new ZodIntersection({
        left,
        right,
        typeName: ZodFirstPartyTypeKind.ZodIntersection,
        ...processCreateParams(params)
      });
    };
    ZodTuple = class _ZodTuple extends ZodType {
      static {
        __name(this, "ZodTuple");
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.array) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.array,
            received: ctx.parsedType
          });
          return INVALID;
        }
        if (ctx.data.length < this._def.items.length) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          return INVALID;
        }
        const rest = this._def.rest;
        if (!rest && ctx.data.length > this._def.items.length) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          status.dirty();
        }
        const items = [...ctx.data].map((item, itemIndex) => {
          const schema = this._def.items[itemIndex] || this._def.rest;
          if (!schema)
            return null;
          return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
        }).filter((x2) => !!x2);
        if (ctx.common.async) {
          return Promise.all(items).then((results) => {
            return ParseStatus.mergeArray(status, results);
          });
        } else {
          return ParseStatus.mergeArray(status, items);
        }
      }
      get items() {
        return this._def.items;
      }
      rest(rest) {
        return new _ZodTuple({
          ...this._def,
          rest
        });
      }
    };
    ZodTuple.create = (schemas, params) => {
      if (!Array.isArray(schemas)) {
        throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
      }
      return new ZodTuple({
        items: schemas,
        typeName: ZodFirstPartyTypeKind.ZodTuple,
        rest: null,
        ...processCreateParams(params)
      });
    };
    ZodRecord = class _ZodRecord extends ZodType {
      static {
        __name(this, "ZodRecord");
      }
      get keySchema() {
        return this._def.keyType;
      }
      get valueSchema() {
        return this._def.valueType;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.object) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.object,
            received: ctx.parsedType
          });
          return INVALID;
        }
        const pairs = [];
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        for (const key in ctx.data) {
          pairs.push({
            key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
            value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
            alwaysSet: key in ctx.data
          });
        }
        if (ctx.common.async) {
          return ParseStatus.mergeObjectAsync(status, pairs);
        } else {
          return ParseStatus.mergeObjectSync(status, pairs);
        }
      }
      get element() {
        return this._def.valueType;
      }
      static create(first, second, third) {
        if (second instanceof ZodType) {
          return new _ZodRecord({
            keyType: first,
            valueType: second,
            typeName: ZodFirstPartyTypeKind.ZodRecord,
            ...processCreateParams(third)
          });
        }
        return new _ZodRecord({
          keyType: ZodString.create(),
          valueType: first,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(second)
        });
      }
    };
    ZodMap = class extends ZodType {
      static {
        __name(this, "ZodMap");
      }
      get keySchema() {
        return this._def.keyType;
      }
      get valueSchema() {
        return this._def.valueType;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.map) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.map,
            received: ctx.parsedType
          });
          return INVALID;
        }
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        const pairs = [...ctx.data.entries()].map(([key, value], index) => {
          return {
            key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
            value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
          };
        });
        if (ctx.common.async) {
          const finalMap = /* @__PURE__ */ new Map();
          return Promise.resolve().then(async () => {
            for (const pair of pairs) {
              const key = await pair.key;
              const value = await pair.value;
              if (key.status === "aborted" || value.status === "aborted") {
                return INVALID;
              }
              if (key.status === "dirty" || value.status === "dirty") {
                status.dirty();
              }
              finalMap.set(key.value, value.value);
            }
            return { status: status.value, value: finalMap };
          });
        } else {
          const finalMap = /* @__PURE__ */ new Map();
          for (const pair of pairs) {
            const key = pair.key;
            const value = pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        }
      }
    };
    ZodMap.create = (keyType, valueType, params) => {
      return new ZodMap({
        valueType,
        keyType,
        typeName: ZodFirstPartyTypeKind.ZodMap,
        ...processCreateParams(params)
      });
    };
    ZodSet = class _ZodSet extends ZodType {
      static {
        __name(this, "ZodSet");
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.set) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.set,
            received: ctx.parsedType
          });
          return INVALID;
        }
        const def = this._def;
        if (def.minSize !== null) {
          if (ctx.data.size < def.minSize.value) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: def.minSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: def.minSize.message
            });
            status.dirty();
          }
        }
        if (def.maxSize !== null) {
          if (ctx.data.size > def.maxSize.value) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: def.maxSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: def.maxSize.message
            });
            status.dirty();
          }
        }
        const valueType = this._def.valueType;
        function finalizeSet(elements2) {
          const parsedSet = /* @__PURE__ */ new Set();
          for (const element of elements2) {
            if (element.status === "aborted")
              return INVALID;
            if (element.status === "dirty")
              status.dirty();
            parsedSet.add(element.value);
          }
          return { status: status.value, value: parsedSet };
        }
        __name(finalizeSet, "finalizeSet");
        const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
        if (ctx.common.async) {
          return Promise.all(elements).then((elements2) => finalizeSet(elements2));
        } else {
          return finalizeSet(elements);
        }
      }
      min(minSize, message) {
        return new _ZodSet({
          ...this._def,
          minSize: { value: minSize, message: errorUtil.toString(message) }
        });
      }
      max(maxSize, message) {
        return new _ZodSet({
          ...this._def,
          maxSize: { value: maxSize, message: errorUtil.toString(message) }
        });
      }
      size(size, message) {
        return this.min(size, message).max(size, message);
      }
      nonempty(message) {
        return this.min(1, message);
      }
    };
    ZodSet.create = (valueType, params) => {
      return new ZodSet({
        valueType,
        minSize: null,
        maxSize: null,
        typeName: ZodFirstPartyTypeKind.ZodSet,
        ...processCreateParams(params)
      });
    };
    ZodFunction = class _ZodFunction extends ZodType {
      static {
        __name(this, "ZodFunction");
      }
      constructor() {
        super(...arguments);
        this.validate = this.implement;
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.function) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.function,
            received: ctx.parsedType
          });
          return INVALID;
        }
        function makeArgsIssue(args, error2) {
          return makeIssue({
            data: args,
            path: ctx.path,
            errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x2) => !!x2),
            issueData: {
              code: ZodIssueCode.invalid_arguments,
              argumentsError: error2
            }
          });
        }
        __name(makeArgsIssue, "makeArgsIssue");
        function makeReturnsIssue(returns, error2) {
          return makeIssue({
            data: returns,
            path: ctx.path,
            errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x2) => !!x2),
            issueData: {
              code: ZodIssueCode.invalid_return_type,
              returnTypeError: error2
            }
          });
        }
        __name(makeReturnsIssue, "makeReturnsIssue");
        const params = { errorMap: ctx.common.contextualErrorMap };
        const fn = ctx.data;
        if (this._def.returns instanceof ZodPromise) {
          const me = this;
          return OK(async function(...args) {
            const error2 = new ZodError([]);
            const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
              error2.addIssue(makeArgsIssue(args, e));
              throw error2;
            });
            const result = await Reflect.apply(fn, this, parsedArgs);
            const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
              error2.addIssue(makeReturnsIssue(result, e));
              throw error2;
            });
            return parsedReturns;
          });
        } else {
          const me = this;
          return OK(function(...args) {
            const parsedArgs = me._def.args.safeParse(args, params);
            if (!parsedArgs.success) {
              throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
            }
            const result = Reflect.apply(fn, this, parsedArgs.data);
            const parsedReturns = me._def.returns.safeParse(result, params);
            if (!parsedReturns.success) {
              throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
            }
            return parsedReturns.data;
          });
        }
      }
      parameters() {
        return this._def.args;
      }
      returnType() {
        return this._def.returns;
      }
      args(...items) {
        return new _ZodFunction({
          ...this._def,
          args: ZodTuple.create(items).rest(ZodUnknown.create())
        });
      }
      returns(returnType) {
        return new _ZodFunction({
          ...this._def,
          returns: returnType
        });
      }
      implement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
      }
      strictImplement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
      }
      static create(args, returns, params) {
        return new _ZodFunction({
          args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
          returns: returns || ZodUnknown.create(),
          typeName: ZodFirstPartyTypeKind.ZodFunction,
          ...processCreateParams(params)
        });
      }
    };
    ZodLazy = class extends ZodType {
      static {
        __name(this, "ZodLazy");
      }
      get schema() {
        return this._def.getter();
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const lazySchema = this._def.getter();
        return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
      }
    };
    ZodLazy.create = (getter, params) => {
      return new ZodLazy({
        getter,
        typeName: ZodFirstPartyTypeKind.ZodLazy,
        ...processCreateParams(params)
      });
    };
    ZodLiteral = class extends ZodType {
      static {
        __name(this, "ZodLiteral");
      }
      _parse(input) {
        if (input.data !== this._def.value) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            received: ctx.data,
            code: ZodIssueCode.invalid_literal,
            expected: this._def.value
          });
          return INVALID;
        }
        return { status: "valid", value: input.data };
      }
      get value() {
        return this._def.value;
      }
    };
    ZodLiteral.create = (value, params) => {
      return new ZodLiteral({
        value,
        typeName: ZodFirstPartyTypeKind.ZodLiteral,
        ...processCreateParams(params)
      });
    };
    __name(createZodEnum, "createZodEnum");
    ZodEnum = class _ZodEnum extends ZodType {
      static {
        __name(this, "ZodEnum");
      }
      _parse(input) {
        if (typeof input.data !== "string") {
          const ctx = this._getOrReturnCtx(input);
          const expectedValues = this._def.values;
          addIssueToContext(ctx, {
            expected: util.joinValues(expectedValues),
            received: ctx.parsedType,
            code: ZodIssueCode.invalid_type
          });
          return INVALID;
        }
        if (!this._cache) {
          this._cache = new Set(this._def.values);
        }
        if (!this._cache.has(input.data)) {
          const ctx = this._getOrReturnCtx(input);
          const expectedValues = this._def.values;
          addIssueToContext(ctx, {
            received: ctx.data,
            code: ZodIssueCode.invalid_enum_value,
            options: expectedValues
          });
          return INVALID;
        }
        return OK(input.data);
      }
      get options() {
        return this._def.values;
      }
      get enum() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      get Values() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      get Enum() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      extract(values, newDef = this._def) {
        return _ZodEnum.create(values, {
          ...this._def,
          ...newDef
        });
      }
      exclude(values, newDef = this._def) {
        return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
          ...this._def,
          ...newDef
        });
      }
    };
    ZodEnum.create = createZodEnum;
    ZodNativeEnum = class extends ZodType {
      static {
        __name(this, "ZodNativeEnum");
      }
      _parse(input) {
        const nativeEnumValues = util.getValidEnumValues(this._def.values);
        const ctx = this._getOrReturnCtx(input);
        if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
          const expectedValues = util.objectValues(nativeEnumValues);
          addIssueToContext(ctx, {
            expected: util.joinValues(expectedValues),
            received: ctx.parsedType,
            code: ZodIssueCode.invalid_type
          });
          return INVALID;
        }
        if (!this._cache) {
          this._cache = new Set(util.getValidEnumValues(this._def.values));
        }
        if (!this._cache.has(input.data)) {
          const expectedValues = util.objectValues(nativeEnumValues);
          addIssueToContext(ctx, {
            received: ctx.data,
            code: ZodIssueCode.invalid_enum_value,
            options: expectedValues
          });
          return INVALID;
        }
        return OK(input.data);
      }
      get enum() {
        return this._def.values;
      }
    };
    ZodNativeEnum.create = (values, params) => {
      return new ZodNativeEnum({
        values,
        typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
        ...processCreateParams(params)
      });
    };
    ZodPromise = class extends ZodType {
      static {
        __name(this, "ZodPromise");
      }
      unwrap() {
        return this._def.type;
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.promise,
            received: ctx.parsedType
          });
          return INVALID;
        }
        const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
        return OK(promisified.then((data) => {
          return this._def.type.parseAsync(data, {
            path: ctx.path,
            errorMap: ctx.common.contextualErrorMap
          });
        }));
      }
    };
    ZodPromise.create = (schema, params) => {
      return new ZodPromise({
        type: schema,
        typeName: ZodFirstPartyTypeKind.ZodPromise,
        ...processCreateParams(params)
      });
    };
    ZodEffects = class extends ZodType {
      static {
        __name(this, "ZodEffects");
      }
      innerType() {
        return this._def.schema;
      }
      sourceType() {
        return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const effect = this._def.effect || null;
        const checkCtx = {
          addIssue: /* @__PURE__ */ __name((arg) => {
            addIssueToContext(ctx, arg);
            if (arg.fatal) {
              status.abort();
            } else {
              status.dirty();
            }
          }, "addIssue"),
          get path() {
            return ctx.path;
          }
        };
        checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
        if (effect.type === "preprocess") {
          const processed = effect.transform(ctx.data, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(processed).then(async (processed2) => {
              if (status.value === "aborted")
                return INVALID;
              const result = await this._def.schema._parseAsync({
                data: processed2,
                path: ctx.path,
                parent: ctx
              });
              if (result.status === "aborted")
                return INVALID;
              if (result.status === "dirty")
                return DIRTY(result.value);
              if (status.value === "dirty")
                return DIRTY(result.value);
              return result;
            });
          } else {
            if (status.value === "aborted")
              return INVALID;
            const result = this._def.schema._parseSync({
              data: processed,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          }
        }
        if (effect.type === "refinement") {
          const executeRefinement = /* @__PURE__ */ __name((acc) => {
            const result = effect.refinement(acc, checkCtx);
            if (ctx.common.async) {
              return Promise.resolve(result);
            }
            if (result instanceof Promise) {
              throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
            }
            return acc;
          }, "executeRefinement");
          if (ctx.common.async === false) {
            const inner = this._def.schema._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            executeRefinement(inner.value);
            return { status: status.value, value: inner.value };
          } else {
            return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
              if (inner.status === "aborted")
                return INVALID;
              if (inner.status === "dirty")
                status.dirty();
              return executeRefinement(inner.value).then(() => {
                return { status: status.value, value: inner.value };
              });
            });
          }
        }
        if (effect.type === "transform") {
          if (ctx.common.async === false) {
            const base = this._def.schema._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (!isValid(base))
              return INVALID;
            const result = effect.transform(base.value, checkCtx);
            if (result instanceof Promise) {
              throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
            }
            return { status: status.value, value: result };
          } else {
            return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
              if (!isValid(base))
                return INVALID;
              return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
                status: status.value,
                value: result
              }));
            });
          }
        }
        util.assertNever(effect);
      }
    };
    ZodEffects.create = (schema, effect, params) => {
      return new ZodEffects({
        schema,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect,
        ...processCreateParams(params)
      });
    };
    ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
      return new ZodEffects({
        schema,
        effect: { type: "preprocess", transform: preprocess },
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        ...processCreateParams(params)
      });
    };
    ZodOptional = class extends ZodType {
      static {
        __name(this, "ZodOptional");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === ZodParsedType.undefined) {
          return OK(void 0);
        }
        return this._def.innerType._parse(input);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    ZodOptional.create = (type, params) => {
      return new ZodOptional({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodOptional,
        ...processCreateParams(params)
      });
    };
    ZodNullable = class extends ZodType {
      static {
        __name(this, "ZodNullable");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === ZodParsedType.null) {
          return OK(null);
        }
        return this._def.innerType._parse(input);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    ZodNullable.create = (type, params) => {
      return new ZodNullable({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodNullable,
        ...processCreateParams(params)
      });
    };
    ZodDefault = class extends ZodType {
      static {
        __name(this, "ZodDefault");
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        let data = ctx.data;
        if (ctx.parsedType === ZodParsedType.undefined) {
          data = this._def.defaultValue();
        }
        return this._def.innerType._parse({
          data,
          path: ctx.path,
          parent: ctx
        });
      }
      removeDefault() {
        return this._def.innerType;
      }
    };
    ZodDefault.create = (type, params) => {
      return new ZodDefault({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodDefault,
        defaultValue: typeof params.default === "function" ? params.default : () => params.default,
        ...processCreateParams(params)
      });
    };
    ZodCatch = class extends ZodType {
      static {
        __name(this, "ZodCatch");
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const newCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          }
        };
        const result = this._def.innerType._parse({
          data: newCtx.data,
          path: newCtx.path,
          parent: {
            ...newCtx
          }
        });
        if (isAsync(result)) {
          return result.then((result2) => {
            return {
              status: "valid",
              value: result2.status === "valid" ? result2.value : this._def.catchValue({
                get error() {
                  return new ZodError(newCtx.common.issues);
                },
                input: newCtx.data
              })
            };
          });
        } else {
          return {
            status: "valid",
            value: result.status === "valid" ? result.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        }
      }
      removeCatch() {
        return this._def.innerType;
      }
    };
    ZodCatch.create = (type, params) => {
      return new ZodCatch({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodCatch,
        catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
        ...processCreateParams(params)
      });
    };
    ZodNaN = class extends ZodType {
      static {
        __name(this, "ZodNaN");
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== ZodParsedType.nan) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.nan,
            received: ctx.parsedType
          });
          return INVALID;
        }
        return { status: "valid", value: input.data };
      }
    };
    ZodNaN.create = (params) => {
      return new ZodNaN({
        typeName: ZodFirstPartyTypeKind.ZodNaN,
        ...processCreateParams(params)
      });
    };
    ZodBranded = class extends ZodType {
      static {
        __name(this, "ZodBranded");
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const data = ctx.data;
        return this._def.type._parse({
          data,
          path: ctx.path,
          parent: ctx
        });
      }
      unwrap() {
        return this._def.type;
      }
    };
    ZodPipeline = class _ZodPipeline extends ZodType {
      static {
        __name(this, "ZodPipeline");
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.common.async) {
          const handleAsync = /* @__PURE__ */ __name(async () => {
            const inResult = await this._def.in._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inResult.status === "aborted")
              return INVALID;
            if (inResult.status === "dirty") {
              status.dirty();
              return DIRTY(inResult.value);
            } else {
              return this._def.out._parseAsync({
                data: inResult.value,
                path: ctx.path,
                parent: ctx
              });
            }
          }, "handleAsync");
          return handleAsync();
        } else {
          const inResult = this._def.in._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return {
              status: "dirty",
              value: inResult.value
            };
          } else {
            return this._def.out._parseSync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        }
      }
      static create(a2, b) {
        return new _ZodPipeline({
          in: a2,
          out: b,
          typeName: ZodFirstPartyTypeKind.ZodPipeline
        });
      }
    };
    ZodReadonly = class extends ZodType {
      static {
        __name(this, "ZodReadonly");
      }
      _parse(input) {
        const result = this._def.innerType._parse(input);
        const freeze = /* @__PURE__ */ __name((data) => {
          if (isValid(data)) {
            data.value = Object.freeze(data.value);
          }
          return data;
        }, "freeze");
        return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    ZodReadonly.create = (type, params) => {
      return new ZodReadonly({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodReadonly,
        ...processCreateParams(params)
      });
    };
    late = {
      object: ZodObject.lazycreate
    };
    (function(ZodFirstPartyTypeKind2) {
      ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
      ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
      ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
      ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
      ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
      ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
      ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
      ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
      ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
      ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
      ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
      ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
      ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
      ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
      ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
      ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
      ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
      ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
      ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
      ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
      ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
      ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
      ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
      ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
      ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
      ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
      ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
      ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
      ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
      ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
      ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
      ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
      ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
      ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
      ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
      ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
    })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
    stringType = ZodString.create;
    numberType = ZodNumber.create;
    nanType = ZodNaN.create;
    bigIntType = ZodBigInt.create;
    booleanType = ZodBoolean.create;
    dateType = ZodDate.create;
    symbolType = ZodSymbol.create;
    undefinedType = ZodUndefined.create;
    nullType = ZodNull.create;
    anyType = ZodAny.create;
    unknownType = ZodUnknown.create;
    neverType = ZodNever.create;
    voidType = ZodVoid.create;
    arrayType = ZodArray.create;
    objectType = ZodObject.create;
    strictObjectType = ZodObject.strictCreate;
    unionType = ZodUnion.create;
    discriminatedUnionType = ZodDiscriminatedUnion.create;
    intersectionType = ZodIntersection.create;
    tupleType = ZodTuple.create;
    recordType = ZodRecord.create;
    mapType = ZodMap.create;
    setType = ZodSet.create;
    functionType = ZodFunction.create;
    lazyType = ZodLazy.create;
    literalType = ZodLiteral.create;
    enumType = ZodEnum.create;
    nativeEnumType = ZodNativeEnum.create;
    promiseType = ZodPromise.create;
    effectsType = ZodEffects.create;
    optionalType = ZodOptional.create;
    nullableType = ZodNullable.create;
    preprocessType = ZodEffects.createWithPreprocess;
    pipelineType = ZodPipeline.create;
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js
var init_external = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_errors2();
    init_parseUtil();
    init_typeAliases();
    init_util();
    init_types();
    init_ZodError();
  }
});

// ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/index.js
var init_zod = __esm({
  "../node_modules/.pnpm/zod@3.25.76/node_modules/zod/index.js"() {
    init_functionsRoutes_0_17677553668797852();
    init_external();
  }
});

// ../lib/api-zod/src/generated/api.ts
var GetSessionResponse, DeleteSessionResponse, lookupCandidateCpfBodyCpfMin, lookupCandidateCpfBodyCpfMax, LookupCandidateCpfBody, LookupCandidateCpfResponse, HealthCheckResponse;
var init_api = __esm({
  "../lib/api-zod/src/generated/api.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_zod();
    GetSessionResponse = objectType({
      "id": stringType().min(1),
      "name": stringType(),
      "login": stringType(),
      "role": enumType(["ADMIN", "SUPERVISOR", "OPERATOR", "CONSULTANT", "SCHOOL", "EXAMINER", "INSTRUCTOR"]),
      "schoolId": stringType().optional(),
      "examinerId": stringType().optional(),
      "instructorId": stringType().optional(),
      "forcePasswordChange": booleanType().optional(),
      "twoFactorEnabled": booleanType().optional(),
      "email": stringType().optional(),
      "phone": stringType().optional(),
      "allowedModules": arrayType(enumType(["cnh", "cfc", "pcd", "cadastro"])).optional(),
      "allowedLocationIds": arrayType(stringType()).optional(),
      "allowedCadastroTabs": arrayType(stringType()).optional()
    });
    DeleteSessionResponse = unknownType();
    lookupCandidateCpfBodyCpfMin = 11;
    lookupCandidateCpfBodyCpfMax = 14;
    LookupCandidateCpfBody = objectType({
      "cpf": stringType().min(lookupCandidateCpfBodyCpfMin).max(lookupCandidateCpfBodyCpfMax),
      "module": enumType(["CNH_BRASIL"])
    });
    LookupCandidateCpfResponse = objectType({
      "name": stringType()
    });
    HealthCheckResponse = objectType({
      "status": stringType()
    });
  }
});

// _session-user.ts
async function readSessionUser(db, users2, token) {
  if (!token) return null;
  const rows = await db.select().from(users2).where(sql`
    ${users2.id} IN (
      SELECT usuario_id FROM sessoes WHERE id = ${token} AND expira_em > NOW()
    )
  `).limit(1);
  if (!rows.length) return null;
  return GetSessionResponse.parse(Object.fromEntries(
    Object.entries(rows[0]).filter(([, value]) => value != null)
  ));
}
var init_session_user = __esm({
  "_session-user.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    init_api();
    __name(readSessionUser, "readSessionUser");
  }
});

// api/session.ts
var onRequestGet3, onRequestDelete;
var init_session3 = __esm({
  "api/session.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_drizzle_orm();
    init_schema2();
    init_session_user();
    onRequestGet3 = /* @__PURE__ */ __name(async ({ request, env }) => {
      const headers = { "Cache-Control": "no-store", Vary: "Authorization" };
      try {
        const token = request.headers.get("Authorization")?.replace(/^Bearer\s+/i, "").trim() || null;
        const user = await readSessionUser(getDb(env), users, token);
        const response = user ? json2(user) : error("Sess\xE3o expirada ou inv\xE1lida. Fa\xE7a login novamente.", 401);
        for (const [key, value] of Object.entries(headers)) response.headers.set(key, value);
        return response;
      } catch {
        const response = error("N\xE3o foi poss\xEDvel verificar sua sess\xE3o. Tente novamente.", 503);
        for (const [key, value] of Object.entries(headers)) response.headers.set(key, value);
        return response;
      }
    }, "onRequestGet");
    onRequestDelete = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const token = request.headers.get("Authorization")?.replace(/^Bearer\s+/i, "").trim();
        if (token) {
          await db.execute(sql`DELETE FROM sessoes WHERE id = ${token}`);
        }
        return json2({ success: true });
      } catch {
        return error("N\xE3o foi poss\xEDvel encerrar a sess\xE3o no servidor.", 503);
      }
    }, "onRequestDelete");
  }
});

// api/setup.ts
var onRequestPost3;
var init_setup = __esm({
  "api/setup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_d1();
    onRequestPost3 = /* @__PURE__ */ __name(async ({ env }) => {
      try {
        const db = getDb(env);
        if (isD1(db)) {
          await verifyD1Schema(db);
          return json2({ success: true, message: "D1 preparado por migra\xE7\xF5es versionadas; setup legado n\xE3o executado." });
        }
        await ensurePortugueseSchema(db);
        const tables = [
          sql`CREATE TABLE IF NOT EXISTS instrutores (id text PRIMARY KEY, nome text NOT NULL, cpf text, telefone text, categoria text, placa text, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS veiculos (id text PRIMARY KEY, instrutor_id text NOT NULL, tipo text NOT NULL, marca text NOT NULL, modelo text NOT NULL, placa text NOT NULL, ativo boolean DEFAULT true, transmissao text, acessorios jsonb DEFAULT '[]'::jsonb, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS autoescolas (id text PRIMARY KEY, nome text NOT NULL, telefone text, endereco text, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS examinadores (id text PRIMARY KEY, nome text NOT NULL, matricula text NOT NULL, pode_examinar_comum boolean DEFAULT true, pode_examinar_pcd boolean DEFAULT false, categorias jsonb DEFAULT '[]'::jsonb, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS bancas (id text PRIMARY KEY, data text NOT NULL, hora text NOT NULL, examinadores_ids jsonb DEFAULT '[]'::jsonb, max_vagas_a integer DEFAULT 10, max_vagas_b integer DEFAULT 10, tipo text NOT NULL, status text NOT NULL, motivo_cancelamento text, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS solicitacoes (id text PRIMARY KEY, nome_candidato text, nome_social text, cpf text, telefone text, status text NOT NULL, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS configuracoes (id integer PRIMARY KEY DEFAULT 1, nome_orgao text DEFAULT 'DETRAN', modo_manutencao boolean DEFAULT false, min_dias_agendamento integer DEFAULT 2, max_vagas_diarias integer DEFAULT 50, max_vagas_a_padrao integer DEFAULT 10, max_vagas_b_padrao integer DEFAULT 10)`,
          sql`CREATE TABLE IF NOT EXISTS usuarios (id text PRIMARY KEY, nome text NOT NULL, login text NOT NULL UNIQUE, senha text, perfil text NOT NULL, autoescola_id text, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS cidades (id text PRIMARY KEY, nome text NOT NULL UNIQUE, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS datas_bloqueadas (id text PRIMARY KEY, data text NOT NULL, descricao text, feriado boolean DEFAULT false, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS resultados_banca (id text PRIMARY KEY, banca_id text, autoescola_id text, categoria text, criado_em timestamp DEFAULT now(), atualizado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS vagas_banca (id text PRIMARY KEY, autoescola_id text NOT NULL, tipo_exame text NOT NULL, tipo_solicitacao text NOT NULL DEFAULT 'FIXA', categoria_pretendida text, data_agendada text, hora_agendada text, examinador_id text, banca_id text, categoria_agendada text, status text NOT NULL DEFAULT 'SCHEDULED', presenca_confirmada boolean DEFAULT false, motivo_cancelamento text, observacao text, criado_em timestamp DEFAULT now(), atualizado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS locais_exame (id text PRIMARY KEY, cidade_id text NOT NULL, endereco text, url_maps text, regioes_atendidas jsonb DEFAULT '[]'::jsonb, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS logs_auditoria (id text PRIMARY KEY, usuario_id text, nome_usuario text, perfil_usuario text, acao text NOT NULL, entidade text NOT NULL, entidade_id text, detalhes jsonb, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS codigos_otp (id text PRIMARY KEY, usuario_id text NOT NULL, codigo text NOT NULL, expira_em timestamp NOT NULL, usado boolean DEFAULT false, tentativas_falhas integer DEFAULT 0, criado_em timestamp DEFAULT now())`,
          sql`ALTER TABLE codigos_otp ADD COLUMN IF NOT EXISTS tentativas_falhas integer DEFAULT 0`,
          sql`CREATE TABLE IF NOT EXISTS sessoes (id text PRIMARY KEY, usuario_id text NOT NULL, expira_em timestamp NOT NULL, criado_em timestamp DEFAULT now())`,
          sql`CREATE TABLE IF NOT EXISTS backups (id text PRIMARY KEY, tipo_gatilho text NOT NULL DEFAULT 'manual', dados jsonb NOT NULL, tamanho_bytes integer DEFAULT 0, criado_em timestamp DEFAULT now())`,
          sql`CREATE UNIQUE INDEX IF NOT EXISTS backups_auto_daily ON backups ((criado_em::date)) WHERE tipo_gatilho = 'auto'`
        ];
        const columns = [
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS email text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS endereco text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS cidade text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS tipo_exame text DEFAULT 'COMMON'`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS categoria_pretendida text DEFAULT 'B'`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS origem text DEFAULT 'SCHOOL'`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS autoescola_id text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS taxa_paga_bool boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS curso_pratico_concluido boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS horas_praticas integer DEFAULT 0`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS tem_veiculo boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS restricao_cnh text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS instrutor text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS placa_veiculo text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS tipo_deficiencia text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS necessidades_especiais text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS resultado text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS banca_id text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS data_agendada text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS hora_agendada text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS categoria_agendada text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS presenca_confirmada boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS motivo_cancelamento text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS observacao text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS historico_exames jsonb DEFAULT '[]'::jsonb`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS atualizado_em timestamp DEFAULT now()`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS fila_atualizado_em timestamptz`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS examinador_id text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS tipo_solicitacao text DEFAULT 'EXTRA'`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS checklist_veiculo boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS curso_pratico_inserido boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS taxa_paga boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS agendado_por text`,
          sql`ALTER TABLE bancas ADD COLUMN IF NOT EXISTS codigo text`,
          sql`ALTER TABLE bancas ADD COLUMN IF NOT EXISTS local_id text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS examinador_id text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS instrutor_id text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS forcar_troca_senha boolean DEFAULT true`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS modulos_permitidos jsonb DEFAULT '[]'::jsonb`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS locais_permitidos_ids jsonb DEFAULT '[]'::jsonb`,
          sql`ALTER TABLE instrutores ADD COLUMN IF NOT EXISTS categoria text`,
          sql`ALTER TABLE instrutores ADD COLUMN IF NOT EXISTS placa text`,
          sql`ALTER TABLE instrutores ADD COLUMN IF NOT EXISTS cpf text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS email text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS cidade text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS servicos jsonb DEFAULT '[]'::jsonb`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_moto text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_carro text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_mudanca text`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS banca_principal jsonb`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS banca_provisoria jsonb`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS patios jsonb DEFAULT '[]'::jsonb`,
          sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS perfil_cnh_brasil boolean NOT NULL DEFAULT false`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS endereco_orgao text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS url_logo text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS template_whatsapp_cfc text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS template_whatsapp text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS endereco_exame_padrao text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS link_exame_padrao text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS nome_exame_pcd text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS endereco_exame_pcd_padrao text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS link_exame_pcd_padrao text`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS banca_principal_pcd jsonb`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS banca_principal_cnh_brasil jsonb`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS bloquear_fins_semana boolean DEFAULT false`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS max_vagas_mudanca_padrao integer DEFAULT 10`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS total_vagas integer DEFAULT 0`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS vagas_usadas integer DEFAULT 0`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS aprovados integer DEFAULT 0`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS reprovados integer DEFAULT 0`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS ausentes integer DEFAULT 0`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS cancelados integer DEFAULT 0`,
          sql`ALTER TABLE veiculos ADD COLUMN IF NOT EXISTS procuracao boolean DEFAULT false`,
          sql`ALTER TABLE configuracoes ADD COLUMN IF NOT EXISTS chave_area_risco text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS email text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS telefone text`,
          sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS dois_fatores_ativo boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS cor_linha text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS sem_duplo_comando boolean DEFAULT false`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS modulo text`,
          sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS quantidades_categoria jsonb DEFAULT '{}'::jsonb`
        ];
        for (const q of tables) {
          try {
            await db.execute(q);
          } catch {
          }
        }
        for (const q of columns) {
          try {
            await db.execute(q);
          } catch {
          }
        }
        const structuralMigrations = [
          sql`CREATE TABLE IF NOT EXISTS migracoes_schema (versao text PRIMARY KEY, aplicado_em timestamp DEFAULT now())`,
          sql`UPDATE solicitacoes SET modulo = CASE
            WHEN tipo_exame = 'PCD' THEN 'PCD'
            WHEN autoescola_id IS NULL OR autoescola_id = '' OR autoescola_id = 'CNH_BRASIL' THEN 'CNH_BRASIL'
            WHEN autoescola_id = 'PCD' THEN 'PCD'
            ELSE 'CFC'
          END WHERE modulo IS NULL OR modulo = ''`,
          sql`ALTER TABLE resultados_banca ADD COLUMN IF NOT EXISTS modulo text`,
          sql`CREATE TABLE IF NOT EXISTS solicitacoes_cnhbrasil (LIKE solicitacoes INCLUDING ALL)`,
          sql`CREATE TABLE IF NOT EXISTS solicitacoes_cfc (LIKE solicitacoes INCLUDING ALL)`,
          sql`CREATE TABLE IF NOT EXISTS solicitacoes_pcd (LIKE solicitacoes INCLUDING ALL)`,
          sql`ALTER TABLE solicitacoes_cnhbrasil ADD COLUMN IF NOT EXISTS sem_duplo_comando boolean DEFAULT false`,
          sql`CREATE TABLE IF NOT EXISTS vagas_cfc (LIKE vagas_banca INCLUDING ALL)`,
          sql`CREATE TABLE IF NOT EXISTS vagas_pcd (LIKE vagas_banca INCLUDING ALL)`
        ];
        for (const q of structuralMigrations) {
          try {
            await db.execute(q);
          } catch {
          }
        }
        try {
          const check = await db.execute(sql`SELECT 1 FROM migracoes_schema WHERE versao = 'module_tables_v1'`);
          const already = check.rows ?? check;
          if (!already || already.length === 0) {
            await db.transaction(async (tx) => {
              await tx.execute(sql`INSERT INTO migracoes_schema (versao) VALUES ('module_tables_v1')`);
              await tx.execute(sql`INSERT INTO solicitacoes_cnhbrasil SELECT * FROM solicitacoes WHERE modulo = 'CNH_BRASIL' ON CONFLICT (id) DO NOTHING`);
              await tx.execute(sql`INSERT INTO solicitacoes_cfc SELECT * FROM solicitacoes WHERE modulo = 'CFC' ON CONFLICT (id) DO NOTHING`);
              await tx.execute(sql`INSERT INTO solicitacoes_pcd SELECT * FROM solicitacoes WHERE modulo = 'PCD' ON CONFLICT (id) DO NOTHING`);
              await tx.execute(sql`INSERT INTO vagas_cfc SELECT * FROM vagas_banca WHERE tipo_exame != 'PCD' ON CONFLICT (id) DO NOTHING`);
              await tx.execute(sql`INSERT INTO vagas_pcd SELECT * FROM vagas_banca WHERE tipo_exame = 'PCD' ON CONFLICT (id) DO NOTHING`);
            });
          }
        } catch {
        }
        const dropColumns = [
          sql`ALTER TABLE solicitacoes_cnhbrasil DROP COLUMN IF EXISTS tipo_deficiencia`,
          sql`ALTER TABLE solicitacoes_cnhbrasil DROP COLUMN IF EXISTS necessidades_especiais`,
          sql`ALTER TABLE solicitacoes_cnhbrasil DROP COLUMN IF EXISTS quantidades_categoria`,
          sql`ALTER TABLE solicitacoes_cfc DROP COLUMN IF EXISTS tipo_deficiencia`,
          sql`ALTER TABLE solicitacoes_cfc DROP COLUMN IF EXISTS necessidades_especiais`,
          sql`ALTER TABLE solicitacoes_pcd DROP COLUMN IF EXISTS sem_duplo_comando`,
          sql`ALTER TABLE solicitacoes_pcd DROP COLUMN IF EXISTS quantidades_categoria`
        ];
        for (const q of dropColumns) {
          try {
            await db.execute(q);
          } catch {
          }
        }
        try {
          await db.insert(users).values({
            id: crypto.randomUUID(),
            name: "Administrador",
            login: "admin",
            role: "ADMIN",
            forcePasswordChange: false
          }).onConflictDoNothing();
        } catch {
        }
        return json2({ success: true, message: "Tabelas criadas e sincronizadas com sucesso!" });
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequestPost");
  }
});

// api/vehicle-lookup.ts
var onRequestGet4;
var init_vehicle_lookup = __esm({
  "api/vehicle-lookup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    onRequestGet4 = /* @__PURE__ */ __name(async ({ request }) => {
      try {
        const { searchParams } = new URL(request.url);
        const plate = searchParams.get("plate")?.toUpperCase().replace(/[^A-Z0-9]/g, "");
        if (!plate) {
          return new Response(JSON.stringify({ error: "Placa \xE9 obrigat\xF3ria" }), { status: 400, headers: { "Content-Type": "application/json" } });
        }
        const resp = await fetch(`https://apicarros.com/v1/consulta/${plate}/json`, {
          headers: { "Accept": "application/json" }
        });
        if (!resp.ok) {
          return new Response(JSON.stringify({ error: "Placa n\xE3o encontrada" }), { status: 404, headers: { "Content-Type": "application/json" } });
        }
        const data = await resp.json();
        return new Response(JSON.stringify(data), { status: 200, headers: { "Content-Type": "application/json" } });
      } catch (e) {
        return new Response(JSON.stringify({ error: e.message ?? "Erro ao consultar placa" }), { status: 500, headers: { "Content-Type": "application/json" } });
      }
    }, "onRequestGet");
  }
});

// api/verify-otp.ts
async function hashCode2(code) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(code));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function createSession2(db, userId) {
  const sessionId = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1e3);
  await db.execute(sql`
    INSERT INTO sessoes (id, usuario_id, expira_em, criado_em)
    VALUES (${sessionId}, ${userId}, ${expiresAt.toISOString()}, now())
  `);
  return sessionId;
}
async function ensureSchema2(db) {
  const stmts = [
    sql`CREATE TABLE IF NOT EXISTS sessoes (id text PRIMARY KEY, usuario_id text NOT NULL, expira_em timestamp NOT NULL, criado_em timestamp DEFAULT now())`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS email text`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS telefone text`,
    sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS dois_fatores_ativo boolean DEFAULT false`
  ];
  for (const s of stmts) {
    try {
      await db.execute(s);
    } catch {
    }
  }
}
var MAX_ATTEMPTS, onRequestPost4;
var init_verify_otp = __esm({
  "api/verify-otp.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_backup();
    MAX_ATTEMPTS = 5;
    __name(hashCode2, "hashCode");
    __name(createSession2, "createSession");
    __name(ensureSchema2, "ensureSchema");
    onRequestPost4 = /* @__PURE__ */ __name(async (context) => {
      const { request, env } = context;
      try {
        const db = getDb(env);
        await ensurePortugueseSchema(db);
        await ensureSchema2(db);
        const body = await parseBody(request);
        const { userId, code } = body;
        if (!userId || !code) return error("userId e code s\xE3o obrigat\xF3rios", 400);
        const inputHash = await hashCode2(code.trim());
        const consumed = await db.execute(sql`
      UPDATE codigos_otp
      SET usado = true
      WHERE usuario_id = ${userId}
        AND codigo = ${inputHash}
        AND usado = false
        AND expira_em > NOW()
        AND tentativas_falhas < ${MAX_ATTEMPTS}
      RETURNING id
    `);
        const rows = consumed.rows ?? consumed;
        if (!rows || rows.length === 0) {
          await db.execute(sql`
        UPDATE codigos_otp
        SET
          tentativas_falhas = COALESCE(tentativas_falhas, 0) + 1,
          usado = CASE
            WHEN COALESCE(tentativas_falhas, 0) + 1 >= ${MAX_ATTEMPTS} THEN true
            ELSE usado
          END
        WHERE usuario_id = ${userId} AND usado = false AND expira_em > NOW()
      `);
          return error("C\xF3digo inv\xE1lido, expirado ou tentativas esgotadas. Fa\xE7a login novamente.", 401);
        }
        const result = await db.select().from(users).where(eq(users.id, userId));
        if (result.length === 0) return error("Usu\xE1rio n\xE3o encontrado", 404);
        const sessionToken = await createSession2(db, userId);
        if (result[0].role === "ADMIN") {
          context.waitUntil(createBackup(db, "auto").catch(() => {
          }));
        }
        const { password: _p, ...safe } = result[0];
        return json2({ ...safe, sessionToken });
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequestPost");
  }
});

// api/backups.ts
var RESTORE_SCHEMA_TABLES, onRequest2;
var init_backups = __esm({
  "api/backups.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_backup();
    init_drizzle_orm();
    init_schema2();
    init_d1();
    init_d1_backup();
    RESTORE_SCHEMA_TABLES = {
      autoescolas: drivingSchools,
      examinadores: examiners,
      instrutores: instructors,
      veiculos: vehicles,
      cidades: cities,
      bancas: examSchedules,
      solicitacoes: examRequests,
      solicitacoes_cnhbrasil: cnhbrasilRequests,
      solicitacoes_cfc: cfcRequests,
      solicitacoes_pcd: pcdRequests,
      vagas_banca: examScheduleSlots,
      vagas_cfc: cfcScheduleSlots,
      vagas_pcd: pcdScheduleSlots,
      resultados_banca: bancaResults,
      locais_exame: examLocations,
      datas_bloqueadas: blockedDates,
      configuracoes: systemSettings,
      usuarios: users
    };
    onRequest2 = /* @__PURE__ */ __name(async (context) => {
      const { request, env, data } = context;
      if (data?.sessionUserRole !== "ADMIN") {
        return error("Acesso negado \u2014 apenas administradores", 403);
      }
      try {
        const db = getDb(env);
        await ensureBackupSchema(db);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          if (query.id) {
            if (isD1(db)) {
              const backup = await readD1Backup(db, query.id);
              return backup ? json2(backup) : error("Backup n\xE3o encontrado", 404);
            }
            const res2 = await db.execute(sql`SELECT id, dados AS payload, criado_em AS created_at FROM backups WHERE id = ${query.id} LIMIT 1`);
            const rows = res2.rows ?? res2;
            if (!rows || rows.length === 0) return error("Backup n\xE3o encontrado", 404);
            return json2(rows[0]);
          }
          const res = await db.execute(sql`
        SELECT id, tipo_gatilho AS trigger_type, tamanho_bytes AS size_bytes, criado_em AS created_at FROM backups ORDER BY criado_em DESC
      `);
          return json2(res.rows ?? res);
        }
        if (method === "POST") {
          const body = await parseBody(request);
          if (body.payload !== void 0 || body.backupId) {
            let payload = body.payload;
            if (body.backupId) {
              if (isD1(db)) {
                const backup = await readD1Backup(db, body.backupId);
                if (!backup) return error("Backup n\xE3o encontrado", 404);
                payload = backup.payload;
              } else {
                const stored = await db.execute(sql`SELECT dados AS payload FROM backups WHERE id = ${body.backupId} LIMIT 1`);
                const storedRows = stored.rows ?? stored;
                if (!storedRows || storedRows.length === 0) return error("Backup n\xE3o encontrado", 404);
                payload = storedRows[0].payload;
              }
            }
            const result2 = await restoreBackup(db, payload, { batchTables: RESTORE_SCHEMA_TABLES });
            return json2({ success: true, ...result2 });
          }
          const result = await createBackup(db, "manual");
          return json2({ success: true, ...result });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/banca-results.ts
var onRequest3;
var init_banca_results = __esm({
  "api/banca-results.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    onRequest3 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          const { scheduleId, schoolId } = query;
          let q = db.select().from(bancaResults);
          if (scheduleId && schoolId) q = q.where(and(eq(bancaResults.scheduleId, scheduleId), eq(bancaResults.schoolId, schoolId)));
          else if (scheduleId) q = q.where(eq(bancaResults.scheduleId, scheduleId));
          else if (schoolId) q = q.where(eq(bancaResults.schoolId, schoolId));
          return json2(await q);
        }
        if (method === "POST") {
          const body = await parseBody(request);
          const { scheduleId, schoolId, category } = body;
          if (!scheduleId || !schoolId || !category) return error("scheduleId, schoolId e category s\xE3o obrigat\xF3rios", 400);
          const existing = await db.select().from(bancaResults).where(
            and(eq(bancaResults.scheduleId, scheduleId), eq(bancaResults.schoolId, schoolId), eq(bancaResults.category, category))
          );
          if (existing.length > 0) {
            const { id, createdAt, updatedAt, ...updates } = body;
            const updated = await db.update(bancaResults).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq(bancaResults.id, existing[0].id)).returning();
            return json2(updated[0]);
          }
          const newItem = await db.insert(bancaResults).values({ id: crypto.randomUUID(), ...body, createdAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).returning();
          return json2(newItem[0]);
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/blocked-dates.ts
var onRequest4;
var init_blocked_dates = __esm({
  "api/blocked-dates.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    onRequest4 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") return json2(await db.select().from(blockedDates).orderBy(blockedDates.date));
        if (method === "POST") {
          const body = await parseBody(request);
          if (!body.date) return error("Data \xE9 obrigat\xF3ria", 400);
          const existing = await db.select().from(blockedDates).where(eq(blockedDates.date, body.date));
          if (existing.length > 0) return error("Esta data j\xE1 est\xE1 bloqueada", 400);
          const newRow = { id: crypto.randomUUID(), date: body.date, description: body.description || "", isHoliday: !!body.isHoliday, createdAt: /* @__PURE__ */ new Date() };
          await db.insert(blockedDates).values(newRow);
          return json2(newRow, 201);
        }
        if (method === "PUT") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          const body = await parseBody(request);
          await db.update(blockedDates).set(body).where(eq(blockedDates.id, id));
          return json2({ success: true });
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(blockedDates).where(eq(blockedDates.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/cities.ts
var onRequest5;
var init_cities = __esm({
  "api/cities.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    onRequest5 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") return json2(await db.select().from(cities));
        if (method === "POST") {
          const body = await parseBody(request);
          if (!body.name) return error("Nome \xE9 obrigat\xF3rio", 400);
          const normalized = body.name.toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          const newCity = { id: crypto.randomUUID(), name: normalized, createdAt: /* @__PURE__ */ new Date() };
          await db.insert(cities).values(newCity);
          return json2(newCity, 201);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const id = body.id || query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          const updates = {};
          if (body.name) updates.name = body.name.toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          await db.update(cities).set(updates).where(eq(cities.id, id));
          return json2({ id, ...updates });
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(cities).where(eq(cities.id, id));
          return new Response(null, { status: 204 });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/cnh-logs.ts
var onRequest6;
var init_cnh_logs = __esm({
  "api/cnh-logs.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_drizzle_orm();
    onRequest6 = /* @__PURE__ */ __name(async ({ request, env }) => {
      if (request.method !== "GET") return error("Method Not Allowed", 405);
      try {
        const db = getDb(env);
        const { limit = "300", offset = "0" } = getQuery(request.url);
        await db.execute(sql`
      CREATE TABLE IF NOT EXISTS logs_auditoria (
        id text PRIMARY KEY,
        usuario_id text,
        nome_usuario text,
        perfil_usuario text,
        acao text NOT NULL,
        entidade text NOT NULL,
        entidade_id text,
        detalhes jsonb,
        criado_em timestamp DEFAULT now()
      )
    `).catch(() => {
        });
        const rows = await db.execute(sql`
      SELECT id, usuario_id AS user_id, nome_usuario AS user_name, perfil_usuario AS user_role,
             acao AS action, entidade AS entity, entidade_id AS entity_id,
             detalhes AS details, criado_em AS created_at
      FROM logs_auditoria
      WHERE entidade LIKE 'CNH_BRASIL%'
      ORDER BY criado_em DESC
      LIMIT ${parseInt(limit)}
      OFFSET ${parseInt(offset)}
    `);
        return json2(rows.rows ?? rows);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _cpf-lookup.ts
function validCpf(value) {
  const cpf = normalizeCpf(value);
  if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;
  for (let size = 9; size <= 10; size++) {
    let sum = 0;
    for (let i = 0; i < size; i++) sum += Number(cpf[i]) * (size + 1 - i);
    const digit = sum * 10 % 11 % 10;
    if (digit !== Number(cpf[size])) return false;
  }
  return true;
}
function canLookupCpf(user) {
  if (!user || !["ADMIN", "SUPERVISOR", "OPERATOR", "INSTRUCTOR"].includes(user.role)) return false;
  if (["OPERATOR", "SUPERVISOR"].includes(user.role) && Array.isArray(user.allowedModules) && user.allowedModules.length && !user.allowedModules.includes("cnh")) return false;
  return true;
}
function cpfSettingError(body, role) {
  if (!Object.prototype.hasOwnProperty.call(body, "cnhCpfAutofillEnabled")) return;
  if (role !== "ADMIN") return "Somente administradores podem configurar o autopreenchimento.";
  if (typeof body.cnhCpfAutofillEnabled !== "boolean") return "A ativa\xE7\xE3o deve ser verdadeira ou falsa.";
  return void 0;
}
async function lookupCpf(options) {
  if (!options.user) return fail(401, "Fa\xE7a login novamente.");
  if (!canLookupCpf(options.user) || options.body?.module !== "CNH_BRASIL") return fail(403, "Consulta n\xE3o autorizada neste m\xF3dulo.");
  if (!options.enabled) return fail(409, "Autopreenchimento desativado.");
  if (typeof options.body?.cpf !== "string" || !validCpf(options.body.cpf)) return fail(400, messages[400]);
  if (!options.key) return fail(503, "Servi\xE7o de CPF n\xE3o configurado no servidor.");
  if (!await options.consumeQuota()) return fail(429, messages[429]);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? 8e3);
  try {
    const url = new URL("https://apicpf.com/api/consulta");
    url.searchParams.set("cpf", normalizeCpf(options.body.cpf));
    const response = await (options.fetcher ?? fetch)(url, {
      headers: { "X-API-KEY": options.key, Accept: "application/json" },
      // Workers only implement follow/manual, not redirect:"error".
      // Never follow redirects carrying the API key or CPF to another origin.
      signal: controller.signal,
      redirect: "manual",
      cache: "no-store"
    });
    if (response.status >= 300 && response.status < 400) {
      return fail(503, "O servi\xE7o de CPF retornou um redirecionamento inesperado.");
    }
    const payload = await response.json().catch(() => null);
    const code = response.ok ? Number(payload?.code ?? response.status) : response.status;
    if (code !== 200) return fail(
      [400, 404, 429].includes(code) ? code : 503,
      messages[code] ?? "Servi\xE7o de CPF indispon\xEDvel."
    );
    const name = payload?.data?.nome;
    if (typeof name !== "string" || !name.trim() || name.length > 300) return fail(503, "Resposta inv\xE1lida do servi\xE7o de CPF.");
    return { status: 200, body: { name: name.trim() } };
  } catch {
    return fail(503, controller.signal.aborted ? "Consulta de CPF demorou demais." : "N\xE3o foi poss\xEDvel conectar ao servi\xE7o de CPF.");
  } finally {
    clearTimeout(timer);
  }
}
async function consumeCpfQuota(db, userId) {
  const minute = Math.floor(Date.now() / 6e4);
  const result = await db.execute(sql`
    INSERT INTO cotas_consulta_cpf (id, janela_minuto, consultas) VALUES (${userId}, ${minute}, 1)
    ON CONFLICT (id) DO UPDATE SET janela_minuto = excluded.janela_minuto,
      consultas = CASE WHEN cotas_consulta_cpf.janela_minuto = excluded.janela_minuto
        THEN cotas_consulta_cpf.consultas + 1 ELSE 1 END
    WHERE cotas_consulta_cpf.janela_minuto != excluded.janela_minuto OR cotas_consulta_cpf.consultas < 10
    RETURNING id
  `);
  return (result.rows ?? result).length > 0;
}
var normalizeCpf, messages, fail;
var init_cpf_lookup = __esm({
  "_cpf-lookup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    normalizeCpf = /* @__PURE__ */ __name((value) => value.replace(/\D/g, ""), "normalizeCpf");
    __name(validCpf, "validCpf");
    __name(canLookupCpf, "canLookupCpf");
    __name(cpfSettingError, "cpfSettingError");
    messages = {
      400: "CPF inv\xE1lido para consulta.",
      404: "CPF n\xE3o encontrado.",
      402: "Servi\xE7o de consulta sem cr\xE9ditos.",
      401: "Chave do servi\xE7o de CPF inv\xE1lida ou ausente.",
      403: "Chave do servi\xE7o de CPF expirada ou sem autoriza\xE7\xE3o.",
      429: "Limite de consultas atingido. Aguarde antes de tentar novamente."
    };
    fail = /* @__PURE__ */ __name((status, message) => ({
      status,
      body: { error: `${message} Preencha o nome manualmente.` }
    }), "fail");
    __name(lookupCpf, "lookupCpf");
    __name(consumeCpfQuota, "consumeCpfQuota");
  }
});

// api/cpf-lookup.ts
var onRequest7;
var init_cpf_lookup2 = __esm({
  "api/cpf-lookup.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_drizzle_orm();
    init_db2();
    init_schema2();
    init_cpf_lookup();
    onRequest7 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      if (request.method !== "POST") return error("Method Not Allowed", 405);
      try {
        const db = getDb(env);
        const [user] = await db.select({ id: users.id, role: users.role, allowedModules: users.allowedModules }).from(users).where(eq(users.id, String(data.sessionUserId)));
        const [settings] = await db.select({ enabled: systemSettings.cnhCpfAutofillEnabled }).from(systemSettings).where(eq(systemSettings.id, 1));
        const result = await lookupCpf({
          body: await parseBody(request),
          user,
          enabled: settings?.enabled === true,
          key: env.APICPF_API_KEY,
          consumeQuota: /* @__PURE__ */ __name(() => consumeCpfQuota(db, user.id), "consumeQuota")
        });
        const response = json2(result.body, result.status);
        response.headers.set("Cache-Control", "no-store");
        return response;
      } catch {
        return error("N\xE3o foi poss\xEDvel consultar o CPF. Preencha o nome manualmente.", 503);
      }
    }, "onRequest");
  }
});

// api/exam-locations.ts
async function ensureTable(db) {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS locais_exame (
        id text PRIMARY KEY,
        cidade_id text NOT NULL,
        endereco text,
        url_maps text,
        regioes_atendidas jsonb DEFAULT '[]'::jsonb,
        criado_em timestamp DEFAULT now()
      )
    `);
    await db.execute(sql`ALTER TABLE bancas ADD COLUMN IF NOT EXISTS local_id text`);
  } catch {
  }
}
var onRequest8;
var init_exam_locations = __esm({
  "api/exam-locations.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    __name(ensureTable, "ensureTable");
    onRequest8 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        await ensureTable(db);
        if (method === "GET") return json2(await db.select().from(examLocations));
        if (method === "POST") {
          const body = await parseBody(request);
          if (!body.cityId) return error("cityId \xE9 obrigat\xF3rio", 400);
          const newLocation = {
            id: crypto.randomUUID(),
            cityId: body.cityId,
            address: body.address || null,
            mapsUrl: body.mapsUrl || null,
            regionsServed: body.regionsServed || [],
            createdAt: /* @__PURE__ */ new Date()
          };
          await db.insert(examLocations).values(newLocation);
          return json2(newLocation, 201);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const id = body.id || query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          const { id: _id, createdAt, ...updates } = body;
          await db.update(examLocations).set(updates).where(eq(examLocations.id, id));
          return json2({ id, ...updates });
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(examLocations).where(eq(examLocations.id, id));
          return new Response(null, { status: 204 });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/examiners.ts
async function ensureSchema3(db) {
  try {
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS categorias jsonb DEFAULT '[]'::jsonb`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS max_vagas_a_padrao integer`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS max_vagas_b_padrao integer`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS max_vagas_mudanca_padrao integer`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS rodizio_provas boolean NOT NULL DEFAULT false`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS disponibilidade_rodizio jsonb`);
    await db.execute(sql`ALTER TABLE public.examinadores ADD COLUMN IF NOT EXISTS periodos_bloqueio jsonb DEFAULT '[]'::jsonb`);
  } catch {
  }
}
var onRequest9;
var init_examiners = __esm({
  "api/examiners.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    __name(ensureSchema3, "ensureSchema");
    onRequest9 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          await ensureSchema3(db);
          const rows = await db.select().from(examiners);
          const normalised = rows.map((r) => ({
            ...r,
            blockedPeriods: Array.isArray(r.blockedPeriods) ? r.blockedPeriods : [],
            categories: Array.isArray(r.categories) ? r.categories : []
          }));
          return json2(normalised);
        }
        if (method === "POST") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          await ensureSchema3(db);
          const body = await parseBody(request);
          const newItem = await db.insert(examiners).values({ id: crypto.randomUUID(), ...body }).returning();
          return json2(newItem[0]);
        }
        if (method === "PUT") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          await ensureSchema3(db);
          const body = await parseBody(request);
          const { id, createdAt, updatedAt, ...updates } = body;
          const updated = await db.update(examiners).set(updates).where(eq(examiners.id, id)).returning();
          return json2(updated[0]);
        }
        if (method === "DELETE") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(examiners).where(eq(examiners.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/instructors.ts
var onRequest10;
var init_instructors = __esm({
  "api/instructors.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    onRequest10 = /* @__PURE__ */ __name(async ({ request, env }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          const allInstructors = await db.select().from(instructors);
          const allVehicles = await db.select().from(vehicles);
          const data = allInstructors.map((inst) => ({
            ...inst,
            vehicles: allVehicles.filter((v2) => v2.instructorId === inst.id)
          }));
          return json2(data);
        }
        if (method === "POST") {
          const body = await parseBody(request);
          const { vehicles: vehiclesList, ...instructorData } = body;
          const newId = crypto.randomUUID();
          const newItem = await db.insert(instructors).values({ id: newId, ...instructorData }).returning();
          if (Array.isArray(vehiclesList)) {
            for (const v2 of vehiclesList) {
              await db.insert(vehicles).values({
                id: crypto.randomUUID(),
                instructorId: newId,
                type: v2.type,
                brand: v2.brand,
                model: v2.model,
                plate: v2.plate,
                active: v2.active ?? true,
                transmission: v2.transmission,
                accessories: v2.accessories || [],
                duploComando: v2.duploComando ?? false,
                procuracao: v2.procuracao ?? false,
                anoFabricacao: v2.anoFabricacao || null
              });
            }
          }
          return json2({ ...newItem[0], vehicles: vehiclesList || [] });
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const { id, vehicles: vehiclesList, createdAt, updatedAt, ...updates } = body;
          const updated = await db.update(instructors).set(updates).where(eq(instructors.id, id)).returning();
          if (Array.isArray(vehiclesList)) {
            await db.delete(vehicles).where(eq(vehicles.instructorId, id));
            for (const v2 of vehiclesList) {
              await db.insert(vehicles).values({
                id: !v2.id || v2.id.startsWith("temp_") ? crypto.randomUUID() : v2.id,
                instructorId: id,
                type: v2.type,
                brand: v2.brand,
                model: v2.model,
                plate: v2.plate,
                active: v2.active ?? true,
                transmission: v2.transmission,
                accessories: v2.accessories || [],
                duploComando: v2.duploComando ?? false,
                procuracao: v2.procuracao ?? false,
                anoFabricacao: v2.anoFabricacao || null
              });
            }
          }
          return json2({ ...updated[0], vehicles: vehiclesList || [] });
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(vehicles).where(eq(vehicles.instructorId, id));
          await db.delete(instructors).where(eq(instructors.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _cfc-confirmed.ts
function canManageConfirmed(role) {
  return role === "ADMIN" || role === "SUPERVISOR";
}
function isConfirmedCfc(row, module, slot = false) {
  return !!row && (slot || module === "CFC") && row.status === "SCHEDULED" && row.attendanceConfirmed === true;
}
function confirmedAccessError(row, module, slot, role, updates) {
  const confirmed = isConfirmedCfc(row, module, slot);
  if (updates.confirmedEdit && !confirmed) return "O agendamento n\xE3o est\xE1 mais confirmado. Atualize a lista.";
  if (confirmed && !canManageConfirmed(role)) {
    const protectedFields = [...confirmedFields, "schoolId", "examType", "modulo", "scheduleId"];
    const changed = protectedFields.some((k) => updates[k] !== void 0 && JSON.stringify(updates[k]) !== JSON.stringify(row[k]));
    const unconfirm = updates.attendanceConfirmed === false && updates.status !== "CANCELLED";
    if (updates.confirmedEdit || changed || unconfirm) {
      return "Somente administradores e supervisores podem editar provas confirmadas.";
    }
  }
  return null;
}
function confirmedPatch(body) {
  const patch = {};
  for (const key of confirmedFields) if (body[key] !== void 0) patch[key] = body[key];
  return patch;
}
function validateConfirmedFields(row, updates, today) {
  const merged = { ...row, ...confirmedPatch(updates) };
  const date2 = merged.scheduledDate;
  if (typeof date2 !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(date2) || Number.isNaN(Date.parse(`${date2}T12:00:00Z`)) || (/* @__PURE__ */ new Date(`${date2}T12:00:00Z`)).toISOString().slice(0, 10) !== date2) return "Informe uma data v\xE1lida.";
  if (date2 < today) return "N\xE3o \xE9 permitido reagendar para uma data passada.";
  if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(merged.scheduledTime ?? "")) return "Informe um hor\xE1rio v\xE1lido.";
  if (typeof merged.examinerId !== "string" || !merged.examinerId) return "Selecione o examinador.";
  if (!["FIXA", "EXTRA", "REPOSICAO"].includes(merged.requestType)) return "Selecione um tipo de agendamento v\xE1lido.";
  const cats = typeof merged.intendedCategory === "string" ? merged.intendedCategory.split(",") : [];
  const allowed = row.examType === "PCD" || row.schoolId === "PCD" ? ["PCD"] : ["A", "B", "C", "D", "E"];
  if (!cats.length || cats.some((c) => !allowed.includes(c)) || new Set(cats).size !== cats.length) {
    return "Selecione categorias v\xE1lidas.";
  }
  const hasHab = cats.some((c) => ["A", "B"].includes(c));
  const hasMudanca = cats.some((c) => ["C", "D", "E"].includes(c));
  const group = cats.includes("PCD") ? "PCD" : hasHab && hasMudanca ? "MISTO" : hasMudanca ? "MUD_CAT" : "1HAB";
  if (updates.examGroup !== void 0 && updates.examGroup !== group) {
    return "As categorias selecionadas n\xE3o correspondem ao exame informado.";
  }
  const quantities = merged.categoryQuantities;
  if (updates.confirmedEdit || updates.categoryQuantities !== void 0) {
    if (!quantities || typeof quantities !== "object" || Array.isArray(quantities) || Object.keys(quantities).some((c) => !cats.includes(c)) || cats.some((c) => !Number.isSafeInteger(quantities[c]) || quantities[c] < 0)) {
      return "Informe vagas inteiras, n\xE3o negativas, para cada categoria selecionada.";
    }
  }
  return null;
}
function todayInBrazil() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(/* @__PURE__ */ new Date());
}
async function validateConfirmedEdit(db, tables, row, updates) {
  const invalid = validateConfirmedFields(row, updates, todayInBrazil());
  if (invalid) return invalid;
  const merged = { ...row, ...confirmedPatch(updates) };
  const [examiners2, settings, blocked] = await Promise.all([
    db.select().from(tables.examiners),
    db.select().from(tables.systemSettings),
    db.select().from(tables.blockedDates)
  ]);
  const examiner = examiners2.find((ex) => ex.id === merged.examinerId);
  if (!examiner) return "Examinador n\xE3o encontrado.";
  const cats = merged.intendedCategory.split(",");
  if (cats.includes("PCD") ? !examiner.canExamPCD : examiner.categories?.length && !cats.some((c) => examiner.categories.includes(c))) {
    return "O examinador n\xE3o atende \xE0s categorias selecionadas.";
  }
  const weekday = (/* @__PURE__ */ new Date(`${merged.scheduledDate}T12:00:00Z`)).getUTCDay();
  if (blocked.some((b) => b.date?.split("T")[0] === merged.scheduledDate) || settings[0]?.blockWeekends && [0, 6].includes(weekday)) return "Esta data est\xE1 bloqueada para agendamento.";
  return null;
}
function hasCandidateIdentity(row) {
  return !!(row.cpf || row.studentName || row.socialName);
}
var confirmedFields, clearAppointment;
var init_cfc_confirmed = __esm({
  "_cfc-confirmed.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    confirmedFields = [
      "scheduledDate",
      "scheduledTime",
      "examinerId",
      "intendedCategory",
      "categoryQuantities",
      "requestType"
    ];
    __name(canManageConfirmed, "canManageConfirmed");
    __name(isConfirmedCfc, "isConfirmedCfc");
    __name(confirmedAccessError, "confirmedAccessError");
    __name(confirmedPatch, "confirmedPatch");
    __name(validateConfirmedFields, "validateConfirmedFields");
    __name(todayInBrazil, "todayInBrazil");
    __name(validateConfirmedEdit, "validateConfirmedEdit");
    __name(hasCandidateIdentity, "hasCandidateIdentity");
    clearAppointment = {
      status: "WAITING_SCHEDULING",
      scheduleId: null,
      scheduledDate: null,
      scheduledTime: null,
      scheduledCategory: null,
      examinerId: null,
      attendanceConfirmed: false,
      queueUpdatedAt: null
    };
  }
});

// _cfc-extra.ts
function canEditExtra(role) {
  return ["ADMIN", "SUPERVISOR", "OPERATOR"].includes(role ?? "");
}
function extraEditError(current, module, role, body) {
  if (!canEditExtra(role)) return { status: 403, error: "Acesso negado." };
  if (!current || module !== "CFC" || current.examType === "PCD" || ["PCD", "CNH_BRASIL"].includes(current.schoolId) || current.status !== "WAITING_SCHEDULING" || current.attendanceConfirmed) {
    return { status: 409, error: "Este pedido n\xE3o est\xE1 mais na fila de provas extras. Atualize a lista." };
  }
  const fail2 = /* @__PURE__ */ __name((error2) => ({ status: 400, error: error2 }), "fail");
  if (Object.keys(body).some((key) => !["id", "extraEdit", "examGroup", ...editable].includes(key))) {
    return fail2("Esta edi\xE7\xE3o permite somente Tipo, Exame, Qtd. por Cat. e Observa\xE7\xF5es.");
  }
  if (!["FIXA", "EXTRA", "REPOSICAO"].includes(body.requestType)) return fail2("Selecione um tipo v\xE1lido.");
  if (typeof body.intendedCategory !== "string") return fail2("Selecione ao menos uma categoria.");
  const cats = body.intendedCategory.split(",");
  if (!cats.length || new Set(cats).size !== cats.length || cats.some((c) => !["A", "B", "C", "D", "E"].includes(c))) {
    return fail2("Selecione categorias v\xE1lidas para o exame.");
  }
  const hab = cats.some((c) => ["A", "B"].includes(c));
  const mud = cats.some((c) => ["C", "D", "E"].includes(c));
  const group = hab && mud ? "MISTO" : mud ? "MUD_CAT" : "1HAB";
  if (body.examGroup !== group) return fail2("As categorias n\xE3o correspondem ao exame selecionado.");
  const quantities = body.categoryQuantities;
  if (!quantities || typeof quantities !== "object" || Array.isArray(quantities) || Object.keys(quantities).length !== cats.length || cats.some((cat) => !Object.hasOwn(quantities, cat) || !Number.isSafeInteger(quantities[cat]) || quantities[cat] < 1)) {
    return fail2("Informe uma quantidade inteira maior que zero para cada categoria selecionada.");
  }
  if (typeof body.observation !== "string") return fail2("Observa\xE7\xF5es inv\xE1lidas.");
  return null;
}
function extraPatch(body) {
  return Object.fromEntries(editable.map((key) => [key, body[key]]));
}
var editable;
var init_cfc_extra = __esm({
  "_cfc-extra.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(canEditExtra, "canEditExtra");
    editable = ["requestType", "intendedCategory", "categoryQuantities", "observation"];
    __name(extraEditError, "extraEditError");
    __name(extraPatch, "extraPatch");
  }
});

// _cfc-interest.ts
function canRegisterInterest(role) {
  return role === "EXAMINER";
}
function isPendingCfcExtra(current, module) {
  return !!current && module === "CFC" && current.examType !== "PCD" && !["PCD", "CNH_BRASIL"].includes(current.schoolId) && current.status === "WAITING_SCHEDULING" && !current.attendanceConfirmed;
}
function interestError(current, module, role, examiner) {
  if (!canRegisterInterest(role)) return { status: 403, error: "Somente examinadores podem registrar interesse." };
  if (!examiner?.id) return { status: 403, error: "Usu\xE1rio sem examinador vinculado." };
  if (!isPendingCfcExtra(current, module)) {
    return { status: 409, error: "Este pedido n\xE3o est\xE1 mais na fila de provas extras. Atualize a lista." };
  }
  const list = Array.isArray(current.interestedExaminers) ? current.interestedExaminers : [];
  if (list.some((i) => i.examinerId === examiner.id)) {
    return { status: 409, error: "Interesse j\xE1 registrado para este pedido." };
  }
  return null;
}
function interestPatch(current, examiner, now = /* @__PURE__ */ new Date()) {
  const list = Array.isArray(current?.interestedExaminers) ? current.interestedExaminers : [];
  if (list.some((i) => i.examinerId === examiner.id)) return { interestedExaminers: list };
  return {
    interestedExaminers: [...list, { examinerId: examiner.id, name: examiner.name, registeredAt: now.toISOString() }]
  };
}
var init_cfc_interest = __esm({
  "_cfc-interest.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(canRegisterInterest, "canRegisterInterest");
    __name(isPendingCfcExtra, "isPendingCfcExtra");
    __name(interestError, "interestError");
    __name(interestPatch, "interestPatch");
  }
});

// _cnh-exam-modality.ts
function modalityValidationError(data) {
  for (const field of ["examModalityA", "examModalityB"]) {
    const value = data[field];
    if (value !== void 0 && value !== null && value !== "STANDARD" && value !== "PCD" && value !== "REABILITACAO") {
      return "Selecione somente uma modalidade v\xE1lida por categoria: PCD ou Reabilita\xE7\xE3o.";
    }
  }
  return null;
}
var init_cnh_exam_modality = __esm({
  "_cnh-exam-modality.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(modalityValidationError, "modalityValidationError");
  }
});

// api/requests.ts
function stripDroppedFields(obj, modulo) {
  const dropped = MODULE_DROPPED_FIELDS[modulo] ?? [];
  if (dropped.length === 0) return obj;
  const out = { ...obj };
  for (const f of dropped) delete out[f];
  return out;
}
function deriveModulo(data) {
  if (data.examType === "PCD" || data.schoolId === "PCD") return "PCD";
  if (!data.schoolId || data.schoolId === "" || data.schoolId === "CNH_BRASIL") return "CNH_BRASIL";
  return "CFC";
}
function filterFields(obj) {
  const out = {};
  for (const k of ALLOWED_FIELDS) if (obj[k] !== void 0) out[k] = obj[k];
  return out;
}
function getRequestTable(modulo) {
  if (modulo === "PCD") return pcdRequests;
  if (modulo === "CFC") return cfcRequests;
  return cnhbrasilRequests;
}
async function findRequestById(db, id) {
  const [cnhRows, cfcRows, pcdRows] = await Promise.all([
    db.select().from(cnhbrasilRequests).where(eq(cnhbrasilRequests.id, id)).limit(1),
    db.select().from(cfcRequests).where(eq(cfcRequests.id, id)).limit(1),
    db.select().from(pcdRequests).where(eq(pcdRequests.id, id)).limit(1)
  ]);
  if (cnhRows.length > 0) return { row: cnhRows[0], modulo: "CNH_BRASIL" };
  if (cfcRows.length > 0) return { row: cfcRows[0], modulo: "CFC" };
  if (pcdRows.length > 0) return { row: pcdRows[0], modulo: "PCD" };
  return null;
}
var ALLOWED_FIELDS, MODULE_DROPPED_FIELDS, onRequest11;
var init_requests = __esm({
  "api/requests.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_cfc_confirmed();
    init_cfc_extra();
    init_cfc_interest();
    init_cnh_exam_modality();
    ALLOWED_FIELDS = [
      "id",
      "studentName",
      "socialName",
      "cpf",
      "phone",
      "email",
      "address",
      "city",
      "requestType",
      "examType",
      "intendedCategory",
      "source",
      "schoolId",
      "paidFee",
      "completedPracticalCourse",
      "practicalHours",
      "hasVehicle",
      "cnhRestriction",
      "instructor",
      "vehiclePlate",
      "disabilityType",
      "specialNeeds",
      "status",
      "result",
      "scheduleId",
      "scheduledDate",
      "scheduledTime",
      "scheduledCategory",
      "examinerId",
      "attendanceConfirmed",
      "cancellationReason",
      "observation",
      "categoryQuantities",
      "examHistory",
      "queueUpdatedAt",
      "checklistVehicle",
      "practicalCourseInserted",
      "taxaPaga",
      "scheduledBy",
      "modulo",
      "semDuploComando",
      "rowColor",
      "examModalityA",
      "examModalityB"
    ];
    MODULE_DROPPED_FIELDS = {
      CNH_BRASIL: ["disabilityType", "specialNeeds", "categoryQuantities", "interestedExaminers"],
      CFC: ["disabilityType", "specialNeeds", "examModalityA", "examModalityB"],
      PCD: ["semDuploComando", "categoryQuantities", "examModalityA", "examModalityB", "interestedExaminers"]
    };
    __name(stripDroppedFields, "stripDroppedFields");
    __name(deriveModulo, "deriveModulo");
    __name(filterFields, "filterFields");
    __name(getRequestTable, "getRequestTable");
    __name(findRequestById, "findRequestById");
    onRequest11 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          if (query.cpf) {
            const clean = query.cpf.replace(/\D/g, "");
            const pattern = `%${clean}%`;
            const [cnhRows2, cfcRows2, pcdRows2] = await Promise.all([
              db.select().from(cnhbrasilRequests).where(like(cnhbrasilRequests.cpf, pattern)),
              db.select().from(cfcRequests).where(like(cfcRequests.cpf, pattern)),
              db.select().from(pcdRequests).where(like(pcdRequests.cpf, pattern))
            ]);
            return json2([...cnhRows2, ...cfcRows2, ...pcdRows2]);
          }
          const [cnhRows, cfcRows, pcdRows] = await Promise.all([
            db.select().from(cnhbrasilRequests),
            db.select().from(cfcRequests),
            db.select().from(pcdRequests)
          ]);
          return json2([...cnhRows, ...cfcRows, ...pcdRows]);
        }
        if (method === "POST") {
          const body = await parseBody(request);
          const modalityError = modalityValidationError(body);
          if (modalityError) return error(modalityError, 400);
          const filtered = filterFields(body);
          if (!filtered.modulo) filtered.modulo = deriveModulo(filtered);
          const safeFiltered = stripDroppedFields(filtered, filtered.modulo);
          const table = getRequestTable(safeFiltered.modulo);
          const newItem = await db.insert(table).values({
            id: safeFiltered.id || crypto.randomUUID(),
            ...safeFiltered,
            studentName: filtered.studentName || null,
            phone: filtered.phone || null,
            createdAt: filtered.createdAt ? new Date(filtered.createdAt) : /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          }).returning();
          const record = newItem[0];
          if (record?.modulo === "CNH_BRASIL") {
            await writeAuditLog(db, extractActor(request), "Foi cadastrado", "CNH_BRASIL_CANDIDATO", record.id, {
              cpf: record.cpf ?? null,
              name: record.studentName ?? null
            });
          }
          return json2(record ?? { id: body.id, ...body });
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const modalityError = modalityValidationError(body);
          if (modalityError) return error(modalityError, 400);
          if (!body?.id) return error("ID obrigat\xF3rio", 400);
          const { id, updatedAt, createdAt, ...rawUpdates } = body;
          const filtered = filterFields(rawUpdates);
          if (filtered.queueUpdatedAt && typeof filtered.queueUpdatedAt === "string") {
            filtered.queueUpdatedAt = new Date(filtered.queueUpdatedAt);
          }
          const found = await findRequestById(db, id);
          const role = data?.sessionUserRole;
          if (body.registerInterest) {
            const sessionUserId = data?.sessionUserId;
            const [sessionUser] = sessionUserId ? await db.select({ examinerId: users.examinerId }).from(users).where(eq(users.id, sessionUserId)).limit(1) : [];
            const [examiner] = sessionUser?.examinerId ? await db.select({ id: examiners.id, name: examiners.name }).from(examiners).where(eq(examiners.id, sessionUser.examinerId)).limit(1) : [];
            const invalid = interestError(found?.row, found?.modulo ?? "", role, examiner);
            if (invalid) return error(invalid.error, invalid.status);
            const rows = await db.update(cfcRequests).set({ ...interestPatch(found.row, examiner), updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(cfcRequests.id, id), eq(cfcRequests.status, "WAITING_SCHEDULING"))).returning();
            if (!rows.length) return error("O pedido mudou. Atualize a lista.", 409);
            return json2(rows[0]);
          }
          if (body.extraEdit) {
            const invalid = extraEditError(found?.row, found?.modulo ?? "", role, body);
            if (invalid) return error(invalid.error, invalid.status);
            const rows = await db.update(cfcRequests).set({ ...extraPatch(body), updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(cfcRequests.id, id), eq(cfcRequests.status, "WAITING_SCHEDULING"))).returning();
            if (!rows.length) return error("O pedido mudou. Atualize a lista.", 409);
            return json2(rows[0]);
          }
          const denied = confirmedAccessError(found?.row, found?.modulo ?? "", false, role, body);
          if (denied) return error(denied, body.confirmedEdit && !isConfirmedCfc(found?.row, found?.modulo ?? "") ? 409 : 403);
          if (body.confirmedEdit) {
            if (!canManageConfirmed(role)) return error("Acesso negado.", 403);
            const invalid = await validateConfirmedEdit(db, { examiners, systemSettings, blockedDates }, found.row, body);
            if (invalid) return error(invalid, 400);
            const rows = await db.update(cfcRequests).set({ ...confirmedPatch(body), updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(cfcRequests.id, id), eq(cfcRequests.status, "SCHEDULED"), eq(cfcRequests.attendanceConfirmed, true))).returning();
            if (!rows.length) return error("O agendamento mudou. Atualize a lista.", 409);
            return json2(rows[0]);
          }
          const isResultConfirmation = rawUpdates.result !== void 0 && Array.isArray(rawUpdates.examHistory);
          const isCurrentlyScheduled = found?.row?.status === "SCHEDULED";
          const isCnhBrasil = (found?.modulo ?? deriveModulo(rawUpdates)) === "CNH_BRASIL";
          if (data?.sessionUserRole === "SUPERVISOR" && !isCnhBrasil && (rawUpdates.scheduleId === null || isCurrentlyScheduled && rawUpdates.scheduleId !== void 0 && rawUpdates.scheduleId !== found?.row?.scheduleId || isCurrentlyScheduled && rawUpdates.status === "WAITING_SCHEDULING" && !isResultConfirmation)) {
            return error("Supervisores n\xE3o podem remover candidatos da banca.", 403);
          }
          const oldModulo = found?.modulo ?? deriveModulo(rawUpdates);
          const mergedExamType = rawUpdates.examType ?? found?.row?.examType;
          const mergedSchoolId = rawUpdates.schoolId ?? found?.row?.schoolId;
          const newModulo = filtered.modulo || deriveModulo({ examType: mergedExamType, schoolId: mergedSchoolId });
          if (data?.sessionUserRole === "SUPERVISOR" && isCurrentlyScheduled && newModulo !== found?.modulo) {
            return error("Supervisores n\xE3o podem mover candidatos agendados para outro m\xF3dulo.", 403);
          }
          const oldTable = getRequestTable(oldModulo);
          const newTable = getRequestTable(newModulo);
          let record;
          if (oldModulo !== newModulo) {
            const merged = stripDroppedFields(
              { ...found?.row, ...filtered, modulo: newModulo, updatedAt: /* @__PURE__ */ new Date() },
              newModulo
            );
            await db.batch([
              db.insert(newTable).values(merged),
              db.delete(oldTable).where(eq(oldTable.id, id))
            ]);
            record = merged;
          } else {
            const safeFiltered = stripDroppedFields({ ...filtered, updatedAt: /* @__PURE__ */ new Date() }, newModulo);
            const updated = await db.update(oldTable).set(safeFiltered).where(eq(oldTable.id, id)).returning();
            record = updated[0];
          }
          if ((record?.modulo ?? newModulo) === "CNH_BRASIL") {
            let action = "Foi modificado";
            if (body.scheduleId && body.status === "SCHEDULED") action = "Foi adicionado na Banca";
            else if (body.scheduleId === null && body.status === "WAITING_SCHEDULING") action = "Foi exclu\xEDdo da Banca";
            await writeAuditLog(db, extractActor(request), action, "CNH_BRASIL_CANDIDATO", id, {
              cpf: (record ?? found?.row)?.cpf ?? null,
              name: (record ?? found?.row)?.studentName ?? null
            });
          }
          return json2(record ?? { id, ...rawUpdates });
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          const found = await findRequestById(db, id);
          const role = data?.sessionUserRole;
          if (isConfirmedCfc(found?.row, found?.modulo ?? "") && !canManageConfirmed(role)) {
            return error("Somente administradores e supervisores podem excluir provas confirmadas.", 403);
          }
          if (query.confirmedDelete === "true") {
            if (!canManageConfirmed(role)) return error("Acesso negado.", 403);
            if (!isConfirmedCfc(found?.row, found?.modulo ?? "")) return error("O agendamento n\xE3o est\xE1 mais confirmado.", 409);
            const condition = and(eq(cfcRequests.id, id), eq(cfcRequests.status, "SCHEDULED"), eq(cfcRequests.attendanceConfirmed, true));
            const affected = hasCandidateIdentity(found.row) ? await db.update(cfcRequests).set({ ...clearAppointment, updatedAt: /* @__PURE__ */ new Date() }).where(condition).returning() : await db.delete(cfcRequests).where(condition).returning();
            if (!affected.length) return error("O agendamento mudou. Atualize a lista.", 409);
            return json2({ success: true });
          }
          if (data?.sessionUserRole === "SUPERVISOR") {
            return error("Supervisores n\xE3o podem excluir candidatos.", 403);
          }
          await db.delete(cnhbrasilRequests).where(eq(cnhbrasilRequests.id, id));
          await db.delete(cfcRequests).where(eq(cfcRequests.id, id));
          await db.delete(pcdRequests).where(eq(pcdRequests.id, id));
          if (found?.modulo === "CNH_BRASIL") {
            await writeAuditLog(db, extractActor(request), "Foi exclu\xEDdo", "CNH_BRASIL_CANDIDATO", id, {
              cpf: found.row?.cpf ?? null,
              name: found.row?.studentName ?? null
            });
          }
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        console.error("[requests] erro:", e);
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _school-schedule.ts
function businessDate(now = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(now);
  const part = /* @__PURE__ */ __name((type) => parts.find((p2) => p2.type === type).value, "part");
  return `${part("year")}-${part("month")}-${part("day")}`;
}
function isCalendarDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date2 = /* @__PURE__ */ new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(date2.getTime()) && date2.toISOString().slice(0, 10) === value;
}
function mainSchedulePaused(school, date2) {
  return !school.provisionalSchedule?.active && !!school.mainSchedule?.pausedDates?.includes(date2);
}
function schoolPauseValidation(body) {
  const dates = body?.mainSchedule?.pausedDates;
  if (dates === void 0) return null;
  if (!Array.isArray(dates) || dates.some((date2) => !isCalendarDate(date2)) || new Set(dates).size !== dates.length) {
    return "Informe datas v\xE1lidas e sem repeti\xE7\xE3o para pausar a Escala Principal.";
  }
  return null;
}
var init_school_schedule = __esm({
  "_school-schedule.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    __name(businessDate, "businessDate");
    __name(isCalendarDate, "isCalendarDate");
    __name(mainSchedulePaused, "mainSchedulePaused");
    __name(schoolPauseValidation, "schoolPauseValidation");
  }
});

// api/schedule-slots.ts
function getSlotTable(examType) {
  return examType === "PCD" ? pcdScheduleSlots : cfcScheduleSlots;
}
async function findSlotById(db, id) {
  const [cfcRows, pcdRows] = await Promise.all([
    db.select().from(cfcScheduleSlots).where(eq(cfcScheduleSlots.id, id)).limit(1),
    db.select().from(pcdScheduleSlots).where(eq(pcdScheduleSlots.id, id)).limit(1)
  ]);
  if (cfcRows.length > 0) return { row: cfcRows[0], module: "CFC" };
  if (pcdRows.length > 0) return { row: pcdRows[0], module: "PCD" };
  return null;
}
var onRequest12;
var init_schedule_slots = __esm({
  "api/schedule-slots.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_cfc_confirmed();
    init_cfc_extra();
    init_d1();
    init_school_schedule();
    __name(getSlotTable, "getSlotTable");
    __name(findSlotById, "findSlotById");
    onRequest12 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        await ensureSlotQuantities(db);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          let cfcQ = db.select().from(cfcScheduleSlots);
          let pcdQ = db.select().from(pcdScheduleSlots);
          if (query.schoolId) {
            cfcQ = cfcQ.where(eq(cfcScheduleSlots.schoolId, query.schoolId));
            pcdQ = pcdQ.where(eq(pcdScheduleSlots.schoolId, query.schoolId));
          }
          if (query.scheduledDate) {
            cfcQ = cfcQ.where(eq(cfcScheduleSlots.scheduledDate, query.scheduledDate));
            pcdQ = pcdQ.where(eq(pcdScheduleSlots.scheduledDate, query.scheduledDate));
          }
          const [cfcRows, pcdRows] = await Promise.all([cfcQ, pcdQ]);
          return json2([...cfcRows, ...pcdRows]);
        }
        if (method === "POST") {
          const body = await parseBody(request);
          if (body?.automaticFixed) {
            if (!["ADMIN", "SUPERVISOR", "OPERATOR"].includes(data?.sessionUserRole)) {
              return error("Acesso negado para gerar escalas.", 403);
            }
            const { schoolId, date: date2, slots } = body.automaticFixed;
            if (typeof schoolId !== "string" || !schoolId || !/^\d{4}-\d{2}-\d{2}$/.test(date2) || !Array.isArray(slots) || slots.length < 1 || slots.length > 20 || slots.some((s) => !s || typeof s.examinerId !== "string" || !s.examinerId || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(s.scheduledTime)) || new Set(slots.map((s) => s.scheduledTime)).size !== slots.length) {
              return error("Dados inv\xE1lidos para a escala fixa.", 400);
            }
            const school = (await db.select().from(drivingSchools).where(eq(drivingSchools.id, schoolId)).limit(1))[0];
            if (!school) return error("Autoescola n\xE3o encontrada.", 404);
            if (mainSchedulePaused(school, date2)) {
              return error("Escala Principal pausada nesta data. Consulte a data novamente.", 409);
            }
            const day = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SAB"][(/* @__PURE__ */ new Date(`${date2}T00:00:00`)).getDay()];
            if (school.provisionalSchedule?.active) {
              const provDates = (school.provisionalSchedule.specificDates ?? []).filter((d) => d.date === date2 && d.examiner && d.time);
              if (!provDates.length || provDates.length !== slots.length) {
                return error("A escala provis\xF3ria mudou. Consulte a data novamente.", 409);
              }
              const ordered = /* @__PURE__ */ __name((items) => [...items].sort().join("|"), "ordered");
              if (ordered(provDates.map((d) => `${d.examiner}:${d.time}`)) !== ordered(slots.map((s) => `${s.examinerId}:${s.scheduledTime}`))) {
                return error("A escala provis\xF3ria mudou. Consulte a data novamente.", 409);
              }
              const existing2 = await db.select().from(cfcScheduleSlots).where(and(
                eq(cfcScheduleSlots.schoolId, schoolId),
                eq(cfcScheduleSlots.scheduledDate, date2),
                eq(cfcScheduleSlots.requestType, "FIXA")
              ));
              if (existing2.some((s) => s.status !== "CANCELLED")) {
                return error("Esta autoescola j\xE1 possui uma escala fixa nesta data.", 409);
              }
              for (const examinerId of new Set(slots.map((s) => s.examinerId))) {
                const booked = await db.select().from(cfcScheduleSlots).where(and(
                  eq(cfcScheduleSlots.examinerId, examinerId),
                  eq(cfcScheduleSlots.scheduledDate, date2)
                ));
                const active = booked.filter((s) => s.status !== "CANCELLED");
                const assigned = slots.filter((s) => s.examinerId === examinerId);
                if (assigned.some((s) => active.some((b) => b.scheduledTime === s.scheduledTime))) {
                  return error("O examinador j\xE1 possui prova nesse hor\xE1rio.", 409);
                }
              }
              const records2 = slots.map((s, index) => ({
                id: `auto-fixed:${schoolId}:${date2}:${existing2.length}:${index}`,
                schoolId,
                scheduledDate: date2,
                scheduledTime: s.scheduledTime,
                examinerId: s.examinerId,
                examType: "COMMON",
                requestType: "FIXA",
                intendedCategory: "A,B",
                status: "SCHEDULED",
                attendanceConfirmed: true,
                observation: "",
                createdAt: /* @__PURE__ */ new Date(),
                updatedAt: /* @__PURE__ */ new Date()
              }));
              const created2 = isD1(db) ? (await db.batch(records2.map((record) => db.insert(cfcScheduleSlots).values(record).returning()))).flat() : await db.insert(cfcScheduleSlots).values(records2).returning();
              return json2(created2);
            }
            const schedule = school.mainSchedule?.active ? school.mainSchedule : null;
            const configured = schedule?.days?.includes(day) ? (schedule.slots ?? []).filter((s) => !s.day || s.day === day) : [];
            if (!configured.length || configured.length !== slots.length) {
              return error("A escala da autoescola mudou. Consulte a data novamente.", 409);
            }
            if (!school.examRotation) {
              const ordered = /* @__PURE__ */ __name((items) => [...items].sort().join("|"), "ordered");
              if (ordered(configured.map((s) => `${s.examiner}:${s.time}`)) !== ordered(slots.map((s) => `${s.examinerId}:${s.scheduledTime}`))) {
                return error("Rod\xEDzio de Provas desativado para a autoescola; use os hor\xE1rios e examinadores da escala fixa.", 409);
              }
            }
            const city = school.examRotation ? (await db.select().from(cities)).find((c) => c.name.trim() === school.city?.trim()) : null;
            if (school.examRotation && !city) {
              return error("Cidade da autoescola n\xE3o cadastrada para o rod\xEDzio.", 409);
            }
            const existing = await db.select().from(cfcScheduleSlots).where(and(
              eq(cfcScheduleSlots.schoolId, schoolId),
              eq(cfcScheduleSlots.scheduledDate, date2),
              eq(cfcScheduleSlots.requestType, "FIXA")
            ));
            if (existing.some((s) => s.status !== "CANCELLED")) {
              return error("Esta autoescola j\xE1 possui uma escala fixa nesta data.", 409);
            }
            for (const examinerId of new Set(slots.map((s) => s.examinerId))) {
              const [booked, examinerRows] = await Promise.all([
                db.select().from(cfcScheduleSlots).where(and(
                  eq(cfcScheduleSlots.examinerId, examinerId),
                  eq(cfcScheduleSlots.scheduledDate, date2)
                )),
                db.select().from(examiners).where(eq(examiners.id, examinerId)).limit(1)
              ]);
              const active = booked.filter((s) => s.status !== "CANCELLED");
              const assigned = slots.filter((s) => s.examinerId === examinerId);
              if (school.examRotation) {
                const examiner = examinerRows[0];
                const availability = examiner?.rotationAvailability;
                const times = availability?.examsPerDay === 2 ? [availability.defaultTime, availability.secondDefaultTime] : [availability?.defaultTime];
                if (!examiner?.examRotation || examiner.canExamCommon === false || !availability?.days?.includes(day) || !availability.cityIds?.includes(city.id) || ![1, 2].includes(availability.examsPerDay) || assigned.some((s) => !times.includes(s.scheduledTime))) {
                  return error("Rod\xEDzio de Provas desativado ou disponibilidade incompat\xEDvel para o examinador.", 409);
                }
              }
              const capacity = examinerRows[0]?.examRotation ? examinerRows[0].rotationAvailability?.examsPerDay : null;
              if (assigned.some((s) => active.some((b) => b.scheduledTime === s.scheduledTime)) || capacity && active.length + assigned.length > capacity) {
                return error("O examinador j\xE1 possui prova nesse hor\xE1rio ou atingiu a capacidade di\xE1ria.", 409);
              }
            }
            const records = slots.map((s, index) => ({
              id: `auto-fixed:${schoolId}:${date2}:${existing.length}:${index}`,
              schoolId,
              scheduledDate: date2,
              scheduledTime: s.scheduledTime,
              examinerId: s.examinerId,
              examType: "COMMON",
              requestType: "FIXA",
              intendedCategory: "A,B",
              status: "SCHEDULED",
              attendanceConfirmed: true,
              observation: "",
              createdAt: /* @__PURE__ */ new Date(),
              updatedAt: /* @__PURE__ */ new Date()
            }));
            const created = isD1(db) ? (await db.batch(records.map((record) => db.insert(cfcScheduleSlots).values(record).returning()))).flat() : await db.insert(cfcScheduleSlots).values(records).returning();
            return json2(created);
          }
          if ((body?.requestType || "FIXA") === "FIXA" && !["ADMIN", "SUPERVISOR", "OPERATOR"].includes(data?.sessionUserRole)) {
            return error("Acesso negado para criar escala fixa.", 403);
          }
          const table = getSlotTable(body.examType || "");
          const newItem = await db.insert(table).values({
            id: body.id || crypto.randomUUID(),
            schoolId: body.schoolId,
            examType: body.examType,
            requestType: body.requestType || "FIXA",
            intendedCategory: body.intendedCategory,
            scheduledDate: body.scheduledDate,
            scheduledTime: body.scheduledTime,
            examinerId: body.examinerId,
            scheduleId: body.scheduleId,
            scheduledCategory: body.scheduledCategory,
            status: body.status || "SCHEDULED",
            attendanceConfirmed: body.attendanceConfirmed ?? false,
            cancellationReason: body.cancellationReason,
            observation: body.observation,
            createdAt: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          }).returning();
          return json2(newItem[0]);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          if (!body?.id) return error("ID obrigat\xF3rio", 400);
          const { id, createdAt, ...updates } = body;
          const allowed = [
            "schoolId",
            "examType",
            "requestType",
            "intendedCategory",
            "scheduledDate",
            "scheduledTime",
            "examinerId",
            "scheduleId",
            "scheduledCategory",
            "status",
            "attendanceConfirmed",
            "cancellationReason",
            "observation"
          ];
          const filtered = {};
          for (const k of allowed) if (updates[k] !== void 0) filtered[k] = updates[k];
          const found = await findSlotById(db, id);
          const role = data?.sessionUserRole;
          if (body.extraEdit) {
            const invalid = extraEditError(found?.row, found?.module ?? "", role, body);
            if (invalid) return error(invalid.error, invalid.status);
            const rows = await db.update(cfcScheduleSlots).set({ ...extraPatch(body), updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(cfcScheduleSlots.id, id), eq(cfcScheduleSlots.status, "WAITING_SCHEDULING"))).returning();
            if (!rows.length) return error("O pedido mudou. Atualize a lista.", 409);
            return json2(rows[0]);
          }
          const denied = confirmedAccessError(found?.row, found?.module ?? "", true, role, body);
          if (denied) return error(denied, body.confirmedEdit && !isConfirmedCfc(found?.row, "", true) ? 409 : 403);
          if (body.confirmedEdit) {
            if (!canManageConfirmed(role)) return error("Acesso negado.", 403);
            const invalid = await validateConfirmedEdit(db, { examiners, systemSettings, blockedDates }, found.row, body);
            if (invalid) return error(invalid, 400);
            const table = found.module === "PCD" ? pcdScheduleSlots : cfcScheduleSlots;
            const rows = await db.update(table).set({ ...confirmedPatch(body), updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(table.id, id), eq(table.status, "SCHEDULED"), eq(table.attendanceConfirmed, true))).returning();
            if (!rows.length) return error("O agendamento mudou. Atualize a lista.", 409);
            return json2(rows[0]);
          }
          const oldModule = found?.module;
          const newExamType = filtered.examType ?? found?.row?.examType ?? "";
          const newModule = newExamType === "PCD" ? "PCD" : "CFC";
          const oldTable = oldModule === "PCD" ? pcdScheduleSlots : cfcScheduleSlots;
          const newTable = newModule === "PCD" ? pcdScheduleSlots : cfcScheduleSlots;
          let result;
          if (oldModule && oldModule !== newModule) {
            const merged = { ...found.row, ...filtered, updatedAt: /* @__PURE__ */ new Date() };
            await db.batch([
              db.insert(newTable).values(merged),
              db.delete(oldTable).where(eq(oldTable.id, id))
            ]);
            result = merged;
          } else {
            const updated = await db.update(oldTable).set({ ...filtered, updatedAt: /* @__PURE__ */ new Date() }).where(eq(oldTable.id, id)).returning();
            result = updated[0] ?? { id, ...updates };
          }
          return json2(result);
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          const found = await findSlotById(db, id);
          if (isConfirmedCfc(found?.row, found?.module ?? "", true) && !canManageConfirmed(data?.sessionUserRole)) {
            return error("Somente administradores e supervisores podem excluir provas confirmadas.", 403);
          }
          if (query.confirmedDelete === "true") {
            if (!canManageConfirmed(data?.sessionUserRole)) return error("Acesso negado.", 403);
            if (!isConfirmedCfc(found?.row, found?.module ?? "", true)) return error("O agendamento n\xE3o est\xE1 mais confirmado.", 409);
            const table = found.module === "PCD" ? pcdScheduleSlots : cfcScheduleSlots;
            const removed = await db.delete(table).where(and(
              eq(table.id, id),
              eq(table.status, "SCHEDULED"),
              eq(table.attendanceConfirmed, true)
            )).returning();
            if (!removed.length) return error("O agendamento mudou. Atualize a lista.", 409);
            return json2({ success: true });
          }
          await db.delete(cfcScheduleSlots).where(eq(cfcScheduleSlots.id, id));
          await db.delete(pcdScheduleSlots).where(eq(pcdScheduleSlots.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        if (String(e.message).includes("D1_EXAMINER_") || String(e.cause?.message).includes("D1_EXAMINER_")) {
          return error("O examinador j\xE1 possui prova nesse hor\xE1rio ou atingiu a capacidade di\xE1ria.", 409);
        }
        if (e.code === "23505" || e.cause?.code === "23505") {
          return error("A escala fixa j\xE1 foi gerada por outra pessoa. Atualize os agendamentos.", 409);
        }
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _cnh-time-conflicts.ts
function cnhBancaConflict(candidate, existing) {
  if (candidate.type !== "COMMON" || candidate.status === "CANCELLED") return null;
  const date2 = dateOnly(candidate.date);
  const time2 = timeOnly(candidate.time);
  if (!date2 || !time2) return null;
  const other = existing.find((item) => item.id !== candidate.id && item.type === "COMMON" && item.status !== "CANCELLED" && dateOnly(item.date) === date2 && timeOnly(item.time) === time2);
  return other ? `J\xE1 existe uma banca CNH do Brasil${other.code ? ` (${other.code})` : ""} em ${dateBR(date2)} \xE0s ${time2}. Escolha outra data ou hor\xE1rio, mesmo que o examinador seja diferente.` : null;
}
function mainEntries(schedule) {
  return (schedule?.slots || []).flatMap((slot) => (slot.day ? [slot.day].filter((day) => schedule?.days?.includes(day)) : schedule?.days || []).filter((day) => days.includes(day) && timeOnly(slot.time)).map((day) => ({ day, time: timeOnly(slot.time) })));
}
function provisionalEntries(schedule, today) {
  return (schedule?.specificDates || []).flatMap((entry) => {
    const date2 = dateOnly(entry.date);
    return isCalendarDate(date2) && date2 >= today && timeOnly(entry.time) ? [{ date: date2, time: timeOnly(entry.time), day: days[(/* @__PURE__ */ new Date(`${date2}T12:00:00Z`)).getUTCDay()] }] : [];
  });
}
function overlap(a2, b, aMain, bMain) {
  if (a2.time !== b.time || a2.day !== b.day) return false;
  if (a2.date && b.date) return a2.date === b.date;
  if (a2.date) return !bMain?.pausedDates?.includes(a2.date);
  if (b.date) return !aMain?.pausedDates?.includes(b.date);
  return true;
}
function when(entry) {
  return entry.date ? `${dateBR(entry.date)} \xE0s ${entry.time}` : `${entry.day} \xE0s ${entry.time}`;
}
function cnhSchoolScaleConflict(candidate, existing, today = businessDate()) {
  if (!candidate.cnhBrasilProfile) return null;
  const main = mainEntries(candidate.mainSchedule);
  const prov = provisionalEntries(candidate.provisionalSchedule, today);
  for (const [entries, label] of [[main, "Principal"], [prov, "Provis\xF3ria"]]) {
    const repeated = entries.find((entry, index) => entries.slice(0, index).some((other) => overlap(entry, other)));
    if (repeated) return `A Escala ${label} cont\xE9m hor\xE1rios repetidos: ${when(repeated)}. N\xE3o \xE9 permitido usar o mesmo dia e hor\xE1rio, mesmo com examinadores diferentes.`;
  }
  for (const other of existing) {
    if (!other.cnhBrasilProfile || other.id === candidate.id) continue;
    const otherMain = mainEntries(other.mainSchedule);
    const otherProv = provisionalEntries(other.provisionalSchedule, today);
    for (const [ownEntries, otherEntries, ownMain, comparedMain] of [
      [main, otherMain, candidate.mainSchedule, other.mainSchedule],
      [main, otherProv, candidate.mainSchedule, null],
      [prov, otherMain, null, other.mainSchedule],
      [prov, otherProv, null, null]
    ]) {
      const conflict = ownEntries.find((a2) => otherEntries.some((b) => overlap(a2, b, ownMain, comparedMain)));
      if (conflict) return `Conflito de hor\xE1rio com a autoescola "${other.name || "sem nome"}", com Perfil CNH do Brasil: ${when(conflict)}. Escolha outro dia ou hor\xE1rio, mesmo que o examinador seja diferente.`;
    }
  }
  return null;
}
var days, dateOnly, timeOnly, dateBR;
var init_cnh_time_conflicts = __esm({
  "_cnh-time-conflicts.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_school_schedule();
    days = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SAB"];
    dateOnly = /* @__PURE__ */ __name((date2) => date2?.split("T")[0] || "", "dateOnly");
    timeOnly = /* @__PURE__ */ __name((time2) => time2?.trim().slice(0, 5) || "", "timeOnly");
    dateBR = /* @__PURE__ */ __name((date2) => date2.split("-").reverse().join("/"), "dateBR");
    __name(cnhBancaConflict, "cnhBancaConflict");
    __name(mainEntries, "mainEntries");
    __name(provisionalEntries, "provisionalEntries");
    __name(overlap, "overlap");
    __name(when, "when");
    __name(cnhSchoolScaleConflict, "cnhSchoolScaleConflict");
  }
});

// api/schedules.ts
async function updateAllModuleTables(db, updates, whereScheduleId) {
  for (const t of [cnhbrasilRequests, cfcRequests, pcdRequests]) {
    await db.update(t).set(updates).where(eq(t.scheduleId, whereScheduleId));
  }
}
var calculateStatus, onRequest13;
var init_schedules = __esm({
  "api/schedules.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_cnh_time_conflicts();
    calculateStatus = /* @__PURE__ */ __name((dateStr, timeStr, currentStatus) => {
      if (currentStatus === "CANCELLED") return "CANCELLED";
      const cleanDate = dateStr.split("T")[0];
      const now = /* @__PURE__ */ new Date();
      const examDate = /* @__PURE__ */ new Date(`${cleanDate}T${timeStr}`);
      const msPerHr = 60 * 60 * 1e3;
      if (now > new Date(examDate.getTime() + 4 * msPerHr)) return "CONCLUDED";
      if (now > new Date(examDate.getTime() - 12 * msPerHr)) return "CLOSED";
      return "OPEN";
    }, "calculateStatus");
    __name(updateAllModuleTables, "updateAllModuleTables");
    onRequest13 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          const schedules = await db.select().from(examSchedules);
          const updates = [];
          for (const s of schedules) {
            const calc = calculateStatus(s.date, s.time, s.status);
            if (calc !== s.status) {
              if (calc === "CONCLUDED" && s.status !== "CONCLUDED") {
                for (const t of [cnhbrasilRequests, cfcRequests, pcdRequests]) {
                  await db.update(t).set({ status: "WAITING_RESULT", updatedAt: /* @__PURE__ */ new Date() }).where(and(eq(t.scheduleId, s.id), eq(t.status, "SCHEDULED")));
                }
              }
              updates.push(db.update(examSchedules).set({ status: calc }).where(eq(examSchedules.id, s.id)));
              s.status = calc;
            }
          }
          if (updates.length) await Promise.all(updates);
          return json2(schedules);
        }
        if (method === "POST") {
          const { sourceSchoolId, ...body } = await parseBody(request);
          if (body.type === "COMMON") {
            if (!["ADMIN", "SUPERVISOR"].includes(data?.sessionUserRole)) {
              return error("Acesso negado para criar bancas CNH do Brasil.", 403);
            }
            if (typeof sourceSchoolId !== "string" || !sourceSchoolId) {
              return error("Selecione uma autoescola com Perfil CNH do Brasil.", 400);
            }
            const school = (await db.select().from(drivingSchools).where(eq(drivingSchools.id, sourceSchoolId)).limit(1))[0];
            if (!school?.cnhBrasilProfile) {
              return error("A autoescola n\xE3o possui Perfil CNH do Brasil ativo.", 409);
            }
          }
          const cleanDate = body.date.split("T")[0];
          const conflict = cnhBancaConflict({ ...body, id: void 0 }, await db.select().from(examSchedules));
          if (conflict) return error(conflict, 409);
          const initialStatus = calculateStatus(cleanDate, body.time, "OPEN");
          const last = await db.select({ code: examSchedules.code }).from(examSchedules).where(isNotNull(examSchedules.code)).orderBy(desc(examSchedules.createdAt)).limit(1);
          let nextCode = "B1000";
          if (last.length > 0 && last[0].code) {
            const n = parseInt(last[0].code.replace("B", ""), 10);
            if (!isNaN(n)) nextCode = `B${n + 1}`;
          }
          const newItem = await db.insert(examSchedules).values({
            id: crypto.randomUUID(),
            code: nextCode,
            status: initialStatus,
            ...body,
            date: cleanDate
          }).returning();
          return json2(newItem[0]);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const { id, action, reason, createdAt, updatedAt, ...updates } = body;
          if (!id) return error("ID obrigat\xF3rio", 400);
          if (data?.sessionUserRole === "SUPERVISOR" && (action === "CANCEL" || updates.status === "CANCELLED")) {
            return error("Supervisores n\xE3o podem cancelar bancas.", 403);
          }
          if (action === "CANCEL") {
            const updated2 = await db.update(examSchedules).set({ status: "CANCELLED", cancellationReason: reason }).where(eq(examSchedules.id, id)).returning();
            const resetFields = {
              status: "WAITING_SCHEDULING",
              scheduleId: null,
              scheduledDate: null,
              scheduledTime: null,
              scheduledCategory: null,
              examinerId: null,
              attendanceConfirmed: false,
              queueUpdatedAt: null,
              updatedAt: /* @__PURE__ */ new Date()
            };
            await updateAllModuleTables(db, resetFields, id);
            try {
              await db.execute(sql`ALTER TABLE solicitacoes ADD COLUMN IF NOT EXISTS fila_atualizado_em timestamptz`);
            } catch {
            }
            await db.execute(sql`
          UPDATE solicitacoes
          SET
            status              = 'WAITING_SCHEDULING',
            banca_id            = NULL,
            data_agendada       = NULL,
            hora_agendada       = NULL,
            categoria_agendada  = NULL,
            examinador_id       = NULL,
            presenca_confirmada = FALSE,
            atualizado_em = COALESCE(fila_atualizado_em, atualizado_em),
            fila_atualizado_em  = NULL
          WHERE banca_id = ${id}
        `);
            return json2(updated2[0] ?? { id, status: "CANCELLED" });
          }
          if (updates.date) updates.date = updates.date.split("T")[0];
          const allowed = ["code", "date", "time", "examinerIds", "maxSlotsA", "maxSlotsB", "type", "status", "cancellationReason", "locationId"];
          const filtered = {};
          for (const k of allowed) if (updates[k] !== void 0) filtered[k] = updates[k];
          const existing = await db.select().from(examSchedules);
          const original = existing.find((schedule) => schedule.id === id);
          if (!original) return error("Banca n\xE3o encontrada.", 404);
          const conflict = cnhBancaConflict({ ...original, ...filtered, id }, existing);
          if (conflict) return error(conflict, 409);
          const updated = await db.update(examSchedules).set(filtered).where(eq(examSchedules.id, id)).returning();
          const current = updated[0] ?? { id, ...updates };
          const newStatus = calculateStatus(current.date, current.time, current.status);
          if (newStatus !== current.status) {
            await db.update(examSchedules).set({ status: newStatus }).where(eq(examSchedules.id, id));
            current.status = newStatus;
          }
          if (updates.date || updates.time) {
            const dateTimeUpdate = {};
            if (updates.date) dateTimeUpdate.scheduledDate = updates.date;
            if (updates.time) dateTimeUpdate.scheduledTime = updates.time;
            await updateAllModuleTables(db, dateTimeUpdate, id);
          }
          return json2(current);
        }
        if (method === "DELETE") {
          if (data?.sessionUserRole === "SUPERVISOR") {
            return error("Supervisores n\xE3o podem excluir bancas.", 403);
          }
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(examSchedules).where(eq(examSchedules.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// _school-yards.ts
function schoolYardsValidation(body) {
  if (body == null || body.yards === void 0) return null;
  const yards = body.yards;
  if (yards === null) return null;
  if (!Array.isArray(yards)) return "P\xE1tios inv\xE1lidos.";
  if (yards.length > 50) return "Limite de 50 p\xE1tios por autoescola.";
  const ids = /* @__PURE__ */ new Set();
  for (const y2 of yards) {
    if (!y2 || typeof y2 !== "object" || Array.isArray(y2)) return "P\xE1tio inv\xE1lido.";
    if (typeof y2.id !== "string" || !y2.id.trim()) return "P\xE1tio sem identificador.";
    if (ids.has(y2.id)) return "P\xE1tio duplicado.";
    ids.add(y2.id);
    if (!YARD_TYPES.includes(y2.type)) return "Selecione o tipo do p\xE1tio (Moto, Carro ou Mudan\xE7a).";
    if (typeof y2.address !== "string" || !y2.address.trim()) return "Informe o endere\xE7o do p\xE1tio.";
    if (y2.address.length > 300) return "Endere\xE7o do p\xE1tio muito longo.";
    if (y2.reference !== void 0 && y2.reference !== null && (typeof y2.reference !== "string" || y2.reference.length > 300)) return "Refer\xEAncia do p\xE1tio inv\xE1lida.";
  }
  return null;
}
var YARD_TYPES;
var init_school_yards = __esm({
  "_school-yards.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    YARD_TYPES = ["MOTO", "CARRO", "MUDANCA"];
    __name(schoolYardsValidation, "schoolYardsValidation");
  }
});

// api/schools.ts
async function ensureSchema4(db) {
  try {
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS email text`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS cidade text`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS servicos jsonb DEFAULT '[]'::jsonb`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_moto text`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_carro text`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS endereco_patio_mudanca text`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS banca_principal jsonb`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS banca_provisoria jsonb`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS nao_criar_usuario boolean NOT NULL DEFAULT false`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS rodizio_provas boolean NOT NULL DEFAULT false`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS perfil_cnh_brasil boolean NOT NULL DEFAULT false`);
    await db.execute(sql`ALTER TABLE autoescolas ADD COLUMN IF NOT EXISTS patios jsonb DEFAULT '[]'::jsonb`);
  } catch (e) {
    throw new Error("N\xE3o foi poss\xEDvel preparar o cadastro de autoescolas.", { cause: e });
  }
}
var onRequest14;
var init_schools = __esm({
  "api/schools.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_school_schedule();
    init_cnh_time_conflicts();
    init_school_yards();
    __name(ensureSchema4, "ensureSchema");
    onRequest14 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          await ensureSchema4(db);
          return json2(await db.select().from(drivingSchools));
        }
        if (method === "POST") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          await ensureSchema4(db);
          const body = await parseBody(request);
          const invalid = schoolPauseValidation(body);
          if (invalid) return error(invalid, 400);
          const invalidYards = schoolYardsValidation(body);
          if (invalidYards) return error(invalidYards, 400);
          const conflict = cnhSchoolScaleConflict({ ...body, id: void 0 }, await db.select().from(drivingSchools));
          if (conflict) return error(conflict, 409);
          const newItem = await db.insert(drivingSchools).values({ id: crypto.randomUUID(), ...body }).returning();
          return json2(newItem[0]);
        }
        if (method === "PUT") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          await ensureSchema4(db);
          const body = await parseBody(request);
          const invalid = schoolPauseValidation(body);
          if (invalid) return error(invalid, 400);
          const invalidYards = schoolYardsValidation(body);
          if (invalidYards) return error(invalidYards, 400);
          const { id, createdAt, ...updates } = body;
          const existing = await db.select().from(drivingSchools);
          const current = existing.find((school) => school.id === id);
          if (!current) return error("Autoescola n\xE3o encontrada.", 404);
          const conflict = cnhSchoolScaleConflict({ ...current, ...updates, id }, existing);
          if (conflict) return error(conflict, 409);
          const updated = await db.update(drivingSchools).set(updates).where(eq(drivingSchools.id, id)).returning();
          return json2(updated[0]);
        }
        if (method === "DELETE") {
          if (data?.sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores", 403);
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(drivingSchools).where(eq(drivingSchools.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/settings.ts
var DEFAULT_AGENCY, DEFAULT_ADDR, getDefaultTemplate, getCfcTemplate, DEFAULTS, onRequest15;
var init_settings = __esm({
  "api/settings.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_cpf_lookup();
    DEFAULT_AGENCY = "Detran de Balne\xE1rio Cambori\xFA";
    DEFAULT_ADDR = "Av. do Estado Dalmo Vieira, 4281 - Centro, Balne\xE1rio Cambori\xFA - SC";
    getDefaultTemplate = /* @__PURE__ */ __name(() => `Ol\xE1, *{CANDIDATO}*! [WAVE][SMILE]

Aqui \xE9 do {AGENCIA} \u2013 Setor CNH.
Estamos confirmando sua presen\xE7a na Prova Pr\xE1tica *(Categoria {CATEGORIA})* [CAR], marcada para:

[CALENDAR] *{DATA}*
[CLOCK] *{HORA}*
[MAP] *{ENDERECO}*

[WARNING] N\xE3o esque\xE7a:
[ID] _*Documento com foto (v\xE1lido)*_
[CAR_FRONT] _*Ve\xEDculo ou moto em condi\xE7\xF5es para a prova*_

[CHECK] *Posso confirmar sua presen\xE7a?*

[HOURGLASS] _*Confirma\xE7\xE3o at\xE9 amanh\xE3 \xE0s 18:00*_`, "getDefaultTemplate");
    getCfcTemplate = /* @__PURE__ */ __name(() => `Ol\xE1, *{AUTOESCOLA}*! [WAVE][SMILE]

Aqui \xE9 do {AGENCIA} \u2013 Setor Prova Pr\xE1tica CFC.
Estamos confirmando o agendamento da Prova Pr\xE1tica (Tipo: *{TIPO}*), marcada para:

[CALENDAR] *{DATA}*
[CLOCK] *{HORARIO}*
[EXAM] Exame: *{EXAME}*
[USER] Examinador: *{EXAMINADOR}*

[CHECK] *Por favor, confirme o recebimento.*`, "getCfcTemplate");
    DEFAULTS = {
      agencyName: DEFAULT_AGENCY,
      agencyAddress: DEFAULT_ADDR,
      maintenanceMode: false,
      maxDailySlots: 50,
      defaultMaxSlotsA: 10,
      defaultMaxSlotsB: 10,
      defaultMaxSlotsMudanca: 10,
      minDaysForScheduling: 2,
      whatsappMessageTemplate: getDefaultTemplate(),
      cfcWhatsappMessageTemplate: getCfcTemplate(),
      defaultExamAddress: DEFAULT_ADDR,
      defaultExamAddressLink: "https://maps.google.com",
      pcdExamName: "PROVA DIRECAO PCD",
      pcdDefaultExamAddress: DEFAULT_ADDR,
      pcdDefaultExamAddressLink: "https://maps.google.com",
      pcdMainSchedule: { frequency: "1_WEEK", days: [], slots: [], active: false },
      cnhBrasilMainSchedule: { frequency: "1_WEEK", days: [], slots: [], active: false },
      anoFabricacaoMaximo: { A: null, B: null, CDE: null },
      cnhCpfAutofillEnabled: false
    };
    onRequest15 = /* @__PURE__ */ __name(async ({ request, env, data }) => {
      try {
        const db = getDb(env);
        const method = request.method;
        if (method === "GET") {
          const data2 = await db.select().from(systemSettings).where(eq(systemSettings.id, 1));
          if (data2.length === 0) return json2(DEFAULTS);
          const s = data2[0];
          if (!s.cfcWhatsappMessageTemplate) s.cfcWhatsappMessageTemplate = getCfcTemplate();
          if (!s.pcdExamName || ["Prova Pr\xE1tica PCD", "PROVA DIRECTAO PCD", "PROVA DIRE\xC7\xC3O PCD", "Prova Dire\xE7\xE3o PCD"].includes(s.pcdExamName)) s.pcdExamName = "PROVA DIRECAO PCD";
          if (!s.pcdDefaultExamAddress) s.pcdDefaultExamAddress = s.defaultExamAddress;
          if (!s.pcdDefaultExamAddressLink) s.pcdDefaultExamAddressLink = s.defaultExamAddressLink;
          if (!s.pcdMainSchedule) s.pcdMainSchedule = DEFAULTS.pcdMainSchedule;
          if (!s.cnhBrasilMainSchedule) s.cnhBrasilMainSchedule = DEFAULTS.cnhBrasilMainSchedule;
          if (s.defaultMaxSlotsA == null) s.defaultMaxSlotsA = 10;
          if (s.defaultMaxSlotsB == null) s.defaultMaxSlotsB = 10;
          if (s.defaultMaxSlotsMudanca == null) s.defaultMaxSlotsMudanca = 10;
          if (!s.anoFabricacaoMaximo) s.anoFabricacaoMaximo = DEFAULTS.anoFabricacaoMaximo;
          return json2(s);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const invalid = cpfSettingError(body, data.sessionUserRole);
          if (invalid) return error(invalid, data.sessionUserRole !== "ADMIN" ? 403 : 400);
          const { enableEmailNotifications, enableSmsNotifications, createdAt, updatedAt, ...valid } = body;
          const existing = await db.select().from(systemSettings).where(eq(systemSettings.id, 1));
          let result;
          if (existing.length === 0) result = await db.insert(systemSettings).values({ id: 1, ...valid }).returning();
          else result = await db.update(systemSettings).set(valid).where(eq(systemSettings.id, 1)).returning();
          return json2(result[0]);
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/users.ts
async function ensureSchema5(db) {
  try {
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS senha text`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS autoescola_id text`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS examinador_id text`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS instrutor_id text`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS forcar_troca_senha boolean DEFAULT true`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS modulos_permitidos jsonb DEFAULT '[]'::jsonb`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS locais_permitidos_ids jsonb DEFAULT '[]'::jsonb`);
    await db.execute(sql`ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS abas_cadastro_permitidas jsonb DEFAULT '[]'::jsonb`);
  } catch {
  }
}
var onRequest16;
var init_users = __esm({
  "api/users.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_schema2();
    init_drizzle_orm();
    init_password();
    __name(ensureSchema5, "ensureSchema");
    onRequest16 = /* @__PURE__ */ __name(async (context) => {
      const { request, env, data } = context;
      const sessionUserRole = data?.sessionUserRole ?? "";
      try {
        const db = getDb(env);
        const method = request.method;
        const query = getQuery(request.url);
        if (method === "GET") {
          if (sessionUserRole !== "ADMIN") {
            return error("Acesso negado \u2014 apenas administradores", 403);
          }
          await ensureSchema5(db);
          const userData = await db.select().from(users);
          return json2(userData.map(({ password, ...rest }) => rest));
        }
        if (!["POST", "PUT", "DELETE"].includes(method)) return error("Method Not Allowed", 405);
        if (sessionUserRole !== "ADMIN") return error("Acesso negado \u2014 apenas administradores podem gerenciar usu\xE1rios", 403);
        if (method === "POST") {
          await ensureSchema5(db);
          const body = await parseBody(request);
          if (body.twoFactorEnabled && !body.email) {
            return error("Verifica\xE7\xE3o em 2 etapas requer e-mail cadastrado.", 400);
          }
          const hashedDefault = await hashPassword("123456");
          const newItem = await db.insert(users).values({ id: crypto.randomUUID(), password: hashedDefault, ...body }).returning();
          const { password, ...safe } = newItem[0];
          return json2(safe);
        }
        if (method === "PUT") {
          const body = await parseBody(request);
          const { id, createdAt, updatedAt, ...updates } = body;
          if (!id) return error("ID obrigat\xF3rio", 400);
          if (updates.twoFactorEnabled && !updates.email) {
            const existing = await db.select().from(users).where(eq(users.id, id));
            const existingEmail = existing[0]?.email;
            if (!existingEmail && !updates.email) {
              return error("Verifica\xE7\xE3o em 2 etapas requer e-mail cadastrado.", 400);
            }
          }
          if (updates.password && !updates.password.startsWith("$2b$") && !updates.password.startsWith("$2a$")) {
            updates.password = await hashPassword(updates.password);
          }
          const updated = await db.update(users).set(updates).where(eq(users.id, id)).returning();
          if (!updated.length) return error("Usu\xE1rio n\xE3o encontrado", 404);
          const { password, ...safe } = updated[0];
          return json2(safe);
        }
        if (method === "DELETE") {
          const id = query.id;
          if (!id) return error("ID obrigat\xF3rio", 400);
          await db.delete(users).where(eq(users.id, id));
          return json2({ success: true });
        }
        return error("Method Not Allowed", 405);
      } catch (e) {
        return error(e.message ?? "Erro interno", 500);
      }
    }, "onRequest");
  }
});

// api/_middleware.ts
var PUBLIC_PATHS, onRequest17;
var init_middleware = __esm({
  "api/_middleware.ts"() {
    "use strict";
    init_functionsRoutes_0_17677553668797852();
    init_db2();
    init_drizzle_orm();
    PUBLIC_PATHS = [
      "/api/auth",
      "/api/verify-otp",
      "/api/setup",
      "/api/health",
      "/api/test",
      "/api/session"
    ];
    onRequest17 = /* @__PURE__ */ __name(async (context) => {
      const { request, env, next, data } = context;
      const url = new URL(request.url);
      if (PUBLIC_PATHS.some((p2) => url.pathname === p2)) {
        return next();
      }
      const authHeader = request.headers.get("Authorization");
      const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7).trim() : null;
      if (!token) {
        return error("N\xE3o autenticado. Fa\xE7a login novamente.", 401);
      }
      try {
        const db = getDb(env);
        await ensurePortugueseSchema(db);
        await ensureColumnMigrations(db);
        await ensureCnhBrasilSdcStorage(db);
        await db.execute(sql`CREATE TABLE IF NOT EXISTS sessoes (id text PRIMARY KEY, usuario_id text NOT NULL, expira_em timestamp NOT NULL, criado_em timestamp DEFAULT now())`).catch(() => {
        });
        const rows = await db.execute(sql`
      SELECT u.id, u.perfil AS role
      FROM sessoes s
      JOIN usuarios u ON u.id = s.usuario_id
      WHERE s.id = ${token} AND s.expira_em > NOW()
      LIMIT 1
    `);
        const rowData = rows.rows ?? rows;
        if (!rowData || rowData.length === 0) {
          return error("Sess\xE3o expirada ou inv\xE1lida. Fa\xE7a login novamente.", 401);
        }
        data.sessionUserId = rowData[0].id;
        data.sessionUserRole = rowData[0].role;
        return next();
      } catch (e) {
        return error("Erro ao verificar sess\xE3o: " + e.message, 500);
      }
    }, "onRequest");
  }
});

// ../.wrangler/tmp/pages-0xz26m/functionsRoutes-0.17677553668797852.mjs
var routes;
var init_functionsRoutes_0_17677553668797852 = __esm({
  "../.wrangler/tmp/pages-0xz26m/functionsRoutes-0.17677553668797852.mjs"() {
    "use strict";
    init_change_own_password();
    init_auth();
    init_events();
    init_health();
    init_risk_area();
    init_session3();
    init_session3();
    init_setup();
    init_vehicle_lookup();
    init_verify_otp();
    init_backups();
    init_banca_results();
    init_blocked_dates();
    init_cities();
    init_cnh_logs();
    init_cpf_lookup2();
    init_exam_locations();
    init_examiners();
    init_instructors();
    init_requests();
    init_schedule_slots();
    init_schedules();
    init_schools();
    init_settings();
    init_users();
    init_middleware();
    routes = [
      {
        routePath: "/api/users/change-own-password",
        mountPath: "/api/users",
        method: "",
        middlewares: [],
        modules: [onRequest]
      },
      {
        routePath: "/api/auth",
        mountPath: "/api",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost]
      },
      {
        routePath: "/api/events",
        mountPath: "/api",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet]
      },
      {
        routePath: "/api/health",
        mountPath: "/api",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet2]
      },
      {
        routePath: "/api/risk-area",
        mountPath: "/api",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost2]
      },
      {
        routePath: "/api/session",
        mountPath: "/api",
        method: "DELETE",
        middlewares: [],
        modules: [onRequestDelete]
      },
      {
        routePath: "/api/session",
        mountPath: "/api",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet3]
      },
      {
        routePath: "/api/setup",
        mountPath: "/api",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost3]
      },
      {
        routePath: "/api/vehicle-lookup",
        mountPath: "/api",
        method: "GET",
        middlewares: [],
        modules: [onRequestGet4]
      },
      {
        routePath: "/api/verify-otp",
        mountPath: "/api",
        method: "POST",
        middlewares: [],
        modules: [onRequestPost4]
      },
      {
        routePath: "/api/backups",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest2]
      },
      {
        routePath: "/api/banca-results",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest3]
      },
      {
        routePath: "/api/blocked-dates",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest4]
      },
      {
        routePath: "/api/cities",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest5]
      },
      {
        routePath: "/api/cnh-logs",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest6]
      },
      {
        routePath: "/api/cpf-lookup",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest7]
      },
      {
        routePath: "/api/exam-locations",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest8]
      },
      {
        routePath: "/api/examiners",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest9]
      },
      {
        routePath: "/api/instructors",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest10]
      },
      {
        routePath: "/api/requests",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest11]
      },
      {
        routePath: "/api/schedule-slots",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest12]
      },
      {
        routePath: "/api/schedules",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest13]
      },
      {
        routePath: "/api/schools",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest14]
      },
      {
        routePath: "/api/settings",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest15]
      },
      {
        routePath: "/api/users",
        mountPath: "/api",
        method: "",
        middlewares: [],
        modules: [onRequest16]
      },
      {
        routePath: "/api",
        mountPath: "/api",
        method: "",
        middlewares: [onRequest17],
        modules: []
      }
    ];
  }
});

// ../node_modules/.pnpm/wrangler@4.149.0_@cloudflare+workers-types@4.20260701.1/node_modules/wrangler/templates/pages-template-worker.ts
init_functionsRoutes_0_17677553668797852();

// ../node_modules/.pnpm/path-to-regexp@6.3.0/node_modules/path-to-regexp/dist.es2015/index.js
init_functionsRoutes_0_17677553668797852();
function lexer(str) {
  var tokens2 = [];
  var i = 0;
  while (i < str.length) {
    var char2 = str[i];
    if (char2 === "*" || char2 === "+" || char2 === "?") {
      tokens2.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char2 === "\\") {
      tokens2.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char2 === "{") {
      tokens2.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char2 === "}") {
      tokens2.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char2 === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens2.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char2 === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens2.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens2.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens2.push({ type: "END", index: i, value: "" });
  return tokens2;
}
__name(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens2 = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name(function(type) {
    if (i < tokens2.length && tokens2[i].type === type)
      return tokens2[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens2[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char3 = delimiter_1[_i];
      if (value2.indexOf(char3) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens2.length) {
    var char2 = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char2 || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char2 || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x2) {
    return x2;
  } : _a;
  return function(pathname) {
    var m2 = re.exec(pathname);
    if (!m2)
      return false;
    var path = m2[0], index = m2.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name(function(i2) {
      if (m2[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m2[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m2[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m2.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens2, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x2) {
    return x2;
  } : _d, _e2 = options.delimiter, delimiter = _e2 === void 0 ? "/#?" : _e2, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens2; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens2[tokens2.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");

// ../node_modules/.pnpm/wrangler@4.149.0_@cloudflare+workers-types@4.20260701.1/node_modules/wrangler/templates/pages-template-worker.ts
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult) {
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: mountMatchResult.path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error2) {
      if (isFailOpen) {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error2;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");
export {
  pages_template_worker_default as default
};
/*! Bundled license information:

@neondatabase/serverless/index.mjs:
  (*! Bundled license information:
  
  ieee754/index.js:
    (*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> *)
  
  buffer/index.js:
    (*!
     * The buffer module from node.js, for the browser.
     *
     * @author   Feross Aboukhadijeh <https://feross.org>
     * @license  MIT
     *)
  *)
*/
