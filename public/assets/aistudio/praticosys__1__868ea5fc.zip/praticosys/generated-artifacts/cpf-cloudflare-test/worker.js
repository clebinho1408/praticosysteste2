// functions/_cpf-lookup.ts
var normalizeCpf = (value) => value.replace(/\D/g, "");
function validCpf(value) {
  const cpf = normalizeCpf(value);
  if (!/^\d{11}$/.test(cpf) || /^(\d)\1{10}$/.test(cpf)) return false;
  for (let size = 9; size <= 10; size++) {
    let sum = 0;
    for (let i = 0; i < size; i++) sum += Number(cpf[i]) * (size + 1 - i);
    const digit = sum * 10 % 11 % 10;
    if (digit !== Number(cpf[size])) return false;
  }
  return true;
}
function canLookupCpf(user) {
  if (!user || !["ADMIN", "SUPERVISOR", "OPERATOR", "INSTRUCTOR"].includes(user.role)) return false;
  if (["OPERATOR", "SUPERVISOR"].includes(user.role) && Array.isArray(user.allowedModules) && user.allowedModules.length && !user.allowedModules.includes("cnh")) return false;
  return true;
}
var messages = {
  400: "CPF inv\xE1lido para consulta.",
  404: "CPF n\xE3o encontrado.",
  402: "Servi\xE7o de consulta sem cr\xE9ditos.",
  401: "Chave do servi\xE7o de CPF inv\xE1lida ou ausente.",
  403: "Chave do servi\xE7o de CPF expirada ou sem autoriza\xE7\xE3o.",
  429: "Limite de consultas atingido. Aguarde antes de tentar novamente."
};
var fail = (status, message) => ({
  status,
  body: { error: `${message} Preencha o nome manualmente.` }
});
async function lookupCpf(options) {
  if (!options.user) return fail(401, "Fa\xE7a login novamente.");
  if (!canLookupCpf(options.user) || options.body?.module !== "CNH_BRASIL") return fail(403, "Consulta n\xE3o autorizada neste m\xF3dulo.");
  if (!options.enabled) return fail(409, "Autopreenchimento desativado.");
  if (typeof options.body?.cpf !== "string" || !validCpf(options.body.cpf)) return fail(400, messages[400]);
  if (!options.key) return fail(503, "Servi\xE7o de CPF n\xE3o configurado no servidor.");
  if (!await options.consumeQuota()) return fail(429, messages[429]);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs ?? 8e3);
  try {
    const url = new URL("https://apicpf.com/api/consulta");
    url.searchParams.set("cpf", normalizeCpf(options.body.cpf));
    const response = await (options.fetcher ?? fetch)(url, {
      headers: { "X-API-KEY": options.key, Accept: "application/json" },
      // Workers only implement follow/manual, not redirect:"error".
      // Never follow redirects carrying the API key or CPF to another origin.
      signal: controller.signal,
      redirect: "manual",
      cache: "no-store"
    });
    if (response.status >= 300 && response.status < 400) {
      return fail(503, "O servi\xE7o de CPF retornou um redirecionamento inesperado.");
    }
    const payload = await response.json().catch(() => null);
    const code = response.ok ? Number(payload?.code ?? response.status) : response.status;
    if (code !== 200) return fail(
      [400, 404, 429].includes(code) ? code : 503,
      messages[code] ?? "Servi\xE7o de CPF indispon\xEDvel."
    );
    const name = payload?.data?.nome;
    if (typeof name !== "string" || !name.trim() || name.length > 300) return fail(503, "Resposta inv\xE1lida do servi\xE7o de CPF.");
    return { status: 200, body: { name: name.trim() } };
  } catch {
    return fail(503, controller.signal.aborted ? "Consulta de CPF demorou demais." : "N\xE3o foi poss\xEDvel conectar ao servi\xE7o de CPF.");
  } finally {
    clearTimeout(timer);
  }
}

// scripts/src/fixtures/cpf-cache-worker.ts
var cpf_cache_worker_default = {
  async fetch(request) {
    let runtimeError;
    const result = await lookupCpf({
      body: { cpf: "12345678909", module: "CNH_BRASIL" },
      user: { id: "synthetic-user", role: "ADMIN" },
      enabled: true,
      key: "synthetic-key-not-a-credential",
      consumeQuota: async () => true,
      fetcher: async (url, options) => {
        const init = new URL(request.url).searchParams.has("legacyRedirect") ? { ...options, redirect: "error" } : options;
        try {
          return await fetch(url, init);
        } catch (e) {
          runtimeError = e instanceof Error ? e.message : "unknown";
          throw e;
        }
      }
    });
    return Response.json({ ...result.body, ...runtimeError ? { runtimeError } : {} }, { status: result.status });
  }
};
export {
  cpf_cache_worker_default as default
};
