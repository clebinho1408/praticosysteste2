CREATE TABLE IF NOT EXISTS "logs_auditoria" ("id" TEXT PRIMARY KEY NOT NULL, "usuario_id" TEXT, "nome_usuario" TEXT, "perfil_usuario" TEXT, "acao" TEXT NOT NULL, "entidade" TEXT NOT NULL, "entidade_id" TEXT, "detalhes" TEXT CHECK ("detalhes" IS NULL OR json_valid("detalhes")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "resultados_banca" ("id" TEXT PRIMARY KEY NOT NULL, "banca_id" TEXT NOT NULL, "autoescola_id" TEXT NOT NULL, "categoria" TEXT NOT NULL, "total_vagas" INTEGER DEFAULT 0, "vagas_usadas" INTEGER DEFAULT 0, "aprovados" INTEGER DEFAULT 0, "reprovados" INTEGER DEFAULT 0, "ausentes" INTEGER DEFAULT 0, "cancelados" INTEGER DEFAULT 0, "modulo" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "datas_bloqueadas" ("id" TEXT PRIMARY KEY NOT NULL, "data" TEXT NOT NULL, "descricao" TEXT, "feriado" INTEGER DEFAULT 0 CHECK ("feriado" IS NULL OR "feriado" IN (0, 1)), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "solicitacoes_cfc" ("id" TEXT PRIMARY KEY NOT NULL, "nome_candidato" TEXT, "nome_social" TEXT, "cpf" TEXT, "telefone" TEXT, "email" TEXT, "endereco" TEXT, "cidade" TEXT, "tipo_solicitacao" TEXT DEFAULT 'EXTRA', "tipo_exame" TEXT NOT NULL, "categoria_pretendida" TEXT DEFAULT 'B', "origem" TEXT NOT NULL, "autoescola_id" TEXT, "taxa_paga_bool" INTEGER DEFAULT 0 CHECK ("taxa_paga_bool" IS NULL OR "taxa_paga_bool" IN (0, 1)), "curso_pratico_concluido" INTEGER DEFAULT 0 CHECK ("curso_pratico_concluido" IS NULL OR "curso_pratico_concluido" IN (0, 1)), "horas_praticas" INTEGER DEFAULT 0, "tem_veiculo" INTEGER DEFAULT 0 CHECK ("tem_veiculo" IS NULL OR "tem_veiculo" IN (0, 1)), "restricao_cnh" TEXT, "instrutor" TEXT, "placa_veiculo" TEXT, "sem_duplo_comando" INTEGER DEFAULT 0 CHECK ("sem_duplo_comando" IS NULL OR "sem_duplo_comando" IN (0, 1)), "checklist_veiculo" INTEGER DEFAULT 0 CHECK ("checklist_veiculo" IS NULL OR "checklist_veiculo" IN (0, 1)), "curso_pratico_inserido" INTEGER DEFAULT 0 CHECK ("curso_pratico_inserido" IS NULL OR "curso_pratico_inserido" IN (0, 1)), "taxa_paga" INTEGER DEFAULT 0 CHECK ("taxa_paga" IS NULL OR "taxa_paga" IN (0, 1)), "status" TEXT NOT NULL, "resultado" TEXT, "banca_id" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "categoria_agendada" TEXT, "examinador_id" TEXT, "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "quantidades_categoria" TEXT CHECK ("quantidades_categoria" IS NULL OR json_valid("quantidades_categoria")), "historico_exames" TEXT DEFAULT '[]' CHECK ("historico_exames" IS NULL OR json_valid("historico_exames")), "modulo" TEXT, "cor_linha" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "fila_atualizado_em" TEXT, "agendado_por" TEXT, "cpf_hash" TEXT);

CREATE TABLE IF NOT EXISTS "vagas_cfc" ("id" TEXT PRIMARY KEY NOT NULL, "autoescola_id" TEXT NOT NULL, "tipo_exame" TEXT NOT NULL, "tipo_solicitacao" TEXT NOT NULL, "categoria_pretendida" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "examinador_id" TEXT, "banca_id" TEXT, "categoria_agendada" TEXT, "status" TEXT NOT NULL DEFAULT 'SCHEDULED', "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "quantidades_categoria" TEXT CHECK ("quantidades_categoria" IS NULL OR json_valid("quantidades_categoria")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "cidades" ("id" TEXT PRIMARY KEY NOT NULL, "nome" TEXT NOT NULL UNIQUE, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "solicitacoes_cnhbrasil" ("id" TEXT PRIMARY KEY NOT NULL, "nome_candidato" TEXT, "nome_social" TEXT, "cpf" TEXT, "telefone" TEXT, "email" TEXT, "endereco" TEXT, "cidade" TEXT, "tipo_solicitacao" TEXT DEFAULT 'EXTRA', "tipo_exame" TEXT NOT NULL, "categoria_pretendida" TEXT DEFAULT 'B', "origem" TEXT NOT NULL, "autoescola_id" TEXT, "taxa_paga_bool" INTEGER DEFAULT 0 CHECK ("taxa_paga_bool" IS NULL OR "taxa_paga_bool" IN (0, 1)), "curso_pratico_concluido" INTEGER DEFAULT 0 CHECK ("curso_pratico_concluido" IS NULL OR "curso_pratico_concluido" IN (0, 1)), "horas_praticas" INTEGER DEFAULT 0, "tem_veiculo" INTEGER DEFAULT 0 CHECK ("tem_veiculo" IS NULL OR "tem_veiculo" IN (0, 1)), "restricao_cnh" TEXT, "instrutor" TEXT, "placa_veiculo" TEXT, "sem_duplo_comando" INTEGER DEFAULT 0 CHECK ("sem_duplo_comando" IS NULL OR "sem_duplo_comando" IN (0, 1)), "checklist_veiculo" INTEGER DEFAULT 0 CHECK ("checklist_veiculo" IS NULL OR "checklist_veiculo" IN (0, 1)), "curso_pratico_inserido" INTEGER DEFAULT 0 CHECK ("curso_pratico_inserido" IS NULL OR "curso_pratico_inserido" IN (0, 1)), "taxa_paga" INTEGER DEFAULT 0 CHECK ("taxa_paga" IS NULL OR "taxa_paga" IN (0, 1)), "status" TEXT NOT NULL, "resultado" TEXT, "banca_id" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "categoria_agendada" TEXT, "examinador_id" TEXT, "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "historico_exames" TEXT DEFAULT '[]' CHECK ("historico_exames" IS NULL OR json_valid("historico_exames")), "modulo" TEXT, "cor_linha" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "fila_atualizado_em" TEXT, "agendado_por" TEXT, "cpf_hash" TEXT);

CREATE TABLE IF NOT EXISTS "autoescolas" ("id" TEXT PRIMARY KEY NOT NULL, "nome" TEXT NOT NULL, "telefone" TEXT, "email" TEXT, "endereco" TEXT, "cidade" TEXT, "servicos" TEXT DEFAULT '[]' CHECK ("servicos" IS NULL OR json_valid("servicos")), "nao_criar_usuario" INTEGER NOT NULL DEFAULT 0 CHECK ("nao_criar_usuario" IS NULL OR "nao_criar_usuario" IN (0, 1)), "rodizio_provas" INTEGER NOT NULL DEFAULT 0 CHECK ("rodizio_provas" IS NULL OR "rodizio_provas" IN (0, 1)), "perfil_cnh_brasil" INTEGER NOT NULL DEFAULT 0 CHECK ("perfil_cnh_brasil" IS NULL OR "perfil_cnh_brasil" IN (0, 1)), "endereco_patio_moto" TEXT, "endereco_patio_carro" TEXT, "endereco_patio_mudanca" TEXT, "banca_principal" TEXT CHECK ("banca_principal" IS NULL OR json_valid("banca_principal")), "banca_provisoria" TEXT CHECK ("banca_provisoria" IS NULL OR json_valid("banca_provisoria")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "locais_exame" ("id" TEXT PRIMARY KEY NOT NULL, "cidade_id" TEXT NOT NULL, "endereco" TEXT, "url_maps" TEXT, "regioes_atendidas" TEXT DEFAULT '[]' CHECK ("regioes_atendidas" IS NULL OR json_valid("regioes_atendidas")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "solicitacoes" ("id" TEXT PRIMARY KEY NOT NULL, "nome_candidato" TEXT, "nome_social" TEXT, "cpf" TEXT, "telefone" TEXT, "email" TEXT, "endereco" TEXT, "cidade" TEXT, "tipo_solicitacao" TEXT DEFAULT 'EXTRA', "tipo_exame" TEXT NOT NULL, "categoria_pretendida" TEXT DEFAULT 'B', "origem" TEXT NOT NULL, "autoescola_id" TEXT, "taxa_paga_bool" INTEGER DEFAULT 0 CHECK ("taxa_paga_bool" IS NULL OR "taxa_paga_bool" IN (0, 1)), "curso_pratico_concluido" INTEGER DEFAULT 0 CHECK ("curso_pratico_concluido" IS NULL OR "curso_pratico_concluido" IN (0, 1)), "horas_praticas" INTEGER DEFAULT 0, "tem_veiculo" INTEGER DEFAULT 0 CHECK ("tem_veiculo" IS NULL OR "tem_veiculo" IN (0, 1)), "restricao_cnh" TEXT, "instrutor" TEXT, "placa_veiculo" TEXT, "sem_duplo_comando" INTEGER DEFAULT 0 CHECK ("sem_duplo_comando" IS NULL OR "sem_duplo_comando" IN (0, 1)), "checklist_veiculo" INTEGER DEFAULT 0 CHECK ("checklist_veiculo" IS NULL OR "checklist_veiculo" IN (0, 1)), "curso_pratico_inserido" INTEGER DEFAULT 0 CHECK ("curso_pratico_inserido" IS NULL OR "curso_pratico_inserido" IN (0, 1)), "taxa_paga" INTEGER DEFAULT 0 CHECK ("taxa_paga" IS NULL OR "taxa_paga" IN (0, 1)), "tipo_deficiencia" TEXT, "necessidades_especiais" TEXT, "status" TEXT NOT NULL, "resultado" TEXT, "banca_id" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "categoria_agendada" TEXT, "examinador_id" TEXT, "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "quantidades_categoria" TEXT CHECK ("quantidades_categoria" IS NULL OR json_valid("quantidades_categoria")), "historico_exames" TEXT DEFAULT '[]' CHECK ("historico_exames" IS NULL OR json_valid("historico_exames")), "modulo" TEXT, "cor_linha" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "fila_atualizado_em" TEXT, "agendado_por" TEXT, "cpf_hash" TEXT);

CREATE TABLE IF NOT EXISTS "vagas_banca" ("id" TEXT PRIMARY KEY NOT NULL, "autoescola_id" TEXT NOT NULL, "tipo_exame" TEXT NOT NULL, "tipo_solicitacao" TEXT NOT NULL, "categoria_pretendida" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "examinador_id" TEXT, "banca_id" TEXT, "categoria_agendada" TEXT, "status" TEXT NOT NULL DEFAULT 'SCHEDULED', "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "bancas" ("id" TEXT PRIMARY KEY NOT NULL, "codigo" TEXT UNIQUE, "data" TEXT NOT NULL, "hora" TEXT NOT NULL, "examinadores_ids" TEXT DEFAULT '[]' CHECK ("examinadores_ids" IS NULL OR json_valid("examinadores_ids")), "max_vagas_a" INTEGER DEFAULT 10, "max_vagas_b" INTEGER DEFAULT 10, "tipo" TEXT NOT NULL, "status" TEXT NOT NULL, "motivo_cancelamento" TEXT, "local_id" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "location_id" TEXT);

CREATE TABLE IF NOT EXISTS "examinadores" ("id" TEXT PRIMARY KEY NOT NULL, "nome" TEXT NOT NULL, "matricula" TEXT NOT NULL, "pode_examinar_comum" INTEGER DEFAULT 1 CHECK ("pode_examinar_comum" IS NULL OR "pode_examinar_comum" IN (0, 1)), "pode_examinar_pcd" INTEGER DEFAULT 0 CHECK ("pode_examinar_pcd" IS NULL OR "pode_examinar_pcd" IN (0, 1)), "categorias" TEXT DEFAULT '[]' CHECK ("categorias" IS NULL OR json_valid("categorias")), "max_vagas_a_padrao" INTEGER, "max_vagas_b_padrao" INTEGER, "max_vagas_mudanca_padrao" INTEGER, "rodizio_provas" INTEGER NOT NULL DEFAULT 0 CHECK ("rodizio_provas" IS NULL OR "rodizio_provas" IN (0, 1)), "disponibilidade_rodizio" TEXT CHECK ("disponibilidade_rodizio" IS NULL OR json_valid("disponibilidade_rodizio")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "categories" TEXT CHECK ("categories" IS NULL OR json_valid("categories")), "default_max_slots_a" INTEGER, "default_max_slots_b" INTEGER, "default_max_slots_mudanca" INTEGER);

CREATE TABLE IF NOT EXISTS "instrutores" ("id" TEXT PRIMARY KEY NOT NULL, "nome" TEXT NOT NULL, "cpf" TEXT NOT NULL, "telefone" TEXT, "categoria" TEXT, "placa" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "cpf_hash" TEXT);

CREATE TABLE IF NOT EXISTS "codigos_otp" ("id" TEXT PRIMARY KEY NOT NULL, "usuario_id" TEXT NOT NULL, "codigo" TEXT NOT NULL, "expira_em" TEXT NOT NULL, "usado" INTEGER DEFAULT 0 CHECK ("usado" IS NULL OR "usado" IN (0, 1)), "tentativas_falhas" INTEGER DEFAULT 0, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "solicitacoes_pcd" ("id" TEXT PRIMARY KEY NOT NULL, "nome_candidato" TEXT, "nome_social" TEXT, "cpf" TEXT, "telefone" TEXT, "email" TEXT, "endereco" TEXT, "cidade" TEXT, "tipo_solicitacao" TEXT DEFAULT 'EXTRA', "tipo_exame" TEXT NOT NULL, "categoria_pretendida" TEXT DEFAULT 'B', "origem" TEXT NOT NULL, "autoescola_id" TEXT, "taxa_paga_bool" INTEGER DEFAULT 0 CHECK ("taxa_paga_bool" IS NULL OR "taxa_paga_bool" IN (0, 1)), "curso_pratico_concluido" INTEGER DEFAULT 0 CHECK ("curso_pratico_concluido" IS NULL OR "curso_pratico_concluido" IN (0, 1)), "horas_praticas" INTEGER DEFAULT 0, "tem_veiculo" INTEGER DEFAULT 0 CHECK ("tem_veiculo" IS NULL OR "tem_veiculo" IN (0, 1)), "restricao_cnh" TEXT, "instrutor" TEXT, "placa_veiculo" TEXT, "checklist_veiculo" INTEGER DEFAULT 0 CHECK ("checklist_veiculo" IS NULL OR "checklist_veiculo" IN (0, 1)), "curso_pratico_inserido" INTEGER DEFAULT 0 CHECK ("curso_pratico_inserido" IS NULL OR "curso_pratico_inserido" IN (0, 1)), "taxa_paga" INTEGER DEFAULT 0 CHECK ("taxa_paga" IS NULL OR "taxa_paga" IN (0, 1)), "tipo_deficiencia" TEXT, "necessidades_especiais" TEXT, "status" TEXT NOT NULL, "resultado" TEXT, "banca_id" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "categoria_agendada" TEXT, "examinador_id" TEXT, "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "historico_exames" TEXT DEFAULT '[]' CHECK ("historico_exames" IS NULL OR json_valid("historico_exames")), "modulo" TEXT, "cor_linha" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "fila_atualizado_em" TEXT, "agendado_por" TEXT, "cpf_hash" TEXT);

CREATE TABLE IF NOT EXISTS "vagas_pcd" ("id" TEXT PRIMARY KEY NOT NULL, "autoescola_id" TEXT NOT NULL, "tipo_exame" TEXT NOT NULL, "tipo_solicitacao" TEXT NOT NULL, "categoria_pretendida" TEXT, "data_agendada" TEXT, "hora_agendada" TEXT, "examinador_id" TEXT, "banca_id" TEXT, "categoria_agendada" TEXT, "status" TEXT NOT NULL DEFAULT 'SCHEDULED', "presenca_confirmada" INTEGER DEFAULT 0 CHECK ("presenca_confirmada" IS NULL OR "presenca_confirmada" IN (0, 1)), "motivo_cancelamento" TEXT, "observacao" TEXT, "quantidades_categoria" TEXT CHECK ("quantidades_categoria" IS NULL OR json_valid("quantidades_categoria")), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "atualizado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "configuracoes" ("id" INTEGER PRIMARY KEY NOT NULL DEFAULT 1, "nome_orgao" TEXT DEFAULT 'DETRAN', "endereco_orgao" TEXT, "url_logo" TEXT, "modo_manutencao" INTEGER DEFAULT 0 CHECK ("modo_manutencao" IS NULL OR "modo_manutencao" IN (0, 1)), "min_dias_agendamento" INTEGER DEFAULT 2, "max_vagas_diarias" INTEGER DEFAULT 50, "max_vagas_a_padrao" INTEGER DEFAULT 10, "max_vagas_b_padrao" INTEGER DEFAULT 10, "max_vagas_mudanca_padrao" INTEGER DEFAULT 10, "template_whatsapp" TEXT, "template_whatsapp_cfc" TEXT, "endereco_exame_padrao" TEXT, "link_exame_padrao" TEXT, "restricoes" TEXT DEFAULT '[]' CHECK ("restricoes" IS NULL OR json_valid("restricoes")), "nome_exame_pcd" TEXT, "endereco_exame_pcd_padrao" TEXT, "link_exame_pcd_padrao" TEXT, "banca_principal_pcd" TEXT CHECK ("banca_principal_pcd" IS NULL OR json_valid("banca_principal_pcd")), "banca_principal_cnh_brasil" TEXT CHECK ("banca_principal_cnh_brasil" IS NULL OR json_valid("banca_principal_cnh_brasil")), "bloquear_fins_semana" INTEGER DEFAULT 0 CHECK ("bloquear_fins_semana" IS NULL OR "bloquear_fins_semana" IN (0, 1)), "chave_area_risco" TEXT, "ano_fabricacao_maximo" TEXT CHECK ("ano_fabricacao_maximo" IS NULL OR json_valid("ano_fabricacao_maximo")), "zapi_instance_id" TEXT, "zapi_token" TEXT, "zapi_client_token" TEXT);

CREATE TABLE IF NOT EXISTS "usuarios" ("id" TEXT PRIMARY KEY NOT NULL, "nome" TEXT NOT NULL, "login" TEXT NOT NULL UNIQUE, "senha" TEXT, "perfil" TEXT NOT NULL, "autoescola_id" TEXT, "examinador_id" TEXT, "instrutor_id" TEXT, "forcar_troca_senha" INTEGER DEFAULT 1 CHECK ("forcar_troca_senha" IS NULL OR "forcar_troca_senha" IN (0, 1)), "modulos_permitidos" TEXT DEFAULT '[]' CHECK ("modulos_permitidos" IS NULL OR json_valid("modulos_permitidos")), "locais_permitidos_ids" TEXT DEFAULT '[]' CHECK ("locais_permitidos_ids" IS NULL OR json_valid("locais_permitidos_ids")), "email" TEXT, "telefone" TEXT, "dois_fatores_ativo" INTEGER DEFAULT 0 CHECK ("dois_fatores_ativo" IS NULL OR "dois_fatores_ativo" IN (0, 1)), "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "veiculos" ("id" TEXT PRIMARY KEY NOT NULL, "instrutor_id" TEXT NOT NULL, "tipo" TEXT NOT NULL, "marca" TEXT NOT NULL, "modelo" TEXT NOT NULL, "placa" TEXT NOT NULL, "ativo" INTEGER DEFAULT 1 CHECK ("ativo" IS NULL OR "ativo" IN (0, 1)), "transmissao" TEXT, "acessorios" TEXT DEFAULT '[]' CHECK ("acessorios" IS NULL OR json_valid("acessorios")), "duplo_comando" INTEGER DEFAULT 0 CHECK ("duplo_comando" IS NULL OR "duplo_comando" IN (0, 1)), "procuracao" INTEGER DEFAULT 0 CHECK ("procuracao" IS NULL OR "procuracao" IN (0, 1)), "ano_fabricacao" TEXT, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "ano_modelo" TEXT);

CREATE TABLE IF NOT EXISTS "sessoes" ("id" TEXT PRIMARY KEY NOT NULL, "usuario_id" TEXT NOT NULL, "expira_em" TEXT NOT NULL, "criado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "backups" ("id" TEXT PRIMARY KEY NOT NULL, "tipo_gatilho" TEXT NOT NULL DEFAULT 'manual', "dados" TEXT CHECK ("dados" IS NULL OR json_valid("dados")), "tamanho_bytes" INTEGER DEFAULT 0, "criado_em" TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), "tamanho_armazenado_bytes" INTEGER, "checksum_sha256" TEXT);

CREATE TABLE IF NOT EXISTS "sessions" ("id" TEXT PRIMARY KEY NOT NULL, "user_id" TEXT NOT NULL, "expires_at" TEXT NOT NULL, "created_at" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS "migracoes_schema" ("versao" TEXT PRIMARY KEY NOT NULL, "aplicado_em" TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));

CREATE TABLE IF NOT EXISTS migracoes_d1 (versao TEXT PRIMARY KEY, checksum TEXT NOT NULL, aplicado_em TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS backups_partes (backup_id TEXT NOT NULL REFERENCES backups(id) ON DELETE CASCADE, parte INTEGER NOT NULL, dados TEXT NOT NULL, PRIMARY KEY (backup_id, parte));

CREATE UNIQUE INDEX IF NOT EXISTS backups_auto_daily ON backups (date(criado_em)) WHERE tipo_gatilho = 'auto';

CREATE INDEX IF NOT EXISTS sessoes_usuario_expira ON sessoes (usuario_id, expira_em);

CREATE INDEX IF NOT EXISTS otp_usuario_expira ON codigos_otp (usuario_id, expira_em);

CREATE INDEX IF NOT EXISTS solicitacoes_cnhbrasil_banca_status ON solicitacoes_cnhbrasil (banca_id, status);

CREATE INDEX IF NOT EXISTS solicitacoes_cfc_banca_status ON solicitacoes_cfc (banca_id, status);

CREATE INDEX IF NOT EXISTS solicitacoes_pcd_banca_status ON solicitacoes_pcd (banca_id, status);

CREATE INDEX IF NOT EXISTS vagas_cfc_examinador_data ON vagas_cfc (examinador_id, data_agendada, hora_agendada);

CREATE INDEX IF NOT EXISTS vagas_cfc_autoescola_data ON vagas_cfc (autoescola_id, data_agendada);

CREATE INDEX IF NOT EXISTS vagas_pcd_examinador_data ON vagas_pcd (examinador_id, data_agendada);

CREATE TRIGGER IF NOT EXISTS vagas_cfc_guard_insert
      BEFORE INSERT ON vagas_cfc
       WHEN true
         AND NEW.status != 'CANCELLED' AND NEW.examinador_id IS NOT NULL
        AND NEW.data_agendada IS NOT NULL AND NEW.hora_agendada IS NOT NULL
      BEGIN
        SELECT CASE WHEN EXISTS (
          SELECT 1 FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND hora_agendada = NEW.hora_agendada
          AND status != 'CANCELLED' AND id != NEW.id
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CONFLICT') END;
        SELECT CASE WHEN (
          SELECT count(*) FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND status != 'CANCELLED' AND id != NEW.id
        ) >= (
          SELECT json_extract(disponibilidade_rodizio, '$.examsPerDay')
          FROM examinadores WHERE id = NEW.examinador_id AND rodizio_provas = 1
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CAPACITY') END;
      END;

CREATE TRIGGER IF NOT EXISTS vagas_cfc_guard_update
      BEFORE UPDATE ON vagas_cfc
       WHEN (NEW.examinador_id IS NOT OLD.examinador_id
         OR NEW.data_agendada IS NOT OLD.data_agendada OR NEW.hora_agendada IS NOT OLD.hora_agendada
         OR (OLD.status = 'CANCELLED' AND NEW.status != 'CANCELLED'))
         AND NEW.status != 'CANCELLED' AND NEW.examinador_id IS NOT NULL
        AND NEW.data_agendada IS NOT NULL AND NEW.hora_agendada IS NOT NULL
      BEGIN
        SELECT CASE WHEN EXISTS (
          SELECT 1 FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND hora_agendada = NEW.hora_agendada
          AND status != 'CANCELLED' AND id != NEW.id
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CONFLICT') END;
        SELECT CASE WHEN (
          SELECT count(*) FROM vagas_cfc WHERE examinador_id = NEW.examinador_id
          AND data_agendada = NEW.data_agendada AND status != 'CANCELLED' AND id != NEW.id
        ) >= (
          SELECT json_extract(disponibilidade_rodizio, '$.examsPerDay')
          FROM examinadores WHERE id = NEW.examinador_id AND rodizio_provas = 1
        ) THEN RAISE(ABORT, 'D1_EXAMINER_CAPACITY') END;
      END;

INSERT INTO migracoes_d1 (versao, checksum, aplicado_em) VALUES ('d1_schema_v1', 'cccc65180e383fdeabad6b239c1a2cc9f51d116b42953cd287e8224372ad3d11', strftime('%Y-%m-%dT%H:%M:%fZ', 'now')) ON CONFLICT (versao) DO NOTHING;
